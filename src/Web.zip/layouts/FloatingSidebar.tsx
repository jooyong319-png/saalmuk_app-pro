import { useState, useEffect } from "react";
import ChatPopup from "./ChatPopup";

// ─── 타입 정의 ───
type ActionType = "link" | "popup" | "message";

interface MenuItem {
  id: string;
  icon: React.ReactNode;
  label: string;
  actionType: ActionType;
  href?: string;
  hasNotification?: boolean;
}

// 채팅 대상 정보 타입
interface ChatTarget {
  userId: string;
  userName: string;
  avatar: string;
  avatarBg: string;
}

// ─── 플로팅 사이드바 컴포넌트 ───
export default function FloatingSidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activePopup, setActivePopup] = useState<string | null>(null);
  const [activeMessage, setActiveMessage] = useState<string | null>(null);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackRating, setFeedbackRating] = useState<number | null>(null);
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [chatTarget, setChatTarget] = useState<ChatTarget | null>(null);

  // openChat 이벤트 리스너 - 프로필 페이지에서 채팅 버튼 클릭 시 호출
  useEffect(() => {
    const handleOpenChat = (event: CustomEvent<ChatTarget>) => {
      // 사이드바가 접혀있으면 펼치기
      setIsCollapsed(false);
      // 채팅 팝업 열기
      setActivePopup("chat");
      setActiveMessage(null);
      // 채팅 대상 정보 저장
      setChatTarget(event.detail);
    };

    window.addEventListener("openChat", handleOpenChat as EventListener);

    return () => {
      window.removeEventListener("openChat", handleOpenChat as EventListener);
    };
  }, []);

  // 메뉴 아이템 정의
  const menuItems: MenuItem[] = [
    {
      id: "interest",
      icon: (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
          />
        </svg>
      ),
      label: "관심",
      actionType: "popup",
    },
    {
      id: "recent",
      icon: (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      ),
      label: "최근 본",
      actionType: "popup",
    },
    {
      id: "chat",
      icon: (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
          />
        </svg>
      ),
      label: "채팅",
      actionType: "popup",
      hasNotification: true,
    },
    {
      id: "lifetech",
      icon: (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
          />
        </svg>
      ),
      label: "생활테크",
      actionType: "link",
      href: "#/lifetech",
      hasNotification: true,
    },
  ];

  // 하단 메뉴 (공란 아래)
  const bottomMenuItems: MenuItem[] = [
    {
      id: "feedback",
      icon: (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"
          />
        </svg>
      ),
      label: "의견",
      actionType: "message",
    },
    {
      id: "settings",
      icon: (
        <svg
          className="w-5 h-5 text-gray-400"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
          />
        </svg>
      ),
      label: "",
      actionType: "link",
      href: "/settings",
    },
  ];

  // 버튼 클릭 핸들러
  const handleClick = (item: MenuItem) => {
    switch (item.actionType) {
      case "link":
        if (item.href) {
          window.location.href = item.href;
        }
        break;
      case "popup":
        setActivePopup(activePopup === item.id ? null : item.id);
        setActiveMessage(null);
        break;
      case "message":
        setActiveMessage(activeMessage === item.id ? null : item.id);
        setActivePopup(null);
        setFeedbackSent(false);
        break;
    }
  };

  // 팝업 외부 클릭 시 닫기
  const closePopups = () => {
    setActivePopup(null);
    setActiveMessage(null);
  };

  // 피드백 전송
  const handleSendFeedback = () => {
    if (feedbackText.trim()) {
      console.log("Feedback sent:", {
        rating: feedbackRating,
        text: feedbackText,
      });
      setFeedbackSent(true);
      setFeedbackText("");
      setFeedbackRating(null);
      setTimeout(() => {
        setActiveMessage(null);
        setFeedbackSent(false);
      }, 2000);
    }
  };

  return (
    <>
      {/* 배경 오버레이 (팝업 열렸을 때) */}
      {(activePopup || activeMessage) && (
        <div className="fixed inset-0 z-[400]" onClick={closePopups} />
      )}

      {/* 플로팅 사이드바 */}
      <div
        className={`fixed right-0 top-1/2 -translate-y-1/2 z-[500] transition-transform duration-300 ${
          isCollapsed ? "translate-x-[calc(100%-24px)]" : "translate-x-0"
        }`}
      >
        <div className="flex">
          {/* 접기/펼치기 버튼 (세로 중앙) */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="w-6 h-12 bg-white border border-r-0 border-gray-200 rounded-l-lg flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-50 transition-colors self-center shadow-sm"
          >
            <span
              className={`text-sm transition-transform duration-300 ${isCollapsed ? "rotate-180" : ""}`}
            >
              «
            </span>
          </button>

          {/* 메뉴 컨테이너 */}
          <div className="bg-white border border-gray-200 rounded-l-2xl shadow-lg py-2 px-2 relative">
            {/* 팝업들 - 사이드바 맨 위 기준 */}
            {activePopup === "chat" && (
              <ChatPopup onClose={closePopups} initialTarget={chatTarget} />
            )}

            {activePopup === "interest" && (
              <div className="absolute right-full top-0 mr-3 w-80 bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden animate-slideInLeft">
                <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-red-50 to-white">
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">
                      관심 목록
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      관심 등록한 게시판
                    </p>
                  </div>
                  <button
                    onClick={closePopups}
                    className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
                <div className="p-3 max-h-[350px] overflow-y-auto space-y-1">
                  {/* 던전앤파이터 (id: 205) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=205";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xl shadow-sm">
                      🎲
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        던전앤파이터
                      </p>
                      <p className="text-xs text-gray-400">PC · 액션 RPG</p>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-red-50 text-red-400 flex items-center justify-center">
                      <svg
                        className="w-5 h-5"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                  </div>

                  {/* 메이플스토리 (id: 202) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=202";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-400 to-orange-500 flex items-center justify-center text-white text-xl shadow-sm">
                      🍁
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        메이플스토리
                      </p>
                      <p className="text-xs text-gray-400">PC · MMORPG</p>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-red-50 text-red-400 flex items-center justify-center">
                      <svg
                        className="w-5 h-5"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                  </div>

                  {/* 로스트아크 (id: 203) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=203";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white text-xl shadow-sm">
                      🏰
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        로스트아크
                      </p>
                      <p className="text-xs text-gray-400">PC · 액션 RPG</p>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-red-50 text-red-400 flex items-center justify-center">
                      <svg
                        className="w-5 h-5"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                  </div>

                  {/* 마비노기 (id: 204) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=204";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center text-white text-xl shadow-sm">
                      🎵
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        마비노기
                      </p>
                      <p className="text-xs text-gray-400">PC · MMORPG</p>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-red-50 text-red-400 flex items-center justify-center">
                      <svg
                        className="w-5 h-5"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="px-4 py-3 border-t border-gray-100 bg-gray-50">
                  <button
                    className="w-full text-center text-sm text-[#72C2FF] font-medium hover:underline"
                    onClick={() => {
                      window.location.href = "#/gallery";
                      closePopups();
                    }}
                  >
                    전체 게시판 보기 →
                  </button>
                </div>
              </div>
            )}

            {activePopup === "recent" && (
              <div className="absolute right-full top-0 mr-3 w-80 bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden animate-slideInLeft">
                <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-blue-50 to-white">
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">최근 본</h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      최근 방문한 게시판
                    </p>
                  </div>
                  <button
                    onClick={closePopups}
                    className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
                <div className="p-3 max-h-[350px] overflow-y-auto space-y-1">
                  {/* 메이플스토리 (id: 202) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=202";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-400 to-orange-500 flex items-center justify-center text-white text-xl shadow-sm">
                      🍁
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        메이플스토리
                      </p>
                      <p className="text-xs text-gray-400">PC · MMORPG</p>
                    </div>
                    <svg
                      className="w-4 h-4 text-gray-300"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>

                  {/* 로스트아크 (id: 203) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=203";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white text-xl shadow-sm">
                      🏰
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        로스트아크
                      </p>
                      <p className="text-xs text-gray-400">PC · 액션 RPG</p>
                    </div>
                    <svg
                      className="w-4 h-4 text-gray-300"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>

                  {/* 리니지M (id: 104) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=104";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-500 to-gray-700 flex items-center justify-center text-white text-xl shadow-sm">
                      ⚔️
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        리니지M
                      </p>
                      <p className="text-xs text-gray-400">모바일 · MMORPG</p>
                    </div>
                    <svg
                      className="w-4 h-4 text-gray-300"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>

                  {/* 아이온2 (id: 101) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=101";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xl shadow-sm">
                      ⚔️
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        아이온2
                      </p>
                      <p className="text-xs text-gray-400">모바일 · MMORPG</p>
                    </div>
                    <svg
                      className="w-4 h-4 text-gray-300"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>

                  {/* 오딘 (id: 103) */}
                  <div
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      window.location.href = "#/gallery?id=103";
                      closePopups();
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center text-white text-xl shadow-sm">
                      🛡️
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        오딘: 발할라 라이징
                      </p>
                      <p className="text-xs text-gray-400">모바일 · MMORPG</p>
                    </div>
                    <svg
                      className="w-4 h-4 text-gray-300"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>
                </div>
                <div className="px-4 py-3 border-t border-gray-100 bg-gray-50">
                  <button
                    className="w-full text-center text-sm text-[#72C2FF] font-medium hover:underline"
                    onClick={() => {
                      window.location.href = "#/gallery";
                      closePopups();
                    }}
                  >
                    전체 게시판 보기 →
                  </button>
                </div>
              </div>
            )}

            {activeMessage === "feedback" && (
              <div className="absolute right-full top-0 mr-3 w-[360px] bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden animate-slideInLeft">
                {/* 헤더 */}
                <div className="px-5 py-4 flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-gray-900 text-[18px]">
                      의견 보내기
                    </h3>
                    <p className="text-[13px] text-gray-400 mt-0.5">
                      <span className="text-[#72C2FF] font-medium">
                        쌀먹닷컴
                      </span>{" "}
                      개선에 참여해주세요
                    </p>
                  </div>
                  <button
                    onClick={closePopups}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>

                <div className="px-5 pb-5">
                  {feedbackSent ? (
                    <div className="py-10 text-center">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                        <svg
                          className="w-8 h-8 text-green-500"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      </div>
                      <p className="text-lg font-bold text-gray-900">
                        의견이 전송되었어요!
                      </p>
                      <p className="text-sm text-gray-400 mt-2">
                        소중한 의견 감사합니다 🙏
                      </p>
                    </div>
                  ) : (
                    <>
                      {/* 만족도 선택 */}
                      <div className="mb-4">
                        <div className="flex justify-center gap-2 mb-2">
                          {[1, 2, 3, 4, 5].map((num) => (
                            <button
                              key={num}
                              onClick={() => setFeedbackRating(num)}
                              className={`w-12 h-12 rounded-xl text-[16px] font-semibold transition-all ${
                                feedbackRating === num
                                  ? "bg-[#72C2FF] text-white"
                                  : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                              }`}
                            >
                              {num}
                            </button>
                          ))}
                        </div>
                        <div className="flex justify-between px-1">
                          <span className="text-[12px] text-gray-400">
                            매우 불만족
                          </span>
                          <span className="text-[12px] text-gray-400">
                            매우 만족
                          </span>
                        </div>
                      </div>

                      {/* 의견 입력 */}
                      <textarea
                        placeholder="쌀먹닷컴에 바라는 점이나 개선 의견을 남겨주세요!"
                        value={feedbackText}
                        onChange={(e) => {
                          if (e.target.value.length <= 500) {
                            setFeedbackText(e.target.value);
                          }
                        }}
                        className="w-full h-32 p-4 border border-gray-200 rounded-xl text-[14px] resize-none focus:outline-none focus:border-[#72C2FF] transition-all placeholder:text-gray-400"
                      />

                      {/* 하단 */}
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-[13px] text-gray-400">
                          {feedbackText.length}/500
                        </span>
                        <button
                          onClick={handleSendFeedback}
                          disabled={!feedbackText.trim()}
                          className={`px-5 py-2 text-[14px] font-semibold rounded-lg transition-all ${
                            feedbackText.trim()
                              ? "bg-gray-900 text-white hover:bg-gray-800"
                              : "bg-gray-100 text-gray-400 cursor-not-allowed"
                          }`}
                        >
                          보내기
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* 메뉴 버튼들 */}
            <div className="flex flex-col items-center gap-1">
              {/* 상단 메뉴: 관심, 최근 본, 채팅, 생활테크 */}
              {menuItems.map((item) => (
                <div key={item.id}>
                  <button
                    onClick={() => handleClick(item)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-colors min-w-[56px] relative ${
                      activePopup === item.id || activeMessage === item.id
                        ? "bg-[#E8F4FD] text-[#72C2FF]"
                        : "text-gray-500 hover:bg-gray-100 hover:text-gray-700"
                    }`}
                  >
                    {/* 알림 표시 (채팅, 생활테크만) */}
                    {item.hasNotification && (
                      <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
                    )}
                    {item.icon}
                    <span className="text-[11px] font-medium whitespace-nowrap">
                      {item.label}
                    </span>
                  </button>
                </div>
              ))}

              {/* 공란 */}
              <div className="h-6" />

              {/* 하단 메뉴: 의견, 설정 */}
              {bottomMenuItems.map((item) => (
                <div key={item.id}>
                  <button
                    onClick={() => handleClick(item)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-colors min-w-[56px] relative ${
                      activePopup === item.id || activeMessage === item.id
                        ? "bg-[#E8F4FD] text-[#72C2FF]"
                        : "text-gray-500 hover:bg-gray-100 hover:text-gray-700"
                    }`}
                  >
                    {item.icon}
                    <span className="text-[11px] font-medium whitespace-nowrap">
                      {item.label}
                    </span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 애니메이션 스타일 */}
      <style>{`
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(10px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-slideInLeft {
          animation: slideInLeft 0.2s ease-out both;
        }
      `}</style>
    </>
  );
}
