import { useEffect, useState } from "react";
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import FloatingSidebar from "./FloatingSidebar";

// ─── 공통 CSS (폰트 + 애니메이션) ───
const globalStyles = `
  /* ═══ 애니메이션 Keyframes ═══ */
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(16px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  @keyframes slideInRight {
    from { opacity: 0; transform: translateX(20px); }
    to { opacity: 1; transform: translateX(0); }
  }

  @keyframes slideInLeft {
    from { opacity: 0; transform: translateX(-20px); }
    to { opacity: 1; transform: translateX(0); }
  }

  @keyframes scaleIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }

  @keyframes twinkle {
    0%, 100% { opacity: 0.3; transform: scale(0.9); }
    50% { opacity: 0.7; transform: scale(1.1); }
  }

  /* ═══ 애니메이션 클래스 ═══ */
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
  .animate-fadeIn { animation: fadeIn 0.4s ease-out both; }
  .animate-slideInRight { animation: slideInRight 0.5s ease-out both; }
  .animate-slideInLeft { animation: slideInLeft 0.5s ease-out both; }
  .animate-scaleIn { animation: scaleIn 0.3s ease-out both; }
  .animate-twinkle { animation: twinkle 2s ease-in-out infinite; }

  /* ═══ 딜레이 클래스 ═══ */
  .delay-1 { animation-delay: 0.1s; }
  .delay-2 { animation-delay: 0.2s; }
  .delay-3 { animation-delay: 0.3s; }
  .delay-4 { animation-delay: 0.4s; }
  .delay-5 { animation-delay: 0.5s; }
  .delay-6 { animation-delay: 0.6s; }
  .delay-7 { animation-delay: 0.7s; }
  .delay-8 { animation-delay: 0.8s; }

  /* ═══ CSS 변수 ═══ */
  :root {
    --primary: #72C2FF;
    --primary-dark: #4AABF5;
    --primary-light: #E8F4FD;
    --accent-pink: #FF6B9D;
    --accent-orange: #FF8C42;
    --accent-yellow: #FFD93D;
    --bg: #F5F6F8;
    --white: #FFFFFF;
    --text-primary: #1A1A2E;
    --text-secondary: #6B7280;
    --text-muted: #9CA3AF;
    --border: #E5E7EB;
    --card-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
    --card-shadow-hover: 0 4px 12px rgba(0,0,0,0.1);
    --radius: 12px;
    --radius-sm: 8px;
    --radius-lg: 16px;
  }
`;

// ─── 공통 상단바 ───
function TopNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const menuItems = [
    { name: "추천", path: "/" },
    { name: "게임순위", path: "/ranking" },
    { name: "생활테크", path: "/lifetech" },
    { name: "갤러리", path: "/gallery" },
    { name: "공지", path: "#" },
  ];

  return (
    <header className="sticky top-0 z-[300] bg-white border-b border-[#E5E7EB] shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
      <div className="max-w-[1280px] mx-auto flex items-center justify-between px-6 h-[60px]">
        {/* Left: Logo + Menu */}
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center">
            <img
              src="https://ssalmuk.com/images/mobile/Logo_ssalmuk.svg"
              alt="SSALMUK"
              className="h-[22px] w-auto object-contain"
            />
          </Link>
          <nav className="hidden md:flex gap-2">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`px-4 py-2 rounded-lg text-[15px] font-semibold transition-all ${
                  location.pathname === item.path
                    ? "bg-[#72C2FF] text-white rounded-[20px]"
                    : "text-[#6B7280] hover:text-[#4AABF5] hover:bg-[#E8F4FD]"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        </div>

        {/* Right: Search + Auth */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 bg-[#F5F6F8] border border-[#E5E7EB] rounded-full px-4 py-2 w-[240px] focus-within:border-[#72C2FF] transition-colors">
            <svg
              width="16"
              height="16"
              fill="none"
              stroke="#9CA3AF"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
            <input
              type="text"
              placeholder="검색어를 입력해주세요"
              className="border-none bg-transparent outline-none text-[13px] text-[#1A1A2E] placeholder-[#9CA3AF] w-full"
            />
          </div>

          {/* 로그인 상태에 따른 버튼 */}
          {isLoggedIn ? (
            <div className="relative">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full hover:bg-gray-100 transition-colors"
              >
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#72C2FF] to-[#4AABF5] flex items-center justify-center text-white font-bold text-sm shadow-sm">
                  쌀
                </div>
                <span className="text-[13px] font-semibold text-gray-700 hidden md:block">
                  쌀먹러
                </span>
                <svg
                  className={`w-4 h-4 text-gray-400 transition-transform ${showProfileMenu ? "rotate-180" : ""}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {/* 프로필 드롭다운 메뉴 */}
              {showProfileMenu && (
                <>
                  <div
                    className="fixed inset-0 z-[350]"
                    onClick={() => setShowProfileMenu(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-[400]">
                    {/* 프로필 헤더 */}
                    <div className="px-4 py-3 border-b border-gray-100">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#72C2FF] to-[#4AABF5] flex items-center justify-center text-white font-bold">
                          쌀
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900">
                            쌀먹러
                          </p>
                          <p className="text-xs text-gray-400">
                            Lv.12 · 포인트 3,500
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* 메뉴 아이템 */}
                    <div className="py-1">
                      <button
                        onClick={() => {
                          navigate("/mypage");
                          setShowProfileMenu(false);
                        }}
                        className="w-full px-4 py-2.5 text-left text-[13px] text-gray-700 hover:bg-gray-50 flex items-center gap-3"
                      >
                        <svg
                          className="w-4 h-4 text-gray-400"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={1.5}
                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                          />
                        </svg>
                        마이페이지
                      </button>
                      <button
                        onClick={() => {
                          setIsLoggedIn(false);
                          setShowProfileMenu(false);
                        }}
                        className="w-full px-4 py-2.5 text-left text-[13px] text-gray-700 hover:bg-gray-50 flex items-center gap-3"
                      >
                        <svg
                          className="w-4 h-4 text-gray-400"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={1.5}
                            d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                          />
                        </svg>
                        로그아웃
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <>
              <button
                onClick={() => setIsLoggedIn(true)}
                className="px-4 py-2 rounded-lg text-[13px] font-semibold text-[#6B7280] hover:text-[#4AABF5] transition-colors"
              >
                로그인
              </button>
              <button
                onClick={() => setIsLoggedIn(true)}
                className="px-4 py-2 rounded-lg text-[13px] font-semibold text-white bg-[#72C2FF] hover:bg-[#4AABF5] transition-colors"
              >
                회원가입
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

// ─── 공통 푸터 ───
function Footer() {
  const links = [
    { name: "회사소개", href: "#" },
    { name: "광고/제휴문의", href: "#" },
    { name: "광고상품", href: "#" },
    { name: "헬프센터", href: "#" },
    { name: "이용약관", href: "#" },
    { name: "1:1문의", href: "#" },
  ];

  return (
    <footer className="bg-white border-t border-[#E5E7EB] pt-10 pb-12 mt-auto">
      <div className="max-w-[1280px] mx-auto px-6 flex flex-col md:flex-row justify-between gap-8">
        <div className="flex flex-col gap-6">
          <img
            src="https://ssalmuk.com/images/logo_footer.svg"
            alt="SSALMUK Footer Logo"
            className="h-[26px] w-auto object-contain self-start"
          />

          {/* Mobile Menu */}
          <ul className="flex flex-wrap gap-x-4 gap-y-2 md:hidden">
            {links.map((link, i) => (
              <li key={i}>
                <a
                  href={link.href}
                  className="text-[13px] text-[#6B7280] hover:text-[#4AABF5] transition-colors"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>

          {/* Company Info */}
          <div className="flex flex-col gap-1.5 text-[13px] text-[#9CA3AF] leading-relaxed">
            <div className="font-bold text-[#1A1A2E] text-[14px] mb-1">
              주식회사 태강에스티
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
              <span>대표 : 우준용</span>
              <span className="hidden sm:block w-px h-3 bg-[#E5E7EB]" />
              <span>사업자등록번호 : 637-87-01568</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
              <span>통신판매업신고번호 : 2022-경기시흥-0999</span>
              <span className="hidden sm:block w-px h-3 bg-[#E5E7EB]" />
              <span>TEL : 0502-1924-4565</span>
            </div>
            <div>대표 E-mail : itemsee@ssalmuk.com</div>
            <div>주소 : 경기도 시흥시 군자천로 237번길 10</div>
          </div>

          <div className="text-[12px] text-[#9CA3AF]/60 font-medium mt-2">
            Copyright © TAEKANG ST Co., Ltd. All rights reserved.
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex flex-col gap-6">
          <ul className="flex items-center gap-6">
            {links.map((link, i) => (
              <li key={i}>
                <a
                  href={link.href}
                  className="text-[13px] font-semibold text-[#6B7280] hover:text-[#4AABF5] transition-colors"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}

// ─── 레이아웃 메인 ───
export default function Layout() {
  useEffect(() => {
    // ✅ 1. Pretendard 폰트 로드
    const existingFontLink = document.querySelector('link[href*="pretendard"]');
    if (!existingFontLink) {
      const fontLink = document.createElement("link");
      fontLink.href =
        "https://cdnjs.cloudflare.com/ajax/libs/pretendard/1.3.9/variable/pretendardvariable.min.css";
      fontLink.rel = "stylesheet";
      document.head.appendChild(fontLink);
    }

    // ✅ 2. 공통 CSS (애니메이션 + CSS 변수) 주입
    const existingStyle = document.querySelector("style[data-ssalmuk-global]");
    if (!existingStyle) {
      const style = document.createElement("style");
      style.setAttribute("data-ssalmuk-global", "true");
      style.textContent = globalStyles;
      document.head.appendChild(style);
    }

    // Cleanup 불필요 (전역 스타일은 유지)
  }, []);

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        fontFamily:
          "'Pretendard Variable', -apple-system, BlinkMacSystemFont, sans-serif",
        background: "#F5F6F8",
        WebkitFontSmoothing: "antialiased",
      }}
    >
      <TopNav />

      {/* Outlet: 각 페이지 내용이 들어감 */}
      <main className="flex-1 w-full">
        <Outlet />
      </main>

      <Footer />

      {/* 플로팅 사이드바 - 모든 페이지에 표시 */}
      <FloatingSidebar />
    </div>
  );
}
