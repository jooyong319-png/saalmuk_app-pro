// @ts-nocheck
import { useEffect } from "react";
import { HashRouter, Routes, Route, useLocation } from "react-router-dom";
import Layout from "./layouts/layout";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [pathname]);
  return null;
}
import WebHome from "./pages/WebHome";
import GameRankingPage from "./pages/GameRankingPage";
import GameDetailPage from "./pages/GameDetailPage";
import GameDetailPage_V1 from "./pages/GameDetailPage_V1";
import GameDetailPage_V2 from "./pages/GameDetailPage_V2";
import GalleryPage from "./pages/GalleryPage";
import ProfilePage from "./pages/ProfilePage";
import MyPage from "./pages/MyPage";
import LifeTechPage from "./pages/LifeTechPage_v2";
import CouponPage from "./pages/CouponPage";
// 웹 스타일 상세 페이지 (v5 - CommentSection 재사용)
import EventDetailPage from "./pages/lifetech/EventDetailPage";
import PointDetailPage from "./pages/lifetech/PointDetailPage";
import MarketDetailPage from "./pages/lifetech/MarketDetailPage";
import SurveyDetailPage from "./pages/lifetech/SurveyDetailPage";

function App() {
  return (
    <HashRouter>
      <ScrollToTop />
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<WebHome />} />
          <Route path="/ranking" element={<GameRankingPage />} />
          <Route path="/game/:id" element={<GameDetailPage />} />
          <Route path="/game-v1/:id" element={<GameDetailPage_V1 />} />
          <Route path="/game-v2/:id" element={<GameDetailPage_V2 />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/mypage" element={<MyPage />} />
          <Route path="/lifetech" element={<LifeTechPage />} />
          <Route path="/coupon" element={<CouponPage />} />
          {/* 생활테크 상세 페이지 - v5 (CommentSection 재사용) */}
          <Route path="/lifetech/event/:id" element={<EventDetailPage />} />
          <Route path="/lifetech/point/:id" element={<PointDetailPage />} />
          <Route path="/lifetech/market/:id" element={<MarketDetailPage />} />
          <Route path="/lifetech/survey/:id" element={<SurveyDetailPage />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}

export default App;
