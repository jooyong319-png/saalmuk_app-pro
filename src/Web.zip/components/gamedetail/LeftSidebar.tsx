export default function LeftSidebar() {
  const relatedGames = [
    { name: "더 샌드박스", img: "https://edge.ssalmuk.com/editorImage/9fee693175524869b862134b430e4835.jpg" },
    { name: "엑시 인피니티", img: "https://edge.ssalmuk.com/editorImage/bad0847c72eb4b948364ed741bcf0c53.jfif" },
    { name: "일루비움", img: "https://edge.ssalmuk.com/editorImage/6e67f2d8c46d489cacf0bd5686b0694f.jpg" },
    { name: "갓즈언체인드", img: "https://edge.ssalmuk.com/editorImage/2037da0b03554abea531a679860b4982.jpg" },
  ];

  return (
    <div className="flex flex-col gap-5">
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 animate-fadeUp delay-1">
        <h3 className="text-[14px] font-bold text-[#1A1A2E] mb-3 flex items-center gap-2">
          🎮 비슷한 게임
        </h3>
        <div className="flex flex-col gap-2">
          {relatedGames.map((game, i) => (
            <div key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
              <img src={game.img} alt={game.name} className="w-10 h-10 rounded-lg object-cover" />
              <span className="text-[13px] font-medium text-[#1A1A2E]">{game.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-xl overflow-hidden shadow-md cursor-pointer hover:-translate-y-0.5 transition-transform animate-fadeUp delay-2">
        <img src="https://i.pinimg.com/736x/e6/c7/77/e6c777962e2034c840f560b73a2f3a6b.jpg" alt="광고 배너" className="w-full h-auto object-cover" />
      </div>
    </div>
  );
}
