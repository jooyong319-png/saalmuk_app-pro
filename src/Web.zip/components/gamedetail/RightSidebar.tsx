export default function RightSidebar() {
  const hotPosts = [
    { title: "디센트럴랜드 초보자 가이드", views: 1234 },
    { title: "이번 주 업데이트 내용 정리", views: 892 },
    { title: "땅 구매 꿀팁 공유합니다", views: 756 },
    { title: "신규 이벤트 보상 후기", views: 543 },
  ];

  return (
    <div className="flex flex-col gap-5">
      <div className="rounded-xl overflow-hidden cursor-pointer hover:-translate-y-0.5 transition-transform shadow-sm animate-fadeUp delay-1">
        <img src="https://i.pinimg.com/736x/3f/4b/99/3f4b99818ca444236c549c2ef8cd87de.jpg" alt="이벤트 배너" className="w-full h-auto object-cover" />
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeUp delay-2">
        <div className="px-4 py-3 text-[13px] font-bold text-[#1A1A2E] border-b border-gray-100 flex items-center gap-1.5">
          🔥 디센트럴랜드 베스트 게시글
        </div>
        <div className="p-3 flex flex-col">
          {hotPosts.map((post, i) => (
            <div key={i} className="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0 cursor-pointer hover:bg-gray-50 transition-colors">
              <span className="text-[13px] text-[#1A1A2E] truncate flex-1">{post.title}</span>
              <span className="text-[11px] text-gray-400 ml-2">👁 {post.views}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
