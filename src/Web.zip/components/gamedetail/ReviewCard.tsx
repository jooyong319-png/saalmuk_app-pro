import { useState } from "react";

export interface ReviewData {
  id: number;
  name: string;
  level: number;
  date: string;
  rating: number;
  stars: string;
  image: string;
  content: string[];
  likes: number;
  comments: number;
  views: number;
}

interface Props {
  review: ReviewData;
  expanded: boolean;
  onToggleExpand: () => void;
  onShowGift: () => void;
}

export default function ReviewCard({ review, expanded, onToggleExpand, onShowGift }: Props) {
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  return (
    <div className="border border-gray-200 rounded-2xl p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start gap-4">
        <img src={review.image} alt="프로필" className="w-12 h-12 rounded-full object-cover" />
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#1A1A2E]">{review.name}</span>
              <span className="bg-[#72C2FF] text-white text-[10px] px-1.5 py-0.5 rounded">Lv.{review.level}</span>
            </div>
            <span className="text-xs text-gray-400">{review.date}</span>
          </div>
          <div className="flex items-center gap-1 mt-1">
            <span className="text-yellow-400 text-sm">{review.stars}</span>
            <span className="font-bold text-sm">{review.rating}</span>
            <span className="text-gray-400 text-xs">점</span>
          </div>
        </div>
      </div>

      <div className="mt-4 text-sm text-gray-700">
        {(expanded ? review.content : review.content.slice(0, 2)).map((line, idx) => (
          <p key={idx} className={idx > 0 ? "mt-1" : ""}>{line}</p>
        ))}
        {review.content.length > 2 && (
          <button className="text-[#4AABF5] text-xs mt-2 hover:underline" onClick={onToggleExpand}>
            {expanded ? "간략하게" : "더보기"}
          </button>
        )}
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
        <div className="flex items-center gap-5 text-gray-400">
          <button className="flex items-center gap-1.5 hover:text-[#FF6B9D] transition-colors">
            <span>❤️</span><span className="text-xs">{review.likes}</span>
          </button>
          <button className="flex items-center gap-1.5 hover:text-[#4AABF5] transition-colors">
            <span>💬</span><span className="text-xs">{review.comments}</span>
          </button>
          <button className="flex items-center gap-1.5 hover:text-[#4AABF5] transition-colors"><span>🔄</span></button>
          <button className="flex items-center gap-1.5 hover:text-[#4AABF5] transition-colors"><span>🔗</span></button>
        </div>
        <div className="flex items-center gap-3">
          <button className="text-gray-300 hover:text-[#FFD93D] transition-colors" onClick={onShowGift}>🎁</button>
          <div className="relative">
            <button className="text-gray-300 hover:text-gray-500 transition-colors" onClick={() => setShowMoreMenu(!showMoreMenu)}>⋮</button>
            {showMoreMenu && (
              <div className="absolute right-0 top-8 bg-white rounded-xl shadow-lg border border-gray-100 py-2 min-w-[120px] z-10">
                <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">저장</button>
                <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">차단</button>
                <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">신고</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
