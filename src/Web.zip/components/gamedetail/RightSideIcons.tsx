export default function RightSideIcons() {
  const icons = [
    { emoji: "🔔", label: "알림" },
    { emoji: "⏱️", label: "최근본" },
    { emoji: "💬", label: "문의" },
    { emoji: "📱", label: "QR" },
  ];

  return (
    <div className="fixed right-0 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-0.5 bg-white rounded-l-xl shadow-[-2px_0_8px_rgba(0,0,0,0.06)] py-2 hidden xl:flex animate-slideInRight delay-3">
      {icons.map((icon, i) => (
        <button
          key={i}
          className="w-12 h-12 flex flex-col items-center justify-center gap-0.5 text-[9px] text-[#9CA3AF] font-semibold hover:bg-[#E8F4FD] hover:text-[#4AABF5] transition-colors"
        >
          <span className="text-base">{icon.emoji}</span>
          {icon.label}
        </button>
      ))}
    </div>
  );
}
