function EventPromoBanner() {
  return (
    <div className="rounded-xl overflow-hidden cursor-pointer hover:-translate-y-0.5 transition-transform shadow-sm animate-fadeUp delay-1">
      <img src="https://i.pinimg.com/736x/3f/4b/99/3f4b99818ca444236c549c2ef8cd87de.jpg" alt="이벤트 배너" className="w-full h-auto object-cover" />
    </div>
  );
}

function RisingGameSection() {
  const risingGames = [
    { name: "아이온2", change: 24.7, img: "https://edge.ssalmuk.com/editorImage/2ee9f32dc12b4ba9b5cdb55289bdd4c4.jfif" },
    { name: "오딘: 발할라...", change: 14.4, img: "https://edge.ssalmuk.com/editorImage/174e967548d240289077708d0b3d57c5.jpg" },
    { name: "라스트 워", change: 8.2, img: "https://edge.ssalmuk.com/editorImage/7e33ccd92eeb404fa7957770c79bde56.jpg" },
  ];
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeUp delay-2">
      <div className="px-4 py-3 text-[13px] font-bold text-[#2E7D32] bg-[#E8F5E9] flex items-center gap-1.5">🚀 급상승 게임</div>
      <div className="p-3 flex flex-col gap-2">
        {risingGames.map((g, i) => (
          <div key={i} className="flex items-center justify-between p-2.5 bg-white border border-gray-100 rounded-lg hover:border-[#72C2FF] hover:shadow-sm transition-all cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded overflow-hidden bg-gray-100">
                {g.img ? <img src={g.img} alt={g.name} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gradient-to-br from-indigo-400 to-purple-500" />}
              </div>
              <span className="text-[13px] font-semibold text-[#1A1A2E]">{g.name}</span>
            </div>
            <span className="text-[12px] font-bold text-red-600">▲ {g.change}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function NewGameSection() {
  const newGames = [
    { name: "마비노기M", date: "2025.01 출시", img: "https://edge.ssalmuk.com/editorImage/fa8c45ace4f74c62922586fe9fc211a2.png" },
    { name: "RF 온라인 넥스트", date: "2025.01 출시", img: "https://edge.ssalmuk.com/editorImage/6f0ee3a64cd14ca293dd200cfdbdd918.jpg" },
    { name: "쿠키런:탑", date: "2025.01 출시" },
  ];
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeUp delay-3">
      <div className="px-4 py-3 text-[13px] font-bold text-[#7B1FA2] bg-[#F3E5F5] flex items-center gap-1.5">🆕 신규 게임</div>
      <div className="p-3 flex flex-col gap-2">
        {newGames.map((g, i) => (
          <div key={i} className="flex items-center justify-between p-2.5 bg-white border border-gray-100 rounded-lg hover:border-[#72C2FF] cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded overflow-hidden bg-gray-200">
                {g.img && <img src={g.img} alt={g.name} className="w-full h-full object-cover" />}
              </div>
              <div className="flex flex-col">
                <span className="text-[13px] font-semibold text-[#1A1A2E]">{g.name}</span>
                <span className="text-[10px] text-gray-400">{g.date}</span>
              </div>
            </div>
            <span className="bg-red-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">NEW</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function GenreTopSection() {
  const genres = [
    { label: "MMORPG 1위", game: "리니지M", img: "https://edge.ssalmuk.com/editorImage/c95724c5a3f2403995112aaadf1289a8.jpg" },
    { label: "전략 1위", game: "라스트 워", img: "https://edge.ssalmuk.com/editorImage/7e33ccd92eeb404fa7957770c79bde56.jpg" },
    { label: "어드벤쳐 1위", game: "로블록스", img: "https://edge.ssalmuk.com/editorImage/9fee693175524869b862134b430e4835.jpg" },
  ];
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeUp delay-4">
      <div className="px-4 py-3 text-[13px] font-bold text-[#1A1A2E] border-b border-gray-100 flex items-center gap-1.5">🎮 장르별 TOP</div>
      <div className="p-3 flex flex-col gap-2">
        {genres.map((g, i) => (
          <div key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
            <div className={`w-10 h-10 rounded-lg overflow-hidden ${!g.img ? "bg-gray-100" : ""}`}>
              {g.img && <img src={g.img} alt={g.game} className="w-full h-full object-cover" />}
            </div>
            <div className="flex flex-col">
              <span className="text-[12px] font-semibold text-[#1A1A2E]">{g.label}</span>
              <span className="text-[11px] text-gray-500">{g.game}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function RightSidebar() {
  return (
    <div className="flex flex-col gap-5">
      <EventPromoBanner />
      <RisingGameSection />
      <NewGameSection />
      <GenreTopSection />
    </div>
  );
}
