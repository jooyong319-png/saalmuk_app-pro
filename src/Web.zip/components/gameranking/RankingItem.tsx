export interface GameData {
  id: number;
  name: string;
  shortName: string;
  genre: string;
  rating: number;
  salesRank: number;
  score: number;
  scoreChange: number;
  rankChange: number;
  img?: string;
}

interface Props {
  rank: number;
  game: GameData;
  change: number;
  isLiked: boolean;
  onToggleLike: (e: React.MouseEvent) => void;
  onClick: () => void;
  animationDelay?: number;
}

export default function RankingItem({ rank, game, change, onClick, animationDelay }: Props) {
  const getChangeDisplay = (val: number) => {
    if (val === 0) return <span className="text-gray-400">-</span>;
    if (val > 0) return <span className="text-red-600 flex items-center">▲ {val}</span>;
    return <span className="text-blue-600 flex items-center">▼ {Math.abs(val)}</span>;
  };

  return (
    <div
      onClick={onClick}
      className="grid grid-cols-[50px_52px_1fr_60px_80px_100px] items-center gap-3 px-4 py-3.5 border-b border-gray-100 last:border-none hover:bg-[#FAFBFC] transition-colors cursor-pointer group animate-fadeIn"
      style={{ animationDelay: `${animationDelay || 0}ms` }}
    >
      <div className="flex flex-col items-center">
        <span className={`text-[18px] font-extrabold ${rank <= 3 ? "text-[#4AABF5] italic" : "text-[#1A1A2E]"}`}>{rank}</span>
        <span className="text-[11px] font-bold mt-0.5">{getChangeDisplay(change)}</span>
      </div>

      <div className="w-12 h-12 rounded-[10px] overflow-hidden shadow-sm group-hover:scale-105 transition-transform bg-gray-100 relative">
        {game.img ? (
          <img src={game.img} alt={game.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-[10px] font-bold">{game.shortName}</div>
        )}
        {rank === 1 && (
          <div className="absolute -top-1 -left-1 w-5 h-5 bg-[#72C2FF] rounded-full border-2 border-white flex items-center justify-center text-[10px] font-bold text-white shadow">1</div>
        )}
      </div>

      <div className="min-w-0">
        <div className="flex items-center gap-1.5 mb-1">
          <span className="text-[14px] font-bold text-[#1A1A2E] truncate">{game.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-semibold text-[#4AABF5] bg-[#E8F4FD] px-1.5 py-0.5 rounded whitespace-nowrap">{game.genre}</span>
          <div className="text-[12px] text-gray-500 flex items-center gap-1">
            <span className="text-yellow-400 text-[11px]">★</span> {game.rating}점
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center gap-0.5">
        <span className="text-[10px] text-gray-400">평가글</span>
        <span className="text-[16px] text-gray-400 cursor-pointer hover:text-[#72C2FF]">📄</span>
      </div>

      <div className="flex flex-col items-center gap-0.5">
        <span className="text-[10px] text-gray-400">매출 순위</span>
        <div className="flex items-center text-[13px] font-semibold text-blue-600">
          {game.salesRank > 0 ? (
            <><img src="https://ssalmuk.com/images/icon_google.svg" alt="Google" className="w-3.5 h-3.5 mr-1" />{game.salesRank}위</>
          ) : (
            <span className="text-gray-400 font-bold">ㅡ</span>
          )}
        </div>
      </div>

      <div className="flex flex-col items-end">
        <span className="text-[10px] text-gray-400">소셜점수</span>
        <span className="text-[15px] font-extrabold text-[#4AABF5]">{game.score.toLocaleString()}</span>
        <span className={`text-[11px] font-semibold ${game.scoreChange < 0 ? "text-blue-600" : game.scoreChange > 0 ? "text-red-600" : "text-gray-400"}`}>
          {game.scoreChange === 0 ? "0.00%" : game.scoreChange > 0 ? `+${game.scoreChange}%` : `${game.scoreChange}%`}
        </span>
      </div>
    </div>
  );
}
