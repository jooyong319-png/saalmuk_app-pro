import { Smartphone, Monitor, Coins } from "lucide-react";

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function LeftSidebar({ activeTab, setActiveTab }: Props) {
  const tabs = [
    { label: "모바일 게임", icon: <Smartphone size={18} /> },
    { label: "PC 게임", icon: <Monitor size={18} /> },
    { label: "P2E 게임", icon: <Coins size={18} /> },
  ];

  return (
    <nav className="flex flex-col gap-0.5">
      {tabs.map((item) => (
        <button
          key={item.label}
          onClick={() => setActiveTab(item.label)}
          className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-[15px] font-medium rounded-lg transition-colors ${
            activeTab === item.label
              ? "text-[#1A1A2E] font-bold bg-gray-100"
              : "text-gray-500 hover:bg-gray-100 hover:text-[#1A1A2E]"
          }`}
        >
          <span className={activeTab === item.label ? "text-[#72C2FF]" : "text-gray-400"}>{item.icon}</span>
          {item.label}
        </button>
      ))}

      <div className="mt-6 px-2">
        <a href="#" className="block rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow" onClick={(e) => e.preventDefault()}>
          <img src="https://i.pinimg.com/736x/e6/c7/77/e6c777962e2034c840f560b73a2f3a6b.jpg" alt="광고" className="w-full h-auto object-cover" />
        </a>
        <p className="text-[10px] text-gray-300 text-center mt-1">AD</p>
      </div>
    </nav>
  );
}
