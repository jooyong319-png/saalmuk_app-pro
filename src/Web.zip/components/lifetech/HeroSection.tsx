// @ts-nocheck
import { marketItems as marketItemsData } from "./data";

export default function HeroSection({
  eventsCount,
  todayCount,
}: {
  eventsCount: number;
  todayCount: number;
}) {
  return (
    <div
      className="rounded-2xl p-6 mb-6 animate-fadeUp"
      style={{ background: "linear-gradient(135deg, #72C2FF 0%, #4AABF5 100%)" }}
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white mb-2">🍚 생활테크</h1>
          <p className="text-white/80 text-sm">
            이벤트 참여하고, 쿠폰 거래하고, 설문으로 캐시 벌기!
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white/20 backdrop-blur-sm rounded-xl px-5 py-3 text-center">
            <div className="text-2xl font-bold text-white">{eventsCount}</div>
            <div className="text-xs text-white/70">진행중 이벤트</div>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-xl px-5 py-3 text-center">
            <div className="text-2xl font-bold text-white">{todayCount}</div>
            <div className="text-xs text-white/70">오늘 마감</div>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-xl px-5 py-3 text-center">
            <div className="text-2xl font-bold text-white">{marketItemsData.length}</div>
            <div className="text-xs text-white/70">장터 상품</div>
          </div>
        </div>
      </div>
    </div>
  );
}
