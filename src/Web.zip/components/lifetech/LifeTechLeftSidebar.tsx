// @ts-nocheck
import { Gift, Coins, ClipboardList, ShoppingBag, MessageCircle } from "lucide-react";

export default function LifeTechLeftSidebar({
  activeTab,
  onTabChange,
}: {
  activeTab: string;
  onTabChange: (tab: string) => void;
}) {
  const tabs = [
    { id: "이벤트", icon: <Gift size={18} /> },
    { id: "앱테크", icon: <Coins size={18} /> },
    { id: "설문조사", icon: <ClipboardList size={18} /> },
    { id: "장터", icon: <ShoppingBag size={18} /> },
    { id: "커뮤니티", icon: <MessageCircle size={18} /> },
  ];

  return (
    <nav className="flex flex-col gap-0.5">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-[15px] font-medium rounded-lg transition-colors ${
            activeTab === tab.id
              ? "text-[#1A1A2E] font-bold bg-gray-100"
              : "text-gray-500 hover:bg-gray-100 hover:text-[#1A1A2E]"
          }`}
        >
          <span className={activeTab === tab.id ? "text-[#72C2FF]" : "text-gray-400"}>
            {tab.icon}
          </span>
          {tab.id}
        </button>
      ))}

      {/* 광고 배너 */}
      <div className="mt-6 px-2">
        <a
          href="#"
          className="block rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
          onClick={(e) => e.preventDefault()}
        >
          <img
            src="https://i.pinimg.com/736x/e6/c7/77/e6c777962e2034c840f560b73a2f3a6b.jpg"
            alt="광고"
            className="w-full h-auto object-cover"
          />
        </a>
        <p className="text-[10px] text-gray-300 text-center mt-1">AD</p>
      </div>
    </nav>
  );
}
