// @ts-nocheck
// 생활테크 (생활쌀먹) 타입 정의 - 앱 기능 통합 버전

export interface UserStats {
  ssalmukCash: number;
  escrowCash: number;
  purchaseDeposit: number;
  coupons: number;
  level: number;
  levelName: string;
  exp: number;
  streak: number;
  totalSurveys: number;
  bankName: string;
  bankAccount: string;
}

export interface Event {
  id: number;
  type: string;
  hot: boolean;
  status: string;
  title: string;
  prize: string;
  winners: number;
  period: string;
  dday: number;
  host: string;
  platform: string;
  likes: number;
  views?: number;
  comments: number;
  isWon?: boolean;
  deadline?: string;
  announceDate?: string;
}

export interface PointSource {
  id: number;
  category: string;
  title: string;
  desc: string;
  reward: string;
  icon: string;
  hot: boolean;
  likes?: number;
  comments?: number;
  views?: number;
  status?: string;
  createdAt?: string;
}

export interface Survey {
  id: number;
  type: string;
  title: string;
  description: string;
  reward: number;
  duration: string;
  participants: number;
  maxParticipants: number;
  deadline: string;
  tags: string[];
  isHot: boolean;
  isPremium?: boolean;
  questions: SurveyQuestion[];
}

export interface SurveyQuestion {
  type: 'single' | 'multi' | 'scale';
  question: string;
  options?: string[];
  min?: number;
  max?: number;
}

export interface QuickPoll {
  id: number;
  question: string;
  tags: string[];
  options: { text: string; votes: number; percent?: number }[];
  reward: number;
  participated: boolean;
  participants: number;
  comments: number;
  likes: number;
}

export interface MarketItem {
  id: number;
  brand: string;
  dday: number;
  name: string;
  originalPrice: number;
  price: number;
  discount: number;
  seller: string;
  rating: number;
  trades: number;
  status: string;
  barcode: string;
  validUntil: string;
  soldDate?: string;
  createdAt?: string;
  image?: string;
}

export interface Post {
  id: number;
  category: string;
  title: string;
  author: string;
  time: string;
  likes: number;
  views?: number;
  comments: number;
  hot: boolean;
}

export interface Coupon {
  id: number;
  brand: string;
  brandLogo: string;
  name: string;
  barcode: string;
  validFrom: string;
  validUntil: string;
  dday: number;
  status: string;
  tradeStatus: string;
  source: string;
  purchaseDate: string;
  usedDate: string | null;
  price: number;
  seller?: string | null;
  buyer?: string | null;
}

export interface CashHistory {
  id: number;
  type: string;
  title: string;
  amount: number;
  date: string;
  status: string;
  icon?: string;
}

export interface MyTrade {
  id: number;
  brand: string;
  name: string;
  price: number;
  status: string;
  date: string;
  barcode?: string | null;
  seller?: string;
  buyer?: string | null;
  settledAmount?: number;
}

export interface BankAccount {
  id: number;
  bank: string;
  bankCode: string;
  account: string;
  holder?: string;
  color?: string;
  isDefault: boolean;
}

// Context 타입 (모달/탭에서 공유하는 상태) - 앱 기능 통합
export interface LifeTechCtx {
  // 유저 데이터
  userStats: UserStats;
  setUserStats: React.Dispatch<React.SetStateAction<UserStats>>;
  myCoupons: Coupon[];
  setMyCoupons: React.Dispatch<React.SetStateAction<Coupon[]>>;
  myTrades: { buying: MyTrade[]; selling: MyTrade[] };
  setMyTrades: React.Dispatch<React.SetStateAction<{ buying: MyTrade[]; selling: MyTrade[] }>>;
  cashHistory: CashHistory[];

  // 탭 상태
  mainTab: string;
  setMainTab: (v: string) => void;
  subTab: string;
  setSubTab: (v: string) => void;
  surveyMainTab: string;
  setSurveyMainTab: (v: string) => void;
  surveyTab: string;
  setSurveyTab: (v: string) => void;
  marketTab: string;
  setMarketTab: (v: string) => void;
  communityTab: string;
  setCommunityTab: (v: string) => void;
  quickPollFilter: string;
  setQuickPollFilter: (v: string) => void;

  // 이벤트 필터
  eventSort: string;
  setEventSort: (v: string) => void;
  eventViewType: string;
  setEventViewType: (v: string) => void;
  eventFilters: { prizeTypes: string[]; entryTypes: string[]; platforms: string[] };
  setEventFilters: React.Dispatch<React.SetStateAction<{ prizeTypes: string[]; entryTypes: string[]; platforms: string[] }>>;

  // 쿠폰 모달
  showMyCoupon: boolean;
  setShowMyCoupon: (v: boolean) => void;
  couponTab: string;
  setCouponTab: (v: string) => void;
  couponSort: string;
  setCouponSort: (v: string) => void;
  selectedCoupon: Coupon | null;
  setSelectedCoupon: (v: Coupon | null) => void;

  // 이벤트 모달
  showEventDetail: Event | null;
  setShowEventDetail: (v: Event | null) => void;
  showMyEntries: boolean;
  setShowMyEntries: (v: boolean) => void;
  showEventFilter: boolean;
  setShowEventFilter: (v: boolean) => void;
  showWinnerRegister: boolean;
  setShowWinnerRegister: (v: boolean) => void;
  showCorrectionRequest: boolean;
  setShowCorrectionRequest: (v: boolean) => void;
  winnerAnnouncement: any;
  setWinnerAnnouncement: (fn: any) => void;
  entryTab: string;
  setEntryTab: (v: string) => void;
  entrySort: string;
  setEntrySort: (v: string) => void;

  // 캐시 모달
  showMyCash: boolean;
  setShowMyCash: (v: boolean) => void;
  showChargeModal: boolean;
  setShowChargeModal: (v: boolean) => void;
  chargeStep: number;
  setChargeStep: (v: number) => void;
  chargeAmount: number;
  setChargeAmount: (v: number) => void;
  showWithdrawModal: boolean;
  setShowWithdrawModal: (v: boolean) => void;
  withdrawStep: number;
  setWithdrawStep: (v: number) => void;
  withdrawAmount: number;
  setWithdrawAmount: (v: number) => void;
  showBankChange: boolean;
  setShowBankChange: (v: boolean) => void;
  showCashHistory: boolean;
  setShowCashHistory: (v: boolean) => void;

  // 장터 모달
  showProductDetail: MarketItem | null;
  setShowProductDetail: (v: MarketItem | null) => void;
  showPurchaseFlow: boolean;
  setShowPurchaseFlow: (v: boolean) => void;
  purchaseStep: number;
  setPurchaseStep: (v: number) => void;
  selectedProduct: MarketItem | null;
  setSelectedProduct: (v: MarketItem | null) => void;
  isSeller: boolean;
  setIsSeller: (v: boolean) => void;
  showSellFlow: boolean;
  setShowSellFlow: (v: boolean) => void;
  sellStep: number;
  setSellStep: (v: number) => void;
  showMyTrade: boolean;
  setShowMyTrade: (v: boolean) => void;
  myTradeTab: string;
  setMyTradeTab: (v: string) => void;
  showChat: boolean;
  setShowChat: (v: boolean) => void;
  chatMessages: any[];
  setChatMessages: (fn: any) => void;
  chatInput: string;
  setChatInput: (v: string) => void;
  chatPartner: string;
  setChatPartner: (v: string) => void;
  showDisputeModal: boolean;
  setShowDisputeModal: (v: boolean) => void;
  disputeReason: string;
  setDisputeReason: (v: string) => void;
  disputeEtcText: string;
  setDisputeEtcText: (v: string) => void;
  showTransactionDetail: boolean;
  setShowTransactionDetail: (v: boolean) => void;
  transactionStatus: string;
  setTransactionStatus: (v: string) => void;

  // 포인트 상태
  showPointDetail: PointSource | null;
  setShowPointDetail: (v: PointSource | null) => void;

  // 설문 상태
  selectedSurvey: Survey | null;
  setSelectedSurvey: (v: Survey | null) => void;
  currentQuestion: number;
  setCurrentQuestion: (v: number) => void;

  // 퀵폴 상태
  quickPollVoted: { [key: number]: boolean };
  setQuickPollVoted: React.Dispatch<React.SetStateAction<{ [key: number]: boolean }>>;

  // 기타 모달 (MiscModals)
  showWriteModal: boolean;
  setShowWriteModal: (v: boolean) => void;
  writeStep: number;
  setWriteStep: (v: number) => void;
  showSearchModal: boolean;
  setShowSearchModal: (v: boolean) => void;
  showNotification: boolean;
  setShowNotification: (v: boolean) => void;

  // 공통 데이터
  events: Event[];
  pointSources: PointSource[];
  setPointSources: React.Dispatch<React.SetStateAction<PointSource[]>>;
  surveys: Survey[];
  quickPolls: QuickPoll[];
  marketItems: MarketItem[];
  posts: Post[];

  // 유틸 함수
  getStatusBadge: (status: string, dday: number) => { text: string; color: string };
  getTypeBadge: (type: string) => string;
  handleVote: (pollId: number, optionIndex: number) => void;
}
