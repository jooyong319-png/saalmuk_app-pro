// @ts-nocheck
export default function SortFilterBar({
  sortValue,
  onSortChange,
  onFilterClick,
  todayCount = 0,
}: {
  sortValue: string;
  onSortChange: (sort: string) => void;
  onFilterClick: () => void;
  todayCount?: number;
}) {
  const toggleSort = () => {
    onSortChange(sortValue === "latest" ? "popular" : "latest");
  };

  return (
    <div className="flex items-center justify-between mb-4 mx-2 text-sm">
      <button
        onClick={toggleSort}
        className="flex items-center gap-1 text-gray-500 hover:text-gray-700"
      >
        <span>{sortValue === "latest" ? "최신순" : "인기순"}</span>
        <span>↕</span>
      </button>

      <div className="flex items-center gap-3">
        {todayCount > 0 && (
          <span>
            <span className="text-gray-900">오늘등록</span>
            <span className="text-[#72C2FF] ml-1">({todayCount}건)</span>
          </span>
        )}
        <button onClick={onFilterClick} className="text-gray-500 hover:text-gray-700">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
          </svg>
        </button>
      </div>
    </div>
  );
}
