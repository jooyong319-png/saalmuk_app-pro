// @ts-nocheck
import PlatformIcon from "./PlatformIcon";
import InteractionBar from "./InteractionBar";

export default function ListItem({
  item,
  type,
  onClick,
}: {
  item: any;
  type: "event" | "apptech" | "market" | "community";
  onClick?: () => void;
}) {
  const badgeColors: Record<string, string> = {
    댓글: "bg-purple-100 text-purple-600",
    퀴즈: "bg-blue-100 text-blue-600",
    공유: "bg-green-100 text-green-600",
    팔로우: "bg-pink-100 text-pink-600",
    인증샷: "bg-orange-100 text-orange-600",
    포인트: "bg-emerald-500 text-white",
    쿠폰: "bg-amber-500 text-white",
    미션: "bg-purple-500 text-white",
    광고: "bg-blue-500 text-white",
    앱테크: "bg-emerald-500 text-white",
    자유: "bg-gray-100 text-gray-600",
    질문: "bg-sky-100 text-sky-600",
    정보: "bg-emerald-100 text-emerald-600",
  };

  const statusColors: Record<string, string> = {
    진행중: "bg-emerald-100 text-emerald-600",
    미정: "bg-gray-200 text-gray-500",
    마감: "bg-gray-200 text-gray-500",
    ended: "bg-gray-200 text-gray-500",
  };

  const getStatusText = (status: string) => {
    if (status === "ended") return "마감";
    return status;
  };

  const getBadgeText = () => {
    if (type === "event") return item.type;
    if (type === "apptech") return item.category;
    if (type === "market") return null;
    if (type === "community") return item.category;
    return null;
  };

  const dDayColor = "bg-emerald-500";
  const badgeText = getBadgeText();

  return (
    <div
      onClick={onClick}
      className="px-5 py-4 bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-gray-200 cursor-pointer transition-all"
    >
      <div className="flex items-start gap-3">
        <div className={`shrink-0 ${type === "market" ? "w-16" : "w-14"} flex justify-center`}>
          {type === "market" ? (
            <div className="w-16 h-16 bg-white border border-gray-200 rounded-xl flex items-center justify-center overflow-hidden">
              {item.image ? (
                <img src={item.image} alt={item.brand} className="w-12 h-12 object-contain" />
              ) : (
                <span className="text-3xl">🎁</span>
              )}
            </div>
          ) : (
            badgeText && (
              <span className={`px-2.5 py-1 rounded text-xs font-medium text-center ${badgeColors[badgeText] || "bg-gray-100 text-gray-600"}`}>
                {badgeText}
              </span>
            )
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            {type === "market" && (
              <span className="px-2 py-0.5 rounded bg-[#E8F4FD] text-[#4A9FD9] text-xs font-medium shrink-0">
                {item.brand}
              </span>
            )}
            {type === "event" && item.platform && <PlatformIcon platform={item.platform} />}
            <h3 className="font-bold text-gray-900 truncate">{item.title || item.name}</h3>
            {type === "event" && item.dday !== undefined && (
              <span className={`px-2 py-0.5 rounded text-xs font-bold text-white shrink-0 ${dDayColor}`}>
                D-{item.dday}
              </span>
            )}
            {type === "apptech" && item.status && (
              <span className={`px-2 py-0.5 rounded text-xs font-medium shrink-0 ${statusColors[item.status] || "bg-gray-200 text-gray-500"}`}>
                {getStatusText(item.status)}
              </span>
            )}
            {type === "event" && (
              <span className="text-sm text-gray-700 ml-auto shrink-0">
                {item.prize} · <span className="text-gray-400">{item.winners}명 당첨</span>
              </span>
            )}
            {type === "market" && item.dday !== undefined && (
              <span className="text-sm text-gray-500 ml-auto shrink-0">D-{item.dday}</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {type === "market" ? (
              <>
                <span className="text-amber-500 text-sm">★ {item.rating}</span>
                <span className="text-sm text-gray-500">거래 {item.trades}회</span>
                <span className="px-1.5 py-0.5 bg-sky-100 text-sky-600 rounded text-xs">
                  {item.sellerBadge || "꿀팁고수"}
                </span>
                <span className="text-sm text-gray-400">{item.time || item.createdAt || "1시간 전"}</span>
                <div className="flex items-center gap-2 ml-auto shrink-0">
                  <span className="text-sm text-gray-400">{item.originalPrice?.toLocaleString()}원</span>
                  <span className="text-red-500 font-bold text-sm">{item.discount}%</span>
                  <span className="text-lg font-bold text-gray-900">{item.price?.toLocaleString()}원</span>
                </div>
              </>
            ) : (
              <>
                <span className="text-sm text-gray-500">{item.author || "김쌀먹"}</span>
                <InteractionBar
                  likes={item.likes}
                  dislikes={item.dislikes}
                  comments={item.comments}
                  views={item.views}
                  size="sm"
                />
                <span className="text-sm text-gray-400 ml-auto shrink-0">
                  {item.time || item.createdAt || "1시간 전"}
                </span>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
