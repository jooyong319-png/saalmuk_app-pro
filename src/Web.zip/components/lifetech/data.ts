// @ts-nocheck
import type { 
  UserStats, Event, PointSource, Survey, QuickPoll, 
  MarketItem, Post, Coupon, CashHistory, MyTrade 
} from "./types";

export const initialUserStats: UserStats = {
  ssalmukCash: 52100,
  escrowCash: 2100,
  purchaseDeposit: 10000,
  coupons: 5,
  level: 3,
  levelName: "알찬벼",
  exp: 65,
  streak: 7,
  totalSurveys: 23,
  bankName: "카카오뱅크",
  bankAccount: "3333-01-******",
};

export const initialCashHistory: CashHistory[] = [
  { id: 1, type: "+", icon: "📋", title: "설문조사 완료", amount: 500, date: "오늘 14:23", status: "완료" },
  { id: 2, type: "+", icon: "🗳️", title: "퀵폴 참여", amount: 30, date: "오늘 12:05", status: "완료" },
  { id: 3, type: "-", icon: "☕", title: "스타벅스 아메리카노 구매", amount: 3650, date: "어제", status: "거래완료" },
  { id: 4, type: "+", icon: "💰", title: "판매 정산", amount: 4462, date: "01.28", status: "정산완료" },
  { id: 5, type: "+", icon: "💳", title: "캐시 충전", amount: 10000, date: "01.27", status: "충전완료" },
  { id: 6, type: "-", icon: "☕", title: "스타벅스 아메리카노 구매", amount: 3200, date: "01.25", status: "거래완료" },
  { id: 7, type: "+", icon: "🎉", title: "이벤트 당첨", amount: 1000, date: "01.24", status: "완료" },
  { id: 8, type: "-", icon: "💸", title: "출금", amount: 5000, date: "01.23", status: "출금완료" },
  { id: 9, type: "+", icon: "📋", title: "설문조사 완료", amount: 800, date: "01.22", status: "완료" },
  { id: 10, type: "+", icon: "👥", title: "친구 초대 보상", amount: 2000, date: "01.20", status: "완료" },
];

export const events: Event[] = [
  { id: 1, type: "퀴즈", hot: true, status: "progress", title: "[CU편의점] 3월 행운퀴즈 이벤트", prize: "CU 5천원권", winners: 100, period: "03.10 ~ 03.15", dday: 3, host: "CU편의점", platform: "홈페이지", likes: 156, views: 2024, comments: 89 },
  { id: 2, type: "댓글", hot: true, status: "progress", title: "[스타벅스] 봄 신메뉴 출시 기념", prize: "아메리카노 T", winners: 50, period: "03.10 ~ 03.14", dday: 1, host: "스타벅스", platform: "인스타그램", likes: 234, views: 609, comments: 123 },
  { id: 3, type: "퀴즈", hot: true, status: "today", title: "[맥도날드] 빅맥 50주년 퀴즈", prize: "빅맥세트", winners: 500, period: "03.01 ~ 03.13", dday: 0, host: "맥도날드", platform: "APP전용", likes: 847, views: 4706, comments: 234 },
  { id: 4, type: "인증샷", hot: false, status: "announce", title: "[GS25] 와인 페스티벌 이벤트", prize: "GS25 1만원권", winners: 200, period: "03.01 ~ 03.10", dday: -2, host: "GS25", platform: "홈페이지", likes: 89, views: 4212, comments: 45 },
  { id: 5, type: "팔로우", hot: false, status: "ended", title: "[올리브영] 봄맞이 럭키드로우", prize: "올리브영 3만원권", winners: 100, period: "02.25 ~ 03.07", dday: -5, host: "올리브영", platform: "인스타그램", likes: 67, views: 3857, comments: 34 },
  { id: 6, type: "댓글", hot: true, status: "progress", title: "[배스킨라빈스] 신규 플레이버 이벤트", prize: "파인트 교환권", winners: 200, period: "03.08 ~ 03.20", dday: 7, host: "배스킨라빈스", platform: "인스타그램", likes: 312, views: 2156, comments: 167 },
  { id: 7, type: "퀴즈", hot: false, status: "progress", title: "[롯데시네마] 봄영화 추천 퀴즈", prize: "영화 관람권 2매", winners: 50, period: "03.05 ~ 03.18", dday: 5, host: "롯데시네마", platform: "홈페이지", likes: 89, views: 892, comments: 23 },
];

export const pointSources: PointSource[] = [
  { id: 1, category: "포인트", title: "[토스] 만보기 출석체크", desc: "매일 걸으면서 포인트 적립! 하루 10분이면 100P", reward: "포인트", icon: "🚶", hot: true, likes: 234, comments: 45, views: 1892, status: "", createdAt: "2시간 전" },
  { id: 2, category: "포인트", title: "[캐시워크] 광고 시청 이벤트", desc: "광고 보고 최대 500P 받기", reward: "포인트", icon: "📺", hot: true, likes: 187, comments: 32, views: 1456, status: "", createdAt: "3시간 전" },
  { id: 3, category: "포인트", title: "[리서치패널] 설문조사 참여", desc: "10분 설문으로 800P 적립", reward: "포인트", icon: "📝", hot: false, likes: 89, comments: 12, views: 892, status: "", createdAt: "5시간 전" },
  { id: 4, category: "쿠폰", title: "[쌀먹] 7일 연속 출석체크", desc: "매일 출석하면 보너스 2배!", reward: "쿠폰", icon: "📅", hot: true, likes: 456, comments: 78, views: 3421, status: "", createdAt: "6시간 전" },
  { id: 5, category: "포인트", title: "[네이버페이] 앱 설치 미션", desc: "앱 설치 후 가입하면 500P 즉시 지급", reward: "포인트", icon: "📱", hot: false, likes: 123, comments: 23, views: 1123, status: "ended", createdAt: "1일 전" },
  { id: 6, category: "기타", title: "[플레이오] 게임 플레이 리워드", desc: "게임하면서 젬 적립, 현금으로 교환", reward: "기타", icon: "🎮", hot: true, likes: 567, comments: 89, views: 4521, status: "", createdAt: "2일 전" },
  { id: 7, category: "포인트", title: "[버즈빌] 잠금화면 광고", desc: "잠금화면에서 스와이프만 해도 적립", reward: "포인트", icon: "🔓", hot: false, likes: 312, comments: 56, views: 2341, status: "", createdAt: "3시간 전" },
  { id: 8, category: "포인트", title: "[카카오페이] 송금하면 포인트", desc: "친구에게 송금하면 최대 1000P", reward: "포인트", icon: "💸", hot: true, likes: 423, comments: 67, views: 3892, status: "", createdAt: "4시간 전" },
  { id: 9, category: "쿠폰", title: "[쿠팡] 첫 구매 미션", desc: "신규가입 후 첫 구매 시 5000원 할인", reward: "쿠폰", icon: "🛒", hot: true, likes: 521, comments: 92, views: 5123, status: "", createdAt: "5시간 전" },
  { id: 10, category: "포인트", title: "[애드픽] 리뷰 작성 리워드", desc: "앱 리뷰 작성하고 300P 받기", reward: "포인트", icon: "✍️", hot: false, likes: 178, comments: 34, views: 1567, status: "", createdAt: "7시간 전" },
  { id: 11, category: "포인트", title: "[OK캐쉬백] 영수증 인증", desc: "영수증 촬영만 해도 포인트 적립", reward: "포인트", icon: "🧾", hot: false, likes: 245, comments: 41, views: 1823, status: "", createdAt: "8시간 전" },
  { id: 12, category: "쿠폰", title: "[배달의민족] 리뷰 이벤트", desc: "리뷰 작성하면 쿠폰 증정", reward: "쿠폰", icon: "🍔", hot: true, likes: 389, comments: 73, views: 2987, status: "", createdAt: "1일 전" },
  { id: 13, category: "기타", title: "[틱톡라이트] 영상 시청 보상", desc: "영상 보면서 최대 일 2000원", reward: "기타", icon: "📱", hot: true, likes: 612, comments: 108, views: 6234, status: "", createdAt: "2시간 전" },
  { id: 14, category: "포인트", title: "[페이코] 간편결제 이벤트", desc: "페이코로 결제하면 2% 추가 적립", reward: "포인트", icon: "💳", hot: false, likes: 156, comments: 28, views: 1234, status: "ended", createdAt: "2일 전" },
];

export const surveys: Survey[] = [
  {
    id: 1, type: "game", title: "2026년 기대되는 모바일 게임 조사", description: "신규 출시 예정 게임에 대한 의견을 들려주세요",
    reward: 500, duration: "5분", participants: 234, maxParticipants: 500, deadline: "오늘 23:59", tags: ["모바일게임", "신작"], isHot: true,
    questions: [
      { type: "single", question: "주로 플레이하는 게임 장르는?", options: ["RPG", "전략", "액션", "퍼즐", "시뮬레이션"] },
      { type: "multi", question: "게임 선택 시 중요하게 생각하는 요소는? (복수선택)", options: ["그래픽", "스토리", "커뮤니티", "PvP", "캐릭터"] },
      { type: "scale", question: "인게임 광고에 대한 거부감은?", min: 1, max: 5 },
      { type: "text", question: "2026년 가장 기대되는 신작 게임과 그 이유를 자유롭게 적어주세요." },
    ],
  },
  {
    id: 2, type: "brand", title: "게이밍 기어 브랜드 인지도 조사", description: "로지텍 X 쌀먹닷컴 제휴 설문",
    reward: 800, duration: "8분", participants: 89, maxParticipants: 200, deadline: "3일 후", tags: ["제휴설문", "게이밍기어"], isHot: false,
    questions: [
      { type: "single", question: "현재 사용 중인 마우스 브랜드는?", options: ["로지텍", "레이저", "스틸시리즈", "코세어", "기타"] },
      { type: "single", question: "게이밍 마우스 구매 시 가장 중요한 요소는?", options: ["센서 정확도", "무게", "디자인", "가격", "무선 여부"] },
      { type: "scale", question: "로지텍 제품의 전반적인 만족도는?", min: 1, max: 5 },
      { type: "multi", question: "보유 중인 게이밍 기어를 모두 선택해주세요. (복수선택)", options: ["게이밍 마우스", "기계식 키보드", "게이밍 헤드셋", "게이밍 모니터", "게이밍 패드"] },
      { type: "single", question: "게이밍 기어 정보를 주로 어디서 얻나요?", options: ["유튜브 리뷰", "커뮤니티 추천", "오프라인 매장 체험", "지인 추천", "공식 홈페이지"] },
    ],
  },
  {
    id: 3, type: "quick", title: "[퀵] P2E 게임 인식 조사", description: "간단한 5문항 설문",
    reward: 150, duration: "2분", participants: 412, maxParticipants: 1000, deadline: "오늘 23:59", tags: ["P2E", "퀵설문"], isHot: false,
    questions: [
      { type: "single", question: "P2E(돈 버는 게임) 게임을 해본 적 있나요?", options: ["현재 하고 있다", "해봤지만 그만뒀다", "관심은 있지만 안 해봤다", "전혀 관심 없다"] },
      { type: "single", question: "P2E 게임에서 가장 우려되는 점은?", options: ["사기/해킹 위험", "게임 재미 부족", "수익 불안정", "진입 장벽 높음"] },
      { type: "scale", question: "P2E 게임의 미래 가능성은?", min: 1, max: 5 },
    ],
  },
  {
    id: 4, type: "beta", title: "🎮 신작 RPG 클로즈베타 테스터 모집", description: "2주간 베타테스트 참여 후 상세 리뷰 작성",
    reward: 5000, duration: "2주", participants: 45, maxParticipants: 100, deadline: "3월 31일", tags: ["베타테스트", "RPG", "프리미엄"], isHot: true, isPremium: true,
    questions: [
      { type: "single", question: "주 플레이 기기는?", options: ["PC", "모바일(Android)", "모바일(iOS)", "콘솔"] },
      { type: "single", question: "일평균 게임 플레이 시간은?", options: ["1시간 미만", "1~2시간", "2~4시간", "4시간 이상"] },
      { type: "multi", question: "선호하는 RPG 요소를 선택해주세요. (복수선택)", options: ["스토리/세계관", "PvP 전투", "레이드/협력", "캐릭터 육성", "오픈월드 탐험"] },
      { type: "scale", question: "베타테스트 참여 후 상세 리뷰 작성이 가능한가요?", min: 1, max: 5 },
    ],
  },
];

export const quickPolls: QuickPoll[] = [
  {
    id: 1, question: "귀하에서는 다음 중 어디에 해당하시나요?", tags: ["#담배"],
    options: [
      { text: "비흡연자 & 1년 내 해외 여행 경험 없음", votes: 1625, percent: 54 },
      { text: "비흡연자 & 1년 내 해외 여행시 공항면세점에서 면세 담배 구입", votes: 391, percent: 13 },
      { text: "비흡연자 & 1년 내 해외 여행시 공항면세점에서 면세 담배 비구입", votes: 541, percent: 18 },
      { text: "흡연자 & 1년 내 해외 여행 경험 없음", votes: 241, percent: 8 },
      { text: "흡연자 & 1년 내 해외 여행시 공항면세점에서 면세 담배 구입", votes: 150, percent: 5 },
      { text: "흡연자 & 1년 내 해외 여행시 공항면세점에서 면세 담배 비구입", votes: 90, percent: 3 },
    ],
    reward: 1, participated: true, participants: 29820, comments: 1, likes: 33,
  },
  {
    id: 2, question: "만일 쿠팡이 영업정지 처분 등의 이유로 이용할 수 없게 된다면, 신선/가공 식품을 주로 어디서 구매하시겠습니까?",
    tags: ["#쇼핑", "#식품구매"],
    options: [
      { text: "신선/가공식품은 쿠팡에서 구매하지 않았음", votes: 0 },
      { text: "네이버 쇼핑/스마트스토어", votes: 0 },
      { text: "11번가/G마켓 등 오픈마켓", votes: 0 },
      { text: "이마트몰/SSG닷컴 등 대형마트 온라인", votes: 0 },
      { text: "컬리 등 신선식품 전문 플랫폼", votes: 0 },
      { text: "기타", votes: 0 },
    ],
    reward: 1, participated: false, participants: 45321, comments: 12, likes: 67,
  },
  {
    id: 3, question: "2026년 설 연휴 KTX 예매 시, 가장 우선 고려할(한) 좌석 유형은 무엇인가요?",
    tags: ["#KTX", "#설연휴"],
    options: [
      { text: "이번 설 연휴에 이용 계획 없음", votes: 0 },
      { text: "일반실 창가", votes: 0 },
      { text: "일반실 통로", votes: 0 },
      { text: "특실", votes: 0 },
      { text: "동반자와 붙는 좌석이 우선", votes: 0 },
      { text: "기타", votes: 0 },
    ],
    reward: 1, participated: false, participants: 46041, comments: 2, likes: 49,
  },
];

export const marketItems: MarketItem[] = [
  { id: 1, brand: "스타벅스", dday: 30, name: "아메리카노 T 떨이요", originalPrice: 4700, price: 3650, discount: 22, seller: "쌀먹고수", rating: 5, trades: 128, status: "available", barcode: "1234-5678-9012-3456", validUntil: "2026.04.15", createdAt: "1시간 전", image: "" },
  { id: 2, brand: "GS25", dday: 28, name: "김치왕뚜껑 급처합니다", originalPrice: 2000, price: 1500, discount: 25, seller: "편의점마스터", rating: 5, trades: 89, status: "available", barcode: "1111-2222-3333-4444", validUntil: "2026.04.30", createdAt: "2시간 전", image: "https://atom.donutbook.co.kr:14405/goods/JDDS2UFQCPZFZLAV70ST.jpg" },
  { id: 3, brand: "GS25", dday: 28, name: "왕뚜껑 싸게 팔아요", originalPrice: 2000, price: 1500, discount: 25, seller: "라면러버", rating: 4.9, trades: 67, status: "available", barcode: "2222-3333-4444-5555", validUntil: "2026.04.30", createdAt: "3시간 전", image: "https://atom.donutbook.co.kr:14405/goods/IRXL2312H5B56SK7GVG7.jpg" },
  { id: 4, brand: "GS25", dday: 28, name: "튀김우동 저렴하게", originalPrice: 2000, price: 1500, discount: 25, seller: "우동좋아", rating: 5, trades: 45, status: "available", barcode: "3333-4444-5555-6666", validUntil: "2026.04.30", createdAt: "4시간 전", image: "https://atom.donutbook.co.kr:14405/goods/LV7AXF31FUS39FV8MSFZ.jpg" },
  { id: 5, brand: "GS25", dday: 28, name: "짜파게티 나눔해요", originalPrice: 2000, price: 1500, discount: 25, seller: "짜파구리", rating: 5, trades: 234, status: "available", barcode: "4444-5555-6666-7777", validUntil: "2026.04.30", createdAt: "5시간 전", image: "https://atom.donutbook.co.kr:14405/goods/Q8C8E0SK014JC6SSASSP.jpg" },
  { id: 6, brand: "GS25", dday: 28, name: "육개장큰사발 떨이", originalPrice: 2000, price: 1500, discount: 25, seller: "육개장팬", rating: 4.8, trades: 123, status: "available", barcode: "5555-6666-7777-8888", validUntil: "2026.04.30", createdAt: "6시간 전", image: "https://atom.donutbook.co.kr:14405/goods/AHPSEK4X0UYTC2ZDCJJP.jpg" },
  { id: 7, brand: "GS25", dday: 28, name: "신라면 반값에 드려요", originalPrice: 2000, price: 1500, discount: 25, seller: "신라면왕", rating: 5, trades: 567, status: "available", barcode: "6666-7777-8888-9999", validUntil: "2026.04.30", createdAt: "7시간 전", image: "https://atom.donutbook.co.kr:14405/goods/5PS517239OQ0C2H99TZI.jpg" },
  { id: 8, brand: "맥도날드", dday: 14, name: "빅맥세트 떨이요", originalPrice: 8900, price: 6500, discount: 27, seller: "이벤트헌터", rating: 5, trades: 89, status: "available", barcode: "9876-5432-1098-7654", validUntil: "2026.03.28", createdAt: "1일 전", image: "" },
  { id: 9, brand: "공차", dday: 21, name: "블랙밀크티 급처", originalPrice: 5500, price: 4200, discount: 24, seller: "당첨왕", rating: 4.8, trades: 234, status: "available", barcode: "5555-6666-7777-8888", validUntil: "2026.04.05", createdAt: "2일 전", image: "" },
  { id: 10, brand: "도미노피자", dday: 45, name: "포테이토M 싸게팝니다", originalPrice: 19900, price: 14000, discount: 30, seller: "쿠폰마스터", rating: 5, trades: 67, status: "available", barcode: "1111-2222-3333-4444", validUntil: "2026.05.01", createdAt: "2일 전", image: "" },
  { id: 11, brand: "스타벅스", dday: 0, name: "카페라떼 나눔완료", originalPrice: 5500, price: 4200, discount: 24, seller: "커피홀릭", rating: 5, trades: 312, status: "sold", barcode: "7777-8888-9999-0000", validUntil: "2026.03.10", createdAt: "3일 전", image: "" },
  { id: 12, brand: "CU", dday: 0, name: "삼각김밥 거래완료", originalPrice: 3000, price: 2200, discount: 27, seller: "편의점고수", rating: 4.9, trades: 156, status: "sold", barcode: "8888-9999-0000-1111", validUntil: "2026.03.08", createdAt: "4일 전", image: "" },
  { id: 13, brand: "BBQ", dday: 0, name: "황올+콜라 판매완료", originalPrice: 25000, price: 19000, discount: 24, seller: "치킨러버", rating: 5, trades: 78, status: "sold", barcode: "9999-0000-1111-2222", validUntil: "2026.03.05", createdAt: "5일 전", image: "" },
];

export const posts: Post[] = [
  { id: 1, category: "꿀팁", title: "스타벅스 이벤트 당첨 확률 높이는 꿀팁!", author: "이벤트고수", time: "2시간 전", likes: 847, views: 2486, comments: 123, hot: true },
  { id: 2, category: "후기", title: "CU 행운퀴즈 당첨 후기입니다 ㅎㅎ", author: "럭키보이", time: "3시간 전", likes: 234, views: 1879, comments: 45, hot: false },
  { id: 3, category: "질문", title: "쌀먹캐시 출금은 어떻게 하나요?", author: "뉴비123", time: "5시간 전", likes: 156, views: 9135, comments: 67, hot: false },
  { id: 4, category: "정보", title: "🔥 이번 주 마감 이벤트 총정리!", author: "정보통", time: "6시간 전", likes: 1523, views: 1624, comments: 234, hot: true },
  { id: 5, category: "잡담", title: "오늘 설문조사로 500캐시 벌었어요", author: "쌀먹러", time: "7시간 전", likes: 89, views: 7112, comments: 23, hot: false },
];

export const initialMyCoupons: Coupon[] = [
  { id: 1, brand: "CJ ONE", brandLogo: "🔵", name: "(HOT)아메리카노", barcode: "5186-0151-4910", validFrom: "2026.02.18", validUntil: "2026.04.09", dday: 27, status: "unused", tradeStatus: "trading", source: "장터구매", purchaseDate: "2026.02.18", usedDate: null, price: 3200, seller: "USER123" },
  { id: 2, brand: "스타벅스", brandLogo: "☕", name: "카페 아메리카노 T", barcode: "8809-1234-5678", validFrom: "2026.02.20", validUntil: "2026.03.20", dday: 7, status: "unused", tradeStatus: "purchased", source: "장터구매", purchaseDate: "2026.02.20", usedDate: null, price: 4500, seller: "SELLER01" },
  { id: 3, brand: "GS25", brandLogo: "🏪", name: "1만원 상품권", barcode: "1234-5678-9012", validFrom: "2026.02.01", validUntil: "2026.04.30", dday: 48, status: "unused", tradeStatus: "purchased", source: "직접등록", purchaseDate: "2026.02.10", usedDate: null, price: 10000, seller: null },
  { id: 4, brand: "메가MGC커피", brandLogo: "🧋", name: "(HOT)아메리카노", barcode: "5186-0151-4962", validFrom: "2026.02.18", validUntil: "2026.04.09", dday: 27, status: "used", tradeStatus: "sold", source: "내가 판매", purchaseDate: "2026.02.18", usedDate: "2026.02.25", price: 2000, buyer: "BUYER01" },
];

export const initialMyTrades = {
  buying: [
    { id: 1, brand: "CU", name: "5천원 상품권", price: 4500, status: "escrow", seller: "행운이", date: "03.10", barcode: null },
    { id: 2, brand: "스타벅스", name: "카페라떼 T", price: 4200, status: "completed", seller: "커피러버", date: "03.08", barcode: "1234-5678-9012-3456" },
  ],
  selling: [
    { id: 1, brand: "GS25", name: "1만원 상품권", price: 9000, status: "waiting", buyer: null, date: "03.10" },
    { id: 2, brand: "배스킨라빈스", name: "파인트", price: 8500, status: "escrow", buyer: "아이스크림왕", date: "03.09" },
    { id: 3, brand: "버거킹", name: "와퍼세트", price: 7500, status: "settled", buyer: "햄버거맨", date: "03.05", settledAmount: 7237 },
  ],
};

// 유틸 함수
export const getStatusBadge = (status: string, dday: number) => {
  if (dday === 0) return { text: "오늘마감", color: "bg-red-500" };
  if (status === "progress") return { text: "진행중", color: "bg-emerald-500" };
  if (status === "today") return { text: "오늘마감", color: "bg-red-500" };
  if (status === "announce") return { text: "발표전", color: "bg-amber-500" };
  if (status === "ended") return { text: "발표완료", color: "bg-gray-400" };
  return { text: "진행중", color: "bg-emerald-500" };
};

export const getTypeBadge = (type: string) => {
  const colors: Record<string, string> = {
    퀴즈: "bg-blue-100 text-blue-700",
    댓글: "bg-purple-100 text-purple-700",
    인증샷: "bg-pink-100 text-pink-700",
    팔로우: "bg-green-100 text-green-700",
  };
  return colors[type] || "bg-gray-100 text-gray-700";
};