// @ts-nocheck
import { useState } from "react";

interface Props {
  showNotification: boolean;
  setShowNotification: (v: boolean) => void;
}

export default function NotificationModal({ showNotification, setShowNotification }: Props) {
  const [notifications] = useState([
    { id: 1, type: "event", title: "🎉 이벤트 당첨!", content: "[CU 행운퀴즈] 이벤트에 당첨되었습니다!", time: "방금 전", isRead: false },
    { id: 2, type: "cash", title: "💰 캐시 충전 완료", content: "10,000 캐시가 충전되었습니다.", time: "1시간 전", isRead: false },
    { id: 3, type: "trade", title: "🛒 거래 완료", content: "스타벅스 아메리카노 거래가 완료되었습니다.", time: "3시간 전", isRead: true },
    { id: 4, type: "survey", title: "📋 설문조사 리워드 지급", content: "500 캐시가 지급되었습니다.", time: "어제", isRead: true },
    { id: 5, type: "system", title: "📢 공지사항", content: "서비스 점검 안내 (3/15 02:00~04:00)", time: "2일 전", isRead: true },
  ]);

  if (!showNotification) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-[500] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">알림</h2>
          <button onClick={() => setShowNotification(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🔔</span>
              </div>
              <p className="text-gray-500">알림이 없습니다</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {notifications.map((noti) => (
                <div
                  key={noti.id}
                  className={`px-6 py-4 hover:bg-gray-50 cursor-pointer transition-colors ${!noti.isRead ? "bg-[#E8F4FD]/30" : ""}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${!noti.isRead ? "bg-[#72C2FF]" : "bg-transparent"}`} />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900">{noti.title}</h4>
                      <p className="text-sm text-gray-500 mt-0.5 line-clamp-1">{noti.content}</p>
                      <span className="text-xs text-gray-400 mt-1">{noti.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100">
          <button className="w-full py-3 text-gray-500 font-medium hover:text-gray-700 transition-colors">
            모두 읽음 처리
          </button>
        </div>
      </div>
    </div>
  );
}
