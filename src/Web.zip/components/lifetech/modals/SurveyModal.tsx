// @ts-nocheck
import { useState } from "react";

export default function SurveyModal({
  survey,
  currentQuestion,
  setCurrentQuestion,
  onComplete,
  onClose,
}: any) {
  const [selectedSingle, setSelectedSingle] = useState<number | null>(null);
  const [selectedMulti, setSelectedMulti] = useState<number[]>([]);

  if (!survey) return null;
  const question = survey.questions[currentQuestion];
  if (!question) return null;

  const isMulti = question.type === "multi";
  const isScale = question.type === "scale";
  const isLast = currentQuestion === survey.questions.length - 1;

  const canProceed = isMulti ? selectedMulti.length > 0 : selectedSingle !== null;

  const goNext = () => {
    setSelectedSingle(null);
    setSelectedMulti([]);
    if (currentQuestion < survey.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      onComplete(survey.reward);
    }
  };

  const handleOptionClick = (idx: number) => {
    if (isMulti) {
      setSelectedMulti((prev) =>
        prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
      );
    } else {
      setSelectedSingle(idx);
    }
  };

  const isOptionSelected = (idx: number) =>
    isMulti ? selectedMulti.includes(idx) : selectedSingle === idx;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl max-w-lg w-full overflow-hidden">
        <div className="px-6 py-4 flex items-center gap-4">
          <button onClick={onClose} className="p-1">
            <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <div className="flex-1">
            <div className="h-2 bg-amber-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all"
                style={{ width: `${((currentQuestion + 1) / survey.questions.length) * 100}%` }}
              />
            </div>
          </div>
          <span className="text-sm text-gray-500">{currentQuestion + 1}/{survey.questions.length}</span>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-amber-500 text-sm font-medium">Q{currentQuestion + 1}</span>
              {isMulti && (
                <span className="text-xs bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full">복수선택</span>
              )}
            </div>
            <h2 className="text-xl font-bold text-gray-900">{question.question}</h2>
          </div>

          <div className="space-y-3">
            {isScale ? (
              <div className="flex justify-between gap-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    onClick={() => setSelectedSingle(n)}
                    className={`flex-1 py-4 border-2 rounded-xl text-lg font-bold transition-all ${
                      selectedSingle === n
                        ? "bg-amber-400 border-amber-400 text-white"
                        : "bg-white border-amber-200 text-amber-600 hover:bg-amber-50 hover:border-amber-400"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            ) : (
              question.options?.map((option: string, idx: number) => (
                <button
                  key={idx}
                  onClick={() => handleOptionClick(idx)}
                  className={`w-full p-4 border-2 rounded-xl text-left font-medium transition-all flex items-center gap-3 ${
                    isOptionSelected(idx)
                      ? "bg-amber-50 border-amber-400 text-amber-700"
                      : "bg-white border-amber-200 text-gray-700 hover:bg-amber-50 hover:border-amber-300"
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all ${
                    isOptionSelected(idx) ? "border-amber-400 bg-amber-400" : "border-gray-300"
                  }`}>
                    {isOptionSelected(idx) && (
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    )}
                  </div>
                  {option}
                </button>
              ))
            )}
          </div>

          <button
            onClick={goNext}
            disabled={!canProceed}
            className={`w-full mt-6 py-3.5 rounded-xl font-bold text-base transition-all ${
              canProceed
                ? "bg-amber-400 text-white hover:bg-amber-500"
                : "bg-gray-200 text-gray-400 cursor-not-allowed"
            }`}
          >
            {isLast ? "제출" : "다음"}
          </button>
        </div>
      </div>
    </div>
  );
}
