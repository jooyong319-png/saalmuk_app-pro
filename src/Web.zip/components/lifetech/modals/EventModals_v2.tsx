// @ts-nocheck
import { useState } from "react";
import type { LifeTechCtx, Event } from "../types_v2";

interface Props {
  ctx: LifeTechCtx;
}

export default function EventModals({ ctx }: Props) {
  const {
    showEventDetail,
    setShowEventDetail,
    showMyEntries,
    setShowMyEntries,
    showEventFilter,
    setShowEventFilter,
    showWinnerRegister,
    setShowWinnerRegister,
    showCorrectionRequest,
    setShowCorrectionRequest,
    winnerAnnouncement,
    setWinnerAnnouncement,
    entryTab,
    setEntryTab,
    entrySort,
    setEntrySort,
    eventFilters,
    setEventFilters,
    events,
    getStatusBadge,
    getTypeBadge,
  } = ctx;

  // ===== 이벤트 상세 모달 =====
  const EventDetailModal = () => {
    const [isLiked, setIsLiked] = useState(false);

    if (!showEventDetail) return null;

    const event = showEventDetail;
    const badge = getStatusBadge(event.status, event.dday);

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <span className={`text-xs font-medium px-2 py-1 rounded-full ${getTypeBadge(event.type)}`}>
                {event.type}
              </span>
              <span className={`text-xs font-medium text-white px-2 py-1 rounded-full ${badge.color}`}>
                {badge.text}
              </span>
            </div>
            <button
              onClick={() => setShowEventDetail(null)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* 콘텐츠 */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* 제목 */}
            <h2 className="text-xl font-bold text-gray-900 mb-4">{event.title}</h2>

            {/* 경품 정보 */}
            <div className="bg-gradient-to-r from-[#72C2FF]/10 to-[#4A9FD9]/10 rounded-xl p-5 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">경품</p>
                  <p className="text-2xl font-bold text-[#72C2FF]">{event.prize}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500 mb-1">당첨자</p>
                  <p className="text-xl font-bold text-gray-900">{event.winners}명</p>
                </div>
              </div>
            </div>

            {/* 상세 정보 */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">주최사</span>
                <span className="text-gray-900 font-medium">{event.host}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">플랫폼</span>
                <span className="text-gray-900">{event.platform}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">진행 기간</span>
                <span className="text-gray-900">{event.period}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">D-Day</span>
                <span className={`font-bold ${event.dday <= 1 ? "text-red-500" : "text-gray-900"}`}>
                  {event.dday === 0 ? "오늘 마감" : event.dday > 0 ? `D-${event.dday}` : `마감 ${Math.abs(event.dday)}일 전`}
                </span>
              </div>
            </div>

            {/* 인터랙션 */}
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsLiked(!isLiked)}
                  className={`flex items-center gap-1.5 ${isLiked ? "text-red-500" : "text-gray-500"}`}
                >
                  <svg className="w-5 h-5" fill={isLiked ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                  <span className="text-sm">{event.likes}</span>
                </button>
                <span className="flex items-center gap-1.5 text-gray-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  <span className="text-sm">{event.comments}</span>
                </span>
                <span className="flex items-center gap-1.5 text-gray-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  <span className="text-sm">{event.views || 0}</span>
                </span>
              </div>
              <button className="flex items-center gap-1.5 text-gray-500 hover:text-gray-700">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
                <span className="text-sm">공유</span>
              </button>
            </div>
          </div>

          {/* 하단 버튼 */}
          <div className="px-6 py-4 border-t border-gray-100 flex gap-3">
            {event.status === "announce" && (
              <button
                onClick={() => {
                  setShowEventDetail(null);
                  setWinnerAnnouncement(event);
                }}
                className="flex-1 py-3.5 bg-amber-500 text-white rounded-xl font-medium hover:bg-amber-600 transition-colors"
              >
                당첨자 확인
              </button>
            )}
            <button
              onClick={() => window.open("#", "_blank")}
              className="flex-1 py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
            >
              이벤트 참여하기
            </button>
          </div>
        </div>
      </div>
    );
  };

  // ===== 내 응모 내역 모달 =====
  const MyEntriesModal = () => {
    const [searchQuery, setSearchQuery] = useState("");
    const [myEntries, setMyEntries] = useState([
      {
        id: 1, type: "댓글", title: "[스타벅스] 겨울 신메뉴 출시 기념",
        prize: "아메리카노 T", status: "progress", isWon: false,
        dday: 5, deadline: "01.12", announceDate: "01.14",
        platform: "인스타그램", likes: 24, comments: 8, views: 312, winners: 1,
        host: "스타벅스코리아", period: "2025.01.01 ~ 2025.01.12",
      },
      {
        id: 2, type: "퀴즈", title: "[CU편의점] 12월 행운퀴즈 이벤트",
        prize: "CU 5천원권", status: "completed", isWon: false,
        deadline: "01.15", announceDate: "01.20",
        platform: "홈페이지", likes: 19, comments: 5, views: 187, winners: 5,
        host: "BGF리테일", period: "2025.01.01 ~ 2025.01.15",
      },
      {
        id: 3, type: "인증샷", title: "[GS25] 와인 페스티벌 이벤트",
        prize: "GS25 1만원권", status: "progress", isWon: false,
        dday: 12, deadline: "02.10", announceDate: "02.15",
        platform: "홈페이지", likes: 11, comments: 3, views: 95, winners: 2,
        host: "GS리테일", period: "2025.01.20 ~ 2025.02.10",
      },
      {
        id: 4, type: "팔로우", title: "[올리브영] 신년맞이 럭키드로우",
        prize: "올리브영 3만원권", status: "completed", isWon: true,
        deadline: "01.07", announceDate: "01.10",
        platform: "인스타그램", likes: 44, comments: 17, views: 521, winners: 10,
        host: "올리브영", period: "2024.12.26 ~ 2025.01.07",
      },
      {
        id: 5, type: "댓글", title: "[배스킨라빈스] 겨울 한정 신메뉴 이벤트",
        prize: "패밀리 세트 쿠폰", status: "completed", isWon: false,
        deadline: "01.20", announceDate: "01.25",
        platform: "인스타그램", likes: 38, comments: 14, views: 403, winners: 5,
        host: "비알코리아", period: "2025.01.10 ~ 2025.01.20",
      },
    ]);

    const toggleWon = (id: number) => {
      setMyEntries((prev) =>
        prev.map((e) => (e.id === id ? { ...e, isWon: !e.isWon } : e))
      );
    };

    const progressCount = myEntries.filter((e) => e.status === "progress").length;
    const completedCount = myEntries.filter((e) => e.status === "completed").length;
    const wonCount = myEntries.filter((e) => e.status === "completed" && e.isWon).length;

    const filteredEntries = myEntries.filter((e) => {
      const matchTab =
        (entryTab === "progress" && e.status === "progress") ||
        (entryTab === "completed" && e.status === "completed") ||
        (entryTab === "won" && e.status === "completed" && e.isWon);
      const matchSearch =
        !searchQuery ||
        e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.prize.toLowerCase().includes(searchQuery.toLowerCase());
      return matchTab && matchSearch;
    });

    const getPlatformIcon = (platform: string) => {
      switch (platform) {
        case "인스타그램": return "📷";
        case "유튜브": return "▶️";
        case "페이스북": return "🔵";
        case "네이버블로그": return "🟢";
        case "X (트위터)": return "🐦";
        case "홈페이지": return "🌐";
        default: return "🎁";
      }
    };

    if (!showMyEntries) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl h-[680px] overflow-hidden flex flex-col">
          {/* 헤더 */}
          <div className="px-6 py-4 border-b border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xl font-bold text-gray-900">응모함</h2>
              <button
                onClick={() => setShowMyEntries(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            {/* 검색 */}
            <div className="flex gap-2">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="이벤트명 · 경품 검색"
                className="flex-1 pl-4 pr-4 py-2.5 bg-gray-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#72C2FF]/30"
              />
              <button className="px-4 py-2.5 bg-[#72C2FF] text-white text-sm font-semibold rounded-xl">
                검색
              </button>
            </div>
          </div>

          {/* 탭 */}
          <div className="px-4 py-3 border-b border-gray-100">
            <div className="flex gap-2">
              {[
                { key: "progress", label: "진행중", count: progressCount },
                { key: "completed", label: "발표완료", count: completedCount },
                { key: "won", label: "당첨함", count: wonCount },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setEntryTab(tab.key)}
                  className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-colors ${
                    entryTab === tab.key
                      ? "bg-[#72C2FF] text-white"
                      : "bg-gray-100 text-gray-500"
                  }`}
                >
                  {tab.label}
                  <span className={`ml-1 text-xs ${entryTab === tab.key ? "text-white/80" : "text-gray-400"}`}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* 목록 */}
          <div className="flex-1 overflow-y-auto bg-[#F5F6F8] p-4 space-y-3">
            {filteredEntries.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-4xl">📋</span>
                </div>
                <p className="text-gray-500 mb-1">응모 내역이 없습니다</p>
                <p className="text-sm text-gray-400">이벤트에 참여해보세요!</p>
              </div>
            ) : (
              filteredEntries.map((entry) => (
                <EntryCard
                  key={entry.id}
                  entry={entry}
                  getPlatformIcon={getPlatformIcon}
                  showWonButton={entryTab === "completed" || entryTab === "won"}
                  onToggleWon={() => toggleWon(entry.id)}
                />
              ))
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 응모함 카드 =====
  const EntryCard = ({ entry, getPlatformIcon, showWonButton, onToggleWon }: any) => {
    const [isLiked, setIsLiked] = useState(false);
    const [isDisliked, setIsDisliked] = useState(false);
    const [showGiftPopup, setShowGiftPopup] = useState(false);

    const badge =
      entry.status === "completed"
        ? { text: "발표완료", color: "text-gray-400" }
        : { text: `D-${entry.dday}`, color: entry.dday <= 3 ? "text-red-500" : "text-[#72C2FF]" };

    return (
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer">
        <h3 className="font-bold text-gray-900 mb-2 line-clamp-2">{entry.title}</h3>

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-1.5">
            <span className="text-base">{getPlatformIcon(entry.platform)}</span>
            <span className={`px-2 py-0.5 rounded text-xs font-medium ${getTypeBadge(entry.type)}`}>
              {entry.type}
            </span>
            <span className="text-gray-300">·</span>
            <span className="text-sm text-gray-500">{entry.prize}</span>
            <span className="text-gray-300">·</span>
            <span className="text-xs text-gray-400">{entry.winners}명 당첨</span>
          </div>
          <span className={`text-xs font-medium ${badge.color}`}>{badge.text}</span>
        </div>

        <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-50">
          {/* 좋아요/싫어요, 댓글, 조회수, 후원 */}
          <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
            {/* 좋아요 */}
            <button
              onClick={() => { setIsLiked(!isLiked); if (isDisliked) setIsDisliked(false); }}
              className={`flex items-center gap-1 text-xs transition-colors ${isLiked ? "text-[#72C2FF]" : "text-gray-400"}`}
            >
              <svg className="w-4 h-4" fill={isLiked ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M14.25 9h2.25M5.904 18.75c.083.205.173.405.27.602.197.4-.078.898-.523.898h-.908c-.889 0-1.713-.518-1.972-1.368a12 12 0 01-.521-3.507c0-1.553.295-3.036.831-4.398C3.387 10.203 4.167 9.75 5 9.75h1.053c.472 0 .745.556.5.96a8.958 8.958 0 00-1.302 4.665c0 1.194.232 2.333.654 3.375z" />
              </svg>
              <span>{entry.likes + (isLiked ? 1 : 0)}</span>
            </button>
            {/* 싫어요 */}
            <button
              onClick={() => { setIsDisliked(!isDisliked); if (isLiked) setIsLiked(false); }}
              className={`flex items-center gap-1 text-xs transition-colors ${isDisliked ? "text-rose-400" : "text-gray-400"}`}
            >
              <svg className="w-4 h-4 rotate-180" fill={isDisliked ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M14.25 9h2.25M5.904 18.75c.083.205.173.405.27.602.197.4-.078.898-.523.898h-.908c-.889 0-1.713-.518-1.972-1.368a12 12 0 01-.521-3.507c0-1.553.295-3.036.831-4.398C3.387 10.203 4.167 9.75 5 9.75h1.053c.472 0 .745.556.5.96a8.958 8.958 0 00-1.302 4.665c0 1.194.232 2.333.654 3.375z" />
              </svg>
            </button>
            {/* 댓글 */}
            <div className="flex items-center gap-1 text-gray-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              <span className="text-xs">{entry.comments}</span>
            </div>
            {/* 조회수 */}
            <div className="flex items-center gap-1 text-gray-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              <span className="text-xs">{entry.views}</span>
            </div>
            {/* 후원 */}
            <button
              onClick={() => setShowGiftPopup(true)}
              className="flex items-center gap-1 text-gray-400 hover:text-amber-500 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
              </svg>
            </button>
          </div>

          {/* 당첨 버튼 */}
          <div onClick={(e) => e.stopPropagation()}>
            {showWonButton ? (
              <button
                onClick={onToggleWon}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-full transition-all ${
                  entry.isWon
                    ? "bg-gray-200 text-gray-500 hover:bg-gray-300"
                    : "bg-amber-400 text-white hover:bg-amber-500"
                }`}
              >
                {entry.isWon ? "당첨취소" : "당첨"}
              </button>
            ) : (
              <span className="text-xs text-gray-400">{entry.deadline} 마감</span>
            )}
          </div>
        </div>

        {showGiftPopup && (
          <div
            className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center"
            onClick={() => setShowGiftPopup(false)}
          >
            <div
              className="bg-white rounded-2xl p-6 w-72 text-center shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-4xl mb-3">🎁</div>
              <h3 className="font-bold text-gray-900 mb-1">후원하기</h3>
              <p className="text-sm text-gray-500 mb-4">이 이벤트를 후원할게요!</p>
              <button
                onClick={() => setShowGiftPopup(false)}
                className="w-full py-2.5 bg-[#72C2FF] text-white font-semibold rounded-xl"
              >
                확인
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  // ===== 이벤트 필터 모달 =====
  const EventFilterModal = () => {
    const [localFilters, setLocalFilters] = useState({ ...eventFilters });

    const prizeTypes = ["기프티콘", "상품권", "현금", "실물상품", "포인트", "기타"];
    const entryTypes = ["퀴즈", "댓글", "인증샷", "팔로우", "구매", "기타"];
    const platforms = ["인스타그램", "유튜브", "네이버", "카카오", "홈페이지", "APP전용"];

    const toggleFilter = (category: keyof typeof localFilters, value: string) => {
      setLocalFilters((prev) => ({
        ...prev,
        [category]: prev[category].includes(value)
          ? prev[category].filter((v) => v !== value)
          : [...prev[category], value],
      }));
    };

    const handleApply = () => {
      setEventFilters(localFilters);
      setShowEventFilter(false);
    };

    const handleReset = () => {
      setLocalFilters({ prizeTypes: [], entryTypes: [], platforms: [] });
    };

    if (!showEventFilter) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">필터</h3>
            <button
              onClick={() => setShowEventFilter(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* 경품 유형 */}
            <div>
              <h4 className="font-medium text-gray-700 mb-3">경품 유형</h4>
              <div className="flex flex-wrap gap-2">
                {prizeTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => toggleFilter("prizeTypes", type)}
                    className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                      localFilters.prizeTypes.includes(type)
                        ? "bg-[#72C2FF] text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* 참여 방식 */}
            <div>
              <h4 className="font-medium text-gray-700 mb-3">참여 방식</h4>
              <div className="flex flex-wrap gap-2">
                {entryTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => toggleFilter("entryTypes", type)}
                    className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                      localFilters.entryTypes.includes(type)
                        ? "bg-[#72C2FF] text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* 플랫폼 */}
            <div>
              <h4 className="font-medium text-gray-700 mb-3">플랫폼</h4>
              <div className="flex flex-wrap gap-2">
                {platforms.map((platform) => (
                  <button
                    key={platform}
                    onClick={() => toggleFilter("platforms", platform)}
                    className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                      localFilters.platforms.includes(platform)
                        ? "bg-[#72C2FF] text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {platform}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 하단 버튼 */}
          <div className="px-6 py-4 border-t border-gray-100 flex gap-3">
            <button
              onClick={handleReset}
              className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
            >
              초기화
            </button>
            <button
              onClick={handleApply}
              className="flex-1 py-3 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
            >
              적용하기
            </button>
          </div>
        </div>
      </div>
    );
  };

  // ===== 당첨 등록 모달 =====
  const WinnerRegisterModal = () => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
      name: "",
      phone: "",
      address: "",
      detailAddress: "",
      memo: "",
    });

    if (!showWinnerRegister || !winnerAnnouncement) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">당첨 등록</h3>
            <button
              onClick={() => {
                setShowWinnerRegister(false);
                setStep(1);
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {step === 1 && (
              <>
                <div className="bg-green-50 rounded-xl p-4 mb-6 text-center">
                  <span className="text-4xl mb-2 block">🎉</span>
                  <h4 className="text-lg font-bold text-green-700">축하합니다!</h4>
                  <p className="text-sm text-green-600 mt-1">{winnerAnnouncement.title}</p>
                  <p className="text-sm text-green-600">이벤트에 당첨되셨습니다.</p>
                </div>

                <div className="bg-gray-50 rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-500">당첨 경품</p>
                  <p className="text-lg font-bold text-gray-900">{winnerAnnouncement.prize}</p>
                </div>

                <button
                  onClick={() => setStep(2)}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  배송 정보 입력
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">이름</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="수령인 이름"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">연락처</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="010-0000-0000"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">주소</label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="주소 검색"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                    <input
                      type="text"
                      value={formData.detailAddress}
                      onChange={(e) => setFormData({ ...formData, detailAddress: e.target.value })}
                      placeholder="상세 주소"
                      className="w-full mt-2 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">배송 메모 (선택)</label>
                    <input
                      type="text"
                      value={formData.memo}
                      onChange={(e) => setFormData({ ...formData, memo: e.target.value })}
                      placeholder="배송 시 요청사항"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(1)}
                    className="flex-1 py-3.5 bg-gray-100 text-gray-700 rounded-xl font-medium"
                  >
                    이전
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    disabled={!formData.name || !formData.phone || !formData.address}
                    className="flex-1 py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium disabled:opacity-50"
                  >
                    등록하기
                  </button>
                </div>
              </>
            )}

            {step === 3 && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">등록 완료!</h3>
                <p className="text-gray-500 mb-6">배송 정보가 등록되었습니다.</p>
                <button
                  onClick={() => {
                    setShowWinnerRegister(false);
                    setWinnerAnnouncement(null);
                    setStep(1);
                  }}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  확인
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 정정 요청 모달 =====
  const CorrectionRequestModal = () => {
    const [reason, setReason] = useState("");
    const [submitted, setSubmitted] = useState(false);

    if (!showCorrectionRequest) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">정정 요청</h3>
            <button
              onClick={() => {
                setShowCorrectionRequest(false);
                setSubmitted(false);
                setReason("");
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {!submitted ? (
              <>
                <p className="text-sm text-gray-500 mb-4">
                  이벤트 정보에 오류가 있다면 정정을 요청해주세요.
                </p>
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="정정이 필요한 내용을 상세히 작성해주세요"
                  rows={5}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF] resize-none mb-4"
                />
                <button
                  onClick={() => setSubmitted(true)}
                  disabled={!reason.trim()}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium disabled:opacity-50"
                >
                  요청하기
                </button>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-2">요청이 접수되었습니다</h4>
                <p className="text-sm text-gray-500 mb-6">검토 후 수정될 예정입니다.</p>
                <button
                  onClick={() => {
                    setShowCorrectionRequest(false);
                    setSubmitted(false);
                    setReason("");
                  }}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  확인
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <EventDetailModal />
      <MyEntriesModal />
      <EventFilterModal />
      <WinnerRegisterModal />
      <CorrectionRequestModal />
    </>
  );
}
