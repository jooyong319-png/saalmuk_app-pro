// @ts-nocheck
import { useState, useEffect, useRef } from "react";
import type { LifeTechCtx, MarketItem, MyTrade } from "../types_v2";

interface Props {
  ctx: LifeTechCtx;
}

export default function MarketModals({ ctx }: Props) {
  const {
    showProductDetail,
    setShowProductDetail,
    showPurchaseFlow,
    setShowPurchaseFlow,
    purchaseStep,
    setPurchaseStep,
    selectedProduct,
    setSelectedProduct,
    isSeller,
    setIsSeller,
    showMyTrade,
    setShowMyTrade,
    myTradeTab,
    setMyTradeTab,
    showChat,
    setShowChat,
    chatMessages,
    setChatMessages,
    chatInput,
    setChatInput,
    chatPartner,
    setChatPartner,
    showDisputeModal,
    setShowDisputeModal,
    disputeReason,
    setDisputeReason,
    disputeEtcText,
    setDisputeEtcText,
    showTransactionDetail,
    setShowTransactionDetail,
    transactionStatus,
    setTransactionStatus,
    userStats,
    setUserStats,
    myTrades,
    setMyTrades,
    marketItems,
  } = ctx;

  // ===== 상품 상세 모달 =====
  const ProductDetailModal = () => {
    if (!showProductDetail) return null;

    const item = showProductDetail;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">상품 상세</h2>
            <button
              onClick={() => setShowProductDetail(null)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* 콘텐츠 */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* 브랜드 & 상품명 */}
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm font-medium text-[#72C2FF] bg-[#E8F4FD] px-3 py-1 rounded-full">
                {item.brand}
              </span>
              {item.dday <= 7 && item.status !== "sold" && (
                <span className="text-sm font-medium text-red-500 bg-red-50 px-3 py-1 rounded-full">
                  D-{item.dday}
                </span>
              )}
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">{item.name}</h3>

            {/* 가격 정보 */}
            <div className="bg-gradient-to-r from-[#72C2FF]/10 to-[#4A9FD9]/10 rounded-xl p-5 mb-6">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-sm text-gray-500 line-through">{item.originalPrice.toLocaleString()}원</p>
                  <p className="text-3xl font-bold text-[#72C2FF]">{item.price.toLocaleString()}원</p>
                </div>
                <span className="text-lg font-bold text-red-500">{item.discount}% OFF</span>
              </div>
            </div>

            {/* 판매자 정보 */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                    <span className="text-lg">👤</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{item.seller}</p>
                    <div className="flex items-center gap-1 text-sm text-gray-500">
                      <span className="text-amber-500">⭐</span>
                      <span>{item.rating}</span>
                      <span>·</span>
                      <span>거래 {item.trades}회</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setChatPartner(item.seller);
                    setChatMessages([
                      { id: 1, sender: "system", text: `${item.seller}님과의 대화가 시작되었습니다.`, time: "방금" },
                    ]);
                    setShowChat(true);
                  }}
                  className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50"
                >
                  채팅하기
                </button>
              </div>
            </div>

            {/* 상품 정보 */}
            <div className="space-y-3">
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">유효기간</span>
                <span className="text-gray-900">{item.validUntil}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">등록일</span>
                <span className="text-gray-900">{item.createdAt || "오늘"}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">상태</span>
                <span className={`font-medium ${item.status === "sold" ? "text-gray-400" : "text-green-500"}`}>
                  {item.status === "sold" ? "판매완료" : "판매중"}
                </span>
              </div>
            </div>

            {/* 안전거래 안내 */}
            <div className="mt-6 bg-sky-50 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <span className="text-xl">🔒</span>
                <div>
                  <h4 className="font-medium text-sky-800 mb-1">안전거래 (에스크로)</h4>
                  <p className="text-sm text-sky-700">
                    구매 확정 전까지 결제금액이 안전하게 보관됩니다.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 하단 버튼 */}
          {item.status !== "sold" && (
            <div className="px-6 py-4 border-t border-gray-100">
              <button
                onClick={() => {
                  setSelectedProduct(item);
                  setShowProductDetail(null);
                  setPurchaseStep(1);
                  setShowPurchaseFlow(true);
                }}
                className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
              >
                구매하기
              </button>
            </div>
          )}
        </div>
      </div>
    );
  };

  // ===== 구매 플로우 모달 =====
  const PurchaseFlowModal = () => {
    if (!showPurchaseFlow || !selectedProduct) return null;

    const item = selectedProduct;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">
              {purchaseStep === 1 && "구매 확인"}
              {purchaseStep === 2 && "결제하기"}
              {purchaseStep === 3 && "구매 완료"}
            </h3>
            <button
              onClick={() => {
                setShowPurchaseFlow(false);
                setPurchaseStep(1);
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {purchaseStep === 1 && (
              <>
                <div className="bg-gray-50 rounded-xl p-4 mb-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-[#72C2FF] bg-[#E8F4FD] px-2 py-0.5 rounded-full">
                      {item.brand}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900">{item.name}</h4>
                  <p className="text-sm text-gray-500 mt-1">유효기간: {item.validUntil}</p>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between">
                    <span className="text-gray-500">상품 금액</span>
                    <span className="text-gray-900">{item.price.toLocaleString()}원</span>
                  </div>
                  <div className="flex justify-between pt-3 border-t border-gray-100">
                    <span className="font-medium text-gray-700">결제 금액</span>
                    <span className="font-bold text-[#72C2FF] text-xl">{item.price.toLocaleString()}원</span>
                  </div>
                </div>

                <div className="bg-amber-50 rounded-xl p-3 mb-6">
                  <p className="text-sm text-amber-700">
                    ⚠️ 구매 확정 전까지 에스크로로 보관됩니다.
                  </p>
                </div>

                <button
                  onClick={() => setPurchaseStep(2)}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  결제하기
                </button>
              </>
            )}

            {purchaseStep === 2 && (
              <>
                <div className="text-center mb-6">
                  <p className="text-sm text-gray-500">결제 금액</p>
                  <p className="text-3xl font-bold text-gray-900">{item.price.toLocaleString()}원</p>
                </div>

                <div className="bg-gray-50 rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-500 mb-1">보유 캐시</p>
                  <p className="text-xl font-bold text-[#72C2FF]">{userStats.ssalmukCash.toLocaleString()}원</p>
                  {userStats.ssalmukCash < item.price && (
                    <p className="text-sm text-red-500 mt-2">잔액이 부족합니다. 충전 후 이용해주세요.</p>
                  )}
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setPurchaseStep(1)}
                    className="flex-1 py-3.5 bg-gray-100 text-gray-700 rounded-xl font-medium"
                  >
                    이전
                  </button>
                  <button
                    onClick={() => {
                      if (userStats.ssalmukCash >= item.price) {
                        setUserStats((prev) => ({
                          ...prev,
                          ssalmukCash: prev.ssalmukCash - item.price,
                          escrowCash: prev.escrowCash + item.price,
                        }));
                        setPurchaseStep(3);
                      }
                    }}
                    disabled={userStats.ssalmukCash < item.price}
                    className="flex-1 py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium disabled:opacity-50"
                  >
                    결제하기
                  </button>
                </div>
              </>
            )}

            {purchaseStep === 3 && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">구매 완료!</h3>
                <p className="text-gray-500 mb-6">
                  쿠폰이 내 쿠폰함에 추가되었습니다.<br />
                  사용 후 구매확정을 눌러주세요.
                </p>
                <button
                  onClick={() => {
                    setShowPurchaseFlow(false);
                    setPurchaseStep(1);
                    setSelectedProduct(null);
                  }}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  확인
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 내 거래 모달 =====
  const MyTradeModal = () => {
    if (!showMyTrade) return null;

    const currentTrades = myTradeTab === "buying" ? myTrades.buying : myTrades.selling;

    const getStatusBadge = (status: string) => {
      switch (status) {
        case "waiting":
          return { text: "판매중", color: "bg-blue-100 text-blue-600" };
        case "escrow":
          return { text: "거래중", color: "bg-amber-100 text-amber-600" };
        case "completed":
          return { text: "거래완료", color: "bg-green-100 text-green-600" };
        case "settled":
          return { text: "정산완료", color: "bg-gray-100 text-gray-600" };
        default:
          return { text: status, color: "bg-gray-100 text-gray-600" };
      }
    };

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">내 거래</h2>
            <button
              onClick={() => setShowMyTrade(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* 탭 */}
          <div className="flex border-b border-gray-100">
            {[
              { key: "buying", label: "구매 내역" },
              { key: "selling", label: "판매 내역" },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setMyTradeTab(tab.key)}
                className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
                  myTradeTab === tab.key ? "text-[#72C2FF]" : "text-gray-500"
                }`}
              >
                {tab.label}
                {myTradeTab === tab.key && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-0.5 bg-[#72C2FF] rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* 목록 */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {currentTrades.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🛒</span>
                </div>
                <p className="text-gray-500">거래 내역이 없습니다</p>
              </div>
            ) : (
              currentTrades.map((trade) => {
                const badge = getStatusBadge(trade.status);
                return (
                  <div
                    key={trade.id}
                    className="bg-white rounded-xl p-4 border border-gray-100 hover:shadow-md transition-all cursor-pointer"
                    onClick={() => {
                      setTransactionStatus(trade.status);
                      setShowTransactionDetail(true);
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-[#72C2FF] bg-[#E8F4FD] px-2 py-0.5 rounded-full">
                            {trade.brand}
                          </span>
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${badge.color}`}>
                            {badge.text}
                          </span>
                        </div>
                        <h4 className="font-medium text-gray-900">{trade.name}</h4>
                        <p className="text-lg font-bold text-gray-900 mt-1">{trade.price.toLocaleString()}원</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                      <span className="text-xs text-gray-400">{trade.date}</span>
                      <div className="flex gap-2">
                        {trade.status === "escrow" && myTradeTab === "buying" && (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowDisputeModal(true);
                              }}
                              className="px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-medium"
                            >
                              신고
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                // 구매확정 처리
                                setUserStats((prev) => ({
                                  ...prev,
                                  escrowCash: prev.escrowCash - trade.price,
                                }));
                                setMyTrades((prev) => ({
                                  ...prev,
                                  buying: prev.buying.map((t) =>
                                    t.id === trade.id ? { ...t, status: "completed" } : t
                                  ),
                                }));
                              }}
                              className="px-3 py-1.5 bg-[#72C2FF] text-white rounded-lg text-xs font-medium"
                            >
                              구매확정
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 채팅 모달 =====
  const ChatModal = () => {
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [chatMessages]);

    const handleSend = () => {
      if (!chatInput.trim()) return;

      const newMessage = {
        id: Date.now(),
        sender: "me",
        text: chatInput,
        time: new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" }),
      };

      setChatMessages((prev: any[]) => [...prev, newMessage]);
      setChatInput("");

      // 자동 응답 시뮬레이션
      setTimeout(() => {
        setChatMessages((prev: any[]) => [
          ...prev,
          {
            id: Date.now() + 1,
            sender: "other",
            text: "네, 확인했습니다! 🙂",
            time: new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" }),
          },
        ]);
      }, 1000);
    };

    if (!showChat) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md h-[600px] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                <span className="text-lg">👤</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">{chatPartner}</p>
                <p className="text-xs text-green-500">온라인</p>
              </div>
            </div>
            <button
              onClick={() => setShowChat(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* 메시지 영역 */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
            {chatMessages.map((msg: any) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === "me" ? "justify-end" : msg.sender === "system" ? "justify-center" : "justify-start"}`}
              >
                {msg.sender === "system" ? (
                  <div className="text-xs text-gray-400 bg-white px-3 py-1.5 rounded-full">
                    {msg.text}
                  </div>
                ) : (
                  <div
                    className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                      msg.sender === "me"
                        ? "bg-[#72C2FF] text-white rounded-br-sm"
                        : "bg-white text-gray-900 rounded-bl-sm"
                    }`}
                  >
                    <p className="text-sm">{msg.text}</p>
                    <p className={`text-xs mt-1 ${msg.sender === "me" ? "text-white/70" : "text-gray-400"}`}>
                      {msg.time}
                    </p>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* 입력 영역 */}
          <div className="p-3 border-t border-gray-100 bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                placeholder="메시지를 입력하세요"
                className="flex-1 px-4 py-2.5 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#72C2FF]/50"
              />
              <button
                onClick={handleSend}
                disabled={!chatInput.trim()}
                className="w-10 h-10 bg-[#72C2FF] text-white rounded-full flex items-center justify-center disabled:opacity-50"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ===== 분쟁 신고 모달 =====
  const DisputeModal = () => {
    const reasons = [
      "바코드가 이미 사용됨",
      "유효기간이 지남",
      "상품 정보와 다름",
      "판매자 연락 불가",
      "기타",
    ];

    const handleSubmit = () => {
      alert("신고가 접수되었습니다. 검토 후 안내드리겠습니다.");
      setShowDisputeModal(false);
      setDisputeReason("");
      setDisputeEtcText("");
    };

    if (!showDisputeModal) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">거래 신고</h3>
            <button
              onClick={() => {
                setShowDisputeModal(false);
                setDisputeReason("");
                setDisputeEtcText("");
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            <p className="text-sm text-gray-500 mb-4">신고 사유를 선택해주세요.</p>

            <div className="space-y-2 mb-4">
              {reasons.map((reason) => (
                <button
                  key={reason}
                  onClick={() => setDisputeReason(reason)}
                  className={`w-full p-3 rounded-xl text-left transition-all ${
                    disputeReason === reason
                      ? "bg-[#E8F4FD] border-2 border-[#72C2FF]"
                      : "bg-gray-50 border-2 border-transparent hover:bg-gray-100"
                  }`}
                >
                  <span className="text-sm font-medium text-gray-900">{reason}</span>
                </button>
              ))}
            </div>

            {disputeReason === "기타" && (
              <textarea
                value={disputeEtcText}
                onChange={(e) => setDisputeEtcText(e.target.value)}
                placeholder="상세 내용을 입력해주세요"
                rows={3}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF] resize-none mb-4"
              />
            )}

            <button
              onClick={handleSubmit}
              disabled={!disputeReason || (disputeReason === "기타" && !disputeEtcText.trim())}
              className="w-full py-3.5 bg-red-500 text-white rounded-xl font-medium hover:bg-red-600 disabled:opacity-50"
            >
              신고하기
            </button>
          </div>
        </div>
      </div>
    );
  };

  // ===== 거래 상세 모달 =====
  const TransactionDetailModal = () => {
    if (!showTransactionDetail) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">거래 상세</h3>
            <button
              onClick={() => setShowTransactionDetail(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {/* 거래 진행 상태 */}
            <div className="mb-6">
              <h4 className="font-medium text-gray-700 mb-3">거래 진행 상태</h4>
              <div className="flex items-center justify-between">
                {["결제", "에스크로", "구매확정", "정산"].map((step, idx) => {
                  const steps = ["waiting", "escrow", "completed", "settled"];
                  const currentIdx = steps.indexOf(transactionStatus);
                  const isActive = idx <= currentIdx;
                  const isCurrent = idx === currentIdx;

                  return (
                    <div key={step} className="flex flex-col items-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center mb-1 ${
                          isCurrent
                            ? "bg-[#72C2FF] text-white"
                            : isActive
                            ? "bg-green-100 text-green-600"
                            : "bg-gray-100 text-gray-400"
                        }`}
                      >
                        {isActive && idx < currentIdx ? (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        ) : (
                          <span className="text-sm font-bold">{idx + 1}</span>
                        )}
                      </div>
                      <span className={`text-xs ${isCurrent ? "text-[#72C2FF] font-medium" : "text-gray-500"}`}>
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-4 mb-4">
              <p className="text-sm text-gray-600">
                {transactionStatus === "waiting" && "구매자를 기다리고 있습니다."}
                {transactionStatus === "escrow" && "구매자가 결제를 완료했습니다. 구매확정을 기다리고 있습니다."}
                {transactionStatus === "completed" && "구매확정이 완료되었습니다. 정산이 진행됩니다."}
                {transactionStatus === "settled" && "정산이 완료되었습니다."}
              </p>
            </div>

            <button
              onClick={() => setShowTransactionDetail(false)}
              className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
            >
              확인
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <ProductDetailModal />
      <PurchaseFlowModal />
      <MyTradeModal />
      <ChatModal />
      <DisputeModal />
      <TransactionDetailModal />
    </>
  );
}
