// @ts-nocheck
import { useState } from "react";
import type { LifeTechCtx, PointSource } from "../types_v2";
import LikeDislikeButton from "../../gallery/LikeDislikeButton";
import GiftPopup from "../../gallery/GiftPopup";

interface Props {
  ctx: LifeTechCtx;
}

export default function PointDetailModal({ ctx }: Props) {
  const {
    showPointDetail,
    setShowPointDetail,
    setPointSources,
  } = ctx;

  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [showGift, setShowGift] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  if (!showPointDetail) return null;

  const source = showPointDetail;

  // 제목에서 [브랜드] 추출
  const brandMatch = source.title.match(/^\[([^\]]+)\]/);
  const brand = brandMatch ? brandMatch[1] : null;
  const titleRest = brandMatch
    ? source.title.slice(brandMatch[0].length).trim()
    : source.title;

  // 마감/마감취소 토글 핸들러
  const handleDeadline = () => {
    const newStatus = source.status === "ended" ? "" : "ended";

    setPointSources((prev: PointSource[]) =>
      prev.map((s) =>
        s.id === source.id ? { ...s, status: newStatus } : s
      )
    );

    setShowPointDetail({ ...source, status: newStatus });
    setShowMoreMenu(false);
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <div className="flex items-center gap-2">
              {brand && (
                <span className="text-sm font-medium text-[#72C2FF] bg-[#E8F4FD] px-3 py-1 rounded-full">
                  {brand}
                </span>
              )}
              {source.status === "ended" && (
                <span className="text-sm font-medium text-white bg-gray-400 px-3 py-1 rounded-full">
                  마감
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              {/* 더보기 메뉴 */}
              <div className="relative">
                <button
                  onClick={() => setShowMoreMenu(!showMoreMenu)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                  </svg>
                </button>
                {showMoreMenu && (
                  <>
                    <div
                      className="fixed inset-0 z-10"
                      onClick={() => setShowMoreMenu(false)}
                    />
                    <div className="absolute right-0 top-full mt-1 w-36 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-20">
                      <button
                        onClick={handleDeadline}
                        className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50"
                      >
                        {source.status === "ended" ? "마감취소" : "마감처리"}
                      </button>
                      <button className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50">
                        신고하기
                      </button>
                    </div>
                  </>
                )}
              </div>
              <button
                onClick={() => setShowPointDetail(null)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* 콘텐츠 */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* 제목 */}
            <h2 className="text-xl font-bold text-gray-900 mb-4">{titleRest}</h2>

            {/* 설명 */}
            <p className="text-gray-600 mb-6 leading-relaxed">{source.desc}</p>

            {/* 리워드 정보 */}
            <div className="bg-gradient-to-r from-[#72C2FF]/10 to-[#4A9FD9]/10 rounded-xl p-5 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">예상 리워드</p>
                  <p className="text-2xl font-bold text-[#72C2FF]">{source.reward}</p>
                </div>
                <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center text-3xl shadow-sm">
                  {source.icon}
                </div>
              </div>
            </div>

            {/* 상세 정보 */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">카테고리</span>
                <span className="text-gray-900 font-medium">{source.category}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">등록일</span>
                <span className="text-gray-900">{source.createdAt || "오늘"}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span className="text-gray-500">조회수</span>
                <span className="text-gray-900">{(source.views || 0).toLocaleString()}</span>
              </div>
            </div>

            {/* 인터랙션 바 */}
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <div className="flex items-center gap-4">
                <LikeDislikeButton
                  likes={source.likes || 0}
                  dislikes={0}
                  isLiked={isLiked}
                  isDisliked={isDisliked}
                  onLike={() => {
                    setIsLiked(!isLiked);
                    if (isDisliked) setIsDisliked(false);
                  }}
                  onDislike={() => {
                    setIsDisliked(!isDisliked);
                    if (isLiked) setIsLiked(false);
                  }}
                  size="md"
                />
                <button className="flex items-center gap-1.5 text-gray-500 hover:text-gray-700">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  <span className="text-sm">{source.comments || 0}</span>
                </button>
                <button
                  onClick={() => setShowGift(true)}
                  className="flex items-center gap-1.5 text-gray-500 hover:text-amber-500 transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                  </svg>
                  <span className="text-sm">후원</span>
                </button>
              </div>
              <button className="flex items-center gap-1.5 text-gray-500 hover:text-gray-700">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
                <span className="text-sm">공유</span>
              </button>
            </div>
          </div>

          {/* 하단 버튼 */}
          <div className="px-6 py-4 border-t border-gray-100">
            <button
              onClick={() => window.open("#", "_blank")}
              className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
            >
              바로가기
            </button>
          </div>
        </div>
      </div>

      {showGift && <GiftPopup onClose={() => setShowGift(false)} />}
    </>
  );
}
