// @ts-nocheck
import { useState } from "react";

interface Props {
  showSearchModal: boolean;
  setShowSearchModal: (v: boolean) => void;
}

export default function SearchModal({ showSearchModal, setShowSearchModal }: Props) {
  const [query, setQuery] = useState("");
  const [recentSearches] = useState(["스타벅스", "CU 이벤트", "토스 만보기", "설문조사"]);

  if (!showSearchModal) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-[500] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
        <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-100">
          <div className="flex-1 relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="이벤트, 앱테크, 설문조사 검색"
              autoFocus
              className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#72C2FF]"
            />
          </div>
          <button onClick={() => setShowSearchModal(false)} className="text-gray-500 hover:text-gray-700 text-sm font-medium">
            취소
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-gray-500">최근 검색어</h3>
            <button className="text-xs text-gray-400 hover:text-gray-600">전체 삭제</button>
          </div>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((term, i) => (
              <button
                key={i}
                onClick={() => setQuery(term)}
                className="px-3 py-1.5 bg-gray-100 text-gray-600 rounded-full text-sm hover:bg-gray-200 transition-colors"
              >
                {term}
              </button>
            ))}
          </div>

          <div className="mt-8">
            <h3 className="text-sm font-medium text-gray-500 mb-3">인기 검색어</h3>
            <div className="space-y-2">
              {["스타벅스 이벤트", "토스 만보기", "CU 행운퀴즈", "설문조사 추천", "기프티콘 할인"].map((term, i) => (
                <button
                  key={i}
                  onClick={() => setQuery(term)}
                  className="flex items-center gap-3 w-full py-2 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i < 3 ? "bg-[#72C2FF] text-white" : "bg-gray-200 text-gray-600"}`}>
                    {i + 1}
                  </span>
                  <span className="text-gray-700">{term}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
