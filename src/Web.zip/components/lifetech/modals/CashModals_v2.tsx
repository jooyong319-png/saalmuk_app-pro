// @ts-nocheck
import { useState } from "react";
import type { LifeTechCtx } from "../types_v2";

interface Props {
  ctx: LifeTechCtx;
}

export default function CashModals({ ctx }: Props) {
  const {
    showMyCash,
    setShowMyCash,
    showChargeModal,
    setShowChargeModal,
    chargeStep,
    setChargeStep,
    chargeAmount,
    setChargeAmount,
    showWithdrawModal,
    setShowWithdrawModal,
    withdrawStep,
    setWithdrawStep,
    withdrawAmount,
    setWithdrawAmount,
    showBankChange,
    setShowBankChange,
    showCashHistory,
    setShowCashHistory,
    cashHistory,
    userStats,
    setUserStats,
  } = ctx;

  // ===== 내 캐시 모달 =====
  const MyCashModal = () => {
    const [bankAccounts] = useState([
      { id: 1, bank: "카카오뱅크", bankCode: "카카오", account: "3333-01-******", color: "bg-yellow-400", isDefault: true },
      { id: 2, bank: "국민은행", bankCode: "국민", account: "000012-**-**1323", color: "bg-amber-500", isDefault: false },
    ]);

    if (!showMyCash) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">내 캐시</h2>
            <button
              onClick={() => setShowMyCash(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {/* 보유 캐시 카드 */}
            <div className="bg-gradient-to-br from-[#72C2FF] to-[#4A9FD9] rounded-2xl p-6 text-white mb-6 relative overflow-hidden">
              <div className="absolute top-4 right-4 w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <p className="text-sm opacity-80">보유 캐시</p>
              <p className="text-3xl font-bold mt-1">{userStats.ssalmukCash.toLocaleString()} 원</p>

              <div className="flex gap-3 mt-5">
                <button
                  onClick={() => {
                    setShowMyCash(false);
                    setChargeStep(1);
                    setChargeAmount(0);
                    setShowChargeModal(true);
                  }}
                  className="flex-1 py-3 bg-white text-[#72C2FF] font-semibold rounded-xl flex items-center justify-center gap-2"
                >
                  + 충전하기
                </button>
                <button
                  onClick={() => {
                    setShowMyCash(false);
                    setWithdrawStep(1);
                    setWithdrawAmount(0);
                    setShowWithdrawModal(true);
                  }}
                  className="flex-1 py-3 bg-[#4A9FD9] text-white font-semibold rounded-xl flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  출금하기
                </button>
              </div>
            </div>

            {/* 캐시 상세 */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="bg-gray-50 rounded-xl p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">출금가능</p>
                <p className="text-lg font-bold text-gray-900">
                  {(userStats.ssalmukCash - userStats.escrowCash - userStats.purchaseDeposit).toLocaleString()}
                </p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">구매예치금</p>
                <p className="text-lg font-bold text-[#72C2FF]">{userStats.purchaseDeposit.toLocaleString()}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">거래중</p>
                <p className="text-lg font-bold text-[#72C2FF]">{userStats.escrowCash.toLocaleString()}</p>
              </div>
            </div>

            {/* 출금 계좌 */}
            <div className="bg-white rounded-xl border border-gray-100 p-4 mb-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-900">출금 계좌</h3>
                <button
                  onClick={() => {
                    setShowMyCash(false);
                    setShowBankChange(true);
                  }}
                  className="text-[#72C2FF] text-sm font-medium"
                >
                  관리
                </button>
              </div>
              <div className="space-y-2">
                {bankAccounts.map((account) => (
                  <div key={account.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className={`w-10 h-10 ${account.color} rounded-lg flex items-center justify-center text-white text-xs font-bold`}>
                      {account.bankCode}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{account.bank}</p>
                      <p className="text-sm text-gray-500">{account.account}</p>
                    </div>
                    {account.isDefault && (
                      <span className="px-2 py-1 bg-[#E8F4FD] text-[#72C2FF] text-xs font-medium rounded">기본</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 최근 거래 */}
            <div className="bg-white rounded-xl border border-gray-100 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-900">최근 거래</h3>
                <button
                  onClick={() => {
                    setShowMyCash(false);
                    setShowCashHistory(true);
                  }}
                  className="text-[#72C2FF] text-sm font-medium"
                >
                  전체보기
                </button>
              </div>
              <div className="space-y-3">
                {cashHistory.slice(0, 5).map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${
                        tx.type === "+" ? "bg-blue-50" : "bg-pink-50"
                      }`}>
                        {tx.icon}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{tx.title}</p>
                        <p className="text-xs text-gray-400">{tx.date}</p>
                      </div>
                    </div>
                    <p className={`font-bold ${tx.type === "+" ? "text-blue-500" : "text-gray-900"}`}>
                      {tx.type}{tx.amount.toLocaleString()}원
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ===== 충전 모달 =====
  const ChargeModal = () => {
    const quickAmounts = [5000, 10000, 30000, 50000, 100000];
    const [paymentMethod, setPaymentMethod] = useState("card");

    if (!showChargeModal) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">캐시 충전</h3>
            <button
              onClick={() => {
                setShowChargeModal(false);
                setChargeStep(1);
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {chargeStep === 1 && (
              <>
                <div className="bg-[#E8F4FD] rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-600">현재 보유 캐시</p>
                  <p className="text-2xl font-bold text-[#72C2FF]">{userStats.ssalmukCash.toLocaleString()}원</p>
                </div>

                <h4 className="font-medium text-gray-700 mb-3">충전 금액</h4>
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {quickAmounts.map((amt) => (
                    <button
                      key={amt}
                      onClick={() => setChargeAmount(amt)}
                      className={`py-3 rounded-xl text-sm font-medium transition-all ${
                        chargeAmount === amt
                          ? "bg-[#72C2FF] text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {amt.toLocaleString()}원
                    </button>
                  ))}
                </div>

                <div className="relative mb-6">
                  <input
                    type="number"
                    value={chargeAmount || ""}
                    onChange={(e) => setChargeAmount(Number(e.target.value))}
                    placeholder="직접 입력"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF] text-right pr-12"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">원</span>
                </div>

                <button
                  onClick={() => setChargeStep(2)}
                  disabled={!chargeAmount || chargeAmount < 1000}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  다음
                </button>
              </>
            )}

            {chargeStep === 2 && (
              <>
                <div className="text-center mb-6">
                  <p className="text-sm text-gray-500">충전 금액</p>
                  <p className="text-3xl font-bold text-gray-900">{chargeAmount.toLocaleString()}원</p>
                </div>

                <h4 className="font-medium text-gray-700 mb-3">결제 수단</h4>
                <div className="space-y-2 mb-6">
                  {[
                    { id: "card", label: "신용/체크카드", icon: "💳" },
                    { id: "kakao", label: "카카오페이", icon: "💛" },
                    { id: "toss", label: "토스페이", icon: "💙" },
                    { id: "bank", label: "계좌이체", icon: "🏦" },
                  ].map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setPaymentMethod(method.id)}
                      className={`w-full p-4 rounded-xl flex items-center gap-3 transition-all ${
                        paymentMethod === method.id
                          ? "bg-[#E8F4FD] border-2 border-[#72C2FF]"
                          : "bg-gray-50 border-2 border-transparent"
                      }`}
                    >
                      <span className="text-xl">{method.icon}</span>
                      <span className="font-medium text-gray-900">{method.label}</span>
                    </button>
                  ))}
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setChargeStep(1)}
                    className="flex-1 py-3.5 bg-gray-100 text-gray-700 rounded-xl font-medium"
                  >
                    이전
                  </button>
                  <button
                    onClick={() => {
                      setUserStats((prev) => ({
                        ...prev,
                        ssalmukCash: prev.ssalmukCash + chargeAmount,
                      }));
                      setChargeStep(3);
                    }}
                    className="flex-1 py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                  >
                    충전하기
                  </button>
                </div>
              </>
            )}

            {chargeStep === 3 && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">충전 완료!</h3>
                <p className="text-gray-500 mb-6">{chargeAmount.toLocaleString()}원이 충전되었습니다.</p>
                <button
                  onClick={() => {
                    setShowChargeModal(false);
                    setChargeStep(1);
                    setChargeAmount(0);
                  }}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  확인
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 출금 모달 =====
  const WithdrawModal = () => {
    const availableAmount = userStats.ssalmukCash - userStats.escrowCash - userStats.purchaseDeposit;
    const quickAmounts = [10000, 30000, 50000, availableAmount];

    if (!showWithdrawModal) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-bold">출금</h3>
            <button
              onClick={() => {
                setShowWithdrawModal(false);
                setWithdrawStep(1);
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {withdrawStep === 1 && (
              <>
                <div className="bg-[#E8F4FD] rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-600">출금 가능 금액</p>
                  <p className="text-2xl font-bold text-[#72C2FF]">{availableAmount.toLocaleString()}원</p>
                </div>

                <div className="bg-amber-50 rounded-xl p-3 mb-4">
                  <p className="text-sm text-amber-700">⚠️ 출금 수수료 3% 차감 후 입금됩니다.</p>
                </div>

                <h4 className="font-medium text-gray-700 mb-3">출금 금액</h4>
                <div className="grid grid-cols-2 gap-2 mb-4">
                  {quickAmounts.map((amt, i) => (
                    <button
                      key={i}
                      onClick={() => setWithdrawAmount(Math.min(amt, availableAmount))}
                      className={`py-3 rounded-xl text-sm font-medium transition-all ${
                        withdrawAmount === amt
                          ? "bg-[#72C2FF] text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {i === 3 ? "전액" : `${amt.toLocaleString()}원`}
                    </button>
                  ))}
                </div>

                <div className="relative mb-6">
                  <input
                    type="number"
                    value={withdrawAmount || ""}
                    onChange={(e) => setWithdrawAmount(Math.min(Number(e.target.value), availableAmount))}
                    placeholder="직접 입력"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF] text-right pr-12"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">원</span>
                </div>

                {withdrawAmount > 0 && (
                  <div className="bg-gray-50 rounded-xl p-4 mb-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">출금 금액</span>
                      <span className="text-gray-900">{withdrawAmount.toLocaleString()}원</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">수수료 (3%)</span>
                      <span className="text-red-500">-{Math.floor(withdrawAmount * 0.03).toLocaleString()}원</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-gray-200">
                      <span className="font-medium text-gray-700">실 입금액</span>
                      <span className="font-bold text-[#72C2FF]">{Math.floor(withdrawAmount * 0.97).toLocaleString()}원</span>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => setWithdrawStep(2)}
                  disabled={!withdrawAmount || withdrawAmount < 1000}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  출금 신청
                </button>
              </>
            )}

            {withdrawStep === 2 && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">출금 신청 완료</h3>
                <p className="text-gray-500 mb-2">
                  {Math.floor(withdrawAmount * 0.97).toLocaleString()}원이<br />
                  {userStats.bankName} {userStats.bankAccount}로<br />
                  입금 예정입니다.
                </p>
                <p className="text-sm text-gray-400 mb-6">영업일 기준 1-2일 소요</p>
                <button
                  onClick={() => {
                    setUserStats((prev) => ({
                      ...prev,
                      ssalmukCash: prev.ssalmukCash - withdrawAmount,
                    }));
                    setShowWithdrawModal(false);
                    setWithdrawStep(1);
                    setWithdrawAmount(0);
                  }}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  확인
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 계좌 변경 모달 =====
  const BankChangeModal = () => {
    const [selectedBank, setSelectedBank] = useState(userStats.bankName);
    const [accountNumber, setAccountNumber] = useState("");
    const [accountHolder, setAccountHolder] = useState("");
    const [step, setStep] = useState(1);

    const banks = [
      { name: "카카오뱅크", icon: "💛" },
      { name: "토스뱅크", icon: "💙" },
      { name: "국민은행", icon: "⭐" },
      { name: "신한은행", icon: "💚" },
      { name: "우리은행", icon: "💜" },
      { name: "하나은행", icon: "🩵" },
      { name: "NH농협", icon: "💚" },
      { name: "기업은행", icon: "🔵" },
    ];

    if (!showBankChange) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-y-auto animate-scaleIn">
          <div className="sticky top-0 bg-white flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <button
              onClick={() => {
                if (step > 1) setStep(step - 1);
                else setShowBankChange(false);
              }}
              className="p-1 hover:bg-gray-100 rounded-full"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <h3 className="text-lg font-bold">
              {step === 1 && "출금 계좌 변경"}
              {step === 2 && "계좌 정보 입력"}
              {step === 3 && "변경 완료"}
            </h3>
            <button onClick={() => setShowBankChange(false)} className="p-1 hover:bg-gray-100 rounded-full">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-6">
            {step === 1 && (
              <>
                <div className="bg-gray-50 rounded-xl p-4 mb-6">
                  <p className="text-xs text-gray-500">현재 등록된 계좌</p>
                  <p className="font-medium text-gray-900 mt-1">{userStats.bankName} {userStats.bankAccount}</p>
                </div>

                <h4 className="font-medium text-gray-700 mb-3">은행 선택</h4>
                <div className="grid grid-cols-4 gap-3 mb-6">
                  {banks.map((bank) => (
                    <button
                      key={bank.name}
                      onClick={() => setSelectedBank(bank.name)}
                      className={`p-3 rounded-xl flex flex-col items-center gap-1 transition-all ${
                        selectedBank === bank.name
                          ? "bg-[#E8F4FD] border-2 border-[#72C2FF]"
                          : "bg-gray-50 border-2 border-transparent hover:bg-gray-100"
                      }`}
                    >
                      <span className="text-2xl">{bank.icon}</span>
                      <span className="text-xs text-gray-700 font-medium">{bank.name}</span>
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setStep(2)}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  다음
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <div className="bg-[#E8F4FD] rounded-xl p-4 mb-6 flex items-center gap-3">
                  <span className="text-2xl">{banks.find((b) => b.name === selectedBank)?.icon}</span>
                  <span className="font-medium text-[#72C2FF]">{selectedBank}</span>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">계좌번호</label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="계좌번호 입력 ('-' 제외)"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">예금주명</label>
                    <input
                      type="text"
                      value={accountHolder}
                      onChange={(e) => setAccountHolder(e.target.value)}
                      placeholder="예금주명 입력"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                    />
                  </div>
                </div>

                <div className="bg-amber-50 rounded-xl p-3 mb-6">
                  <p className="text-sm text-amber-700">⚠️ 본인 명의의 계좌만 등록 가능합니다.</p>
                </div>

                <button
                  onClick={() => {
                    if (accountNumber && accountHolder) {
                      setUserStats((prev) => ({
                        ...prev,
                        bankName: selectedBank,
                        bankAccount: accountNumber.slice(0, 7) + "-******",
                      }));
                      setStep(3);
                    }
                  }}
                  disabled={!accountNumber || !accountHolder}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium disabled:opacity-50"
                >
                  계좌 인증하기
                </button>
              </>
            )}

            {step === 3 && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">계좌 변경 완료</h3>
                <p className="text-gray-500 mb-6">{selectedBank} {userStats.bankAccount}</p>
                <button
                  onClick={() => {
                    setShowBankChange(false);
                    setStep(1);
                  }}
                  className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-medium"
                >
                  확인
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ===== 캐시 내역 모달 =====
  const CashHistoryModal = () => {
    const [filter, setFilter] = useState("all");

    const filteredHistory = cashHistory.filter((h) => {
      if (filter === "all") return true;
      if (filter === "charge") return h.type === "+" && h.title.includes("충전");
      if (filter === "withdraw") return h.type === "-" && h.title.includes("출금");
      if (filter === "trade") return h.title.includes("구매") || h.title.includes("판매");
      return true;
    });

    if (!showCashHistory) return null;

    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">캐시 내역</h2>
            <button
              onClick={() => setShowCashHistory(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="flex border-b border-gray-100 px-4">
            {[
              { key: "all", label: "전체" },
              { key: "charge", label: "충전" },
              { key: "withdraw", label: "출금" },
              { key: "trade", label: "거래" },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key)}
                className={`px-4 py-3 text-sm font-medium transition-colors relative ${
                  filter === tab.key ? "text-[#72C2FF]" : "text-gray-500"
                }`}
              >
                {tab.label}
                {filter === tab.key && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-[#72C2FF] rounded-full" />
                )}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {filteredHistory.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">💰</span>
                </div>
                <p className="text-gray-500">내역이 없습니다</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredHistory.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${
                        tx.type === "+" ? "bg-blue-100" : "bg-pink-100"
                      }`}>
                        {tx.icon}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{tx.title}</p>
                        <p className="text-xs text-gray-400">{tx.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${tx.type === "+" ? "text-blue-500" : "text-gray-900"}`}>
                        {tx.type}{tx.amount.toLocaleString()}원
                      </p>
                      <p className="text-xs text-gray-400">{tx.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <MyCashModal />
      <ChargeModal />
      <WithdrawModal />
      <BankChangeModal />
      <CashHistoryModal />
    </>
  );
}
