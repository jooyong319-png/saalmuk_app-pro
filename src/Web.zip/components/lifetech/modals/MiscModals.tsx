// @ts-nocheck
import type { LifeTechCtx } from "../types_v2";
import PointDetailModal from "./PointDetailModal";
import WriteModal from "./WriteModal";
import SearchModal from "./SearchModal";
import NotificationModal from "./NotificationModal";

interface Props {
  ctx: LifeTechCtx;
}

export default function MiscModals({ ctx }: Props) {
  const { showSearchModal, setShowSearchModal, showNotification, setShowNotification } = ctx;

  return (
    <>
      <WriteModal ctx={ctx} />
      <SearchModal showSearchModal={showSearchModal} setShowSearchModal={setShowSearchModal} />
      <NotificationModal showNotification={showNotification} setShowNotification={setShowNotification} />
      <PointDetailModal ctx={ctx} />
    </>
  );
}
