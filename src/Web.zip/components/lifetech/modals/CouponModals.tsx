// @ts-nocheck
import { useState } from "react";
import type { LifeTechCtx, Coupon } from "../types_v2";

interface Props {
  ctx: LifeTechCtx;
}

export default function CouponModals({ ctx }: Props) {
  const {
    showMyCoupon,
    setShowMyCoupon,
    myCoupons,
    setMyCoupons,
    couponTab,
    setCouponTab,
    couponSort,
    setCouponSort,
    selectedCoupon,
    setSelectedCoupon,
    userStats,
    setUserStats,
  } = ctx;

  // 쿠폰 등록 상태
  const [showAddCoupon, setShowAddCoupon] = useState(false);
  const [barcodeInputType, setBarcodeInputType] = useState("");
  const [showBarcodePopup, setShowBarcodePopup] = useState(false);
  const [showUseConfirm, setShowUseConfirm] = useState(false);
  const [confirmCoupon, setConfirmCoupon] = useState<Coupon | null>(null);
  const [couponFormData, setCouponFormData] = useState({
    brand: "",
    customBrand: "",
    name: "",
    barcode: "",
    validUntil: "",
    barcodeImage: null as string | null,
  });

  // 검색
  const [searchQuery, setSearchQuery] = useState("");

  // 필터링된 쿠폰
  const getFilteredCoupons = () => {
    let filtered = [...myCoupons];

    if (couponTab === "unused") {
      filtered = filtered.filter((c) => c.status === "unused");
    } else if (couponTab === "used") {
      filtered = filtered.filter((c) => c.status === "used");
    } else if (couponTab === "myTrade") {
      filtered = filtered.filter(
        (c) => c.tradeStatus === "trading" || c.tradeStatus === "sold"
      );
    }

    if (searchQuery) {
      filtered = filtered.filter(
        (c) =>
          c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.brand.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (couponSort === "latest") {
      filtered.sort(
        (a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime()
      );
    } else if (couponSort === "expiringSoon") {
      filtered.sort((a, b) => a.dday - b.dday);
    } else if (couponSort === "expiringLate") {
      filtered.sort((a, b) => b.dday - a.dday);
    }

    return filtered;
  };

  const filteredCoupons = getFilteredCoupons();
  const unusedCount = myCoupons.filter((c) => c.status === "unused").length;
  const usedCount = myCoupons.filter((c) => c.status === "used").length;
  const myTradeCount = myCoupons.filter(
    (c) => c.tradeStatus === "trading" || c.tradeStatus === "sold"
  ).length;

  // 쿠폰 사용 처리
  const handleUseCoupon = (coupon: Coupon) => {
    setMyCoupons((prev: Coupon[]) =>
      prev.map((c) =>
        c.id === coupon.id
          ? { ...c, status: "used", usedDate: new Date().toISOString().split("T")[0] }
          : c
      )
    );
    setConfirmCoupon(null);
    setShowUseConfirm(false);
    setSelectedCoupon(null);
  };

  // 쿠폰 등록
  const handleAddCoupon = () => {
    const newCoupon: Coupon = {
      id: Date.now(),
      brand: couponFormData.customBrand || couponFormData.brand,
      brandLogo: "🎫",
      name: couponFormData.name,
      barcode: couponFormData.barcode,
      validFrom: new Date().toISOString().split("T")[0].replace(/-/g, "."),
      validUntil: couponFormData.validUntil.replace(/-/g, "."),
      dday: Math.ceil(
        (new Date(couponFormData.validUntil).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      ),
      status: "unused",
      tradeStatus: "none",
      source: "직접등록",
      purchaseDate: new Date().toISOString().split("T")[0].replace(/-/g, "."),
      usedDate: null,
      price: 0,
      seller: null,
    };
    setMyCoupons((prev: Coupon[]) => [newCoupon, ...prev]);
    setShowAddCoupon(false);
    setCouponFormData({
      brand: "",
      customBrand: "",
      name: "",
      barcode: "",
      validUntil: "",
      barcodeImage: null,
    });
  };

  if (!showMyCoupon) return null;

  return (
    <>
      {/* 내 쿠폰함 모달 */}
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">내 쿠폰함</h2>
            <button
              onClick={() => setShowMyCoupon(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* 검색 */}
          <div className="px-6 py-3 border-b border-gray-100">
            <div className="relative">
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="브랜드 또는 상품명 검색"
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#72C2FF]"
              />
            </div>
          </div>

          {/* 탭 */}
          <div className="flex border-b border-gray-100">
            {[
              { key: "unused", label: "미사용", count: unusedCount },
              { key: "used", label: "사용완료", count: usedCount },
              { key: "myTrade", label: "내거래", count: myTradeCount },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setCouponTab(tab.key)}
                className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
                  couponTab === tab.key ? "text-[#72C2FF]" : "text-gray-500"
                }`}
              >
                {tab.label} ({tab.count})
                {couponTab === tab.key && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-0.5 bg-[#72C2FF] rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* 정렬 */}
          <div className="flex items-center justify-between px-6 py-2 bg-gray-50">
            <span className="text-sm text-gray-500">{filteredCoupons.length}개</span>
            <select
              value={couponSort}
              onChange={(e) => setCouponSort(e.target.value)}
              className="text-sm text-gray-600 bg-transparent border-none focus:outline-none cursor-pointer"
            >
              <option value="latest">최신순</option>
              <option value="expiringSoon">만료임박순</option>
              <option value="expiringLate">만료여유순</option>
            </select>
          </div>

          {/* 쿠폰 목록 */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {filteredCoupons.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🎫</span>
                </div>
                <p className="text-gray-500">쿠폰이 없습니다</p>
              </div>
            ) : (
              filteredCoupons.map((coupon) => (
                <div
                  key={coupon.id}
                  onClick={() => setSelectedCoupon(coupon)}
                  className={`bg-white rounded-xl p-4 border cursor-pointer transition-all hover:shadow-md ${
                    coupon.status === "used" ? "opacity-60 border-gray-200" : "border-gray-100"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-2xl">
                      {coupon.brandLogo}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-[#72C2FF] bg-[#E8F4FD] px-2 py-0.5 rounded-full">
                          {coupon.brand}
                        </span>
                        {coupon.dday <= 7 && coupon.status === "unused" && (
                          <span className="text-xs text-red-500 font-medium">
                            D-{coupon.dday}
                          </span>
                        )}
                      </div>
                      <h4 className="font-medium text-gray-900 truncate mt-1">
                        {coupon.name}
                      </h4>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {coupon.validUntil}까지 · {coupon.source}
                      </p>
                    </div>
                    {coupon.status === "used" && (
                      <span className="text-xs bg-gray-100 text-gray-500 px-2 py-1 rounded-full">
                        사용완료
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* 쿠폰 등록 버튼 */}
          <div className="px-6 py-4 border-t border-gray-100">
            <button
              onClick={() => setShowAddCoupon(true)}
              className="w-full py-3 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
            >
              + 쿠폰 등록하기
            </button>
          </div>
        </div>
      </div>

      {/* 쿠폰 상세 모달 */}
      {selectedCoupon && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-scaleIn">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h3 className="text-lg font-bold">쿠폰 상세</h3>
              <button
                onClick={() => setSelectedCoupon(null)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="p-6">
              {/* 브랜드 & 상품명 */}
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-3 text-3xl">
                  {selectedCoupon.brandLogo}
                </div>
                <span className="text-sm font-medium text-[#72C2FF]">{selectedCoupon.brand}</span>
                <h4 className="text-lg font-bold text-gray-900 mt-1">{selectedCoupon.name}</h4>
              </div>

              {/* 바코드 */}
              <div className="bg-gray-50 rounded-xl p-4 mb-4">
                <div className="text-center">
                  <div className="bg-white rounded-lg p-4 mb-2">
                    {/* 바코드 이미지 대신 텍스트로 표시 */}
                    <div className="h-16 flex items-center justify-center border-2 border-dashed border-gray-200 rounded-lg">
                      <span className="font-mono text-lg tracking-wider">{selectedCoupon.barcode}</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-400">바코드를 보여주세요</p>
                </div>
              </div>

              {/* 정보 */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">유효기간</span>
                  <span className="text-gray-900">{selectedCoupon.validFrom} ~ {selectedCoupon.validUntil}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">출처</span>
                  <span className="text-gray-900">{selectedCoupon.source}</span>
                </div>
                {selectedCoupon.price > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">구매가</span>
                    <span className="text-gray-900">{selectedCoupon.price.toLocaleString()}원</span>
                  </div>
                )}
              </div>

              {/* 버튼 */}
              {selectedCoupon.status === "unused" && (
                <div className="mt-6 flex gap-3">
                  <button
                    onClick={() => {
                      setConfirmCoupon(selectedCoupon);
                      setShowUseConfirm(true);
                    }}
                    className="flex-1 py-3 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
                  >
                    사용완료 처리
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 사용완료 확인 팝업 */}
      {showUseConfirm && confirmCoupon && (
        <div className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 animate-scaleIn">
            <h3 className="text-lg font-bold text-center mb-2">사용완료 처리</h3>
            <p className="text-sm text-gray-500 text-center mb-6">
              "{confirmCoupon.name}" 쿠폰을<br />사용완료 처리하시겠습니까?
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowUseConfirm(false);
                  setConfirmCoupon(null);
                }}
                className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
              >
                취소
              </button>
              <button
                onClick={() => handleUseCoupon(confirmCoupon)}
                className="flex-1 py-3 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors"
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 쿠폰 등록 모달 */}
      {showAddCoupon && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-hidden flex flex-col animate-scaleIn">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h3 className="text-lg font-bold">쿠폰 등록</h3>
              <button
                onClick={() => setShowAddCoupon(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* 브랜드 선택 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">브랜드</label>
                <select
                  value={couponFormData.brand}
                  onChange={(e) => setCouponFormData({ ...couponFormData, brand: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                >
                  <option value="">브랜드 선택</option>
                  <option value="스타벅스">스타벅스</option>
                  <option value="CU">CU</option>
                  <option value="GS25">GS25</option>
                  <option value="세븐일레븐">세븐일레븐</option>
                  <option value="배스킨라빈스">배스킨라빈스</option>
                  <option value="맥도날드">맥도날드</option>
                  <option value="버거킹">버거킹</option>
                  <option value="기타">기타 (직접입력)</option>
                </select>
                {couponFormData.brand === "기타" && (
                  <input
                    type="text"
                    value={couponFormData.customBrand}
                    onChange={(e) => setCouponFormData({ ...couponFormData, customBrand: e.target.value })}
                    placeholder="브랜드명 입력"
                    className="w-full mt-2 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                  />
                )}
              </div>

              {/* 상품명 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">상품명</label>
                <input
                  type="text"
                  value={couponFormData.name}
                  onChange={(e) => setCouponFormData({ ...couponFormData, name: e.target.value })}
                  placeholder="예) 아메리카노 T"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                />
              </div>

              {/* 바코드 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">바코드 번호</label>
                <input
                  type="text"
                  value={couponFormData.barcode}
                  onChange={(e) => setCouponFormData({ ...couponFormData, barcode: e.target.value })}
                  placeholder="바코드 번호 입력"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                />
              </div>

              {/* 유효기간 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">유효기간</label>
                <input
                  type="date"
                  value={couponFormData.validUntil}
                  onChange={(e) => setCouponFormData({ ...couponFormData, validUntil: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF]"
                />
              </div>
            </div>

            <div className="px-6 py-4 border-t border-gray-100">
              <button
                onClick={handleAddCoupon}
                disabled={!couponFormData.name || !couponFormData.barcode || !couponFormData.validUntil || (!couponFormData.brand && !couponFormData.customBrand)}
                className="w-full py-3 bg-[#72C2FF] text-white rounded-xl font-medium hover:bg-[#5BA8E6] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                등록하기
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
