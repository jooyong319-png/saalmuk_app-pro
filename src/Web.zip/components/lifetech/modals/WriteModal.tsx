// @ts-nocheck
import { useState } from "react";
import type { LifeTechCtx } from "../types_v2";

interface Props {
  ctx: LifeTechCtx;
}

export default function WriteModal({ ctx }: Props) {
  const {
    mainTab,
    showWriteModal,
    setShowWriteModal,
    writeStep,
    setWriteStep,
    showSellFlow,
    setShowSellFlow,
    sellStep,
    setSellStep,
  } = ctx;

  const [eventForm, setEventForm] = useState({
    title: "", type: "추첨", prize: "", winners: "", startDate: "", endDate: "",
    host: "", platform: "", link: "", description: "", images: [] as string[],
  });

  const [pointForm, setPointForm] = useState({
    appName: "", category: "앱테크", reward: "", rewardType: "포인트",
    difficulty: "쉬움", description: "", link: "", images: [] as string[],
  });

  const [surveyForm, setSurveyForm] = useState({
    type: "일반설문", content: "", email: "", contact: "",
  });

  const [communityForm, setCommunityForm] = useState({
    category: "자유", title: "", content: "",
  });

  const getModalTitle = () => {
    switch (mainTab) {
      case "이벤트": return "이벤트 공유하기";
      case "앱테크": return "포인트 정보 공유";
      case "설문조사": return "설문조사 의뢰하기";
      case "장터": return "기프티콘 판매하기";
      case "커뮤니티": return "글쓰기";
      default: return "글쓰기";
    }
  };

  const getTabIcon = () => {
    switch (mainTab) {
      case "이벤트": return "🎁";
      case "앱테크": return "💰";
      case "설문조사": return "📋";
      case "장터": return "🛒";
      case "커뮤니티": return "💬";
      default: return "✏️";
    }
  };

  const getTabStyles = () => {
    switch (mainTab) {
      case "이벤트": return { bgLight: "bg-sky-50", textDark: "text-sky-700", bgSolid: "bg-[#72C2FF] hover:bg-[#5BA8E6]" };
      case "앱테크": return { bgLight: "bg-amber-50", textDark: "text-amber-700", bgSolid: "bg-amber-500 hover:bg-amber-600" };
      case "설문조사": return { bgLight: "bg-emerald-50", textDark: "text-emerald-700", bgSolid: "bg-emerald-500 hover:bg-emerald-600" };
      case "커뮤니티": return { bgLight: "bg-purple-50", textDark: "text-purple-700", bgSolid: "bg-purple-500 hover:bg-purple-600" };
      default: return { bgLight: "bg-gray-50", textDark: "text-gray-700", bgSolid: "bg-gray-500 hover:bg-gray-600" };
    }
  };

  const styles = getTabStyles();

  if (mainTab === "장터" && showWriteModal) {
    setShowWriteModal(false);
    setSellStep(1);
    setShowSellFlow(true);
    return null;
  }

  const isEventValid = mainTab !== "이벤트" || (
    eventForm.host.trim() && eventForm.winners.toString().trim() &&
    eventForm.title.trim() && eventForm.link.trim() &&
    eventForm.startDate && eventForm.endDate && eventForm.prize && eventForm.type && eventForm.platform
  );
  const isPointValid = mainTab !== "앱테크" || (pointForm.appName.trim() && pointForm.description.trim());
  const isSurveyValid = mainTab !== "설문조사" || (surveyForm.content.trim() && surveyForm.email.trim());
  const isCommunityValid = mainTab !== "커뮤니티" || (communityForm.title.trim() && communityForm.content.trim());
  const isFormValid = isEventValid && isPointValid && isSurveyValid && isCommunityValid;

  if (!showWriteModal) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-[500] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col animate-scaleIn">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <button
            onClick={() => { setShowWriteModal(false); setWriteStep(1); }}
            className="p-1 hover:bg-gray-100 rounded-full"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          {mainTab === "설문조사" ? (
            <h3 className="text-base font-medium text-gray-900">
              <span>설문조사</span><span className="mx-2 text-gray-300">|</span><span>의뢰하기</span>
            </h3>
          ) : (
            <h3 className="text-lg font-bold text-gray-900">{getModalTitle()}</h3>
          )}
          <div className="w-6" />
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Step 1: 작성 */}
          {writeStep === 1 && (
            <div className="p-6">
              {mainTab === "설문조사" ? (
                <p className="text-sm text-gray-500 text-center mb-6">
                  의뢰하시고 싶은 설문 내용을 남겨주시면,<br />확인 후 빠르게 연락 드리겠습니다.
                </p>
              ) : (
                <div className={`${styles.bgLight} rounded-xl p-4 mb-6`}>
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{getTabIcon()}</span>
                      <p className={`font-medium ${styles.textDark}`}>{getModalTitle()}</p>
                    </div>
                    <p className="text-xs text-gray-400 shrink-0">
                      {mainTab === "이벤트" && <span className="flex items-center gap-1">이벤트 등록시 <span className="font-bold text-sky-500">+30포인트</span></span>}
                      {mainTab === "앱테크" && "포인트 적립 꿀팁을 공유해주세요!"}
                      {mainTab === "커뮤니티" && "자유롭게 이야기를 나눠보세요!"}
                    </p>
                  </div>
                </div>
              )}

              {/* 이벤트 폼 */}
              {mainTab === "이벤트" && (
                <div className="space-y-5">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">주최사 <span className="text-red-400">*</span></label>
                      <input type="text" value={eventForm.host} onChange={(e) => setEventForm({ ...eventForm, host: e.target.value })} placeholder="스타벅스" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:border-[#72C2FF] focus:outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">당첨자 수 <span className="text-red-400">*</span></label>
                      <input type="number" value={eventForm.winners} onChange={(e) => setEventForm({ ...eventForm, winners: e.target.value })} placeholder="100" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:border-[#72C2FF] focus:outline-none text-sm" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">이벤트 제목 <span className="text-red-400">*</span></label>
                    <input type="text" value={eventForm.title} onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })} placeholder="예: 스타벅스 아메리카노 100명 추첨" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:border-[#72C2FF] focus:outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">이벤트 링크 <span className="text-red-400">*</span></label>
                    <input type="url" value={eventForm.link} onChange={(e) => setEventForm({ ...eventForm, link: e.target.value })} placeholder="https://" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:border-[#72C2FF] focus:outline-none text-sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">시작일 <span className="text-red-400">*</span></label>
                      <input type="date" value={eventForm.startDate} onChange={(e) => setEventForm({ ...eventForm, startDate: e.target.value })} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:border-[#72C2FF] focus:outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">종료일 <span className="text-red-400">*</span></label>
                      <input type="date" value={eventForm.endDate} onChange={(e) => setEventForm({ ...eventForm, endDate: e.target.value })} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:border-[#72C2FF] focus:outline-none text-sm" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">경품정보 <span className="text-red-400">*</span></label>
                    <div className="flex gap-2 flex-wrap">
                      {["현금/자산", "가전", "식음료", "상품권", "뷰티", "문화", "기타"].map((p) => (
                        <button key={p} onClick={() => setEventForm({ ...eventForm, prize: p })}
                          className={`px-3 py-1.5 rounded-lg text-sm transition-all border ${eventForm.prize === p ? "bg-[#72C2FF] text-white border-[#72C2FF]" : "bg-white text-gray-600 border-gray-300 hover:border-gray-400"}`}>
                          {p === "기타" ? "※ 기타" : p}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">응모형태 <span className="text-red-400">*</span></label>
                    <div className="flex gap-2 flex-wrap">
                      {["추첨", "선착순", "출석", "미션", "퀴즈", "기타"].map((t) => (
                        <button key={t} onClick={() => setEventForm({ ...eventForm, type: t })}
                          className={`px-3 py-1.5 rounded-lg text-sm transition-all border ${eventForm.type === t ? "bg-[#72C2FF] text-white border-[#72C2FF]" : "bg-white text-gray-600 border-gray-300 hover:border-gray-400"}`}>
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">응모 플랫폼 <span className="text-red-400">*</span></label>
                    <div className="flex gap-2 flex-wrap">
                      {[{ name: "인스타그램", emoji: "📷" }, { name: "유튜브", emoji: "▶️" }, { name: "페이스북", emoji: "🔵" }, { name: "홈페이지", emoji: "🏠" }, { name: "네이버블로그", emoji: "🟢" }, { name: "X (트위터)", emoji: "🐦" }, { name: "기타", emoji: "※" }].map((pl) => (
                        <button key={pl.name} onClick={() => setEventForm({ ...eventForm, platform: pl.name })}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm transition-all border ${eventForm.platform === pl.name ? "bg-[#72C2FF] text-white border-[#72C2FF]" : "bg-white text-gray-600 border-gray-300 hover:border-gray-400"}`}>
                          <span className="text-xs">{pl.emoji}</span>
                          <span>{pl.name === "기타" ? "※ 기타" : pl.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="border border-gray-200 rounded-xl overflow-hidden">
                    <textarea value={eventForm.description} onChange={(e) => setEventForm({ ...eventForm, description: e.target.value.slice(0, 2000) })} placeholder="내용을 입력하세요" rows={5} className="w-full px-4 py-3 focus:outline-none resize-none text-sm" />
                    <div className="flex items-center justify-between px-4 py-2 border-t border-gray-100 bg-gray-50">
                      <div className="flex items-center gap-3">
                        <button className="text-gray-400 hover:text-gray-600">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
                        </button>
                      </div>
                      <span className="text-xs text-gray-400">{eventForm.description?.length ?? 0}/2,000</span>
                    </div>
                  </div>
                </div>
              )}

              {/* 앱테크 폼 */}
              {mainTab === "앱테크" && (
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-700">사진/동영상</label>
                      <span className="text-xs text-amber-500">포인트 등록시 보너스 포인트 지급</span>
                    </div>
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      <label className="flex-shrink-0 w-20 h-20 bg-gray-100 rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors">
                        <svg className="w-6 h-6 text-gray-400 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        <span className="text-xs text-gray-500">{pointForm.images.length}/5</span>
                        <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => {
                          const files = Array.from(e.target.files || []).slice(0, 5 - pointForm.images.length);
                          const newImages = files.map((file) => URL.createObjectURL(file));
                          setPointForm({ ...pointForm, images: [...pointForm.images, ...newImages].slice(0, 5) });
                        }} />
                      </label>
                      {pointForm.images.map((img, idx) => (
                        <div key={idx} className="relative flex-shrink-0 w-20 h-20">
                          <img src={img} alt="" className="w-full h-full object-cover rounded-xl" />
                          <button onClick={() => setPointForm({ ...pointForm, images: pointForm.images.filter((_, i) => i !== idx) })} className="absolute -top-1 -right-1 w-5 h-5 bg-gray-800 text-white rounded-full flex items-center justify-center text-xs">✕</button>
                          {idx === 0 && <span className="absolute bottom-1 left-1 px-1 py-0.5 bg-amber-500 text-white text-[10px] rounded">대표</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">카테고리 <span className="text-red-400">*</span></label>
                    <div className="flex gap-2 flex-wrap">
                      {["앱테크", "광고", "출석", "미션", "게임", "설문", "기타"].map((cat) => (
                        <button key={cat} onClick={() => setPointForm({ ...pointForm, category: cat })}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${pointForm.category === cat ? "bg-amber-500 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">앱/서비스명 <span className="text-red-400">*</span></label>
                    <input type="text" value={pointForm.appName} onChange={(e) => setPointForm({ ...pointForm, appName: e.target.value })} placeholder="예: 토스, 캐시워크, 리브메이트" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-amber-500 focus:outline-none" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">보상 <span className="text-red-400">*</span></label>
                      <input type="text" value={pointForm.reward} onChange={(e) => setPointForm({ ...pointForm, reward: e.target.value })} placeholder="500" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-amber-500 focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">보상 유형</label>
                      <select value={pointForm.rewardType} onChange={(e) => setPointForm({ ...pointForm, rewardType: e.target.value })} className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-amber-500 focus:outline-none">
                        <option value="포인트">포인트</option>
                        <option value="현금">현금</option>
                        <option value="기프티콘">기프티콘</option>
                        <option value="캐시">캐시</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">다운로드/참여 링크</label>
                    <input type="url" value={pointForm.link} onChange={(e) => setPointForm({ ...pointForm, link: e.target.value })} placeholder="https://" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-amber-500 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">상세 설명 <span className="text-red-400">*</span></label>
                    <textarea value={pointForm.description} onChange={(e) => setPointForm({ ...pointForm, description: e.target.value })} placeholder="포인트 적립 방법, 꿀팁 등을 자세히 작성해주세요" rows={4} className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-amber-500 focus:outline-none resize-none" />
                  </div>
                </div>
              )}

              {/* 설문조사 의뢰 폼 */}
              {mainTab === "설문조사" && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">설문 유형 <span className="text-red-500">*</span></label>
                    <div className="flex gap-2">
                      {["일반설문", "퀵설문"].map((type) => (
                        <button key={type} onClick={() => setSurveyForm({ ...surveyForm, type })}
                          className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${surveyForm.type === type ? "bg-gray-800 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">설문내용 <span className="text-red-500">*</span></label>
                    <textarea value={surveyForm.content} onChange={(e) => setSurveyForm({ ...surveyForm, content: e.target.value })} placeholder="의뢰하실 설문의 내용, 목적, 대상 등을 자세히 작성해주세요" rows={5} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:border-gray-500 focus:outline-none resize-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">이메일 주소 <span className="text-red-500">*</span></label>
                    <input type="email" value={surveyForm.email} onChange={(e) => setSurveyForm({ ...surveyForm, email: e.target.value })} placeholder="example@email.com" className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:border-gray-500 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">담당자님 성함 / 연락처 <span className="text-gray-400 text-xs">(필수사항 아님)</span></label>
                    <input type="text" value={surveyForm.contact} onChange={(e) => setSurveyForm({ ...surveyForm, contact: e.target.value })} placeholder="홍길동 / 010-1234-5678" className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:border-gray-500 focus:outline-none" />
                  </div>
                  <button
                    onClick={() => { if (surveyForm.content && surveyForm.email) setWriteStep(3); }}
                    disabled={!surveyForm.content || !surveyForm.email}
                    className={`w-full py-4 rounded-xl font-bold text-white mt-4 transition-colors ${surveyForm.content && surveyForm.email ? "bg-gray-800 hover:bg-gray-900" : "bg-gray-300 cursor-not-allowed"}`}
                  >
                    의뢰하기
                  </button>
                </div>
              )}

              {/* 커뮤니티 폼 */}
              {mainTab === "커뮤니티" && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">카테고리 <span className="text-red-400">*</span></label>
                    <div className="flex gap-2 flex-wrap">
                      {["자유", "질문", "정보", "후기", "꿀팁", "잡담"].map((cat) => (
                        <button key={cat} onClick={() => setCommunityForm({ ...communityForm, category: cat })}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${communityForm.category === cat ? "bg-purple-500 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">제목 <span className="text-red-400">*</span></label>
                    <input type="text" value={communityForm.title} onChange={(e) => setCommunityForm({ ...communityForm, title: e.target.value })} placeholder="제목을 입력하세요" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">내용 <span className="text-red-400">*</span></label>
                    <textarea value={communityForm.content} onChange={(e) => setCommunityForm({ ...communityForm, content: e.target.value })} placeholder="내용을 입력하세요" rows={8} className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none resize-none" />
                  </div>
                  <div className="flex gap-3">
                    <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                      <span className="text-sm">이미지</span>
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                      <span className="text-sm">링크</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 2: 미리보기 */}
          {writeStep === 2 && (
            <div className="p-6">
              <div className="bg-gray-50 rounded-xl p-4 mb-4">
                <p className="text-sm text-gray-500 mb-2">미리보기</p>
                {mainTab === "이벤트" && eventForm.title && (
                  <div className="bg-white rounded-xl p-4 border border-gray-100">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="px-2 py-0.5 rounded text-xs font-medium bg-sky-100 text-sky-700">{eventForm.type}</span>
                      {eventForm.endDate && <span className="text-xs text-gray-400">~{eventForm.endDate}</span>}
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">{eventForm.title}</h3>
                    <div className="space-y-1 text-sm">
                      {eventForm.prize && <p className="text-gray-600">🎁 {eventForm.prize} {eventForm.winners && `(${eventForm.winners}명)`}</p>}
                      {eventForm.host && <p className="text-gray-600">🏢 {eventForm.host}</p>}
                      {eventForm.platform && <p className="text-gray-600">📱 {eventForm.platform}</p>}
                    </div>
                  </div>
                )}
                {mainTab === "앱테크" && pointForm.appName && (
                  <div className="bg-white rounded-xl p-4 border border-gray-100">
                    <span className="px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">{pointForm.category}</span>
                    <h3 className="font-bold text-gray-900 my-2">{pointForm.appName}</h3>
                    <p className="text-amber-600 font-bold mb-2">+{pointForm.reward} {pointForm.rewardType}</p>
                    {pointForm.description && <p className="text-sm text-gray-500">{pointForm.description}</p>}
                  </div>
                )}
                {mainTab === "커뮤니티" && communityForm.title && (
                  <div className="bg-white rounded-xl p-4 border border-gray-100">
                    <span className="px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-700">{communityForm.category}</span>
                    <h3 className="font-bold text-gray-900 my-2">{communityForm.title}</h3>
                    <p className="text-sm text-gray-600 whitespace-pre-wrap">{communityForm.content}</p>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setWriteStep(1)} className="py-3 bg-gray-100 text-gray-700 font-medium rounded-xl hover:bg-gray-200">수정하기</button>
                <button onClick={() => setWriteStep(3)} className={`py-3 text-white font-bold rounded-xl ${styles.bgSolid}`}>등록하기</button>
              </div>
            </div>
          )}

          {/* Step 3: 등록 완료 */}
          {writeStep === 3 && (
            <div className="p-6 text-center py-12">
              <div className={`w-24 h-24 ${mainTab === "설문조사" ? "bg-gray-100" : "bg-emerald-100"} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <svg className={`w-12 h-12 ${mainTab === "설문조사" ? "text-gray-600" : "text-emerald-500"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{mainTab === "설문조사" ? "의뢰 접수 완료!" : "등록 완료!"}</h3>
              <p className="text-gray-500 mb-6">{mainTab === "설문조사" ? "설문 의뢰가 접수되었습니다. 검토 후 빠르게 연락드리겠습니다." : "게시글이 등록되었습니다."}</p>
              {mainTab !== "설문조사" && (
                <div className="bg-amber-50 rounded-xl p-4 mb-6 text-left">
                  <p className="text-sm text-amber-700 font-medium">🎉 보상 안내</p>
                  <p className="text-xs text-amber-600 mt-1">정보 공유로 50 쌀먹캐시가 적립되었어요!</p>
                </div>
              )}
              <button onClick={() => { setShowWriteModal(false); setWriteStep(1); }} className="w-full py-4 bg-[#72C2FF] text-white font-bold rounded-xl hover:bg-[#5BA8E6]">확인</button>
            </div>
          )}
        </div>

        {/* 하단 등록하기 버튼 */}
        {mainTab !== "설문조사" && writeStep === 1 && (
          <div className="px-6 py-4 bg-white border-t border-gray-100">
            <button
              onClick={() => isFormValid && setWriteStep(3)}
              disabled={!isFormValid}
              className={`w-full py-4 font-bold text-base rounded-xl transition-colors ${isFormValid ? "bg-[#72C2FF] text-white active:bg-[#5AB0F0]" : "bg-gray-200 text-gray-400 cursor-not-allowed"}`}
            >
              등록하기
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
