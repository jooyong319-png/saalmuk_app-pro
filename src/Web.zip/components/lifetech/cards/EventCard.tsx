// @ts-nocheck
import type { Event } from "../types";

interface Props {
  event: Event;
  onEventClick?: (event: Event) => void;
  getStatusBadge: (status: string, dday: number) => { text: string; color: string };
  getTypeBadge: (type: string) => string;
  showWonButton?: boolean;
  isWon?: boolean;
  onToggleWon?: () => void;
}

export default function EventCard({
  event,
  onEventClick,
  getStatusBadge,
  getTypeBadge,
  showWonButton = false,
  isWon = false,
  onToggleWon,
}: Props) {
  const statusBadge = getStatusBadge(event.status, event.dday);
  const typeBadgeClass = getTypeBadge(event.type);

  return (
    <div
      onClick={() => onEventClick?.(event)}
      className="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition-all cursor-pointer group"
    >
      {/* 상단: 타입 뱃지 + HOT + 상태 뱃지 */}
      <div className="flex items-center gap-2 mb-2">
        <span className={`px-2 py-0.5 text-xs font-medium rounded ${typeBadgeClass}`}>
          {event.type}
        </span>
        {event.hot && (
          <span className="text-xs text-red-500 font-medium">🔥 HOT</span>
        )}
        <span className={`px-2 py-0.5 text-xs font-medium rounded text-white ${statusBadge.color}`}>
          {statusBadge.text}
        </span>
        {event.dday > 0 && event.status === "progress" && (
          <span className="text-xs text-gray-400">D-{event.dday}</span>
        )}
      </div>

      {/* 제목 */}
      <h3 className="font-bold text-gray-900 mb-2 group-hover:text-sky-600 transition-colors line-clamp-2">
        {event.title}
      </h3>

      {/* 경품 정보 */}
      <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
        <span className="flex items-center gap-1">
          <span>🎁</span> {event.prize}
        </span>
        <span className="flex items-center gap-1">
          <span>👥</span> {event.winners}명
        </span>
      </div>

      {/* 하단: 좋아요, 댓글, 기간 */}
      <div className="flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span>❤️</span> {event.likes}
          </span>
          <span className="flex items-center gap-1">
            <span>💬</span> {event.comments}
          </span>
          {event.views && (
            <span className="flex items-center gap-1">
              <span>👁️</span> {event.views}
            </span>
          )}
        </div>
        <span>{event.period}</span>
      </div>

      {/* 당첨 버튼 (내응모함에서 사용) */}
      {showWonButton && (
        <div className="mt-3 pt-3 border-t border-gray-100">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleWon?.();
            }}
            className={`w-full py-2 rounded-lg text-sm font-medium transition-colors ${
              isWon
                ? "bg-amber-100 text-amber-700 border border-amber-300"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {isWon ? "🏆 당첨됨" : "당첨 등록하기"}
          </button>
        </div>
      )}
    </div>
  );
}
