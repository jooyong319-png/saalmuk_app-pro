// @ts-nocheck
import type { Survey } from "../types_v2";

interface Props {
  survey: Survey;
  onSurveyClick: (survey: Survey) => void;
}

export default function SurveyCard({ survey, onSurveyClick }: Props) {
  const progressPercent = Math.round((survey.participants / survey.maxParticipants) * 100);

  return (
    <div
      onClick={() => onSurveyClick(survey)}
      className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md hover:border-[#72C2FF]/30 transition-all cursor-pointer"
    >
      {/* 상단: 태그 + 뱃지 */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {survey.tags.map((tag, i) => (
            <span
              key={i}
              className="text-xs text-[#72C2FF] bg-[#E8F4FD] px-2 py-0.5 rounded-full"
            >
              #{tag}
            </span>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          {survey.isHot && (
            <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">
              🔥 HOT
            </span>
          )}
          {survey.isPremium && (
            <span className="text-xs bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full font-medium">
              ⭐ 프리미엄
            </span>
          )}
        </div>
      </div>

      {/* 제목 */}
      <h3 className="font-bold text-[15px] text-gray-900 mb-1 line-clamp-1">
        {survey.title}
      </h3>

      {/* 설명 */}
      <p className="text-sm text-gray-500 mb-4 line-clamp-1">
        {survey.description}
      </p>

      {/* 진행 바 */}
      <div className="mb-3">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-gray-400">참여 현황</span>
          <span className="text-gray-600 font-medium">
            {survey.participants}/{survey.maxParticipants}명
          </span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#72C2FF] to-[#4A9FD9] rounded-full transition-all"
            style={{ width: `${Math.min(progressPercent, 100)}%` }}
          />
        </div>
      </div>

      {/* 하단 정보 */}
      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
        <div className="flex items-center gap-3 text-xs text-gray-400">
          <span>⏱️ {survey.duration}</span>
          <span>📅 {survey.deadline}</span>
        </div>
        <div className="flex items-center gap-1 text-[#72C2FF] font-bold">
          <span>🎁</span>
          <span>{survey.reward.toLocaleString()}P</span>
        </div>
      </div>
    </div>
  );
}
