// @ts-nocheck
import type { MarketItem } from "../types";

interface Props {
  item: MarketItem;
  onClick?: (item: MarketItem) => void;
}

export default function MarketCard({ item, onClick }: Props) {
  return (
    <div
      onClick={() => onClick?.(item)}
      className="bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-md transition-all cursor-pointer group"
    >
      {/* 상품 이미지 */}
      <div className="aspect-square bg-gray-50 flex items-center justify-center relative">
        {item.image ? (
          <img
            src={item.image}
            alt={item.name}
            className="w-full h-full object-contain p-4"
          />
        ) : (
          <div className="text-4xl">
            {item.brand === "스타벅스" ? "☕" : 
             item.brand === "맥도날드" ? "🍔" : 
             item.brand === "공차" ? "🧋" : 
             item.brand === "도미노피자" ? "🍕" : 
             item.brand === "배스킨라빈스" ? "🍨" : "🎁"}
          </div>
        )}
        
        {/* D-day 뱃지 */}
        {item.dday <= 7 && (
          <span className={`absolute top-2 left-2 px-2 py-0.5 text-xs font-medium rounded ${
            item.dday === 0 ? "bg-red-500 text-white" : "bg-amber-100 text-amber-700"
          }`}>
            {item.dday === 0 ? "오늘마감" : `D-${item.dday}`}
          </span>
        )}

        {/* 할인율 */}
        {item.discount > 0 && (
          <span className="absolute top-2 right-2 px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded">
            {item.discount}%
          </span>
        )}
      </div>

      {/* 상품 정보 */}
      <div className="p-3">
        <p className="text-xs text-gray-500 mb-1">{item.brand}</p>
        <h3 className="font-medium text-gray-900 text-sm mb-2 line-clamp-2 group-hover:text-sky-600 transition-colors">
          {item.name}
        </h3>
        
        <div className="flex items-baseline gap-2">
          <span className="text-lg font-bold text-gray-900">
            {item.price.toLocaleString()}원
          </span>
          {item.originalPrice > item.price && (
            <span className="text-xs text-gray-400 line-through">
              {item.originalPrice.toLocaleString()}원
            </span>
          )}
        </div>

        {/* 판매자 정보 */}
        <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
          <span>{item.seller}</span>
          <span className="flex items-center gap-1">
            <span>⭐</span> {item.rating} · 거래 {item.trades}회
          </span>
        </div>
      </div>
    </div>
  );
}
