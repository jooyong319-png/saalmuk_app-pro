// @ts-nocheck
import type { Post } from "../types_v2";

interface Props {
  post: Post;
  onPostClick?: (post: Post) => void;
}

export default function PostCard({ post, onPostClick }: Props) {
  const getCategoryStyle = (category: string) => {
    const styles: Record<string, string> = {
      꿀팁: "bg-amber-100 text-amber-700",
      후기: "bg-green-100 text-green-700",
      질문: "bg-blue-100 text-blue-700",
      정보: "bg-purple-100 text-purple-700",
      잡담: "bg-gray-100 text-gray-700",
    };
    return styles[category] || "bg-gray-100 text-gray-700";
  };

  return (
    <div
      onClick={() => onPostClick?.(post)}
      className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md hover:border-[#72C2FF]/30 transition-all cursor-pointer"
    >
      {/* 상단: 카테고리 + HOT 뱃지 */}
      <div className="flex items-center gap-2 mb-2">
        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getCategoryStyle(post.category)}`}>
          {post.category}
        </span>
        {post.hot && (
          <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">
            🔥 HOT
          </span>
        )}
      </div>

      {/* 제목 */}
      <h3 className="font-bold text-[15px] text-gray-900 mb-2 line-clamp-1">
        {post.title}
      </h3>

      {/* 하단 정보 */}
      <div className="flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center gap-2">
          <span className="text-gray-600 font-medium">{post.author}</span>
          <span>·</span>
          <span>{post.time}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            {post.likes}
          </span>
          <span className="flex items-center gap-1">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            {post.comments}
          </span>
          {post.views && (
            <span className="flex items-center gap-1">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              {post.views}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
