// @ts-nocheck
import { useState } from "react";
import type { QuickPoll } from "../types_v2";

interface Props {
  poll: QuickPoll;
  voted: boolean;
  onVote: (pollId: number, optionIndex: number) => void;
}

export default function QuickPollCard({ poll, voted, onVote }: Props) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showAllOptions, setShowAllOptions] = useState(false);
  const [localVotes, setLocalVotes] = useState(poll.options.map((o) => o.votes));

  const totalVotes = localVotes.reduce((sum, v) => sum + v, 0);

  const handleVote = (idx: number) => {
    if (voted || poll.participated) return;
    setSelectedOption(idx);
    setLocalVotes((prev) => prev.map((v, i) => (i === idx ? v + 1 : v)));
    onVote(poll.id, idx);
  };

  const visibleOptions = showAllOptions ? poll.options : poll.options.slice(0, 4);
  const hasMore = poll.options.length > 4;

  return (
    <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
      {poll.tags.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {poll.tags.map((tag, i) => (
            <span key={i} className="text-xs text-[#72C2FF] bg-[#E8F4FD] px-2 py-0.5 rounded-full">
              {tag}
            </span>
          ))}
        </div>
      )}

      <h3 className="font-bold text-[15px] text-gray-900 mb-4 leading-relaxed">{poll.question}</h3>

      <div className="space-y-2">
        {visibleOptions.map((option, idx) => {
          const votes = localVotes[idx] ?? option.votes;
          const percent = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
          const isSelected = selectedOption === idx;
          const showResult = voted || poll.participated;

          return (
            <button
              key={idx}
              onClick={() => handleVote(idx)}
              disabled={showResult}
              className={`w-full text-left p-3 rounded-lg border transition-all relative overflow-hidden ${
                showResult
                  ? isSelected
                    ? "border-[#72C2FF] bg-[#E8F4FD]"
                    : "border-gray-200 bg-gray-50"
                  : "border-gray-200 hover:border-[#72C2FF] hover:bg-[#E8F4FD]/30"
              }`}
            >
              {showResult && (
                <div
                  className={`absolute left-0 top-0 bottom-0 transition-all duration-500 ${
                    isSelected ? "bg-[#72C2FF]/20" : "bg-gray-100"
                  }`}
                  style={{ width: `${percent}%` }}
                />
              )}
              <div className="relative flex items-center justify-between">
                <span className={`text-sm ${showResult && isSelected ? "font-medium text-[#4A9FD9]" : "text-gray-700"}`}>
                  {option.text}
                </span>
                {showResult && (
                  <span className={`text-sm font-bold ml-2 whitespace-nowrap ${isSelected ? "text-[#4A9FD9]" : "text-gray-500"}`}>
                    {percent}%
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {hasMore && !showAllOptions && (
        <button onClick={() => setShowAllOptions(true)} className="w-full mt-2 py-2 text-sm text-gray-500 hover:text-[#72C2FF] transition-colors">
          +{poll.options.length - 4}개 더보기
        </button>
      )}

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100 text-xs text-gray-400">
        <div className="flex items-center gap-3">
          <span>참여 {(poll.participants + (voted && !poll.participated ? 1 : 0)).toLocaleString()}명</span>
          <span>댓글 {poll.comments}</span>
          <span>좋아요 {poll.likes}</span>
        </div>
        <div className="flex items-center gap-1 text-[#72C2FF] font-medium">
          <span>🎁</span>
          <span>{poll.reward}P</span>
        </div>
      </div>
    </div>
  );
}
