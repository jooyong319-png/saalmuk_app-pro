// @ts-nocheck
import { initialPosts as galleryPostsData } from "../gallery/postsData";

const getPopularPosts = () => {
  return galleryPostsData
    .filter((post) => post.boardId === "생활테크")
    .sort((a, b) => b.likes - a.likes)
    .slice(0, 5);
};

export default function PopularPostsSection({
  onPostClick,
}: {
  onPostClick?: (postId: number) => void;
}) {
  const popularPosts = getPopularPosts();

  const getRankStyle = (index: number) => {
    switch (index) {
      case 0: return "bg-amber-400 text-white";
      case 1: return "bg-gray-400 text-white";
      case 2: return "bg-amber-600 text-white";
      default: return "bg-white border border-gray-300 text-gray-400";
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-5 animate-fadeUp delay-2">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
        <h3 className="font-bold text-gray-900 flex items-center gap-2">
          <span>🔥</span> 생활테크 인기글
        </h3>
        <button onClick={() => onPostClick?.(0)} className="text-sm text-gray-400 hover:text-[#72C2FF]">
          더보기 →
        </button>
      </div>
      <div className="p-3">
        {popularPosts.map((post, i) => (
          <div
            key={post.id}
            onClick={() => onPostClick?.(post.id)}
            className="flex items-center gap-3 py-2.5 px-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
          >
            <span className={`w-7 h-6 rounded flex items-center justify-center text-xs font-bold ${getRankStyle(i)}`}>
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="flex-1 text-sm text-gray-700 truncate">{post.title}</span>
            {post.comments > 0 && (
              <span className="text-xs text-[#72C2FF]">[{post.comments}]</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
