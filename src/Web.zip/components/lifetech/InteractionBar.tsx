// @ts-nocheck
import { useState } from "react";
import LikeDislikeButton from "../gallery/LikeDislikeButton";

export default function InteractionBar({
  likes = 0,
  dislikes = 0,
  comments = 0,
  views = 0,
  showGift = true,
  size = "sm",
}: {
  likes?: number;
  dislikes?: number;
  comments?: number;
  views?: number;
  showGift?: boolean;
  size?: "xs" | "sm" | "md";
}) {
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (isDisliked) setIsDisliked(false);
  };

  const handleDislike = () => {
    setIsDisliked(!isDisliked);
    if (isLiked) setIsLiked(false);
  };

  const iconSize =
    size === "xs"
      ? "w-3.5 h-3.5"
      : size === "sm"
        ? "w-[18px] h-[18px]"
        : "w-5 h-5";
  const textSize =
    size === "xs" ? "text-[11px]" : size === "sm" ? "text-sm" : "text-[13px]";

  return (
    <div className="flex items-center gap-1 text-gray-400">
      <LikeDislikeButton
        likes={likes}
        dislikes={dislikes}
        isLiked={isLiked}
        isDisliked={isDisliked}
        onLike={handleLike}
        onDislike={handleDislike}
        size={size === "xs" ? "xs" : "md"}
      />

      {/* 댓글 */}
      <button className="flex items-center gap-0.5 px-1.5 py-1 rounded-lg hover:bg-gray-100 transition-colors">
        <svg className={iconSize} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
        <span className={textSize}>{comments}</span>
      </button>

      {/* 후원 */}
      {showGift && (
        <button className="flex items-center gap-0.5 px-1.5 py-1 rounded-lg hover:text-amber-500 transition-colors">
          <svg className={iconSize} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
          </svg>
        </button>
      )}

      {/* 조회수 */}
      <span className={`flex items-center gap-0.5 ${textSize}`}>
        <svg className={iconSize} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
        </svg>
        {views.toLocaleString()}
      </span>
    </div>
  );
}
