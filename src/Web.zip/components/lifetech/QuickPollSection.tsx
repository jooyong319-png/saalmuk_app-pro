// @ts-nocheck
import { useState } from "react";
import { quickPolls as quickPollsData } from "./data";

export default function QuickPollSection({ quickPollVoted, setQuickPollVoted }: any) {
  const poll = quickPollsData[1];
  const [voted, setVoted] = useState(false);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [localVotes, setLocalVotes] = useState(poll.options.map((o: any) => o.votes));

  const totalVotes = localVotes.reduce((sum: number, v: number) => sum + v, 0);

  const handleVote = (idx: number) => {
    if (voted) return;
    setSelectedIdx(idx);
    setLocalVotes((prev: number[]) => prev.map((v: number, i: number) => (i === idx ? v + 1 : v)));
    setVoted(true);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-100">
        <span className="text-lg">📊</span>
        <h3 className="font-bold text-gray-900">퀵폴</h3>
      </div>
      <div className="p-4">
        <p className="text-sm text-gray-700 mb-4 leading-relaxed">{poll.question}</p>
        <div className="flex flex-col gap-2">
          {poll.options.slice(0, 4).map((option: any, i: number) => {
            const votes = localVotes[i] ?? 0;
            const percent = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
            const isSelected = selectedIdx === i;

            return (
              <button
                key={i}
                onClick={() => handleVote(i)}
                className={`w-full text-left px-4 py-3 rounded-lg border text-sm transition-all relative overflow-hidden ${
                  voted
                    ? isSelected
                      ? "border-[#72C2FF] bg-[#E8F4FD]"
                      : "border-gray-200 bg-gray-50"
                    : "border-gray-200 text-gray-600 hover:border-[#72C2FF] hover:bg-[#E8F4FD]/30 cursor-pointer"
                }`}
              >
                {voted && (
                  <div
                    className={`absolute left-0 top-0 bottom-0 transition-all duration-500 ${isSelected ? "bg-[#72C2FF]/20" : "bg-gray-100"}`}
                    style={{ width: `${percent}%` }}
                  />
                )}
                <div className="relative flex justify-between items-center">
                  <span className={`truncate flex-1 ${voted && isSelected ? "font-medium text-[#4A9FD9]" : ""}`}>
                    {option.text}
                  </span>
                  {voted && (
                    <span className={`font-bold ml-2 whitespace-nowrap ${isSelected ? "text-[#4A9FD9]" : "text-gray-500"}`}>
                      {percent}%
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 text-xs text-gray-400">
          <span>참여 {(poll.participants + (voted ? 1 : 0)).toLocaleString()}명</span>
          <div className="flex items-center gap-1">
            <span className="text-red-500">♥</span>
            <span>{poll.likes}</span>
            <span className="text-[#72C2FF]">+{poll.reward}원</span>
          </div>
        </div>
      </div>
    </div>
  );
}
