// @ts-nocheck
export default function CashCard({
  userStats,
  onChargeClick,
  onWithdrawClick,
  onDetailClick,
  onCouponClick,
}: {
  userStats: any;
  onChargeClick: () => void;
  onWithdrawClick: () => void;
  onDetailClick: () => void;
  onCouponClick?: () => void;
}) {
  const availableCash = userStats.ssalmukCash - userStats.escrowCash;

  return (
    <div
      className="rounded-2xl overflow-hidden mb-5 animate-fadeUp delay-1"
      style={{ background: "linear-gradient(135deg, #8B7CF7 0%, #6B9FE7 50%, #72C2FF 100%)" }}
    >
      <div className="px-5 pt-5 pb-4 text-white">
        <div className="flex items-center justify-between mb-2">
          <div className="inline-block px-3 py-1 bg-white/20 rounded text-xs font-medium">
            내 쌀먹캐시
          </div>
          <button onClick={onDetailClick} className="text-xs text-white/70 hover:text-white transition-colors">
            상세보기 →
          </button>
        </div>
        <div className="text-3xl font-bold">
          {userStats.ssalmukCash.toLocaleString()}{" "}
          <span className="text-lg font-normal opacity-80">원</span>
        </div>
        {onCouponClick && (
          <button
            onClick={onCouponClick}
            className="mt-3 w-full py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium text-white transition-colors flex items-center justify-center gap-2"
          >
            <span>🎫</span>
            <span>내 쿠폰함</span>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 bg-white/10 backdrop-blur-sm">
        <div className="p-4 text-center border-r border-white/20">
          <div className="flex items-center justify-center gap-1 text-xs text-white/70 mb-1">
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10" strokeWidth="2" />
              <path strokeLinecap="round" strokeWidth="2" d="M12 8v4m0 4h.01" />
            </svg>
            <span>사용가능</span>
          </div>
          <div className="text-lg font-bold text-white mb-2">
            {availableCash.toLocaleString()}{" "}
            <span className="text-xs font-normal opacity-80">원</span>
          </div>
          <button
            onClick={onChargeClick}
            className="w-full py-1.5 bg-white/20 hover:bg-white/30 rounded text-xs font-medium text-white transition-colors"
          >
            충전하기
          </button>
        </div>

        <div className="p-4 text-center">
          <div className="flex items-center justify-center gap-1 text-xs text-white/70 mb-1">
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10" strokeWidth="2" />
              <path strokeLinecap="round" strokeWidth="2" d="M12 8v4m0 4h.01" />
            </svg>
            <span>에스크로 보관중</span>
          </div>
          <div className="text-lg font-bold text-white mb-2">
            {userStats.escrowCash.toLocaleString()}{" "}
            <span className="text-xs font-normal opacity-80">원</span>
          </div>
          <button
            onClick={onWithdrawClick}
            className="w-full py-1.5 bg-white/20 hover:bg-white/30 rounded text-xs font-medium text-white transition-colors"
          >
            출금하기
          </button>
        </div>
      </div>
    </div>
  );
}
