// @ts-nocheck
export default function SubFilters({
  filters,
  activeFilter,
  onFilterChange,
  onMyEntriesClick,
  onMyTradeClick,
  onWriteClick,
  todayCount = 0,
}: {
  filters: string[];
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  onMyEntriesClick?: () => void;
  onMyTradeClick?: () => void;
  onWriteClick?: () => void;
  todayCount?: number;
}) {
  return (
    <div className="flex items-center justify-between mb-2">
      <div className="flex gap-2">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => {
              if (filter === "내응모함" && onMyEntriesClick) {
                onMyEntriesClick();
              } else if (filter === "내거래함" && onMyTradeClick) {
                onMyTradeClick();
              } else {
                onFilterChange(filter);
              }
            }}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
              activeFilter === filter
                ? "bg-[#72C2FF] text-white"
                : "bg-white border border-gray-200 text-gray-600 hover:border-[#72C2FF] hover:text-[#72C2FF]"
            }`}
          >
            {filter}
          </button>
        ))}
      </div>
      {onWriteClick && (
        <button
          onClick={onWriteClick}
          className="flex items-center gap-1.5 px-4 py-1.5 bg-[#72C2FF] text-white text-sm font-semibold rounded-full hover:bg-[#5BA8E6] transition-colors"
        >
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
          </svg>
          등록하기
        </button>
      )}
    </div>
  );
}
