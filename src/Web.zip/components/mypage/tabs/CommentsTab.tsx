import { useNavigate } from "react-router-dom";
import type { ActivityItem } from "../types";

interface CommentsTabProps {
  comments: ActivityItem[];
}

export default function CommentsTab({ comments }: CommentsTabProps) {
  const navigate = useNavigate();

  return (
    <div className="divide-y divide-gray-100">
      {comments.map((comment) => (
        <div
          key={comment.id}
          onClick={() =>
            navigate(`/gallery?id=${comment.galleryId}&post=${comment.postId}`)
          }
          className="p-5 hover:bg-gray-50 transition-colors cursor-pointer"
        >
          <div className="flex items-start gap-3">
            {/* 아이콘 */}
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-lg shrink-0">
              {comment.targetIcon}
            </div>

            {/* 내용 */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-semibold text-gray-900">
                  {comment.targetName}
                </span>
              </div>
              <p className="text-xs text-gray-400 mb-2">{comment.date}</p>

              {comment.mentionedUser && (
                <p className="text-sm text-[#72C2FF] mb-1">
                  @{comment.mentionedUser} ♥♥
                </p>
              )}

              {comment.content && (
                <p className="text-sm text-gray-600 line-clamp-3 leading-relaxed">
                  {comment.content}
                </p>
              )}

              <div className="flex items-center gap-1 mt-2 text-gray-400">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1.5}
                    d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                  />
                </svg>
                <span className="text-xs">{comment.likes}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
