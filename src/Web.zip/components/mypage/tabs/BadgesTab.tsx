import type { BadgeItem } from "../types";

interface BadgesTabProps {
  badgeItems: BadgeItem[];
  equippedBadge: number;
  onSelectBadge: (badge: BadgeItem) => void;
}

export default function BadgesTab({
  badgeItems,
  equippedBadge,
  onSelectBadge,
}: BadgesTabProps) {
  const achievementBadges = badgeItems.filter((b) => b.category === "achievement");
  const rankingBadges = badgeItems.filter((b) => b.category === "ranking");

  return (
    <div className="p-5">
      {/* 업적 배지 */}
      <div className="mb-8">
        <h3 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#72C2FF]" />
          업적 배지
        </h3>
        <div className="grid grid-cols-6 gap-3">
          {achievementBadges.map((badge) => (
            <button
              key={badge.id}
              onClick={() => onSelectBadge(badge)}
              className={`relative flex flex-col items-center p-3 rounded-xl transition-all ${
                badge.owned
                  ? "hover:bg-gray-50 cursor-pointer"
                  : "opacity-40 grayscale cursor-pointer"
              } ${equippedBadge === badge.id ? "ring-2 ring-[#72C2FF] ring-offset-2" : ""}`}
            >
              <div
                className={`w-14 h-14 rounded-xl bg-gradient-to-br ${badge.bgColor} flex items-center justify-center text-2xl mb-2 shadow-sm`}
              >
                {badge.emoji}
              </div>
              <span className="text-xs text-gray-600 font-medium text-center line-clamp-1">
                {badge.name}
              </span>
              {equippedBadge === badge.id && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#72C2FF] rounded-full flex items-center justify-center">
                  <svg
                    className="w-3 h-3 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={3}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 랭킹 배지 */}
      <div>
        <h3 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          랭킹 배지
        </h3>
        <div className="grid grid-cols-6 gap-3">
          {rankingBadges.map((badge) => (
            <button
              key={badge.id}
              onClick={() => onSelectBadge(badge)}
              className={`relative flex flex-col items-center p-3 rounded-xl transition-all ${
                badge.owned
                  ? "hover:bg-gray-50 cursor-pointer"
                  : "opacity-40 grayscale cursor-pointer"
              } ${equippedBadge === badge.id ? "ring-2 ring-[#72C2FF] ring-offset-2" : ""}`}
            >
              <div
                className={`w-14 h-14 rounded-xl bg-gradient-to-br ${badge.bgColor} flex items-center justify-center text-2xl mb-2 shadow-sm`}
              >
                {badge.emoji}
              </div>
              <span className="text-xs text-gray-600 font-medium text-center line-clamp-1">
                {badge.name}
              </span>
              {equippedBadge === badge.id && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#72C2FF] rounded-full flex items-center justify-center">
                  <svg
                    className="w-3 h-3 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={3}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
