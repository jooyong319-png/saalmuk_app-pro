import { useNavigate } from "react-router-dom";
import type { PostItem } from "../types";

interface PostsTabProps {
  posts: PostItem[];
}

export default function PostsTab({ posts }: PostsTabProps) {
  const navigate = useNavigate();

  return (
    <div className="divide-y divide-gray-100">
      {posts.map((post) => (
        <div
          key={post.id}
          onClick={() =>
            navigate(`/gallery?id=${post.galleryId}&post=${post.id}`)
          }
          className="p-5 hover:bg-gray-50 transition-colors cursor-pointer"
        >
          <div className="flex items-start gap-3">
            {/* 게시판 아이콘 */}
            <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center text-lg shrink-0">
              {post.boardIcon}
            </div>

            {/* 내용 */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs text-[#72C2FF] font-medium">
                  {post.boardName}
                </span>
                <span className="text-xs text-gray-300">·</span>
                <span className="text-xs text-gray-400">{post.date}</span>
              </div>
              <h3 className="text-sm font-semibold text-gray-900 mb-1 line-clamp-1">
                {post.title}
              </h3>
              <p className="text-sm text-gray-500 line-clamp-2 leading-relaxed mb-2">
                {post.content}
              </p>

              <div className="flex items-center gap-4 text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  <svg
                    className="w-3.5 h-3.5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                    />
                  </svg>
                  {post.views.toLocaleString()}
                </span>
                <span className="flex items-center gap-1">
                  <svg
                    className="w-3.5 h-3.5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                    />
                  </svg>
                  {post.likes}
                </span>
                <span className="flex items-center gap-1">
                  <svg
                    className="w-3.5 h-3.5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                    />
                  </svg>
                  {post.comments}
                </span>
              </div>
            </div>

            {/* 화살표 */}
            <svg
              className="w-5 h-5 text-gray-300 shrink-0"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </div>
        </div>
      ))}
    </div>
  );
}
