// import React from "react";
import type { SocialLink, UserInfo } from "./types";
import { getPlatform } from "./data";

interface ProfileHeaderProps {
  user: UserInfo;
  socialLinks: SocialLink[];
  onOpenFollowerPopup: () => void;
  onOpenFollowingPopup: () => void;
  onOpenSocialModal: () => void;
  onOpenEditPopup: () => void;
  onOpenFameMenu: () => void;
}

export default function ProfileHeader({
  user,
  socialLinks,
  onOpenFollowerPopup,
  onOpenFollowingPopup,
  onOpenSocialModal,
  onOpenEditPopup,
  onOpenFameMenu,
}: ProfileHeaderProps) {
  return (
    <div className="bg-white rounded-2xl p-6 mb-4 shadow-sm">
      <div className="flex items-start gap-5">
        {/* 아바타 */}
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center text-4xl shadow-sm">
          {user.avatar}
        </div>

        {/* 프로필 정보 */}
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-xl font-bold text-gray-900">{user.nickname}</h1>
            <span className="px-2.5 py-1 rounded-full bg-[#E8F4FD] text-[#72C2FF] text-xs font-semibold">
              {user.badge}
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <button
              onClick={onOpenFollowerPopup}
              className="hover:text-[#72C2FF] transition-colors"
            >
              <span className="font-semibold text-gray-700">팔로워</span>{" "}
              {user.followers}
            </button>
            <span className="text-gray-300">·</span>
            <button
              onClick={onOpenFollowingPopup}
              className="hover:text-[#72C2FF] transition-colors"
            >
              <span className="font-semibold text-gray-700">팔로잉</span>{" "}
              {user.following}
            </button>
            <span className="text-gray-300">·</span>
            <button
              onClick={onOpenFameMenu}
              className="hover:text-[#72C2FF] transition-colors"
            >
              <span className="font-semibold text-gray-700">Fame</span>{" "}
              {user.fame}
            </button>
            <span className="text-gray-300">·</span>
            {/* 소셜 링크 버튼 */}
            <button
              onClick={onOpenSocialModal}
              className="flex items-center gap-1 hover:opacity-80 transition-opacity"
            >
              {socialLinks.length > 0 ? (
                <>
                  {socialLinks.slice(0, 3).map((link) => {
                    const platform = getPlatform(link.platformId);
                    return (
                      <span
                        key={link.platformId}
                        style={{ color: platform?.color }}
                        className="w-4 h-4 [&>svg]:w-4 [&>svg]:h-4"
                      >
                        {platform?.icon}
                      </span>
                    );
                  })}
                  {socialLinks.length > 3 && (
                    <span className="text-xs text-gray-400">
                      +{socialLinks.length - 3}
                    </span>
                  )}
                </>
              ) : (
                <>
                  <svg
                    className="w-4 h-4 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                    />
                  </svg>
                  <span className="text-xs text-gray-400">소셜 링크</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 버튼들 */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenEditPopup}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#72C2FF] text-[#72C2FF] text-sm font-semibold hover:bg-[#E8F4FD] transition-colors"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
              />
            </svg>
            프로필 편집
          </button>
          <button className="w-10 h-10 rounded-lg border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-gray-50 transition-colors">
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
