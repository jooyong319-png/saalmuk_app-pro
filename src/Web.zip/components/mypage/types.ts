// ─── 활동 아이템 (댓글) ───
export interface ActivityItem {
  id: number;
  type: "comment" | "post";
  targetIcon: string;
  targetName: string;
  targetType: string;
  date: string;
  content: string;
  mentionedUser?: string;
  likes?: number;
  postId?: number;
  galleryId?: number;
}

// ─── 게시글 아이템 ───
export interface PostItem {
  id: number;
  galleryId: number;
  boardIcon: string;
  boardName: string;
  title: string;
  content: string;
  date: string;
  views: number;
  likes: number;
  comments: number;
}

// ─── 아바타 아이템 ───
export interface AvatarItem {
  id: number;
  src: string;
  name: string;
  description: string;
  unlockFame: number;
  owned: boolean;
}

// ─── 배지 아이템 ───
export interface BadgeItem {
  id: number;
  emoji: string;
  name: string;
  description: string;
  bgColor: string;
  owned: boolean;
  category: "achievement" | "ranking";
}

// ─── 소셜 플랫폼 ───
export interface SocialPlatform {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  placeholder: string;
}

// ─── 소셜 링크 ───
export interface SocialLink {
  platformId: string;
  displayText: string;
  url: string;
}

// ─── 팔로워/팔로잉 ───
export interface FollowerItem {
  id: number;
  avatar: string;
  name: string;
  isFollowing: boolean;
}

export interface FollowingCommunity {
  id: number;
  icon: string;
  name: string;
}

export interface FollowingPerson {
  id: number;
  avatar: string;
  name: string;
}

// ─── 유저 정보 ───
export interface UserInfo {
  avatar: string;
  nickname: string;
  badge: string;
  followers: number;
  following: number;
  fame: number;
  youtubeCount: number;
  point: number;
  cash: number;
  coupons: number;
  marketItems: number;
}
