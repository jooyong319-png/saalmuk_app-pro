import type { UserInfo } from "./types";

interface SidebarProps {
  user: UserInfo;
}

export default function Sidebar({ user }: SidebarProps) {
  return (
    <div className="space-y-3">
      {/* 포인트 */}
      <button className="w-full bg-[#72C2FF] hover:bg-[#5BB5F5] text-white rounded-xl p-4 flex items-center justify-between transition-colors">
        <span className="font-semibold">포인트</span>
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold">
            {user.point.toLocaleString()}
          </span>
          <svg
            className="w-5 h-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5l7 7-7 7"
            />
          </svg>
        </div>
      </button>

      {/* 캐시 */}
      <button className="w-full bg-white hover:bg-gray-50 rounded-xl p-4 flex items-center justify-between border border-gray-100 transition-colors shadow-sm">
        <span className="font-semibold text-gray-700">캐시</span>
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-gray-900">
            {user.cash.toLocaleString()}
          </span>
          <svg
            className="w-5 h-5 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5l7 7-7 7"
            />
          </svg>
        </div>
      </button>

      {/* 보유쿠폰 */}
      <button className="w-full bg-white hover:bg-gray-50 rounded-xl p-4 flex items-center justify-between border border-gray-100 transition-colors shadow-sm">
        <span className="font-semibold text-gray-700">보유쿠폰</span>
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-gray-900">{user.coupons}</span>
          <svg
            className="w-5 h-5 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5l7 7-7 7"
            />
          </svg>
        </div>
      </button>

      {/* 장터 진행중 */}
      <button className="w-full bg-white hover:bg-gray-50 rounded-xl p-4 flex items-center justify-between border border-gray-100 transition-colors shadow-sm">
        <span className="font-semibold text-gray-700">장터 진행중</span>
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-gray-900">
            {user.marketItems}건
          </span>
          <svg
            className="w-5 h-5 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5l7 7-7 7"
            />
          </svg>
        </div>
      </button>
    </div>
  );
}
