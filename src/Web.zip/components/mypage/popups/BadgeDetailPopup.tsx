import type { BadgeItem } from "../types";

interface BadgeDetailPopupProps {
  badge: BadgeItem | null;
  onClose: () => void;
  equippedBadge: number;
  onEquipBadge: (badgeId: number) => void;
}

export default function BadgeDetailPopup({
  badge,
  onClose,
  equippedBadge,
  onEquipBadge,
}: BadgeDetailPopupProps) {
  if (!badge) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-[360px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 배지 이미지 영역 */}
        <div
          className={`relative h-48 bg-gradient-to-br ${badge.bgColor} flex items-center justify-center`}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
          <div
            className={`w-24 h-24 rounded-2xl bg-white/30 backdrop-blur-sm flex items-center justify-center text-5xl shadow-lg ${
              !badge.owned ? "grayscale opacity-60" : ""
            }`}
          >
            {badge.emoji}
          </div>
        </div>

        {/* 배지 정보 */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xl font-bold text-gray-900">{badge.name}</h3>
            {badge.owned ? (
              <span className="px-2.5 py-1 rounded-full bg-green-100 text-green-600 text-xs font-semibold">
                보유중
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-full bg-gray-100 text-gray-500 text-xs font-semibold">
                미보유
              </span>
            )}
          </div>

          <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-line mb-6">
            {badge.description}
          </p>

          {/* 장착 버튼 */}
          {badge.owned ? (
            equippedBadge === badge.id ? (
              <button
                disabled
                className="w-full py-3.5 rounded-xl bg-gray-200 text-gray-500 font-bold text-sm cursor-not-allowed"
              >
                대표배지 장착 중
              </button>
            ) : (
              <button
                onClick={() => onEquipBadge(badge.id)}
                className="w-full py-3.5 rounded-xl bg-[#72C2FF] hover:bg-[#5BB5F5] text-white font-bold text-sm transition-colors"
              >
                대표배지 장착
              </button>
            )
          ) : (
            <button
              disabled
              className="w-full py-3.5 rounded-xl bg-gray-200 text-gray-500 font-bold text-sm cursor-not-allowed"
            >
              미보유 배지입니다
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
