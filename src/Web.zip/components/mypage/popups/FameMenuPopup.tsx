interface FameMenuPopupProps {
  onClose: () => void;
  onSelectFame: () => void;
  onSelectReward: () => void;
  onSelectRanking: () => void;
}

export default function FameMenuPopup({
  onClose,
  onSelectFame,
  onSelectReward,
  onSelectRanking,
}: FameMenuPopupProps) {
  const menuItems = [
    { id: "fame", label: "Fame", icon: "⭐", onClick: onSelectFame },
    { id: "reward", label: "리워드", icon: "🎁", onClick: onSelectReward },
    {
      id: "ranking",
      label: "이달의 랭킹전",
      icon: "🏆",
      onClick: onSelectRanking,
    },
  ];

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      {/* 메뉴 카드 */}
      <div
        className="bg-white rounded-2xl shadow-2xl overflow-hidden w-[280px] animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 헤더 */}
        <div className="bg-[#72C2FF] px-5 py-4 flex items-center justify-between">
          <span className="text-[16px] font-bold text-white">Fame 메뉴</span>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* 메뉴 리스트 */}
        <div className="py-2">
          {menuItems.map((item, index) => (
            <button
              key={item.id}
              onClick={item.onClick}
              className={`w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-gray-50 transition-colors ${
                index !== menuItems.length - 1 ? "border-b border-gray-100" : ""
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="text-[15px] font-medium text-gray-700">
                {item.label}
              </span>
              <svg
                className="w-4 h-4 text-gray-400 ml-auto"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn { animation: fadeIn 0.2s ease-out; }
      `}</style>
    </div>
  );
}
