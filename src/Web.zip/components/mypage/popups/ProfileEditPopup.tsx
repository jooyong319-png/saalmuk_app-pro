import type { AvatarItem } from "../types";

interface ProfileEditPopupProps {
  show: boolean;
  onClose: () => void;
  nickname: string;
  onNicknameChange: (nickname: string) => void;
  selectedAvatar: number;
  onAvatarSelect: (avatarId: number) => void;
  avatarItems: AvatarItem[];
  onShowAvatarDetail: (avatar: AvatarItem) => void;
}

export default function ProfileEditPopup({
  show,
  onClose,
  nickname,
  onNicknameChange,
  selectedAvatar,
  onAvatarSelect,
  avatarItems,
  onShowAvatarDetail,
}: ProfileEditPopupProps) {
  if (!show) return null;

  return (
    <>
      {/* 오버레이 */}
      <div
        className="fixed inset-0 bg-black/50 z-[500]"
        onClick={onClose}
      />

      {/* 팝업 */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] max-h-[80vh] bg-white rounded-2xl shadow-2xl z-[501] overflow-hidden">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">프로필 편집</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-lg border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-gray-50 transition-colors"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* 콘텐츠 */}
        <div className="p-6 overflow-y-auto max-h-[calc(80vh-140px)]">
          {/* 프로필 & 닉네임 */}
          <div className="flex items-start gap-5 mb-8">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center overflow-hidden shadow-sm shrink-0">
              {selectedAvatar ? (
                <img
                  src={avatarItems.find((a) => a.id === selectedAvatar)?.src}
                  alt="선택된 아바타"
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-4xl">🐼</span>
              )}
            </div>
            <div className="flex-1">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                닉네임 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={nickname}
                onChange={(e) => onNicknameChange(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-gray-100 border-none text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#72C2FF]"
                placeholder="닉네임을 입력하세요"
              />
              <p className="text-xs text-gray-400 mt-2">
                닉네임은 2일 뒤 다시 바꿀 수 있어요
              </p>
            </div>
          </div>

          {/* 아바타 선택 */}
          <div className="grid grid-cols-4 gap-4">
            {avatarItems.map((avatar) => (
              <div
                key={avatar.id}
                onClick={() => {
                  if (avatar.owned) {
                    onAvatarSelect(avatar.id);
                  } else {
                    onShowAvatarDetail(avatar);
                  }
                }}
                className={`flex flex-col items-center cursor-pointer transition-all ${
                  !avatar.owned ? "opacity-50 grayscale" : ""
                }`}
              >
                <div
                  className={`w-24 h-24 rounded-xl overflow-hidden mb-2 transition-all ${
                    selectedAvatar === avatar.id
                      ? "ring-4 ring-[#72C2FF] ring-offset-2"
                      : "hover:ring-2 hover:ring-gray-200"
                  }`}
                >
                  <img
                    src={avatar.src}
                    alt={avatar.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-xs text-gray-600 text-center">
                  {avatar.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 푸터 */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-100 bg-gray-50">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-lg border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-100 transition-colors"
          >
            취소
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-lg bg-[#72C2FF] text-sm font-semibold text-white hover:bg-[#5BB5F5] transition-colors"
          >
            저장하기
          </button>
        </div>
      </div>
    </>
  );
}
