// import React from "react";
import type { SocialLink, SocialPlatform } from "../types";
import { getPlatform, MAX_SOCIAL_LINKS } from "../data";

interface SocialLinkModalProps {
  show: boolean;
  onClose: () => void;
  step: "select" | "edit";
  onStepChange: (step: "select" | "edit") => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  socialLinks: SocialLink[];
  filteredPlatforms: SocialPlatform[];
  editingLink: SocialLink | null;
  onEditingLinkChange: (link: SocialLink | null) => void;
  onPlatformSelect: (platformId: string) => void;
  onSave: () => void;
  onDelete: () => void;
}

export default function SocialLinkModal({
  show,
  onClose,
  step,
  onStepChange,
  searchQuery,
  onSearchChange,
  socialLinks,
  filteredPlatforms,
  editingLink,
  onEditingLinkChange,
  onPlatformSelect,
  onSave,
  onDelete,
}: SocialLinkModalProps) {
  if (!show) return null;

  // 커스텀 링크 개수 (custom_로 시작하는 것들)
  const customLinkCount = socialLinks.filter((l) =>
    l.platformId.startsWith("custom"),
  ).length;

  // 플랫폼이 이미 등록되어 있는지 확인 (커스텀 제외)
  const isPlatformRegistered = (platformId: string) => {
    if (platformId === "custom") return false; // 커스텀은 항상 추가 가능
    return socialLinks.some((l) => l.platformId === platformId);
  };

  // 커스텀 링크 추가 핸들러
  const handleCustomAdd = () => {
    if (socialLinks.length >= MAX_SOCIAL_LINKS) return;
    const customId = `custom_${Date.now()}`;
    onEditingLinkChange({
      platformId: customId,
      displayText: "",
      url: "",
    });
    onStepChange("edit");
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-[500]"
      onClick={onClose}
    >
      {step === "select" ? (
        // ─── 플랫폼 선택 화면 ───
        <div
          className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* 헤더 */}
          <div className="flex items-start justify-between p-5 pb-3">
            <div>
              <h2 className="text-lg font-bold text-gray-900">소셜 링크</h2>
              <p className="text-sm text-gray-500 mt-1">
                프로필에 표시할 링크를 최대 {MAX_SOCIAL_LINKS}개까지 추가할 수
                있습니다.
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors text-gray-400"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>

          {/* 검색 */}
          <div className="px-5 pb-3">
            <div className="relative">
              <svg
                className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              <input
                type="text"
                placeholder="찾다"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#72C2FF] focus:border-transparent"
              />
            </div>
          </div>

          {/* 플랫폼 목록 */}
          <div className="overflow-y-auto max-h-[340px] px-2">
            {filteredPlatforms
              .filter((p) => p.id !== "custom")
              .map((platform) => {
                const isRegistered = isPlatformRegistered(platform.id);
                const isDisabled =
                  !isRegistered && socialLinks.length >= MAX_SOCIAL_LINKS;

                return (
                  <button
                    key={platform.id}
                    onClick={() => !isDisabled && onPlatformSelect(platform.id)}
                    disabled={isDisabled}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors ${
                      isDisabled
                        ? "opacity-40 cursor-not-allowed"
                        : "hover:bg-gray-50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        style={{ color: platform.color }}
                        className="w-6 h-6 flex items-center justify-center"
                      >
                        {platform.icon}
                      </span>
                      <span className="text-gray-900 text-[15px]">
                        {platform.name}
                      </span>
                    </div>
                    {isRegistered && (
                      <svg
                        className="w-5 h-5 text-[#72C2FF]"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        strokeWidth={2.5}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    )}
                  </button>
                );
              })}

            {/* 커스텀 링크 추가 버튼 */}
            <button
              onClick={handleCustomAdd}
              disabled={socialLinks.length >= MAX_SOCIAL_LINKS}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors ${
                socialLinks.length >= MAX_SOCIAL_LINKS
                  ? "opacity-40 cursor-not-allowed"
                  : "hover:bg-gray-50"
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 flex items-center justify-center text-gray-500">
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                    />
                  </svg>
                </span>
                <span className="text-gray-900 text-[15px]">커스텀 링크</span>
              </div>
              {customLinkCount > 0 && (
                <span className="text-sm text-gray-400">
                  {customLinkCount}개 등록됨
                </span>
              )}
            </button>

            {/* 등록된 커스텀 링크 목록 */}
            {socialLinks
              .filter((l) => l.platformId.startsWith("custom"))
              .map((link) => (
                <button
                  key={link.platformId}
                  onClick={() => {
                    onEditingLinkChange({ ...link });
                    onStepChange("edit");
                  }}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors ml-4"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 flex items-center justify-center text-gray-400">
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                        />
                      </svg>
                    </span>
                    <span className="text-gray-700 text-sm">
                      {link.displayText || "커스텀 링크"}
                    </span>
                  </div>
                  <svg
                    className="w-5 h-5 text-[#72C2FF]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    strokeWidth={2.5}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </button>
              ))}
          </div>

          {/* 하단 버튼 */}
          <div className="flex items-center justify-end gap-2 p-4 border-t border-gray-100">
            <button
              onClick={onClose}
              className="px-5 py-2.5 text-gray-600 text-sm font-medium hover:bg-gray-100 rounded-lg transition-colors"
            >
              취소
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2.5 bg-[#4A7CFE] text-white text-sm font-medium rounded-lg hover:bg-[#3D6CE8] transition-colors"
            >
              저장
            </button>
          </div>
        </div>
      ) : (
        // ─── 링크 편집 화면 ───
        <div
          className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* 헤더 */}
          <div className="flex items-center justify-between p-5 pb-4">
            <h2 className="text-lg font-bold text-gray-900">소셜 링크</h2>
            <button
              onClick={() => {
                onStepChange("select");
                onEditingLinkChange(null);
              }}
              className="w-8 h-8 flex items-center justify-center rounded-full border border-gray-200 hover:bg-gray-50 transition-colors text-gray-500"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>

          {/* 입력 필드 */}
          {editingLink && (
            <div className="px-5 pb-5 space-y-4">
              {/* 표시 텍스트 */}
              <div>
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 focus-within:border-[#72C2FF] focus-within:ring-2 focus-within:ring-[#72C2FF]/20 transition-all">
                  <label className="block text-xs text-gray-500 mb-1">
                    표시 텍스트<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={editingLink.displayText}
                    onChange={(e) =>
                      onEditingLinkChange({
                        ...editingLink,
                        displayText: e.target.value,
                      })
                    }
                    placeholder={
                      editingLink.platformId.startsWith("custom")
                        ? "링크 이름"
                        : getPlatform(editingLink.platformId)?.name || ""
                    }
                    className="w-full bg-transparent text-gray-900 text-[15px] focus:outline-none"
                  />
                </div>
              </div>

              {/* URL */}
              <div>
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 focus-within:border-[#72C2FF] focus-within:ring-2 focus-within:ring-[#72C2FF]/20 transition-all">
                  <label className="block text-xs text-gray-500 mb-1">
                    {editingLink.platformId.startsWith("custom")
                      ? "URL"
                      : `${getPlatform(editingLink.platformId)?.name} URL`}
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="url"
                    value={editingLink.url}
                    onChange={(e) =>
                      onEditingLinkChange({
                        ...editingLink,
                        url: e.target.value,
                      })
                    }
                    placeholder={
                      editingLink.platformId.startsWith("custom")
                        ? "https://example.com"
                        : getPlatform(editingLink.platformId)?.placeholder
                    }
                    className="w-full bg-transparent text-gray-900 text-[15px] focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 하단 버튼 */}
          <div className="flex items-center justify-between p-4 border-t border-gray-100">
            <div>
              {socialLinks.some(
                (l) => l.platformId === editingLink?.platformId,
              ) && (
                <button
                  onClick={onDelete}
                  className="px-4 py-2.5 bg-red-500 text-white text-sm font-medium rounded-lg hover:bg-red-600 transition-colors"
                >
                  링크 삭제
                </button>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onStepChange("select");
                  onEditingLinkChange(null);
                }}
                className="px-5 py-2.5 text-gray-600 text-sm font-medium hover:bg-gray-100 rounded-lg transition-colors"
              >
                취소
              </button>
              <button
                onClick={onSave}
                disabled={!editingLink?.url || !editingLink?.displayText}
                className="px-5 py-2.5 bg-[#4A7CFE] text-white text-sm font-medium rounded-lg hover:bg-[#3D6CE8] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                저장
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
