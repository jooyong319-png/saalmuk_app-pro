import type { AvatarItem } from "../types";

interface AvatarDetailPopupProps {
  avatar: AvatarItem | null;
  onClose: () => void;
  userFame: number;
}

export default function AvatarDetailPopup({
  avatar,
  onClose,
  userFame,
}: AvatarDetailPopupProps) {
  if (!avatar) return null;

  return (
    <>
      {/* 오버레이 */}
      <div
        className="fixed inset-0 bg-black/50 z-[600]"
        onClick={onClose}
      />

      {/* 팝업 */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] bg-white rounded-2xl shadow-2xl z-[601] overflow-hidden">
        {/* 닫기 버튼 */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-lg border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-gray-50 transition-colors z-10"
        >
          <svg
            className="w-5 h-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>

        {/* 콘텐츠 */}
        <div className="p-8 text-center">
          {/* 제목 */}
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            {avatar.name}
          </h2>
          <p className="text-sm text-gray-500 mb-8 px-4 leading-relaxed">
            {avatar.description}
          </p>

          {/* 아바타 이미지 (잠금 상태) */}
          <div className="w-48 h-48 mx-auto mb-8 rounded-2xl overflow-hidden grayscale opacity-60">
            <img
              src={avatar.src}
              alt={avatar.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* 진행 바 */}
          <div className="w-full h-2 bg-gray-200 rounded-full mb-6 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-orange-400 to-orange-500"
              style={{
                width: `${Math.min((userFame / avatar.unlockFame) * 100, 100)}%`,
              }}
            />
          </div>

          {/* 잠금해제 정보 */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-xl font-bold text-gray-900">
                {avatar.unlockFame.toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">잠금해제 Fame</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4 flex items-center justify-center gap-2">
              <div className="w-5 h-3 rounded-sm bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400" />
              <span className="text-lg font-bold text-gray-900">공통</span>
            </div>
          </div>

          {/* 장착하기 버튼 (비활성화) */}
          <button
            disabled
            className="w-full py-4 rounded-xl bg-gray-200 text-gray-400 font-semibold cursor-not-allowed"
          >
            장착하기
          </button>
        </div>
      </div>
    </>
  );
}
