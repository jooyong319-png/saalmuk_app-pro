import { useState } from "react";

interface RankingPopupProps {
  onClose: () => void;
  initialTab?: "fame" | "reward";
}

interface RankUser {
  rank: number;
  nickname: string;
  avatar?: string;
  badge?: string;
  value: number;
  reward: number;
}

// 더미 데이터
const fameRankings: RankUser[] = [
  { rank: 1, nickname: "힌고미이", badge: "팔로우 부자", value: 98121, reward: 100000 },
  { rank: 2, nickname: "iouiouip", value: 55121, reward: 50000 },
  { rank: 3, nickname: "awerfasd", avatar: "🐸", value: 25121, reward: 25000 },
  { rank: 4, nickname: "word349", value: 15121, reward: 20000 },
  { rank: 5, nickname: "gfhgjhbm", value: 13121, reward: 15000 },
  { rank: 6, nickname: "tedtedoi", avatar: "🌻", value: 13121, reward: 10000 },
  { rank: 7, nickname: "sddcdcs", avatar: "🌻", value: 13121, reward: 10000 },
  { rank: 8, nickname: "player88", value: 12500, reward: 8000 },
  { rank: 9, nickname: "gamer99", value: 11800, reward: 7000 },
  { rank: 10, nickname: "pro100", value: 10500, reward: 5000 },
];

const rewardRankings: RankUser[] = [
  { rank: 1, nickname: "힌고미이", badge: "팔로우 부자", value: 98121, reward: 100000 },
  { rank: 2, nickname: "iouiouip", value: 55121, reward: 50000 },
  { rank: 3, nickname: "awerfasd", avatar: "🐸", value: 25121, reward: 25000 },
  { rank: 4, nickname: "word349", value: 15121, reward: 20000 },
  { rank: 5, nickname: "gfhgjhbm", value: 13121, reward: 15000 },
  { rank: 6, nickname: "tedtedoi", avatar: "🌻", value: 13121, reward: 10000 },
  { rank: 7, nickname: "sddcdcs", avatar: "🌻", value: 13121, reward: 10000 },
];

// 내 정보
const myInfo = {
  nickname: "쿠놀",
  avatar: "https://picsum.photos/100/100?random=me",
  fame: 121,
  reward: 121,
  point: 0,
};

export default function RankingPopup({
  onClose,
  initialTab = "fame",
}: RankingPopupProps) {
  const [activeTab, setActiveTab] = useState<"fame" | "reward">(initialTab);

  const rankings = activeTab === "fame" ? fameRankings : rewardRankings;
  const currentMonth = new Date().getMonth() + 1;

  // 순위 메달/숫자 렌더링
  const renderRank = (rank: number) => {
    if (rank === 1) return <span className="text-2xl">🥇</span>;
    if (rank === 2) return <span className="text-2xl">🥈</span>;
    if (rank === 3) return <span className="text-2xl">🥉</span>;
    return <span className="text-[16px] font-bold text-gray-500">{rank}</span>;
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-[600px] max-h-[85vh] overflow-hidden shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 헤더 */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <h2 className="text-[18px] font-bold text-gray-900">랭킹</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-500 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 탭 */}
        <div className="flex border-b border-gray-100 shrink-0">
          <button
            onClick={() => setActiveTab("fame")}
            className={`flex-1 py-3.5 text-[15px] font-semibold text-center transition-colors ${
              activeTab === "fame"
                ? "text-gray-900 border-b-2 border-gray-900"
                : "text-gray-400 hover:text-gray-600"
            }`}
          >
            Fame
          </button>
          <button
            onClick={() => setActiveTab("reward")}
            className={`flex-1 py-3.5 text-[15px] font-semibold text-center transition-colors ${
              activeTab === "reward"
                ? "text-gray-900 border-b-2 border-gray-900"
                : "text-gray-400 hover:text-gray-600"
            }`}
          >
            리워드
          </button>
        </div>

        {/* 랭킹전 배너 */}
        <div className="px-6 py-5 bg-gray-50 shrink-0">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl">P</span>
            </div>
            <span className="text-[20px] font-bold text-gray-900">{currentMonth}월 랭킹전</span>
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </div>

          {/* 총 상금 / 남은 시간 */}
          <div className="flex bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="flex-1 py-4 text-center border-r border-gray-200">
              <p className="text-[12px] text-gray-500 mb-1">총 상금</p>
              <p className="text-[18px] font-bold text-gray-900 flex items-center justify-center gap-1">
                <span className="text-yellow-500">⭐</span>
                335,000
              </p>
            </div>
            <div className="flex-1 py-4 text-center">
              <p className="text-[12px] text-gray-500 mb-1">남은 시간</p>
              <p className="text-[18px] font-bold text-gray-900">6일 8시간 27분</p>
            </div>
          </div>
        </div>

        {/* 내 정보 카드 */}
        <div className="px-6 py-4 border-b border-gray-100 shrink-0">
          <div className="flex items-center gap-4 p-4 bg-[#E8F4FC] rounded-xl">
            <div className="w-14 h-14 rounded-full overflow-hidden bg-white shadow-sm">
              <img
                src={myInfo.avatar}
                alt={myInfo.nickname}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <p className="text-[16px] font-bold text-gray-900">{myInfo.nickname}</p>
              <p className="text-[14px] text-gray-500">
                {activeTab === "fame" ? myInfo.fame.toLocaleString() : myInfo.reward.toLocaleString()} {activeTab === "fame" ? "Fame" : "리워드"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <span className="text-white font-bold text-xs">P</span>
              </div>
              <span className="text-[18px] font-bold text-gray-900">{myInfo.point.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* 랭킹 리스트 */}
        <div className="flex-1 overflow-y-auto">
          {rankings.map((user) => (
            <div
              key={user.rank}
              className="flex items-center gap-4 px-6 py-4 border-b border-gray-50 hover:bg-gray-50 transition-colors"
            >
              {/* 순위 */}
              <div className="w-10 flex items-center justify-center">
                {renderRank(user.rank)}
              </div>

              {/* 아바타 */}
              <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                {user.avatar ? (
                  <span className="text-2xl">{user.avatar}</span>
                ) : (
                  <svg className="w-7 h-7 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                  </svg>
                )}
              </div>

              {/* 닉네임 + 배지 + 값 */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[15px] font-semibold text-gray-900 truncate">
                    {user.nickname}
                  </span>
                  {user.badge && (
                    <span className="text-[11px] px-2 py-0.5 bg-purple-100 text-purple-600 rounded-full font-medium shrink-0">
                      {user.badge}
                    </span>
                  )}
                </div>
                <p className="text-[13px] text-gray-500 mt-0.5">
                  {user.value.toLocaleString()} {activeTab === "fame" ? "Fame" : "리워드"}
                </p>
              </div>

              {/* 리워드 */}
              <div className="flex items-center gap-2 shrink-0">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <span className="text-white font-bold text-[10px]">P</span>
                </div>
                <span className="text-[16px] font-bold text-gray-900">
                  {user.reward.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
