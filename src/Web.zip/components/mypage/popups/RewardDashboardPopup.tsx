interface RewardDashboardPopupProps {
  onClose: () => void;
  totalReward?: number;
  monthlyReward?: number;
}

export default function RewardDashboardPopup({
  onClose,
  totalReward = 1432500,
  monthlyReward = 432500,
}: RewardDashboardPopupProps) {
  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-[420px] overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 헤더 */}
        <div className="bg-[#72C2FF] px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <span className="text-2xl">🎁</span>
            </div>
            <span className="text-[18px] font-bold text-white">리워드</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 전체 리워드 */}
        <div className="p-6">
          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-8 border border-yellow-200">
            <p className="text-[14px] text-gray-500 text-center mb-3">전체 리워드</p>
            <p className="text-[48px] font-bold text-yellow-600 text-center tracking-tight">
              {totalReward.toLocaleString()}
            </p>
            <p className="text-[13px] text-gray-400 text-center mt-3">
              활동으로 획득한 총 리워드
            </p>
          </div>
        </div>

        {/* 이달의 리워드 */}
        <div className="px-6 pb-6">
          <div className="bg-gray-50 rounded-xl p-8 border border-gray-100">
            <div className="flex items-center justify-center gap-2 mb-3">
              <p className="text-[14px] text-gray-500">이달의 리워드</p>
              <span className="text-[11px] text-gray-400 bg-white px-2.5 py-1 rounded-full border border-gray-200">
                {new Date().getFullYear()}년 {new Date().getMonth() + 1}월
              </span>
            </div>
            <p className="text-[40px] font-bold text-gray-700 text-center tracking-tight">
              {monthlyReward.toLocaleString()}
            </p>
          </div>
        </div>

        {/* 안내 문구 */}
        <div className="px-6 pb-6">
          <p className="text-[12px] text-gray-400 text-center">
            리워드는 랭킹전 참여 및 이벤트를 통해 획득할 수 있습니다
          </p>
        </div>
      </div>
    </div>
  );
}
