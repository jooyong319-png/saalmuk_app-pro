import { useState } from "react";

interface FamePopupProps {
  onClose: () => void;
  totalFame?: number;
  postFame?: number;
  commentFame?: number;
  postCount?: number;
  commentCount?: number;
  monthlyFame?: number;
  monthlyPostFame?: number;
  monthlyCommentFame?: number;
  monthlyPostCount?: number;
  monthlyCommentCount?: number;
  totalReward?: number;
  monthlyReward?: number;
}

interface RankUser {
  rank: number;
  nickname: string;
  avatar?: string;
  badge?: string;
  value: number;
  reward: number;
}

// 더미 랭킹 데이터
const fameRankings: RankUser[] = [
  { rank: 1, nickname: "힌고미이", badge: "팔로우 부자", value: 98121, reward: 100000 },
  { rank: 2, nickname: "iouiouip", value: 55121, reward: 50000 },
  { rank: 3, nickname: "awerfasd", avatar: "🐸", value: 25121, reward: 25000 },
  { rank: 4, nickname: "word349", value: 15121, reward: 20000 },
  { rank: 5, nickname: "gfhgjhbm", value: 13121, reward: 15000 },
  { rank: 6, nickname: "tedtedoi", avatar: "🌻", value: 13121, reward: 10000 },
  { rank: 7, nickname: "sddcdcs", avatar: "🌻", value: 13121, reward: 10000 },
];

const rewardRankings: RankUser[] = [
  { rank: 1, nickname: "힌고미이", badge: "팔로우 부자", value: 98121, reward: 100000 },
  { rank: 2, nickname: "iouiouip", value: 55121, reward: 50000 },
  { rank: 3, nickname: "awerfasd", avatar: "🐸", value: 25121, reward: 25000 },
  { rank: 4, nickname: "word349", value: 15121, reward: 20000 },
  { rank: 5, nickname: "gfhgjhbm", value: 13121, reward: 15000 },
  { rank: 6, nickname: "tedtedoi", avatar: "🌻", value: 13121, reward: 10000 },
  { rank: 7, nickname: "sddcdcs", avatar: "🌻", value: 13121, reward: 10000 },
];

const myInfo = {
  nickname: "쿠놀",
  avatar: "https://picsum.photos/100/100?random=me",
  fame: 121,
  reward: 121,
  point: 0,
};

export default function FamePopup({
  onClose,
  totalFame = 1432500,
  postFame = 840500,
  commentFame = 592000,
  postCount = 1250,
  commentCount = 3840,
  monthlyFame = 432500,
  monthlyPostFame = 40500,
  monthlyCommentFame = 92000,
  monthlyPostCount = 85,
  monthlyCommentCount = 620,
  totalReward = 1432500,
  monthlyReward = 432500,
}: FamePopupProps) {
  const [activeMenu, setActiveMenu] = useState<"fame" | "reward" | "ranking">("fame");
  const [rankingTab, setRankingTab] = useState<"fame" | "reward">("fame");

  const menuItems = [
    { id: "fame" as const, label: "Fame" },
    { id: "reward" as const, label: "리워드" },
    { id: "ranking" as const, label: "이달의 랭킹전" },
  ];

  const rankings = rankingTab === "fame" ? fameRankings : rewardRankings;
  const currentMonth = new Date().getMonth() + 1;

  const renderRank = (rank: number) => {
    if (rank === 1) return <span className="text-xl">🥇</span>;
    if (rank === 2) return <span className="text-xl">🥈</span>;
    if (rank === 3) return <span className="text-xl">🥉</span>;
    return <span className="text-[15px] font-bold text-gray-500">{rank}</span>;
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl overflow-hidden flex w-[900px] h-[700px]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 왼쪽 메뉴 */}
        <div className="w-[180px] bg-gray-50 border-r border-gray-100 py-6 shrink-0">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveMenu(item.id)}
              className={`w-full text-left px-6 py-3 text-[15px] font-medium transition-colors ${
                activeMenu === item.id
                  ? "text-gray-900 bg-white border-r-2 border-[#72C2FF]"
                  : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* 오른쪽 콘텐츠 */}
        <div className="flex-1 relative flex flex-col overflow-hidden">
          {/* 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full hover:bg-black/10 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors z-10"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* Fame 대시보드 */}
          {activeMenu === "fame" && (
            <div className="flex-1 overflow-y-auto p-6 bg-white">
              {/* 헤더 */}
              <div className="flex items-center justify-center gap-2 mb-6">
                <span className="text-xl">⭐</span>
                <span className="text-[17px] font-bold text-gray-800">Fame 대시보드</span>
              </div>

              {/* 전체 Fame */}
              <div className="bg-gradient-to-r from-[#72C2FF]/10 to-[#72C2FF]/5 rounded-xl p-5 border border-[#72C2FF]/20 mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[13px] text-gray-500 font-medium">전체 Fame</span>
                </div>
                <p className="text-[42px] font-bold text-gray-900 tracking-tight">
                  {totalFame.toLocaleString()}
                </p>
                <p className="text-[12px] text-gray-400 mt-1">
                  글과 댓글에서 받은 전체 기간 추천수의 합
                </p>

                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[12px]">📝</span>
                      <span className="text-[12px] text-gray-500">게시글 Fame</span>
                    </div>
                    <p className="text-[22px] font-bold text-gray-800">{postFame.toLocaleString()}</p>
                    <p className="text-[11px] text-gray-400">/ 게시글 {postCount.toLocaleString()}개</p>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[12px]">💬</span>
                      <span className="text-[12px] text-gray-500">댓글 Fame</span>
                    </div>
                    <p className="text-[22px] font-bold text-gray-800">{commentFame.toLocaleString()}</p>
                    <p className="text-[11px] text-gray-400">/ 댓글 {commentCount.toLocaleString()}개</p>
                  </div>
                </div>
              </div>

              {/* 이달의 Fame */}
              <div className="bg-orange-50 rounded-xl p-5 border border-orange-100">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-orange-500">🔥</span>
                    <span className="text-[13px] text-gray-500 font-medium">이달의 Fame</span>
                  </div>
                  <span className="text-[11px] text-gray-400 bg-white px-2 py-0.5 rounded-full border border-gray-200">
                    {new Date().getFullYear()}년 {new Date().getMonth() + 1}월
                  </span>
                </div>
                <p className="text-[36px] font-bold text-orange-500 tracking-tight">
                  {monthlyFame.toLocaleString()}
                </p>
                <p className="text-[12px] text-gray-400 mt-1">
                  이번 달 글과 댓글에서 받은 추천수의 합
                </p>

                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="bg-white rounded-lg p-4 border border-gray-100">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[11px]">📝</span>
                      <span className="text-[12px] text-gray-500">게시글 Fame</span>
                    </div>
                    <p className="text-[20px] font-bold text-gray-800">{monthlyPostFame.toLocaleString()}</p>
                    <p className="text-[11px] text-gray-400">/ 게시글 {monthlyPostCount}개</p>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-gray-100">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[11px]">💬</span>
                      <span className="text-[12px] text-gray-500">댓글 Fame</span>
                    </div>
                    <p className="text-[20px] font-bold text-gray-800">{monthlyCommentFame.toLocaleString()}</p>
                    <p className="text-[11px] text-gray-400">/ 댓글 {monthlyCommentCount}개</p>
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-gray-400 text-center mt-4">
                Fame = 글 추천수 + 댓글 추천수 · 총 갯수는 작성한 글/댓글 수
              </p>
            </div>
          )}

          {/* 리워드 대시보드 */}
          {activeMenu === "reward" && (
            <div className="flex-1 overflow-y-auto p-6 bg-white flex flex-col justify-center">
              {/* 헤더 */}
              <div className="flex items-center justify-center gap-2 mb-6">
                <span className="text-xl">🎁</span>
                <span className="text-[17px] font-bold text-gray-800">리워드</span>
              </div>

              {/* 전체 리워드 */}
              <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-8 border border-yellow-200 mb-4">
                <p className="text-[14px] text-gray-500 text-center mb-3">전체 리워드</p>
                <p className="text-[48px] font-bold text-yellow-600 text-center tracking-tight">
                  {totalReward.toLocaleString()}
                </p>
                <p className="text-[12px] text-gray-400 text-center mt-2">
                  활동으로 획득한 총 리워드
                </p>
              </div>

              {/* 이달의 리워드 */}
              <div className="bg-gray-50 rounded-xl p-8 border border-gray-100">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <p className="text-[14px] text-gray-500">이달의 리워드</p>
                  <span className="text-[11px] text-gray-400 bg-white px-2 py-0.5 rounded-full border border-gray-200">
                    {new Date().getFullYear()}년 {new Date().getMonth() + 1}월
                  </span>
                </div>
                <p className="text-[42px] font-bold text-gray-700 text-center tracking-tight">
                  {monthlyReward.toLocaleString()}
                </p>
              </div>
            </div>
          )}

          {/* 이달의 랭킹전 */}
          {activeMenu === "ranking" && (
            <div className="flex-1 flex flex-col overflow-hidden bg-white">
              {/* 탭 */}
              <div className="flex border-b border-gray-100 shrink-0">
                <button
                  onClick={() => setRankingTab("fame")}
                  className={`flex-1 py-3 text-[14px] font-semibold text-center transition-colors ${
                    rankingTab === "fame"
                      ? "text-gray-900 border-b-2 border-gray-900"
                      : "text-gray-400 hover:text-gray-600"
                  }`}
                >
                  Fame
                </button>
                <button
                  onClick={() => setRankingTab("reward")}
                  className={`flex-1 py-3 text-[14px] font-semibold text-center transition-colors ${
                    rankingTab === "reward"
                      ? "text-gray-900 border-b-2 border-gray-900"
                      : "text-gray-400 hover:text-gray-600"
                  }`}
                >
                  리워드
                </button>
              </div>

              {/* 랭킹전 배너 */}
              <div className="px-5 py-4 bg-gray-50 border-b border-gray-100 shrink-0">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-md">
                    <span className="text-white font-bold text-lg">P</span>
                  </div>
                  <span className="text-[18px] font-bold text-gray-900">{currentMonth}월 랭킹전</span>
                  <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>

                <div className="flex bg-white rounded-lg border border-gray-200 overflow-hidden">
                  <div className="flex-1 py-3 text-center border-r border-gray-200">
                    <p className="text-[11px] text-gray-500 mb-0.5">총 상금</p>
                    <p className="text-[16px] font-bold text-gray-900 flex items-center justify-center gap-1">
                      <span className="text-yellow-500">⭐</span>
                      335,000
                    </p>
                  </div>
                  <div className="flex-1 py-3 text-center">
                    <p className="text-[11px] text-gray-500 mb-0.5">남은 시간</p>
                    <p className="text-[16px] font-bold text-gray-900">6일 8시간 27분</p>
                  </div>
                </div>
              </div>

              {/* 내 정보 카드 */}
              <div className="px-5 py-3 border-b border-gray-100 shrink-0">
                <div className="flex items-center gap-3 p-3 bg-[#E8F4FC] rounded-xl">
                  <div className="w-11 h-11 rounded-full overflow-hidden bg-white shadow-sm">
                    <img src={myInfo.avatar} alt={myInfo.nickname} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[14px] font-bold text-gray-900">{myInfo.nickname}</p>
                    <p className="text-[12px] text-gray-500">
                      {rankingTab === "fame" ? myInfo.fame : myInfo.reward} {rankingTab === "fame" ? "Fame" : "리워드"}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                      <span className="text-white font-bold text-[10px]">P</span>
                    </div>
                    <span className="text-[15px] font-bold text-gray-900">{myInfo.point}</span>
                  </div>
                </div>
              </div>

              {/* 랭킹 리스트 */}
              <div className="flex-1 overflow-y-auto">
                {rankings.map((user) => (
                  <div
                    key={user.rank}
                    className="flex items-center gap-3 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition-colors"
                  >
                    <div className="w-8 flex items-center justify-center">
                      {renderRank(user.rank)}
                    </div>
                    <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                      {user.avatar ? (
                        <span className="text-xl">{user.avatar}</span>
                      ) : (
                        <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                        </svg>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[14px] font-semibold text-gray-900 truncate">{user.nickname}</span>
                        {user.badge && (
                          <span className="text-[10px] px-1.5 py-0.5 bg-purple-100 text-purple-600 rounded font-medium shrink-0">
                            {user.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[12px] text-gray-500">
                        {user.value.toLocaleString()} {rankingTab === "fame" ? "Fame" : "리워드"}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <div className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                        <span className="text-white font-bold text-[9px]">P</span>
                      </div>
                      <span className="text-[14px] font-bold text-gray-900">{user.reward.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
