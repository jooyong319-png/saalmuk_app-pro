interface FameDashboardPopupProps {
  onClose: () => void;
  totalFame?: number;
  postFame?: number;
  commentFame?: number;
  postCount?: number;
  commentCount?: number;
  monthlyFame?: number;
  monthlyPostFame?: number;
  monthlyCommentFame?: number;
  monthlyPostCount?: number;
  monthlyCommentCount?: number;
}

export default function FameDashboardPopup({
  onClose,
  totalFame = 1432500,
  postFame = 840500,
  commentFame = 592000,
  postCount = 1250,
  commentCount = 3840,
  monthlyFame = 432500,
  monthlyPostFame = 40500,
  monthlyCommentFame = 92000,
  monthlyPostCount = 85,
  monthlyCommentCount = 620,
}: FameDashboardPopupProps) {
  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-[480px] overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 헤더 */}
        <div className="bg-[#72C2FF] px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <span className="text-2xl">⭐</span>
            </div>
            <span className="text-[18px] font-bold text-white">Fame 대시보드</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 전체 Fame */}
        <div className="p-6">
          <div className="bg-gradient-to-r from-[#72C2FF]/10 to-[#72C2FF]/5 rounded-xl p-6 border border-[#72C2FF]/20">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-yellow-500">★</span>
              <span className="text-[14px] text-gray-500 font-medium">전체 FAME</span>
            </div>
            <p className="text-[40px] font-bold text-gray-900 tracking-tight">
              {totalFame.toLocaleString()}
            </p>
            <p className="text-[13px] text-gray-400 mt-1">
              글과 댓글에서 받은 전체 기간 추천수의 합
            </p>

            {/* 게시글 / 댓글 Fame */}
            <div className="grid grid-cols-2 gap-4 mt-5">
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[14px]">📝</span>
                  <span className="text-[13px] text-gray-500">게시글 Fame</span>
                </div>
                <p className="text-[24px] font-bold text-gray-800">{postFame.toLocaleString()}</p>
                <p className="text-[12px] text-gray-400 mt-1">/ 게시글 {postCount.toLocaleString()}개</p>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[14px]">💬</span>
                  <span className="text-[13px] text-gray-500">댓글 Fame</span>
                </div>
                <p className="text-[24px] font-bold text-gray-800">{commentFame.toLocaleString()}</p>
                <p className="text-[12px] text-gray-400 mt-1">/ 댓글 {commentCount.toLocaleString()}개</p>
              </div>
            </div>
          </div>
        </div>

        {/* 이달의 Fame */}
        <div className="px-6 pb-6">
          <div className="bg-orange-50 rounded-xl p-6 border border-orange-100">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-orange-500">🔥</span>
                <span className="text-[14px] text-gray-500 font-medium">이달의 FAME</span>
              </div>
              <span className="text-[12px] text-gray-500 bg-white px-3 py-1 rounded-full border border-gray-200">
                {new Date().getFullYear()}년 {new Date().getMonth() + 1}월
              </span>
            </div>
            <p className="text-[36px] font-bold text-orange-500 tracking-tight">
              {monthlyFame.toLocaleString()}
            </p>
            <p className="text-[13px] text-gray-400 mt-1">
              이번 달 글과 댓글에서 받은 추천수의 합
            </p>

            {/* 이달 게시글 / 댓글 Fame */}
            <div className="grid grid-cols-2 gap-4 mt-5">
              <div className="bg-white rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[13px]">📝</span>
                  <span className="text-[12px] text-gray-500">게시글 Fame</span>
                </div>
                <p className="text-[20px] font-bold text-gray-800">{monthlyPostFame.toLocaleString()}</p>
                <p className="text-[12px] text-gray-400 mt-1">/ 게시글 {monthlyPostCount}개</p>
              </div>
              <div className="bg-white rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[13px]">💬</span>
                  <span className="text-[12px] text-gray-500">댓글 Fame</span>
                </div>
                <p className="text-[20px] font-bold text-gray-800">{monthlyCommentFame.toLocaleString()}</p>
                <p className="text-[12px] text-gray-400 mt-1">/ 댓글 {monthlyCommentCount}개</p>
              </div>
            </div>
          </div>
        </div>

        {/* Fame 계산식 */}
        <div className="px-6 pb-6">
          <p className="text-[12px] text-gray-400 text-center">
            Fame = 글 추천수 + 댓글 추천수 · 총 갯수는 작성한 글/댓글 수
          </p>
        </div>
      </div>
    </div>
  );
}
