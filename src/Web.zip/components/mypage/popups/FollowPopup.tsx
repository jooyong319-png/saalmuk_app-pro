import type { FollowerItem, FollowingCommunity, FollowingPerson } from "../types";

interface FollowPopupProps {
  show: boolean;
  onClose: () => void;
  activeTab: "follower" | "following";
  onTabChange: (tab: "follower" | "following") => void;
  followingTab: "community" | "people";
  onFollowingTabChange: (tab: "community" | "people") => void;
  followers: FollowerItem[];
  followingCommunities: FollowingCommunity[];
  followingPeople: FollowingPerson[];
  nickname: string;
}

export default function FollowPopup({
  show,
  onClose,
  activeTab,
  onTabChange,
  followingTab,
  onFollowingTabChange,
  followers,
  followingCommunities,
  followingPeople,
  nickname,
}: FollowPopupProps) {
  if (!show) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-[900px] h-[600px] flex overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 왼쪽 사이드바 */}
        <div className="w-[120px] bg-gray-50 p-3 border-r border-gray-100">
          <button
            onClick={() => onTabChange("follower")}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              activeTab === "follower"
                ? "bg-white text-gray-900 shadow-sm"
                : "text-gray-500 hover:bg-gray-100"
            }`}
          >
            팔로워
          </button>
          <button
            onClick={() => onTabChange("following")}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors mt-1 ${
              activeTab === "following"
                ? "bg-white text-gray-900 shadow-sm"
                : "text-gray-500 hover:bg-gray-100"
            }`}
          >
            팔로잉
          </button>
        </div>

        {/* 오른쪽 메인 영역 */}
        <div className="flex-1 flex flex-col">
          {/* 헤더 */}
          <div className="p-5 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                {activeTab === "follower" ? (
                  <>
                    <h3 className="text-lg font-bold text-gray-900">
                      팔로워 {followers.length}
                    </h3>
                    <p className="text-sm text-gray-400 mt-0.5">
                      {nickname}님을 팔로우하는 사람들이에요.
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="text-lg font-bold text-gray-900">
                      팔로잉 {followingCommunities.length + followingPeople.length}
                    </h3>
                    <p className="text-sm text-gray-400 mt-0.5">
                      {nickname}님이 팔로우 중이에요.
                    </p>
                  </>
                )}
              </div>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>

            {/* 팔로잉 서브탭 */}
            {activeTab === "following" && (
              <div className="flex mt-4 bg-gray-100 rounded-xl p-1">
                <button
                  onClick={() => onFollowingTabChange("community")}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                    followingTab === "community"
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  커뮤니티 {followingCommunities.length}
                </button>
                <button
                  onClick={() => onFollowingTabChange("people")}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                    followingTab === "people"
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  사람 {followingPeople.length}
                </button>
              </div>
            )}
          </div>

          {/* 리스트 */}
          <div className="flex-1 overflow-y-auto p-3">
            {activeTab === "follower"
              ? // 팔로워 리스트
                followers.map((follower) => (
                  <div
                    key={follower.id}
                    className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-lg">
                        {follower.avatar}
                      </div>
                      <span className="font-medium text-gray-900">
                        {follower.name}
                      </span>
                    </div>
                    <button
                      className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-colors ${
                        follower.isFollowing
                          ? "bg-gray-100 text-gray-500 hover:bg-gray-200"
                          : "bg-[#72C2FF] text-white hover:bg-[#5BB5F5]"
                      }`}
                    >
                      {follower.isFollowing ? "팔로잉" : "팔로우"}
                    </button>
                  </div>
                ))
              : // 팔로잉 리스트
                followingTab === "community"
                ? followingCommunities.map((community) => (
                    <div
                      key={community.id}
                      className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-xl transition-colors cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-lg">
                        {community.icon}
                      </div>
                      <span className="font-medium text-gray-900">
                        {community.name}
                      </span>
                    </div>
                  ))
                : followingPeople.map((person) => (
                    <div
                      key={person.id}
                      className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-lg">
                          {person.avatar}
                        </div>
                        <span className="font-medium text-gray-900">
                          {person.name}
                        </span>
                      </div>
                      <button className="px-4 py-1.5 rounded-lg text-sm font-semibold bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors">
                        팔로잉
                      </button>
                    </div>
                  ))}
          </div>
        </div>
      </div>
    </div>
  );
}
