// Types
export * from "./types";

// Data
export * from "./data";

// Components
export { default as ProfileHeader } from "./ProfileHeader.tsx";
export { default as Sidebar } from "./Sidebar.tsx";

// Tabs
export { default as PostsTab } from "./tabs/PostsTab.tsx";
export { default as CommentsTab } from "./tabs/CommentsTab.tsx";
export { default as SavedTab } from "./tabs/SavedTab.tsx";
export { default as BadgesTab } from "./tabs/BadgesTab.tsx";

// Popups
export { default as FollowPopup } from "./popups/FollowPopup.tsx";
export { default as SocialLinkModal } from "./popups/SocialLinkModal.tsx";
export { default as ProfileEditPopup } from "./popups/ProfileEditPopup.tsx";
export { default as AvatarDetailPopup } from "./popups/AvatarDetailPopup.tsx";
export { default as BadgeDetailPopup } from "./popups/BadgeDetailPopup.tsx";