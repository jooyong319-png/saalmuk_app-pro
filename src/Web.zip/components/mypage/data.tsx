// import React from "react";
import type {
  SocialPlatform,
  AvatarItem,
  BadgeItem,
  FollowerItem,
  FollowingCommunity,
  FollowingPerson,
  UserInfo,
  PostItem,
  ActivityItem,
} from "./types";

// ─── 소셜 플랫폼 목록 ───
export const SOCIAL_PLATFORMS: SocialPlatform[] = [
  {
    id: "youtube",
    name: "유튜브",
    color: "#FF0000",
    placeholder: "https://youtube.com/@채널명",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z" />
      </svg>
    ),
  },
  {
    id: "twitch",
    name: "트위치",
    color: "#9146FF",
    placeholder: "https://twitch.tv/채널명",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714Z" />
      </svg>
    ),
  },
  {
    id: "instagram",
    name: "인스타그램",
    color: "#E4405F",
    placeholder: "https://instagram.com/아이디",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
      </svg>
    ),
  },
  {
    id: "twitter",
    name: "X (트위터)",
    color: "#000000",
    placeholder: "https://x.com/아이디",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>
    ),
  },
  {
    id: "tiktok",
    name: "틱톡",
    color: "#000000",
    placeholder: "https://tiktok.com/@아이디",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
      </svg>
    ),
  },
  {
    id: "discord",
    name: "디스코드",
    color: "#5865F2",
    placeholder: "https://discord.gg/초대코드",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z" />
      </svg>
    ),
  },
  {
    id: "reddit",
    name: "레딧",
    color: "#FF4500",
    placeholder: "https://reddit.com/u/아이디",
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z" />
      </svg>
    ),
  },
  {
    id: "custom",
    name: "커스텀 링크",
    color: "#6B7280",
    placeholder: "https://example.com",
    icon: (
      <svg
        className="w-5 h-5"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
        />
      </svg>
    ),
  },
];

// 플랫폼 정보 가져오기
export const getPlatform = (platformId: string) =>
  SOCIAL_PLATFORMS.find((p) => p.id === platformId);

// ─── 아바타 데이터 ───
export const avatarItems: AvatarItem[] = [
  {
    id: 1,
    src: "https://edge.ssalmuk.com/editorImage/164433adf1f74f30adf6d65de1bcf631.png",
    name: "불꽃 달팽이",
    description:
      "쌀먹닷컴의 열정 넘치는 불꽃 달팽이, 느리지만 뜨거운 열정으로 달려간다!",
    unlockFame: 0,
    owned: true,
  },
  {
    id: 2,
    src: "https://edge.ssalmuk.com/editorImage/628e9422ca0d4d0a9c4676b282e8f370.png",
    name: "주황 달팽이",
    description:
      "상큼한 오렌지 컬러의 달팽이, 활기찬 에너지로 커뮤니티를 밝힌다!",
    unlockFame: 0,
    owned: true,
  },
  {
    id: 3,
    src: "https://edge.ssalmuk.com/editorImage/d13662afec0a4b36b490a27aa0e44d5f.png",
    name: "초록 달팽이",
    description: "자연을 사랑하는 초록 달팽이, 힐링 에너지를 전파한다!",
    unlockFame: 0,
    owned: true,
  },
  {
    id: 4,
    src: "https://edge.ssalmuk.com/editorImage/452483c1a34849f19fdd91b084f6cc6d.png",
    name: "핑크 달팽이",
    description: "사랑스러운 핑크 달팽이, 달콤한 매력으로 모두를 사로잡는다!",
    unlockFame: 0,
    owned: true,
  },
  {
    id: 5,
    src: "https://edge.ssalmuk.com/editorImage/a5d026e2b1e74974b7291b9b0720c5c8.png",
    name: "파랑 달팽이",
    description: "차분하고 지적인 파랑 달팽이, 깊은 통찰력으로 길을 안내한다!",
    unlockFame: 50000,
    owned: false,
  },
  {
    id: 6,
    src: "https://edge.ssalmuk.com/editorImage/93460ed22a3a4a1180c5b1558d3475ae.png",
    name: "보라 달팽이",
    description: "신비로운 보라 달팽이, 창의적인 아이디어로 가득 차 있다!",
    unlockFame: 100000,
    owned: false,
  },
  {
    id: 7,
    src: "https://edge.ssalmuk.com/editorImage/636ec77257614b1eafd00eb6852984cd.png",
    name: "노랑 달팽이",
    description: "밝고 명랑한 노랑 달팽이, 어디서든 분위기 메이커!",
    unlockFame: 200000,
    owned: false,
  },
  {
    id: 8,
    src: "https://edge.ssalmuk.com/editorImage/ed19af783aad472ba506c749c1894e4a.png",
    name: "민트 달팽이",
    description: "시원한 민트 달팽이, 청량한 매력으로 인기 만점!",
    unlockFame: 500000,
    owned: false,
  },
  {
    id: 9,
    src: "https://edge.ssalmuk.com/editorImage/1503bab4d1a84925883922dd3c6962e0.png",
    name: "회색 달팽이",
    description: "묵묵히 자신의 길을 가는 회색 달팽이, 꾸준함의 아이콘!",
    unlockFame: 1000000,
    owned: false,
  },
  {
    id: 10,
    src: "https://edge.ssalmuk.com/editorImage/0490382f65a84ad584dc1d36b1336b04.png",
    name: "검정 달팽이",
    description: "카리스마 넘치는 검정 달팽이, 강렬한 존재감을 뽐낸다!",
    unlockFame: 2000000,
    owned: false,
  },
  {
    id: 11,
    src: "https://edge.ssalmuk.com/editorImage/c5de86eaadef4674bbe044bfec7dacfc.png",
    name: "무지개 달팽이",
    description: "모든 색을 품은 무지개 달팽이, 다양성과 포용의 상징!",
    unlockFame: 5000000,
    owned: false,
  },
  {
    id: 12,
    src: "https://edge.ssalmuk.com/editorImage/1c58b4cbb5914bd0bba0ae27e6dd1175.png",
    name: "골드 달팽이",
    description:
      "최고의 영예를 상징하는 골드 달팽이, 전설의 쌀먹러만이 획득 가능!",
    unlockFame: 10000000,
    owned: false,
  },
];

// ─── 배지 데이터 ───
export const badgeItems: BadgeItem[] = [
  // 업적배지
  {
    id: 1,
    emoji: "🌱",
    name: "첫시작",
    description:
      "쌀먹닷컴에 첫 발을 내딛었어요.\n당신의 앱테크 여정, 쌀먹닷컴에서 멋진 활동을 응원해요",
    bgColor: "from-green-100 to-emerald-200",
    owned: true,
    category: "achievement",
  },
  {
    id: 2,
    emoji: "🧭",
    name: "탐험가",
    description:
      "게시판을 10개 이상 둘러봤어요.\n쌀먹닷컴 구석구석을 꿰뚫는 개척자시네요.",
    bgColor: "from-blue-100 to-indigo-200",
    owned: true,
    category: "achievement",
  },
  {
    id: 3,
    emoji: "💬",
    name: "커뮤니티 스타트",
    description: "커뮤니티에서 첫 발자국을 남겼어요.\n우리 오늘을 기념해요",
    bgColor: "from-purple-100 to-violet-200",
    owned: true,
    category: "achievement",
  },
  {
    id: 4,
    emoji: "🎁",
    name: "리워드 입문",
    description:
      "리워드 활동을 시작했어요.\n쌀알 하나가 산이 되는 여정의 시작!",
    bgColor: "from-amber-100 to-yellow-200",
    owned: true,
    category: "achievement",
  },
  {
    id: 5,
    emoji: "🎟️",
    name: "현명한 소비",
    description: "처음으로 쿠폰을 손에 넣었어요.\n첫 스타트를 축하해요!",
    bgColor: "from-pink-100 to-rose-200",
    owned: true,
    category: "achievement",
  },
  {
    id: 6,
    emoji: "🤝",
    name: "첫거래 성사",
    description: "장터에서 처음으로 거래를 했어요.\n위대한 활동이 시작되었군요",
    bgColor: "from-teal-100 to-cyan-200",
    owned: true,
    category: "achievement",
  },
  {
    id: 7,
    emoji: "⭐",
    name: "라이징 스타",
    description:
      "첫 달에 추천 100개 돌파!\n쌀먹닷컴의 떠오르는 별이에요.\n※ 달성 후 1개월간 닉네임 옆에 노출됩니다.",
    bgColor: "from-yellow-100 to-orange-200",
    owned: false,
    category: "achievement",
  },
  {
    id: 8,
    emoji: "👥",
    name: "팔로워부자",
    description:
      "팔로워 100명 달성!\n모두가 주목하는 매력 만점 쌀먹러시네요.\n✨ 달성 후 즉시 닉네임 옆에 노출됩니다.",
    bgColor: "from-indigo-100 to-purple-200",
    owned: false,
    category: "achievement",
  },
  {
    id: 9,
    emoji: "📷",
    name: "공식 크리에이터",
    description:
      "유튜브, 인스타, 블로그에서 활발히 활동 중인 인플루언서!\n📷 인증 후 닉네임 옆에 노출됩니다.",
    bgColor: "from-red-100 to-pink-200",
    owned: false,
    category: "achievement",
  },
  // 랭킹배지
  {
    id: 101,
    emoji: "✍️",
    name: "크리에이터 상위 5%",
    description:
      "2026년 1월 크리에이터 중 추천수가 상위 5%!\n당신의 콘텐츠가 빛났어요",
    bgColor: "from-blue-100 to-blue-200",
    owned: false,
    category: "ranking",
  },
  {
    id: 102,
    emoji: "🏆",
    name: "크리에이터 상위 1%",
    description:
      "2026년 1월 크리에이터 중 추천수가 상위 1%!\n쌀먹닷컴을 빛내는 전설",
    bgColor: "from-yellow-200 to-amber-300",
    owned: false,
    category: "ranking",
  },
  {
    id: 103,
    emoji: "📝",
    name: "포스터 상위 5%",
    description:
      "2026년 1월 한 달 작성한 글의 추천수가 상위 5%!\n글쓰기의 감각이 남다르시네요.",
    bgColor: "from-green-100 to-green-200",
    owned: false,
    category: "ranking",
  },
  {
    id: 104,
    emoji: "📜",
    name: "포스터 상위 1%",
    description:
      "2026년 1월 한 달 작성한 글의 추천수가 상위 1%!\n당신의 글은 언제나 명작",
    bgColor: "from-yellow-200 to-amber-300",
    owned: false,
    category: "ranking",
  },
  {
    id: 105,
    emoji: "💭",
    name: "댓글러 상위 5%",
    description:
      "2026년 1월 한 달 댓글 추천수가 상위 5%!\n센스 있는 한마디의 힘",
    bgColor: "from-purple-100 to-purple-200",
    owned: false,
    category: "ranking",
  },
  {
    id: 106,
    emoji: "🗣️",
    name: "댓글러 상위 1%",
    description:
      "2026년 1월 한 달 댓글 추천수가 상위 1%!\n댓글계의 레전드 등극.",
    bgColor: "from-yellow-200 to-amber-300",
    owned: false,
    category: "ranking",
  },
  {
    id: 107,
    emoji: "💰",
    name: "리워더 상위 5%",
    description: "2026년 1월 한 달 리워드 수익이 상위 5%!\n꾸준함이 만든 성과.",
    bgColor: "from-emerald-100 to-emerald-200",
    owned: false,
    category: "ranking",
  },
  {
    id: 108,
    emoji: "💎",
    name: "리워더 상위 1%",
    description:
      "2026년 1월 한 달 리워드 수익이 상위 1%!\n진정한 앱테크 마스터.",
    bgColor: "from-yellow-200 to-amber-300",
    owned: false,
    category: "ranking",
  },
  {
    id: 109,
    emoji: "🏪",
    name: "장터러 상위 5%",
    description:
      "2026년 1월 한 달 장터 수익이 상위 5%!\n거래의 감각이 남다르시네요.",
    bgColor: "from-orange-100 to-orange-200",
    owned: false,
    category: "ranking",
  },
  {
    id: 110,
    emoji: "🏛️",
    name: "장터러 상위 1%",
    description:
      "2026년 1월 한 달 장터 수익이 상위 1%!\n쌀먹 장터의 큰손 등극.",
    bgColor: "from-yellow-200 to-amber-300",
    owned: false,
    category: "ranking",
  },
  {
    id: 111,
    emoji: "🛒",
    name: "컬렉터 상위 5%",
    description: "2026년 1월 한 달 쿠폰 구매량이 상위 5%!\n현명한 쇼퍼의 품격!",
    bgColor: "from-pink-100 to-pink-200",
    owned: false,
    category: "ranking",
  },
  {
    id: 112,
    emoji: "👑",
    name: "컬렉터 상위 1%",
    description:
      "2026년 1월 한 달 쿠폰 구매량이 상위 1%!\n쿠폰계의 큰손, 멋진 안목이에요.",
    bgColor: "from-yellow-200 to-amber-300",
    owned: false,
    category: "ranking",
  },
];

// ─── 더미 유저 데이터 ───
export const defaultUser: UserInfo = {
  avatar: "🐼",
  nickname: "쌀먹러",
  badge: "팔로우 부자",
  followers: 128,
  following: 45,
  fame: 293,
  youtubeCount: 3,
  point: 12773,
  cash: 12773,
  coupons: 10,
  marketItems: 0,
};

// ─── 더미 게시글 데이터 ───
export const defaultPosts: PostItem[] = [
  {
    id: 1,
    galleryId: 202,
    boardIcon: "🍁",
    boardName: "메이플스토리",
    title: "275레벨 달성 후기입니다",
    content: "드디어 275 찍었네요.. 3년 걸렸습니다 ㅠㅠ 다들 파이팅하세요!",
    date: "2월 11일 15:30",
    views: 1542,
    likes: 89,
    comments: 23,
  },
  {
    id: 2,
    galleryId: 203,
    boardIcon: "🏰",
    boardName: "로스트아크",
    title: "카양겔 하드 첫 클리어!",
    content: "공대원분들 덕분에 드디어 클리어했습니다. 너무 기쁘네요",
    date: "2월 10일 22:15",
    views: 892,
    likes: 45,
    comments: 12,
  },
  {
    id: 3,
    galleryId: 104,
    boardIcon: "⚔️",
    boardName: "리니지M",
    title: "+20 무기 도전기",
    content: "500만원 들어갔습니다... 성공은 했는데 현타가 오네요",
    date: "2월 9일 18:40",
    views: 3241,
    likes: 156,
    comments: 87,
  },
];

// ─── 더미 댓글 데이터 ───
export const defaultComments: ActivityItem[] = [
  {
    id: 1,
    type: "comment",
    targetIcon: "🎮",
    targetName: "아이온2 갤러리에 남긴 댓글",
    targetType: "comment",
    date: "2월 11일 17:20",
    content: "이번 업데이트 진짜 대박이네요 ㄷㄷ",
    mentionedUser: "고전적인라이102",
    likes: 3,
    postId: 1,
    galleryId: 101,
  },
  {
    id: 2,
    type: "comment",
    targetIcon: "🍁",
    targetName: "메이플스토리 갤러리에 남긴 댓글",
    targetType: "comment",
    date: "2월 11일 15:45",
    content: "275 축하드려요!! 저도 열심히 해야겠네요",
    likes: 12,
    postId: 2,
    galleryId: 202,
  },
  {
    id: 3,
    type: "comment",
    targetIcon: "🏰",
    targetName: "로스트아크 갤러리에 남긴 댓글",
    targetType: "comment",
    date: "2월 10일 21:30",
    content: "카양겔 하드 공략 정보 감사합니다! 덕분에 클리어했어요",
    likes: 8,
    postId: 3,
    galleryId: 203,
  },
  {
    id: 4,
    type: "comment",
    targetIcon: "⚔️",
    targetName: "리니지M 갤러리에 남긴 댓글",
    targetType: "comment",
    date: "2월 9일 19:15",
    content: "+20 대박... 저도 도전해볼까 고민되네요 ㅋㅋ",
    likes: 5,
    postId: 4,
    galleryId: 104,
  },
  {
    id: 5,
    type: "comment",
    targetIcon: "💬",
    targetName: "쌀먹 라운지에 남긴 댓글",
    targetType: "comment",
    date: "2월 8일 14:22",
    content: "요즘 할만한 모바일 게임 추천 부탁드려요~",
    likes: 2,
    postId: 5,
    galleryId: 3,
  },
  {
    id: 6,
    type: "comment",
    targetIcon: "🛡️",
    targetName: "오딘 갤러리에 남긴 댓글",
    targetType: "comment",
    date: "2월 7일 20:10",
    content: "발키리 스킬트리 이렇게 찍는게 맞나요?",
    mentionedUser: "오딘마스터",
    likes: 1,
    postId: 6,
    galleryId: 103,
  },
];

// ─── 더미 저장된 게시글 데이터 ───
export const defaultSavedPosts: PostItem[] = [
  {
    id: 1,
    galleryId: 202,
    boardIcon: "🍁",
    boardName: "메이플스토리",
    title: "[공략] 보스 데미지 올리는 꿀팁 정리",
    content: "스탯 찍는 순서랑 링크스킬 조합 정리해봤습니다. 참고하세요!",
    date: "2월 10일 18:20",
    views: 5234,
    likes: 342,
    comments: 89,
  },
  {
    id: 2,
    galleryId: 203,
    boardIcon: "🏰",
    boardName: "로스트아크",
    title: "이번주 레이드 보상 정리표",
    content: "골드, 재료 등 한눈에 보기 쉽게 정리했습니다",
    date: "2월 9일 12:30",
    views: 8921,
    likes: 567,
    comments: 123,
  },
  {
    id: 3,
    galleryId: 101,
    boardIcon: "⚔️",
    boardName: "아이온2",
    title: "신규 유저 필독! 초반 세팅 가이드",
    content:
      "처음 시작하시는 분들을 위한 가이드입니다. 스탯, 스킬, 장비 순서대로 설명드릴게요",
    date: "2월 8일 09:15",
    views: 3456,
    likes: 234,
    comments: 67,
  },
  {
    id: 4,
    galleryId: 3,
    boardIcon: "💬",
    boardName: "쌀먹 라운지",
    title: "2024 상반기 출시 예정 게임 총정리",
    content: "기대되는 신작들 모아봤어요. 사전예약 일정도 같이 확인하세요!",
    date: "2월 5일 16:40",
    views: 12453,
    likes: 892,
    comments: 234,
  },
];

// ─── 팔로워 더미 데이터 ───
export const defaultFollowers: FollowerItem[] = [
  { id: 1, avatar: "🐸", name: "젊은영무조개82", isFollowing: false },
  { id: 2, avatar: "🔴", name: "테슬라가즈", isFollowing: false },
  { id: 3, avatar: "🐜", name: "개미감각", isFollowing: false },
  { id: 4, avatar: "😊", name: "영짱zz", isFollowing: true },
  { id: 5, avatar: "🐻", name: "밤나무둥지", isFollowing: false },
  { id: 6, avatar: "🤖", name: "탈퇴한회원4274358", isFollowing: false },
  { id: 7, avatar: "⚫", name: "고영이덜리", isFollowing: true },
  { id: 8, avatar: "🐳", name: "부유한돌고래47", isFollowing: false },
  { id: 9, avatar: "📈", name: "추격매수금지프로도", isFollowing: false },
  { id: 10, avatar: "🦎", name: "모두를팔로우할그날까지", isFollowing: false },
  { id: 11, avatar: "🎭", name: "특이점선점", isFollowing: false },
];

// ─── 팔로잉 - 커뮤니티 더미 데이터 ───
export const defaultFollowingCommunities: FollowingCommunity[] = [
  { id: 1, icon: "😊", name: "아무말대잔치" },
  { id: 2, icon: "🔴", name: "채권투자노트" },
  { id: 3, icon: "🔵", name: "주식투자Q&A" },
  { id: 4, icon: "🟢", name: "따박따박배당투자" },
  { id: 5, icon: "🇺🇸", name: "미국주식이야기" },
];

// ─── 팔로잉 - 사람 더미 데이터 ───
export const defaultFollowingPeople: FollowingPerson[] = [
  { id: 1, avatar: "🐸", name: "젊은영무조개82" },
  { id: 2, avatar: "🔴", name: "테슬라가즈" },
  { id: 3, avatar: "🐜", name: "개미감각" },
  { id: 4, avatar: "😊", name: "영짱zz" },
  { id: 5, avatar: "🐻", name: "밤나무둥지" },
];

export const MAX_SOCIAL_LINKS = 5;
