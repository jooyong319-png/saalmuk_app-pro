import { useState, useMemo, useCallback } from "react";
import {
  Star,
  Plus,
  Settings,
  // ChevronDown,
  Bell,
  X,
  Clock,
  Check,
  GripVertical,
  Search,
  // Pencil,
  Trash2,
} from "lucide-react";
import { useInterest } from "./InterestContext";
import { useRecent } from "./RecentContext";
import { getGalleryById, galleries } from "./galleryData";

// ===== 타입 =====
type SortType = "custom" | "added" | "alphabetical" | "popular";

// ===== 정렬 옵션 =====
const sortOptions: { type: SortType; label: string }[] = [
  { type: "custom", label: "직접 설정한 순" },
  { type: "added", label: "추가한 순" },
  { type: "alphabetical", label: "가나다 순" },
  { type: "popular", label: "유저 많은 순" },
];

// ===== Props =====
interface InterestContentProps {
  onGalleryClick?: (galleryId: string) => void;
}

// ===== 메인 컴포넌트 =====
export default function InterestContent({
  onGalleryClick,
}: InterestContentProps) {
  const {
    groups,
    allInterestGalleryIds,
    addGroup,
    addToGroup,
    removeFromGroup,
    removeGroup,
    renameGroup,
  } = useInterest();
  const { recentGalleryIds, removeRecent } = useRecent();

  // 탭 상태
  const [activeTab, setActiveTab] = useState("recent");

  // 편집 모드 (팝업)
  const [showEditPopup, setShowEditPopup] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  // 정렬
  const [sortTypes, setSortTypes] = useState<Record<string, SortType>>({});
  const [showSortSheet, setShowSortSheet] = useState(false);

  // 그룹 관리
  const [showGroupEditModal, setShowGroupEditModal] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [groupToDelete, setGroupToDelete] = useState<string | null>(null);

  // 그룹 추가
  const [showAddGroupModal, setShowAddGroupModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");

  // 갤러리 추가
  const [showAddGalleryModal, setShowAddGalleryModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [galleriesSelected, setGalleriesSelected] = useState<string[]>([]);

  // 그룹 변경
  const [showGroupChangeSheet, setShowGroupChangeSheet] = useState(false);

  // 드래그 상태 (PC)
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);
  const [localOrder, setLocalOrder] = useState<string[]>([]);

  // ===== 탭 목록 =====
  const tabs = useMemo(
    () => [
      { id: "recent", label: "최근 본" },
      { id: "all", label: "전체" },
      ...groups.map((g) => ({ id: g.id, label: g.name })),
    ],
    [groups],
  );

  // ===== 현재 탭의 갤러리 ID 목록 =====
  const currentGalleryIds = useMemo(() => {
    if (activeTab === "recent") return recentGalleryIds;
    if (activeTab === "all") return allInterestGalleryIds;
    return groups.find((g) => g.id === activeTab)?.galleryIds || [];
  }, [activeTab, recentGalleryIds, allInterestGalleryIds, groups]);

  // ===== 정렬된 갤러리 =====
  const currentSortType = sortTypes[activeTab] || "custom";

  const sortedGalleries = useMemo(() => {
    // 로컬 순서가 있으면 사용
    const orderToUse = localOrder.length > 0 ? localOrder : currentGalleryIds;

    const galleriesArr = orderToUse
      .map((id) => getGalleryById(id))
      .filter(
        (g): g is NonNullable<ReturnType<typeof getGalleryById>> => g !== null,
      );

    if (currentSortType === "custom" || localOrder.length > 0) {
      return galleriesArr;
    }

    switch (currentSortType) {
      case "alphabetical":
        return [...galleriesArr].sort((a, b) =>
          a.name.localeCompare(b.name, "ko"),
        );
      case "popular":
        return [...galleriesArr].sort(
          (a, b) => (b.memberCount || 0) - (a.memberCount || 0),
        );
      default:
        return galleriesArr;
    }
  }, [currentGalleryIds, currentSortType, localOrder]);

  const isRecentTab = activeTab === "recent";
  const currentGroup = groups.find((g) => g.id === activeTab);

  // ===== 탭 변경 시 로컬 순서 초기화 =====
  const handleTabChange = useCallback((tabId: string) => {
    setActiveTab(tabId);
    setSelectedItems([]);
    setLocalOrder([]);
  }, []);

  // ===== 핸들러 =====
  const handleGalleryClick = useCallback(
    (galleryId: string) => {
      onGalleryClick?.(galleryId);
    },
    [onGalleryClick],
  );

  const handleRemoveRecent = useCallback(
    (galleryId: string) => {
      removeRecent(galleryId);
    },
    [removeRecent],
  );

  // 전체 선택/해제
  const handleSelectAll = useCallback(() => {
    if (selectedItems.length === currentGalleryIds.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems([...currentGalleryIds]);
    }
  }, [selectedItems, currentGalleryIds]);

  // 아이템 선택 토글
  const toggleSelectItem = useCallback((galleryId: string) => {
    setSelectedItems((prev) =>
      prev.includes(galleryId)
        ? prev.filter((id) => id !== galleryId)
        : [...prev, galleryId],
    );
  }, []);

  // 정렬 변경
  const handleSortChange = useCallback(
    (sortType: SortType) => {
      setSortTypes((prev) => ({ ...prev, [activeTab]: sortType }));
      setLocalOrder([]); // 정렬 변경 시 로컬 순서 초기화
      setShowSortSheet(false);
    },
    [activeTab],
  );

  // 선택 삭제
  const handleDeleteSelected = useCallback(() => {
    if (!currentGroup) return;
    selectedItems.forEach((id) => {
      removeFromGroup(id, currentGroup.id);
    });
    setSelectedItems([]);
    setLocalOrder([]);
  }, [currentGroup, selectedItems, removeFromGroup]);

  // 그룹 변경
  const handleChangeGroup = useCallback(
    (targetGroupId: string) => {
      if (!currentGroup) return;
      selectedItems.forEach((galleryId) => {
        removeFromGroup(galleryId, currentGroup.id);
        addToGroup(galleryId, targetGroupId);
      });
      setSelectedItems([]);
      setShowGroupChangeSheet(false);
      setLocalOrder([]);
    },
    [currentGroup, selectedItems, removeFromGroup, addToGroup],
  );

  // 그룹 삭제
  const handleDeleteGroup = useCallback(() => {
    if (groupToDelete) {
      removeGroup(groupToDelete);
      setActiveTab("all");
    }
    setShowDeleteConfirm(false);
    setGroupToDelete(null);
    setShowGroupEditModal(false);
  }, [groupToDelete, removeGroup]);

  // 그룹 이름 변경
  const handleRenameGroup = useCallback(() => {
    if (currentGroup && renameValue.trim()) {
      renameGroup(currentGroup.id, renameValue.trim());
    }
    setShowRenameModal(false);
    setRenameValue("");
  }, [currentGroup, renameValue, renameGroup]);

  // 그룹 추가
  const handleAddGroup = useCallback(() => {
    if (newGroupName.trim()) {
      addGroup(newGroupName.trim(), "📁");
      setNewGroupName("");
      setShowAddGroupModal(false);
    }
  }, [newGroupName, addGroup]);

  // 갤러리 추가
  const handleAddGalleries = useCallback(() => {
    if (!currentGroup) return;
    galleriesSelected.forEach((galleryId) => {
      addToGroup(galleryId, currentGroup.id);
    });
    setGalleriesSelected([]);
    setShowAddGalleryModal(false);
  }, [currentGroup, galleriesSelected, addToGroup]);

  // ===== 드래그 앤 드롭 (PC) =====
  const handleDragStart = useCallback(
    (e: React.DragEvent, galleryId: string) => {
      setDraggedId(galleryId);
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", galleryId);
    },
    [],
  );

  const handleDragOver = useCallback(
    (e: React.DragEvent, galleryId: string) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      if (draggedId && galleryId !== draggedId) {
        setDragOverId(galleryId);
      }
    },
    [draggedId],
  );

  const handleDragLeave = useCallback(() => {
    setDragOverId(null);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent, targetId: string) => {
      e.preventDefault();
      if (!draggedId || draggedId === targetId) {
        setDraggedId(null);
        setDragOverId(null);
        return;
      }

      // 현재 순서 가져오기
      const currentOrder =
        localOrder.length > 0 ? [...localOrder] : [...currentGalleryIds];
      const draggedIndex = currentOrder.indexOf(draggedId);
      const targetIndex = currentOrder.indexOf(targetId);

      if (draggedIndex === -1 || targetIndex === -1) return;

      // 순서 변경
      currentOrder.splice(draggedIndex, 1);
      currentOrder.splice(targetIndex, 0, draggedId);

      setLocalOrder(currentOrder);
      setDraggedId(null);
      setDragOverId(null);
    },
    [draggedId, localOrder, currentGalleryIds],
  );

  const handleDragEnd = useCallback(() => {
    setDraggedId(null);
    setDragOverId(null);
  }, []);

  // 검색된 갤러리
  const allGalleriesArray = useMemo(() => Object.values(galleries), []);

  const filteredAllGalleries = useMemo(() => {
    return allGalleriesArray.filter((g) =>
      g.name.toLowerCase().includes(searchQuery.toLowerCase()),
    );
  }, [searchQuery, allGalleriesArray]);

  const currentSortLabel =
    sortOptions.find((o) => o.type === currentSortType)?.label ||
    "직접 설정한 순";

  // ===== 기본 화면 =====
  return (
    <div className="flex flex-col h-full">
      {/* 그룹 탭 */}
      <div className="flex items-center gap-2 py-3 overflow-x-auto hide-scrollbar">
        {tabs.map((tab) => {
          const count =
            tab.id === "recent"
              ? recentGalleryIds.length
              : tab.id === "all"
                ? null
                : groups.find((g) => g.id === tab.id)?.galleryIds.length || 0;

          return (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? "bg-[#72C2FF] text-white"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              {tab.label}
              {count !== null && (
                <span className="text-[11px] opacity-70">({count})</span>
              )}
            </button>
          );
        })}

        {/* 그룹 추가 */}
        <button
          onClick={() => setShowAddGroupModal(true)}
          className="flex items-center gap-1 px-3 py-2 rounded-full text-[13px] font-medium text-gray-400 border border-dashed border-gray-300 hover:border-[#72C2FF] hover:text-[#72C2FF] transition-colors whitespace-nowrap"
        >
          <Plus size={14} />
          그룹 추가
        </button>

        {/* 편집 */}
        <button
          onClick={() => setShowEditPopup(true)}
          className="flex items-center gap-1 px-3 py-2 rounded-full text-[13px] font-medium text-gray-400 hover:text-[#72C2FF] hover:bg-gray-100 transition-colors whitespace-nowrap ml-auto"
        >
          <Settings size={14} />
          편집
        </button>
      </div>

      {/* 갤러리 그리드 */}
      {sortedGalleries.length > 0 ? (
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            {sortedGalleries.map((gallery) => {
              return (
                <div key={gallery.id} className="relative">
                  <button
                    onClick={() => handleGalleryClick(gallery.id)}
                    className="relative w-full flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-xl hover:border-[#72C2FF] hover:shadow-sm transition-all text-left group"
                  >
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${gallery.color}`}
                    >
                      {gallery.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-[#1A1A2E] truncate">
                        {gallery.name}
                      </p>
                      <p className="text-[12px] text-gray-400 truncate">
                        {gallery.description}
                      </p>
                    </div>
                  </button>

                  {isRecentTab && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveRecent(gallery.id);
                      }}
                      className="absolute top-1/2 right-3 -translate-y-1/2 w-6 h-6 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors z-10"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {!isRecentTab && (
            <div className="mt-6 p-4 bg-gray-50 rounded-xl">
              <div className="flex items-start gap-3">
                <Bell className="w-5 h-5 text-[#72C2FF] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-[13px] font-medium text-gray-700">
                    관심 갤러리 알림 받기
                  </p>
                  <p className="text-[12px] text-gray-500 mt-1">
                    관심 갤러리에 인기글이 올라오면 알림을 받을 수 있어요.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            {isRecentTab ? (
              <Clock className="w-8 h-8 text-gray-300" />
            ) : (
              <Star className="w-8 h-8 text-gray-300" />
            )}
          </div>
          <p className="text-[15px] font-medium text-gray-600 mb-2">
            {isRecentTab
              ? "최근 방문한 갤러리가 없어요"
              : activeTab === "all"
                ? "관심 갤러리가 없어요"
                : "이 그룹에 갤러리가 없어요"}
          </p>
          <p className="text-[13px] text-gray-400 mb-4">
            {isRecentTab
              ? "갤러리에 방문하면 여기에 기록돼요"
              : "갤러리 상세에서 ⭐ 버튼을 눌러 추가해보세요"}
          </p>
        </div>
      )}

      {/* ===== 편집 모드 팝업 (2컬럼 레이아웃) ===== */}
      {showEditPopup && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          onClick={() => {
            setShowEditPopup(false);
            setSelectedItems([]);
          }}
        >
          <div
            className="w-full max-w-4xl h-[720px] bg-white rounded-2xl overflow-hidden flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 헤더 */}
            <div className="border-b border-gray-200 px-5 py-4 flex items-center justify-between">
              <h2 className="text-[18px] font-bold text-gray-900">
                관심 갤러리 편집
              </h2>
              <button
                onClick={() => {
                  setShowEditPopup(false);
                  setSelectedItems([]);
                }}
                className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={22} />
              </button>
            </div>

            {/* 2컬럼 본문 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 좌측 사이드바: 그룹 목록 */}
              <div className="w-52 border-r border-gray-200 flex flex-col bg-gray-50">
                {/* 그룹 추가 버튼 */}
                <button
                  onClick={() => setShowAddGroupModal(true)}
                  className="flex items-center gap-2 px-4 py-3 text-[14px] font-medium text-gray-600 hover:bg-gray-100 transition-colors border-b border-gray-200"
                >
                  <Plus size={16} className="text-gray-400" />
                  그룹 추가
                </button>

                {/* 그룹 목록 */}
                <div className="flex-1 overflow-y-auto">
                  {tabs.map((tab) => {
                    const count =
                      tab.id === "recent"
                        ? recentGalleryIds.length
                        : tab.id === "all"
                          ? allInterestGalleryIds.length
                          : groups.find((g) => g.id === tab.id)?.galleryIds
                              .length || 0;
                    const isActive = activeTab === tab.id;

                    return (
                      <button
                        key={tab.id}
                        onClick={() => handleTabChange(tab.id)}
                        className={`w-full flex items-center justify-between px-4 py-3 text-left transition-colors ${
                          isActive
                            ? "bg-[#E8F4FD] text-[#1A1A2E]"
                            : "hover:bg-gray-100 text-gray-600"
                        }`}
                      >
                        <span className="text-[14px] font-medium truncate">
                          {tab.label}
                        </span>
                        <span
                          className={`text-[13px] ${isActive ? "text-[#4A9FD9]" : "text-gray-400"}`}
                        >
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 우측 메인 영역 */}
              <div className="flex-1 flex flex-col bg-white">
                {/* 상단 툴바 */}
                <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-200">
                  {/* 전체선택 체크박스 */}
                  <button
                    onClick={isRecentTab ? undefined : handleSelectAll}
                    disabled={isRecentTab}
                    className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors shrink-0 ${
                      isRecentTab
                        ? "border-gray-200 bg-gray-100 cursor-not-allowed"
                        : selectedItems.length === currentGalleryIds.length &&
                            currentGalleryIds.length > 0
                          ? "bg-[#72C2FF] border-[#72C2FF]"
                          : "border-gray-300 hover:border-gray-400"
                    }`}
                  >
                    {selectedItems.length === currentGalleryIds.length &&
                      currentGalleryIds.length > 0 &&
                      !isRecentTab && (
                        <Check size={12} className="text-white" />
                      )}
                  </button>

                  {/* 군 이동 버튼 */}
                  <button
                    onClick={() =>
                      selectedItems.length > 0 &&
                      !isRecentTab &&
                      activeTab !== "all" &&
                      setShowGroupChangeSheet(true)
                    }
                    disabled={
                      selectedItems.length === 0 ||
                      isRecentTab ||
                      activeTab === "all"
                    }
                    className={`px-3 py-1.5 text-[13px] font-medium rounded-lg border transition-colors ${
                      selectedItems.length > 0 &&
                      !isRecentTab &&
                      activeTab !== "all"
                        ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                        : "border-gray-200 text-gray-300 cursor-not-allowed"
                    }`}
                  >
                    군 이동
                  </button>

                  {/* 삭제 버튼 */}
                  <button
                    onClick={() =>
                      selectedItems.length > 0 &&
                      !isRecentTab &&
                      handleDeleteSelected()
                    }
                    disabled={selectedItems.length === 0 || isRecentTab}
                    className={`px-3 py-1.5 text-[13px] font-medium rounded-lg border transition-colors flex items-center gap-1 ${
                      selectedItems.length > 0 && !isRecentTab
                        ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                        : "border-gray-200 text-gray-300 cursor-not-allowed"
                    }`}
                  >
                    <Trash2 size={14} />
                    삭제
                  </button>

                  <div className="flex-1" />

                  {/* 갤러리 추가 버튼 */}
                  <button
                    onClick={() =>
                      !isRecentTab &&
                      activeTab !== "all" &&
                      setShowAddGalleryModal(true)
                    }
                    disabled={isRecentTab || activeTab === "all"}
                    className={`px-3 py-1.5 text-[13px] font-medium rounded-lg border transition-colors flex items-center gap-1 ${
                      !isRecentTab && activeTab !== "all"
                        ? "border-[#72C2FF] text-[#72C2FF] hover:bg-[#F0F9FF]"
                        : "border-gray-200 text-gray-300 cursor-not-allowed"
                    }`}
                  >
                    <Plus size={14} />
                    갤러리 추가
                  </button>

                  {/* 정렬 드롭다운 */}
                  <button
                    onClick={() => !isRecentTab && setShowSortSheet(true)}
                    disabled={isRecentTab}
                    className={`px-3 py-1.5 text-[13px] font-medium rounded-lg border transition-colors flex items-center gap-1 ${
                      !isRecentTab
                        ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                        : "border-gray-200 text-gray-300 cursor-not-allowed"
                    }`}
                  >
                    ↕ {currentSortLabel}
                  </button>
                </div>

                {/* 갤러리 목록 */}
                <div className="flex-1 overflow-y-auto">
                  {sortedGalleries.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                      <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <Star className="w-8 h-8 text-gray-300" />
                      </div>
                      <p className="text-[15px] font-medium text-gray-500 mb-2">
                        {isRecentTab
                          ? "최근 본 갤러리가 없어요"
                          : "갤러리가 없어요"}
                      </p>
                      <p className="text-[13px] text-gray-400">
                        {isRecentTab
                          ? "갤러리에 방문하면 여기에 기록돼요"
                          : activeTab !== "all"
                            ? "'+ 갤러리 추가' 버튼으로 추가해보세요"
                            : "관심 갤러리를 추가해보세요"}
                      </p>
                    </div>
                  ) : (
                    <div className="flex flex-col">
                      {sortedGalleries.map((gallery) => {
                        const isDragging = draggedId === gallery.id;
                        const isDragOver = dragOverId === gallery.id;

                        return (
                          <div
                            key={gallery.id}
                            draggable={
                              !isRecentTab && currentSortType === "custom"
                            }
                            onDragStart={(e) => handleDragStart(e, gallery.id)}
                            onDragOver={(e) => handleDragOver(e, gallery.id)}
                            onDragLeave={handleDragLeave}
                            onDrop={(e) => handleDrop(e, gallery.id)}
                            onDragEnd={handleDragEnd}
                            className={`flex items-center gap-3 py-3 px-5 border-b border-gray-100 bg-white transition-all ${
                              isDragging ? "opacity-50 scale-[0.98]" : ""
                            } ${isDragOver ? "border-t-2 border-t-[#72C2FF]" : ""}`}
                          >
                            {/* 드래그 핸들 (최근 본 제외, 직접설정순일 때만) */}
                            {!isRecentTab && currentSortType === "custom" ? (
                              <div className="p-1 text-gray-300 cursor-grab active:cursor-grabbing">
                                <GripVertical size={18} />
                              </div>
                            ) : (
                              <div className="w-7" />
                            )}

                            {/* 체크박스 (최근 본 제외) */}
                            {!isRecentTab ? (
                              <button
                                onClick={() => toggleSelectItem(gallery.id)}
                                className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors shrink-0 ${
                                  selectedItems.includes(gallery.id)
                                    ? "bg-[#72C2FF] border-[#72C2FF]"
                                    : "border-gray-300 hover:border-gray-400"
                                }`}
                              >
                                {selectedItems.includes(gallery.id) && (
                                  <Check size={12} className="text-white" />
                                )}
                              </button>
                            ) : (
                              <div className="w-5" />
                            )}

                            {/* 아이콘 */}
                            <div
                              className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 ${gallery.color}`}
                            >
                              {gallery.icon}
                            </div>

                            {/* 이름 */}
                            <p className="flex-1 text-[14px] font-medium text-gray-900 truncate">
                              {gallery.name}
                            </p>

                            {/* 최근 본: X 삭제 */}
                            {isRecentTab && (
                              <button
                                onClick={() => handleRemoveRecent(gallery.id)}
                                className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                              >
                                <X size={18} />
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== 정렬 바텀시트 ===== */}
      {showSortSheet && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4"
          onClick={() => setShowSortSheet(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-4 border-b border-gray-100">
              <h3 className="text-[16px] font-bold text-center">정렬</h3>
            </div>
            <div className="py-2">
              {sortOptions.map((option) => (
                <button
                  key={option.type}
                  onClick={() => handleSortChange(option.type)}
                  className={`w-full px-4 py-3 text-left text-[14px] flex items-center justify-between ${
                    currentSortType === option.type
                      ? "text-[#72C2FF] font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  {option.label}
                  {currentSortType === option.type && (
                    <Check size={18} className="text-[#72C2FF]" />
                  )}
                </button>
              ))}
            </div>
            <div className="p-4 border-t border-gray-100">
              <button
                onClick={() => setShowSortSheet(false)}
                className="w-full py-3 text-gray-500 font-medium"
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 그룹편집 모달 ===== */}
      {showGroupEditModal && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4"
          onClick={() => setShowGroupEditModal(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-4 border-b border-gray-100">
              <h3 className="text-[16px] font-bold text-center">그룹 편집</h3>
            </div>
            <div className="max-h-72 overflow-y-auto">
              {/* 그룹 추가 */}
              <button
                onClick={() => {
                  setShowGroupEditModal(false);
                  setShowAddGroupModal(true);
                }}
                className="w-full px-4 py-3 flex items-center gap-3 text-[#72C2FF] hover:bg-gray-50"
              >
                <div className="w-7 h-7 rounded-full bg-[#72C2FF] flex items-center justify-center">
                  <Plus size={14} className="text-white" />
                </div>
                <span className="text-[14px] font-medium">그룹 추가</span>
              </button>

              {/* 그룹 목록 */}
              {tabs
                .filter((t) => t.id !== "all")
                .map((group) => {
                  const isRecent = group.id === "recent";
                  const count =
                    group.id === "recent"
                      ? recentGalleryIds.length
                      : groups.find((g) => g.id === group.id)?.galleryIds
                          .length || 0;

                  return (
                    <div
                      key={group.id}
                      className="w-full px-4 py-3 flex items-center gap-3"
                    >
                      {/* 삭제 버튼 */}
                      <button
                        onClick={() => {
                          if (!isRecent) {
                            setGroupToDelete(group.id);
                            setShowDeleteConfirm(true);
                          }
                        }}
                        disabled={isRecent}
                        className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                          isRecent
                            ? "bg-gray-200"
                            : "bg-red-500 hover:bg-red-600"
                        }`}
                      >
                        <span className="text-white text-sm font-bold leading-none">
                          −
                        </span>
                      </button>

                      {/* 그룹 이름 */}
                      <span
                        className={`text-[14px] font-medium flex-1 ${
                          isRecent ? "text-gray-400" : "text-gray-900"
                        }`}
                      >
                        {group.label}
                      </span>

                      {/* 개수 */}
                      <span className="text-[12px] text-gray-400">
                        {count}개
                      </span>
                    </div>
                  );
                })}
            </div>
            <div className="p-4 border-t border-gray-100">
              <button
                onClick={() => setShowGroupEditModal(false)}
                className="w-full py-3 text-gray-500 font-medium"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 그룹 추가 모달 ===== */}
      {showAddGroupModal && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4"
          onClick={() => setShowAddGroupModal(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl overflow-hidden shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-5">
              <h3 className="text-[16px] font-bold text-gray-900 mb-4 text-center">
                새 그룹 만들기
              </h3>

              {/* 그룹 이름 입력 */}
              <div>
                <p className="text-[13px] text-gray-500 mb-2">그룹 이름</p>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-[14px] focus:outline-none focus:border-[#72C2FF]"
                  placeholder="그룹 이름을 입력하세요"
                  autoFocus
                />
              </div>
            </div>
            <div className="flex border-t border-gray-100">
              <button
                onClick={() => {
                  setShowAddGroupModal(false);
                  setNewGroupName("");
                }}
                className="flex-1 py-4 text-gray-500 font-medium border-r border-gray-100"
              >
                취소
              </button>
              <button
                onClick={handleAddGroup}
                disabled={!newGroupName.trim()}
                className={`flex-1 py-4 font-semibold ${
                  newGroupName.trim() ? "text-[#72C2FF]" : "text-gray-300"
                }`}
              >
                추가
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 그룹 삭제 확인 ===== */}
      {showDeleteConfirm && groupToDelete && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl overflow-hidden shadow-xl">
            <div className="px-6 py-6 text-center">
              <p className="text-[16px] font-bold text-gray-900 mb-2">
                그룹을 삭제할까요?
              </p>
              <p className="text-[14px] text-gray-500">
                그룹 내 갤러리도 함께 삭제됩니다.
              </p>
            </div>
            <div className="flex border-t border-gray-100">
              <button
                onClick={() => {
                  setGroupToDelete(null);
                  setShowDeleteConfirm(false);
                }}
                className="flex-1 py-4 text-gray-500 font-medium border-r border-gray-100"
              >
                취소
              </button>
              <button
                onClick={handleDeleteGroup}
                className="flex-1 py-4 text-red-500 font-semibold"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 그룹 이름 변경 모달 ===== */}
      {showRenameModal && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl overflow-hidden shadow-xl">
            <div className="px-6 py-6">
              <p className="text-[16px] font-bold text-gray-900 mb-4 text-center">
                그룹 이름 변경
              </p>
              <input
                type="text"
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-[14px] focus:outline-none focus:border-[#72C2FF]"
                placeholder="그룹 이름"
                autoFocus
              />
            </div>
            <div className="flex border-t border-gray-100">
              <button
                onClick={() => {
                  setShowRenameModal(false);
                  setRenameValue("");
                }}
                className="flex-1 py-4 text-gray-500 font-medium border-r border-gray-100"
              >
                취소
              </button>
              <button
                onClick={handleRenameGroup}
                disabled={!renameValue.trim()}
                className={`flex-1 py-4 font-semibold ${
                  renameValue.trim() ? "text-[#72C2FF]" : "text-gray-300"
                }`}
              >
                변경
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 갤러리 추가 모달 ===== */}
      {showAddGalleryModal && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4"
          onClick={() => {
            setShowAddGalleryModal(false);
            setGalleriesSelected([]);
            setSearchQuery("");
          }}
        >
          <div
            className="w-full max-w-lg max-h-[80vh] bg-white rounded-2xl overflow-hidden flex flex-col shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
              <h2 className="text-[16px] font-bold text-gray-900">
                갤러리 추가
              </h2>
              <button
                onClick={() => {
                  setShowAddGalleryModal(false);
                  setGalleriesSelected([]);
                  setSearchQuery("");
                }}
                className="w-8 h-8 flex items-center justify-center text-gray-400"
              >
                <X size={20} />
              </button>
            </div>

            {/* 검색 */}
            <div className="px-4 py-3 border-b border-gray-100">
              <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-lg">
                <Search size={16} className="text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent text-[14px] outline-none"
                  placeholder="갤러리 검색"
                />
              </div>
            </div>

            {/* 갤러리 목록 */}
            <div className="flex-1 overflow-y-auto">
              {filteredAllGalleries.map((gallery) => {
                const isSelected = galleriesSelected.includes(gallery.id);
                const isAlreadyAdded = currentGalleryIds.includes(gallery.id);

                return (
                  <button
                    key={gallery.id}
                    onClick={() => {
                      if (isAlreadyAdded) return;
                      setGalleriesSelected((prev) =>
                        prev.includes(gallery.id)
                          ? prev.filter((id) => id !== gallery.id)
                          : [...prev, gallery.id],
                      );
                    }}
                    disabled={isAlreadyAdded}
                    className={`w-full flex items-center gap-3 px-4 py-3 border-b border-gray-100 hover:bg-gray-50 ${
                      isAlreadyAdded ? "opacity-50" : ""
                    }`}
                  >
                    {/* 체크박스 */}
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors shrink-0 ${
                        isSelected
                          ? "bg-[#72C2FF] border-[#72C2FF]"
                          : isAlreadyAdded
                            ? "border-gray-200 bg-gray-100"
                            : "border-gray-300"
                      }`}
                    >
                      {(isSelected || isAlreadyAdded) && (
                        <Check
                          size={12}
                          className={
                            isSelected ? "text-white" : "text-gray-400"
                          }
                        />
                      )}
                    </div>

                    {/* 아이콘 */}
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 ${gallery.color}`}
                    >
                      {gallery.icon}
                    </div>

                    {/* 정보 */}
                    <div className="flex-1 text-left min-w-0">
                      <p className="text-[13px] font-medium text-gray-900 truncate">
                        {gallery.name}
                      </p>
                      <p className="text-[11px] text-gray-400 truncate">
                        {gallery.description}
                      </p>
                    </div>

                    {isAlreadyAdded && (
                      <span className="text-[11px] text-gray-400 shrink-0">
                        추가됨
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* 추가 버튼 */}
            <div className="p-4 border-t border-gray-100">
              <button
                onClick={handleAddGalleries}
                disabled={galleriesSelected.length === 0}
                className={`w-full py-3 font-semibold rounded-xl transition-colors ${
                  galleriesSelected.length > 0
                    ? "bg-[#72C2FF] text-white"
                    : "bg-gray-200 text-gray-400"
                }`}
              >
                {galleriesSelected.length > 0
                  ? `${galleriesSelected.length}개 추가`
                  : "추가"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 그룹 변경 시트 ===== */}
      {showGroupChangeSheet && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4"
          onClick={() => setShowGroupChangeSheet(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-4 border-b border-gray-100">
              <h3 className="text-[16px] font-bold text-center">그룹 변경</h3>
            </div>
            <div className="py-2 max-h-60 overflow-y-auto">
              {groups
                .filter((g) => g.id !== activeTab)
                .map((group) => (
                  <button
                    key={group.id}
                    onClick={() => handleChangeGroup(group.id)}
                    className="w-full px-4 py-3 text-left text-[14px] text-gray-700 hover:bg-gray-50"
                  >
                    {group.name}
                  </button>
                ))}
            </div>
            <div className="p-4 border-t border-gray-100">
              <button
                onClick={() => setShowGroupChangeSheet(false)}
                className="w-full py-3 text-gray-500 font-medium"
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
