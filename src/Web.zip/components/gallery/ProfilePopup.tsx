import type { PostData } from "./types";

interface ProfilePopupProps {
  profile: PostData;
  isFollowed: boolean;
  onClose: () => void;
  onFollow: () => void;
}

export default function ProfilePopup({
  profile,
  isFollowed,
  onClose,
  onFollow,
}: ProfilePopupProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-2xl w-full max-w-sm p-6 animate-fadeUp">
        <button className="absolute top-4 right-4" onClick={onClose}>
          <svg
            className="w-6 h-6 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
        <div className="text-center">
          <div
            className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl"
            style={{ background: profile.avatarBg }}
          >
            {profile.avatar}
          </div>
          <h3 className="text-xl font-bold mb-1">{profile.name}</h3>
          {profile.badge && (
            <span className="inline-block text-xs px-2 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-600 mb-3">
              {profile.badge}
            </span>
          )}
          <p className="text-sm text-gray-500 mb-4">팔로워 1,234 · 게시글 56</p>
          <button
            className={`w-full py-3 rounded-full font-semibold transition-colors ${
              isFollowed
                ? "bg-gray-100 text-gray-500"
                : "bg-[#72C2FF] text-white"
            }`}
            onClick={onFollow}
          >
            {isFollowed ? "팔로잉" : "팔로우"}
          </button>
        </div>
      </div>
    </div>
  );
}
