import type { GalleryItemData } from "./types";

// ─── 오른쪽 사이드바 ───

interface RightSidebarProps {
  selectedGallery?: GalleryItemData | null;
}

export default function RightSidebar({ selectedGallery }: RightSidebarProps) {
  const weeklyPosts = [
    {
      title: "메이플하면 쌀먹이지 ㅋㅋㅋ",
      hot: true,
      image:
        "https://ssalmuk.com/crosseditor/binary/images/000131/aW1hZ2U=_62.png",
    },
    {
      title: "신규 보스 공략 총정리",
      hot: false,
      image:
        "https://ssalmuk.com/crosseditor/binary/images/000131/aW1hZ2U=_65.png",
    },
  ];

  const popularList = [
    "오늘 드디어 상한가 찍었습니다!!",
    "초보자 필독! 시작 가이드",
    "이번 업데이트 변경점 정리",
    "수익 인증합니다 ㅎㅎ",
    "초보자 필독! 시작 가이드",
  ];

  // 주간 인기 유저 (갤러리별로 다르게 설정 가능)
  const weeklyTopUsers = [
    { name: "해방촌오른발잡이", avatar: "😊", isFollowed: false },
    { name: "별의끄비", avatar: "🌟", isFollowed: false },
    { name: "매니아fs", avatar: "🎮", isFollowed: false },
  ];

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* 이벤트 배너 - 이미지 */}
      <div className="rounded-xl overflow-hidden cursor-pointer hover:-translate-y-0.5 transition-transform shadow-sm">
        <img
          src="https://i.pinimg.com/736x/3f/4b/99/3f4b99818ca444236c549c2ef8cd87de.jpg"
          alt="이벤트 배너"
          className="w-full h-auto object-cover"
        />
      </div>

      {/* 주간 인기 */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-4 py-3 text-[15px] font-bold text-[#1A1A2E] border-b border-gray-200 flex items-center gap-1.5">
          🔥 주간 인기
        </div>
        <div className="p-4">
          {/* 썸네일 그리드 */}
          <div className="grid grid-cols-2 gap-2.5 mb-3">
            {weeklyPosts.map((post, i) => (
              <div key={i} className="cursor-pointer">
                <div className="w-full aspect-[16/10] rounded-lg overflow-hidden mb-1.5 relative">
                  {post.image ? (
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-[#1a1a2e] to-[#2d1b3d]" />
                  )}
                  {post.hot && (
                    <span className="absolute top-1.5 left-1.5 bg-[#FF4757] text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded">
                      HOT
                    </span>
                  )}
                </div>
                <p className="text-[12px] font-medium leading-snug line-clamp-2">
                  {post.title}
                </p>
              </div>
            ))}
          </div>

          {/* 인기글 리스트 */}
          <div className="border-t border-gray-200 pt-2">
            {popularList.map((title, i) => (
              <div
                key={i}
                className="py-2 px-2 -mx-2 text-[13px] text-gray-500 truncate cursor-pointer hover:text-[#4AABF5] hover:bg-[#E8F4FD] rounded transition-colors border-b border-gray-100 last:border-0"
              >
                {title}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 주간 인기 TOP3 - 갤러리 선택 시에만 표시 */}
      {selectedGallery && (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 text-[15px] font-bold text-[#1A1A2E] border-b border-gray-200">
            {selectedGallery.name} 주간 인기 TOP3
          </div>
          <div className="p-4">
            <div className="space-y-3">
              {weeklyTopUsers.map((user, i) => (
                <div key={i} className="flex items-center gap-3">
                  {/* 아바타 */}
                  <div className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-lg shrink-0">
                    {user.avatar}
                  </div>

                  {/* 이름 */}
                  <span className="flex-1 text-[14px] font-medium text-[#1A1A2E] truncate">
                    {user.name}
                  </span>

                  {/* 팔로우 버튼 */}
                  <button
                    className={`px-3 py-1.5 text-[12px] font-bold rounded-lg transition-colors ${
                      user.isFollowed
                        ? "bg-gray-100 text-gray-500"
                        : "bg-[#E8F4FD] text-[#72C2FF] hover:bg-[#D0EBFF]"
                    }`}
                  >
                    {user.isFollowed ? "팔로잉" : "팔로우"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
