import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { createPortal } from "react-dom";

// ─── 타입 ───
type ToastType = "success" | "link" | "block" | "info";

interface ToastOptions {
  type?: ToastType;
  userName?: string;
  onUndo?: () => void;
}

interface ToastItem {
  id: number;
  message: string;
  type: ToastType;
  userName?: string;
  onUndo?: () => void;
}

interface ToastContextType {
  showToast: (message: string, options?: ToastOptions) => void;
}

// ─── Context ───
const ToastContext = createContext<ToastContextType | null>(null);

// ─── Hook ───
export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    return { showToast: () => {} };
  }
  return context;
}

// ─── 아이콘 컴포넌트 ───
const ToastIcon = ({ type }: { type: ToastType }) => {
  switch (type) {
    case "link":
      return (
        <svg className="w-5 h-5 text-[#72C2FF]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
        </svg>
      );
    case "block":
      return (
        <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
        </svg>
      );
    case "success":
    default:
      return (
        <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
        </svg>
      );
  }
};

// ─── Provider ───
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const removeToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback((message: string, options?: ToastOptions) => {
    const id = Date.now();
    const type = options?.type || "success";
    
    setToasts((prev) => [...prev, { 
      id, 
      message, 
      type,
      userName: options?.userName,
      onUndo: options?.onUndo
    }]);

    // 3초 후 자동 제거
    setTimeout(() => {
      removeToast(id);
    }, 3000);
  }, [removeToast]);

  const handleUndo = (toast: ToastItem) => {
    if (toast.onUndo) {
      toast.onUndo();
    }
    removeToast(toast.id);
  };

  const toastContainer = toasts.length > 0 ? createPortal(
    <>
      <div 
        className="fixed bottom-24 left-1/2 -translate-x-1/2 flex flex-col gap-3 pointer-events-auto"
        style={{ zIndex: 99999 }}
      >
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="px-4 py-3.5 rounded-2xl bg-gray-900/95 backdrop-blur-sm shadow-xl animate-toastIn min-w-[280px] max-w-[360px]"
          >
            <div className="flex items-center gap-3">
              <ToastIcon type={toast.type} />
              <span className="flex-1 text-[14px] text-white leading-snug">
                {toast.message}
              </span>
              {toast.type === "block" && toast.onUndo && (
                <button
                  onClick={() => handleUndo(toast)}
                  className="px-3 py-1 text-[13px] font-medium text-gray-400 hover:text-white transition-colors shrink-0"
                >
                  취소
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes toastIn {
          0% {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          100% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        .animate-toastIn {
          animation: toastIn 0.25s ease-out both;
        }
      `}</style>
    </>,
    document.body
  ) : null;

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      {toastContainer}
    </ToastContext.Provider>
  );
}

// ─── 토스트 메시지 생성 함수 ───
export const createToastMessage = {
  // 팔로우
  follow: (name: string) => ({
    message: `${name}님이 새 글을 올리거나 거래할 때 알려드릴게요`,
    options: { type: "success" as ToastType }
  }),
  unfollow: (name: string) => ({
    message: `${name}님 팔로우를 취소했어요`,
    options: { type: "success" as ToastType }
  }),
  
  // 저장
  save: (name: string) => ({
    message: `${name}님의 글을 저장했어요.`,
    options: { type: "success" as ToastType }
  }),
  
  // 차단
  block: (name: string, onUndo?: () => void) => ({
    message: `${name}님을 차단했어요`,
    options: { type: "block" as ToastType, onUndo }
  }),
  
  // 링크 복사
  linkCopied: () => ({
    message: "링크를 복사했어요",
    options: { type: "link" as ToastType }
  }),
};

// ─── 기존 호환용 토스트 메시지 프리셋 ───
export const TOAST_MESSAGES = {
  // 팔로우
  FOLLOW: "팔로우했습니다",
  UNFOLLOW: "팔로우를 취소했습니다",
  
  // 글/댓글
  POST_CREATED: "글이 등록되었습니다",
  COMMENT_CREATED: "댓글이 등록되었습니다",
  REPLY_CREATED: "답글이 등록되었습니다",
  
  // 더보기 메뉴
  LINK_COPIED: "링크를 복사했어요",
  SAVED: "저장했어요",
  BLOCKED: "차단했어요",
  REPORTED: "신고가 접수되었습니다",
  
  // 기타
  VOTE_COMPLETE: "투표 완료!",
  GIFT_SENT: "선물을 보냈습니다",
} as const;
