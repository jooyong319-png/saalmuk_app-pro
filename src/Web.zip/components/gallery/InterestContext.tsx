import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";

// ===== 타입 =====
export interface InterestGroup {
  id: string;
  name: string;
  emoji: string;
  galleryIds: string[];
}

interface InterestContextType {
  // 그룹 관리
  groups: InterestGroup[];
  addGroup: (name: string, emoji: string) => void;
  removeGroup: (groupId: string) => void;
  renameGroup: (groupId: string, newName: string) => void;

  // 갤러리-그룹 관계
  addToGroup: (galleryId: string, groupId: string) => void;
  removeFromGroup: (galleryId: string, groupId: string) => void;
  getGroupsForGallery: (galleryId: string) => InterestGroup[];
  isInAnyGroup: (galleryId: string) => boolean;

  // 전체 관심 갤러리
  allInterestGalleryIds: string[];
  addInterest: (galleryId: string, groupId?: string) => void;
  removeInterest: (galleryId: string) => void;
  isInterested: (galleryId: string) => boolean;
}

// ===== 기본 그룹 =====
const defaultGroups: InterestGroup[] = [
  {
    id: "game",
    name: "게임",
    emoji: "🎮",
    galleryIds: ["genshin", "bluearchive", "lostark"],
  },
  {
    id: "info",
    name: "정보",
    emoji: "💰",
    galleryIds: ["saenghwaltech", "barossalmuk"],
  },
];

// ===== Context =====
const InterestContext = createContext<InterestContextType | null>(null);

// ===== Provider =====
export function InterestProvider({ children }: { children: ReactNode }) {
  const [groups, setGroups] = useState<InterestGroup[]>(defaultGroups);

  // 그룹 추가
  const addGroup = useCallback((name: string, emoji: string) => {
    const newGroup: InterestGroup = {
      id: `group_${Date.now()}`,
      name,
      emoji,
      galleryIds: [],
    };
    setGroups((prev) => [...prev, newGroup]);
  }, []);

  // 그룹 삭제
  const removeGroup = useCallback((groupId: string) => {
    setGroups((prev) => prev.filter((g) => g.id !== groupId));
  }, []);

  // 그룹 이름 변경
  const renameGroup = useCallback((groupId: string, newName: string) => {
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, name: newName } : g)),
    );
  }, []);

  // 갤러리를 그룹에 추가
  const addToGroup = useCallback((galleryId: string, groupId: string) => {
    setGroups((prev) =>
      prev.map((g) => {
        if (g.id === groupId && !g.galleryIds.includes(galleryId)) {
          return { ...g, galleryIds: [...g.galleryIds, galleryId] };
        }
        return g;
      }),
    );
  }, []);

  // 갤러리를 그룹에서 제거
  const removeFromGroup = useCallback((galleryId: string, groupId: string) => {
    setGroups((prev) =>
      prev.map((g) => {
        if (g.id === groupId) {
          return {
            ...g,
            galleryIds: g.galleryIds.filter((id) => id !== galleryId),
          };
        }
        return g;
      }),
    );
  }, []);

  // 갤러리가 속한 그룹들 조회
  const getGroupsForGallery = useCallback(
    (galleryId: string) => {
      return groups.filter((g) => g.galleryIds.includes(galleryId));
    },
    [groups],
  );

  // 갤러리가 어떤 그룹에든 속해있는지
  const isInAnyGroup = useCallback(
    (galleryId: string) => {
      return groups.some((g) => g.galleryIds.includes(galleryId));
    },
    [groups],
  );

  // 전체 관심 갤러리 ID 목록
  const allInterestGalleryIds = Array.from(
    new Set(groups.flatMap((g) => g.galleryIds)),
  );

  // 관심 추가 (그룹 지정 없으면 첫 번째 그룹에)
  const addInterest = useCallback(
    (galleryId: string, groupId?: string) => {
      const targetGroupId = groupId || groups[0]?.id;
      if (targetGroupId) {
        addToGroup(galleryId, targetGroupId);
      }
    },
    [groups, addToGroup],
  );

  // 관심 제거 (모든 그룹에서)
  const removeInterest = useCallback((galleryId: string) => {
    setGroups((prev) =>
      prev.map((g) => ({
        ...g,
        galleryIds: g.galleryIds.filter((id) => id !== galleryId),
      })),
    );
  }, []);

  // 관심 여부 확인
  const isInterested = useCallback(
    (galleryId: string) => {
      return allInterestGalleryIds.includes(galleryId);
    },
    [allInterestGalleryIds],
  );

  return (
    <InterestContext.Provider
      value={{
        groups,
        addGroup,
        removeGroup,
        renameGroup,
        addToGroup,
        removeFromGroup,
        getGroupsForGallery,
        isInAnyGroup,
        allInterestGalleryIds,
        addInterest,
        removeInterest,
        isInterested,
      }}
    >
      {children}
    </InterestContext.Provider>
  );
}

// ===== Hook =====
export function useInterest() {
  const context = useContext(InterestContext);
  if (!context) {
    throw new Error("useInterest must be used within InterestProvider");
  }
  return context;
}
