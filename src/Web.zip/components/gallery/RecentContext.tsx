import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";

// ===== 타입 =====
interface RecentItem {
  galleryId: string;
  visitedAt: number; // timestamp
}

interface RecentContextType {
  recentGalleryIds: string[];
  addRecent: (galleryId: string) => void;
  removeRecent: (galleryId: string) => void;
  clearRecent: () => void;
  isRecent: (galleryId: string) => boolean;
}

// ===== 설정 =====
const MAX_RECENT_COUNT = 10;

// ===== 기본 데이터 =====
const defaultRecent: RecentItem[] = [
  { galleryId: "genshin", visitedAt: Date.now() - 1000 },
  { galleryId: "bluearchive", visitedAt: Date.now() - 2000 },
  { galleryId: "nikke", visitedAt: Date.now() - 3000 },
  { galleryId: "lostark", visitedAt: Date.now() - 4000 },
  { galleryId: "saenghwaltech", visitedAt: Date.now() - 5000 },
];

// ===== Context =====
const RecentContext = createContext<RecentContextType | null>(null);

// ===== Provider =====
export function RecentProvider({ children }: { children: ReactNode }) {
  const [recentItems, setRecentItems] = useState<RecentItem[]>(defaultRecent);

  // 최근 방문 추가 (이미 있으면 맨 앞으로)
  const addRecent = useCallback((galleryId: string) => {
    setRecentItems((prev) => {
      // 기존에 있으면 제거
      const filtered = prev.filter((item) => item.galleryId !== galleryId);
      // 맨 앞에 추가
      const newItems = [
        { galleryId, visitedAt: Date.now() },
        ...filtered,
      ].slice(0, MAX_RECENT_COUNT);
      return newItems;
    });
  }, []);

  // 최근 방문에서 제거
  const removeRecent = useCallback((galleryId: string) => {
    setRecentItems((prev) =>
      prev.filter((item) => item.galleryId !== galleryId),
    );
  }, []);

  // 전체 삭제
  const clearRecent = useCallback(() => {
    setRecentItems([]);
  }, []);

  // 최근 방문 여부
  const isRecent = useCallback(
    (galleryId: string) => {
      return recentItems.some((item) => item.galleryId === galleryId);
    },
    [recentItems],
  );

  // ID 목록만 추출 (시간순 정렬됨)
  const recentGalleryIds = recentItems.map((item) => item.galleryId);

  return (
    <RecentContext.Provider
      value={{
        recentGalleryIds,
        addRecent,
        removeRecent,
        clearRecent,
        isRecent,
      }}
    >
      {children}
    </RecentContext.Provider>
  );
}

// ===== Hook =====
export function useRecent() {
  const context = useContext(RecentContext);
  if (!context) {
    throw new Error("useRecent must be used within RecentProvider");
  }
  return context;
}
