import { useState } from "react";

interface ManagementRecord {
  id: number;
  nickname: string;
  code: string;
  type: "댓글" | "게시글";
  content: string;
  reason: string;
  duration: string;
  processedAt: string;
  processor: string;
  action?: string;
}

interface GalleryManagementPopupProps {
  galleryName: string;
  onClose: () => void;
}

// 더미 데이터
const dummyBlockRecords: ManagementRecord[] = [
  {
    id: 1291,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "니애미정녀요 ㅂㅅ아 ㅋㅋ",
    reason: "신문고 욕설",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(soft3518)",
  },
  {
    id: 1290,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "죽어",
    reason: "도배",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(hang2563)",
  },
  {
    id: 1289,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "게시글",
    content: "https://m.dcinside.com/mini...",
    reason: "신문고 허위남용",
    duration: "6시간",
    processedAt: "2026.02.25",
    processor: "공지 허위 댓글\n차단",
    action: "공지 허위 댓글 차단",
  },
  {
    id: 1288,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "ㄴㄱㅁ",
    reason: "신문고욕설",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(soft3518)",
  },
  {
    id: 1287,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "디시콘",
    reason: "신문고 장난",
    duration: "1일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(knbn43lmv46z)",
  },
  {
    id: 1286,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "ㅌㄹㄱㄹㅁㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    reason: "도배",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(truly8574)",
  },
  {
    id: 1285,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "디시콘",
    reason: "신문고 도배",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(soft3518)",
  },
  {
    id: 1284,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "ㅌㄹㄱㄹㅁㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    reason: "도배",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(truly8574)",
  },
  {
    id: 1283,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "https://moneyapp.co.kr/1",
    reason: "광고",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(truly8574)",
  },
  {
    id: 1282,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "ㅌㄹㄱㄹㅁㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    reason: "도배",
    duration: "31일",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(truly8574)",
  },
];

const dummyDeleteRecords: ManagementRecord[] = [
  {
    id: 501,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "게시글",
    content: "광고글입니다",
    reason: "광고",
    duration: "-",
    processedAt: "2026.02.25",
    processor: "ㅇㅇ\n(soft3518)",
  },
  {
    id: 500,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "댓글",
    content: "스팸 댓글",
    reason: "스팸",
    duration: "-",
    processedAt: "2026.02.24",
    processor: "ㅇㅇ\n(hang2563)",
  },
  {
    id: 499,
    nickname: "ㅇㅇ",
    code: "ㅇㅇ",
    type: "게시글",
    content: "부적절한 내용",
    reason: "불건전",
    duration: "-",
    processedAt: "2026.02.24",
    processor: "ㅇㅇ\n(truly8574)",
  },
];

export default function GalleryManagementPopup({
  // galleryName,
  onClose,
}: GalleryManagementPopupProps) {
  const [activeTab, setActiveTab] = useState<"block" | "delete">("block");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const records =
    activeTab === "block" ? dummyBlockRecords : dummyDeleteRecords;
  const totalPages = Math.ceil(records.length / itemsPerPage);
  const paginatedRecords = records.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 배경 오버레이 */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* 모달 */}
      <div className="relative w-full max-w-[750px] max-h-[85vh] bg-white rounded-xl shadow-2xl overflow-hidden flex flex-col animate-fadeUp mx-4">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-5 py-4 bg-[#72C2FF] text-white">
          <h2 className="text-[16px] font-bold">갤러리 관리 내역</h2>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded hover:bg-white/20 transition-colors"
          >
            <svg
              width="18"
              height="18"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <path d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 매니저 / 부매니저 정보 */}
        <div className="px-5 py-4 bg-[#E8F4FC]">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[14px] font-bold text-gray-800">매니저</span>
            <svg
              className="w-4 h-4 text-orange-400"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                clipRule="evenodd"
              />
            </svg>
            <span className="text-[14px] text-gray-700">우라마이싱</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[14px] font-bold text-gray-800">
              부매니저
            </span>
            <span className="text-[14px] text-gray-700">
              김고로케, 나모띠, 모사궁, 이떠리, 야이쓰
            </span>
          </div>
        </div>

        {/* 탭 + 내 차단 내역 버튼 */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-gray-200 bg-white">
          <div className="flex items-center gap-6">
            <button
              onClick={() => {
                setActiveTab("block");
                setCurrentPage(1);
              }}
              className={`text-[14px] font-semibold transition-colors ${
                activeTab === "block"
                  ? "text-gray-900"
                  : "text-gray-400 hover:text-gray-600"
              }`}
            >
              차단 내역
            </button>
            <button
              onClick={() => {
                setActiveTab("delete");
                setCurrentPage(1);
              }}
              className={`text-[14px] font-semibold transition-colors ${
                activeTab === "delete"
                  ? "text-gray-900"
                  : "text-gray-400 hover:text-gray-600"
              }`}
            >
              삭제 내역
            </button>
          </div>
          <button className="px-3 py-1.5 text-[12px] font-medium text-[#72C2FF] border border-[#72C2FF] rounded hover:bg-[#72C2FF] hover:text-white transition-colors">
            내 차단 내역
          </button>
        </div>

        {/* 테이블 */}
        <div className="flex-1 overflow-auto">
          <table className="w-full text-[13px]">
            <thead className="bg-gray-50 sticky top-0">
              <tr className="text-gray-500">
                <th className="py-3 px-3 text-center font-medium w-[60px]">
                  번호
                </th>
                <th className="py-3 px-3 text-center font-medium w-[100px]">
                  닉네임
                  <br />
                  <span className="text-[11px] text-gray-400">
                    (식별 코드/IP)
                  </span>
                </th>
                <th className="py-3 px-3 text-center font-medium">
                  게시글 / 댓글
                </th>
                <th className="py-3 px-3 text-center font-medium w-[90px]">
                  사유
                </th>
                <th className="py-3 px-3 text-center font-medium w-[60px]">
                  기간
                </th>
                <th className="py-3 px-3 text-center font-medium w-[85px]">
                  처리일
                </th>
                <th className="py-3 px-3 text-center font-medium w-[90px]">
                  처리자
                </th>
              </tr>
            </thead>
            <tbody>
              {paginatedRecords.map((record) => (
                <tr
                  key={record.id}
                  className="border-b border-gray-100 hover:bg-gray-50"
                >
                  <td className="py-3 px-3 text-center text-gray-600">
                    {record.id}
                  </td>
                  <td className="py-3 px-3 text-center text-gray-600">
                    {record.nickname}
                  </td>
                  <td className="py-3 px-3 text-gray-700">
                    <span className="text-[#72C2FF] font-medium">
                      {record.type}
                    </span>{" "}
                    <span className="text-gray-500 truncate inline-block max-w-[180px] align-bottom">
                      {record.content}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center text-gray-600">
                    {record.reason}
                  </td>
                  <td className="py-3 px-3 text-center text-gray-600">
                    {record.duration}
                  </td>
                  <td className="py-3 px-3 text-center text-gray-500 text-[12px]">
                    {record.processedAt}
                  </td>
                  <td className="py-3 px-3 text-center text-gray-500 text-[12px] whitespace-pre-line">
                    {record.processor}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 푸터 - 안내문구 + 페이지네이션 */}
        <div className="px-5 py-4 border-t border-gray-200 bg-gray-50">
          <p className="text-[11px] text-gray-400 mb-3">
            ※ 최근 30일 내역만 공개됩니다.
          </p>

          {/* 페이지네이션 */}
          <div className="flex items-center justify-center gap-1">
            {/* 이전 페이지 */}
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className={`w-7 h-7 flex items-center justify-center rounded transition-colors ${
                currentPage === 1
                  ? "text-gray-300 cursor-not-allowed"
                  : "text-gray-500 hover:bg-gray-200"
              }`}
            >
              <svg
                width="14"
                height="14"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M15 19l-7-7 7-7" />
              </svg>
            </button>

            {/* 페이지 번호 */}
            {Array.from(
              { length: Math.min(totalPages, 10) },
              (_, i) => i + 1,
            ).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-7 h-7 flex items-center justify-center text-[13px] rounded transition-colors ${
                  currentPage === page
                    ? "bg-[#72C2FF] text-white font-bold"
                    : "text-gray-500 hover:bg-gray-200"
                }`}
              >
                {page}
              </button>
            ))}

            {/* 다음 페이지 */}
            <button
              onClick={() =>
                setCurrentPage(Math.min(totalPages, currentPage + 1))
              }
              disabled={currentPage === totalPages}
              className={`w-7 h-7 flex items-center justify-center rounded transition-colors ${
                currentPage === totalPages
                  ? "text-gray-300 cursor-not-allowed"
                  : "text-gray-500 hover:bg-gray-200"
              }`}
            >
              <svg
                width="14"
                height="14"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeUp { animation: fadeUp 0.3s ease-out both; }
      `}</style>
    </div>
  );
}
