import { useState, useRef, useEffect, useCallback, Fragment } from "react";
import PostCardFull from "./PostCardFull";
import PostListItem from "./PostListItem";
import PostDetail from "./PostDetail";
import Pagination from "./Pagination";
import GiftPopup from "./GiftPopup";
import ProfilePopup from "./ProfilePopup";
import AdCard from "./AdCard";
import AdListItem from "./AdListItem";
import { useToast } from "./Toast";
import { initialPosts } from "./postsData";
import type {
  PostData,
  Comment,
  ReplyTarget,
  Reply,
  ContentBlock,
} from "./types";

// ─── 애니메이션 스타일 ───
const animationStyles = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes highlight {
    0%, 100% { background-color: transparent; }
    50% { background-color: #FEF3C7; }
  }
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
  .animate-highlight { animation: highlight 1s ease-in-out; }
  .animate-spin { animation: spin 1s linear infinite; }
  .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  .hide-scrollbar::-webkit-scrollbar { display: none; }
`;

// ─── 본문 텍스트 추출 함수 ───
const getBodyText = (body: string | ContentBlock[]): string => {
  if (typeof body === "string") {
    return body;
  }
  return body
    .filter((block) => block.type === "text")
    .map((block) => block.content || "")
    .join(" ");
};

// ─── 광고 데이터 ───
const cardAd = {
  id: "ad-card-1",
  avatar: "🇺🇸",
  avatarBg: "#E5E7EB",
  name: "히어로 키우기",
  time: "27분",
  media: {
    type: "video" as const,
    src: "https://example.com/ad-video.mp4",
    thumbnail: "https://picsum.photos/800/450?random=ad1",
  },
  title: "히어로 키우기",
  link: "https://example.com",
};

const listAd = {
  id: "ad-list-1",
  thumbnail: "https://picsum.photos/100/100?random=ad2",
  name: "히어로키우기",
  description:
    "언어 학습 앱은 정답 하나만 가르쳐주지만, 인생은 그렇지 않습니다. Preply 튜터와 함께 연습을 시작하고 첫날부터 자신감을 키워보세요.",
  link: "https://example.com",
};

// ─── 지금핫한 콘텐츠 ───

interface HotContentProps {
  onProfileClick?: (name: string, avatar: string, avatarBg?: string) => void;
  initialPostId?: number | null;
  onPostOpened?: () => void;
}

export default function HotContent({ onProfileClick, initialPostId, onPostOpened }: HotContentProps) {
  const { showToast } = useToast();

  const [subTab, setSubTab] = useState("베스트");
  const [viewMode, setViewMode] = useState<"card" | "list">("card");
  const [showViewDropdown, setShowViewDropdown] = useState(false);
  const [showCountDropdown, setShowCountDropdown] = useState(false);

  // ─── 게시글 상세 상태 ───
  const [selectedPost, setSelectedPost] = useState<PostData | null>(null);

  // initialPostId로 자동 오픈
  useEffect(() => {
    if (initialPostId) {
      const post = initialPosts.find((p: PostData) => p.id === initialPostId);
      if (post) {
        setSelectedPost(post);
        onPostOpened?.();
      }
    }
  }, [initialPostId]);

  // ─── 무한스크롤 상태 (카드형) ───
  const [displayCount, setDisplayCount] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const loadMoreRef = useRef<HTMLDivElement>(null);

  // ─── 페이지네이션 상태 (목록형) ───
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(50);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [searchType, setSearchType] = useState("title");

  // 상호작용 상태
  const [likedPosts, setLikedPosts] = useState<number[]>([]);
  const [dislikedPosts, setDislikedPosts] = useState<number[]>([]);
  const [followedUsers, setFollowedUsers] = useState<string[]>(["김쌀먹"]);
  const [followedPosts, setFollowedPosts] = useState<number[]>([]);
  const [expandedComments, setExpandedComments] = useState<number[]>([]);

  // 댓글 상태
  const [commentInputs, setCommentInputs] = useState<{ [key: number]: string }>(
    {},
  );
  const [replyingTo, setReplyingTo] = useState<ReplyTarget | null>(null);
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: string }>({});
  const [likedComments, setLikedComments] = useState<string[]>([]);
  const [dislikedComments, setDislikedComments] = useState<string[]>([]);
  const [highlightedComment, setHighlightedComment] = useState<string | null>(
    null,
  );
  const commentRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  // 팝업 상태
  const [showGiftPopup, setShowGiftPopup] = useState(false);
  const [showCommentGiftPopup, setShowCommentGiftPopup] = useState<
    string | null
  >(null);
  const [showProfilePopup, setShowProfilePopup] = useState(false);
  const [profileTarget, setProfileTarget] = useState<PostData | null>(null);

  const subTabs = ["인증글", "베스트", "인기글"];

  // 샘플 댓글 데이터
  const [commentsData, setCommentsData] = useState<{
    [postId: number]: Comment[];
  }>({
    1: [
      {
        id: 101,
        author: "축하드려요",
        avatar: "🎉",
        avatarBg: "linear-gradient(135deg,#F59E0B,#D97706)",
        content: "와 대박!! 275 축하드립니다!! 저도 열심히 해야겠네요 ㅎㅎ",
        time: "10분 전",
        likes: 45,
        dislikes: 2,
        isBest: true,
        replies: [
          {
            id: 1001,
            author: "메이플고수",
            avatar: "🍁",
            avatarBg: "linear-gradient(135deg,#F59E0B,#D97706)",
            content: "감사합니다!! 화이팅하세요!",
            time: "8분 전",
            likes: 12,
            dislikes: 0,
          },
        ],
      },
      {
        id: 102,
        author: "부럽다",
        avatar: "😭",
        avatarBg: "#93C5FD",
        content: "저는 아직 250도 안됐는데... 비결이 뭔가요?",
        time: "5분 전",
        likes: 23,
        dislikes: 1,
        isBest: true,
      },
      {
        id: 103,
        author: "초보자",
        avatar: "🌱",
        avatarBg: "#86EFAC",
        content: "275가 뭔가요? 레벨인가요?",
        time: "3분 전",
        likes: 5,
        dislikes: 0,
      },
    ],
    2: [
      {
        id: 201,
        author: "리니지팬",
        avatar: "⚔️",
        avatarBg: "#C4B5FD",
        content: "오 이거 진짜 유용한 정보네요! 저도 해봐야겠어요",
        time: "8분 전",
        likes: 67,
        dislikes: 3,
        isBest: true,
      },
      {
        id: 202,
        author: "장사꾼",
        avatar: "💰",
        avatarBg: "#FDE047",
        content: "와 31만 아덴 실화?? 대박이다",
        time: "5분 전",
        likes: 34,
        dislikes: 2,
        isBest: true,
      },
    ],
  });

  // 상대 시간 변환 함수
  const getRelativeTime = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;

    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return "방금 전";
    if (minutes < 60) return `${minutes}분 전`;
    if (hours < 24) return `${hours}시간 전`;
    if (days < 7) return `${days}일 전`;

    const date = new Date(timestamp);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  };

  // ─── 필터링 + 검색 (인기순 정렬) ───
  const filteredPosts = initialPosts
    .filter((post) => {
      // 서브탭 필터
      if (subTab === "인증글" && !post.isVerified) return false;
      if (
        subTab === "베스트" &&
        !(post.views >= 5000 || post.likes >= 100 || post.comments >= 50)
      )
        return false;

      // 검색 필터
      if (searchKeyword) {
        const keyword = searchKeyword.toLowerCase();
        const bodyText = getBodyText(post.body);
        switch (searchType) {
          case "title":
            return post.title.toLowerCase().includes(keyword);
          case "content":
            return bodyText.toLowerCase().includes(keyword);
          case "author":
            return post.name.toLowerCase().includes(keyword);
          case "title_content":
            return (
              post.title.toLowerCase().includes(keyword) ||
              bodyText.toLowerCase().includes(keyword)
            );
          default:
            return true;
        }
      }
      return true;
    })
    .sort((a, b) => b.views - a.views); // 인기순 정렬

  // ─── 무한스크롤 (카드형) ───
  const cardPosts = filteredPosts.slice(0, displayCount);
  const hasMoreCards = displayCount < filteredPosts.length;

  const loadMore = useCallback(() => {
    if (isLoading || !hasMoreCards) return;

    setIsLoading(true);
    setTimeout(() => {
      setDisplayCount((prev) => Math.min(prev + 10, filteredPosts.length));
      setIsLoading(false);
    }, 500);
  }, [isLoading, hasMoreCards, filteredPosts.length]);

  // IntersectionObserver for infinite scroll
  useEffect(() => {
    if (viewMode !== "card" || selectedPost) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMoreCards && !isLoading) {
          loadMore();
        }
      },
      { threshold: 0.1 },
    );

    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current);
    }

    return () => observer.disconnect();
  }, [viewMode, hasMoreCards, isLoading, loadMore, selectedPost]);

  // 필터 변경 시 리셋
  useEffect(() => {
    setDisplayCount(10);
    setCurrentPage(1);
  }, [subTab, searchKeyword]);

  // ─── 페이지네이션 계산 (목록형) ───
  const totalPages = Math.max(
    1,
    Math.ceil(filteredPosts.length / itemsPerPage),
  );
  const paginatedPosts = filteredPosts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  // 핸들러 함수들
  const handleLike = (postId: number) => {
    setLikedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
    setDislikedPosts((prev) => prev.filter((id) => id !== postId));
  };

  const handleDislike = (postId: number) => {
    setDislikedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
    setLikedPosts((prev) => prev.filter((id) => id !== postId));
  };

  const handleFollow = (name: string) => {
    setFollowedUsers((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name],
    );
  };

  const handleFollowPost = (postId: number) => {
    setFollowedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
    // 토스트는 하위 컴포넌트에서 표시
  };

  const handleToggleComments = (postId: number) => {
    setExpandedComments((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
  };

  const handleShowGiftPopup = () => {
    setShowGiftPopup(true);
  };

  const handleShowProfile = (post: PostData) => {
    if (onProfileClick) {
      onProfileClick(post.author || post.name, post.avatar, post.avatarBg);
    } else {
      setProfileTarget(post);
      setShowProfilePopup(true);
    }
  };

  const handleCommentInputChange = (postId: number, value: string) => {
    setCommentInputs((prev) => ({ ...prev, [postId]: value }));
  };

  const handleSubmitComment = (postId: number) => {
    const input = commentInputs[postId]?.trim();
    if (!input) return;

    const newComment: Comment = {
      id: Date.now(),
      author: "나",
      avatar: "👤",
      content: input,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replies: [],
    };

    setCommentsData((prev) => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment],
    }));
    setCommentInputs((prev) => ({ ...prev, [postId]: "" }));
    showToast("댓글이 등록되었습니다");
  };

  const handleCommentLike = (key: string) => {
    setLikedComments((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
    setDislikedComments((prev) => prev.filter((k) => k !== key));
  };

  const handleCommentDislike = (key: string) => {
    setDislikedComments((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
    setLikedComments((prev) => prev.filter((k) => k !== key));
  };

  const handleStartReply = (key: string, author: string) => {
    setReplyingTo({ key, author });
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
  };

  const scrollToComment = (postId: number, commentId: number) => {
    const key = `${postId}-${commentId}`;
    const element = commentRefs.current[key];
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
      setHighlightedComment(key);
      setTimeout(() => setHighlightedComment(null), 1500);
    }
  };

  const handleReplyInputChange = (key: string, value: string) => {
    setReplyInputs((prev) => ({ ...prev, [key]: value }));
  };

  const addReplyToNested = (
    replies: Reply[],
    targetId: number,
    newReply: Reply,
  ): Reply[] => {
    return replies.map((reply) => {
      if (reply.id === targetId) {
        return {
          ...reply,
          replies: [...(reply.replies || []), newReply],
        };
      }
      if (reply.replies && reply.replies.length > 0) {
        return {
          ...reply,
          replies: addReplyToNested(reply.replies, targetId, newReply),
        };
      }
      return reply;
    });
  };

  const handleSubmitReply = (postId: number, commentId: number) => {
    if (!replyingTo) return;

    const key = replyingTo.key;
    const input = replyInputs[key]?.trim();
    if (!input) return;

    const newReply: Reply = {
      id: Date.now(),
      author: "나",
      avatar: "👤",
      content: input,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replyTo: replyingTo.author,
      replies: [],
    };

    const keyParts = key.split("-");

    if (keyParts.length === 2) {
      setCommentsData((prev) => ({
        ...prev,
        [postId]: (prev[postId] || []).map((comment) =>
          comment.id === commentId
            ? { ...comment, replies: [...(comment.replies || []), newReply] }
            : comment,
        ),
      }));
    } else {
      const targetReplyId = parseInt(keyParts[keyParts.length - 1]);
      setCommentsData((prev) => ({
        ...prev,
        [postId]: (prev[postId] || []).map((comment) =>
          comment.id === commentId
            ? {
                ...comment,
                replies: addReplyToNested(
                  comment.replies || [],
                  targetReplyId,
                  newReply,
                ),
              }
            : comment,
        ),
      }));
    }

    setReplyInputs((prev) => ({ ...prev, [key]: "" }));
    setReplyingTo(null);
    showToast("답글이 등록되었습니다");
  };

  const handleScrollToComment = (postId: number, commentId: number) => {
    const key = `${postId}-${commentId}`;
    setHighlightedComment(key);
    setTimeout(() => setHighlightedComment(null), 2000);

    const el = commentRefs.current[key];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  const handleSearch = (keyword: string, type: string) => {
    setSearchKeyword(keyword);
    setSearchType(type);
    setCurrentPage(1);
  };

  // ─── 게시글 클릭 핸들러 (목록형) ───
  const handlePostClick = (post: PostData) => {
    setSelectedPost(post);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // ─── 상세에서 뒤로가기 ───
  const handleBackFromDetail = () => {
    setSelectedPost(null);
  };

  return (
    <>
      <style>{animationStyles}</style>

      {/* 게시글 상세 모드 */}
      {selectedPost ? (
        <PostDetail
          post={selectedPost}
          comments={commentsData[selectedPost.id] || []}
          isLiked={likedPosts.includes(selectedPost.id)}
          isDisliked={dislikedPosts.includes(selectedPost.id)}
          isFollowed={followedUsers.includes(selectedPost.name)}
          onBack={handleBackFromDetail}
          onLike={() => handleLike(selectedPost.id)}
          onDislike={() => handleDislike(selectedPost.id)}
          onFollow={handleFollow}
          onShowGiftPopup={handleShowGiftPopup}
          onShowProfile={() => handleShowProfile(selectedPost)}
          // 댓글 관련 props
          commentInput={commentInputs[selectedPost.id] || ""}
          replyingTo={replyingTo}
          replyInputs={replyInputs}
          likedComments={likedComments}
          dislikedComments={dislikedComments}
          followedUsers={followedUsers}
          highlightedComment={highlightedComment}
          commentRefs={commentRefs}
          onCommentInputChange={(value) =>
            setCommentInputs((prev) => ({ ...prev, [selectedPost.id]: value }))
          }
          onSubmitComment={() => handleSubmitComment(selectedPost.id)}
          onCommentLike={handleCommentLike}
          onCommentDislike={handleCommentDislike}
          onCommentGift={(key) => setShowCommentGiftPopup(key)}
          onStartReply={handleStartReply}
          onCancelReply={handleCancelReply}
          onReplyInputChange={handleReplyInputChange}
          onSubmitReply={(commentId) =>
            handleSubmitReply(selectedPost.id, commentId)
          }
          onScrollToComment={(commentId) =>
            scrollToComment(selectedPost.id, commentId)
          }
        />
      ) : (
        <>
          {/* 서브 탭 */}
          <div className="flex items-center gap-1 py-3 border-b border-gray-200">
            {subTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setSubTab(tab)}
                className={`px-4 py-1.5 rounded-full text-[14px] font-semibold transition-colors flex items-center gap-1 ${
                  subTab === tab
                    ? "bg-[#72C2FF] text-white"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                {tab === "인증글" && (
                  <img
                    src="https://ssalmuk.com/images/img_commu/cm_list_adminmark_size22.svg"
                    alt=""
                    className="w-4 h-4"
                  />
                )}
                {tab}
              </button>
            ))}
            <div className="flex-1" />
            {/* 개수 선택 드롭다운 (목록형일 때만) */}
            {viewMode === "list" && (
              <div className="relative">
                <button
                  className="flex items-center gap-1 px-3 py-1.5 text-[14px] text-gray-500 rounded-lg hover:bg-gray-100 transition-colors"
                  onClick={() => setShowCountDropdown(!showCountDropdown)}
                >
                  {itemsPerPage}개
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {showCountDropdown && (
                  <>
                    <div
                      className="fixed inset-0 z-10"
                      onClick={() => setShowCountDropdown(false)}
                    />
                    <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg py-1.5 min-w-[100px] z-20">
                      {[30, 50, 100].map((count) => (
                        <button
                          key={count}
                          className={`w-full flex items-center gap-2 px-3 py-2 text-[14px] font-medium transition-colors ${
                            itemsPerPage === count
                              ? "text-[#72C2FF] bg-blue-50"
                              : "text-gray-600 hover:bg-gray-50"
                          }`}
                          onClick={() => {
                            setItemsPerPage(count);
                            setCurrentPage(1);
                            setShowCountDropdown(false);
                          }}
                        >
                          {itemsPerPage === count && (
                            <svg
                              className="w-4 h-4"
                              fill="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                            </svg>
                          )}
                          {count}개
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}
            {/* 보기 전환 드롭다운 */}
            <div className="relative">
              <button
                className="flex items-center gap-1 px-2.5 py-1.5 text-[14px] text-gray-400 rounded-lg hover:bg-gray-100 transition-colors"
                onClick={() => setShowViewDropdown(!showViewDropdown)}
              >
                ☰ ▾
              </button>
              {showViewDropdown && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setShowViewDropdown(false)}
                  />
                  <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg py-1.5 min-w-[140px] z-20">
                    <p className="px-3 py-1.5 text-[12px] font-semibold text-gray-400">
                      View
                    </p>
                    <button
                      className={`w-full flex items-center gap-2 px-3 py-2 text-[14px] font-semibold transition-colors ${
                        viewMode === "card"
                          ? "text-[#1A1A2E] bg-gray-50"
                          : "text-gray-500 hover:bg-gray-50"
                      }`}
                      onClick={() => {
                        setViewMode("card");
                        setShowViewDropdown(false);
                      }}
                    >
                      🃏 카드형
                    </button>
                    <button
                      className={`w-full flex items-center gap-2 px-3 py-2 text-[14px] font-semibold transition-colors ${
                        viewMode === "list"
                          ? "text-[#1A1A2E] bg-gray-50"
                          : "text-gray-500 hover:bg-gray-50"
                      }`}
                      onClick={() => {
                        setViewMode("list");
                        setShowViewDropdown(false);
                      }}
                    >
                      📋 목록형
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* 콘텐츠 */}
          {filteredPosts.length === 0 ? (
            <div className="py-20 text-center">
              <p className="text-5xl mb-4">📭</p>
              <p className="text-[16px] font-semibold text-gray-500 mb-2">
                게시글이 없어요
              </p>
              <p className="text-[14px] text-gray-400">
                다른 탭을 선택해보세요!
              </p>
            </div>
          ) : viewMode === "card" ? (
            <>
              {/* 카드형 (무한스크롤) */}
              <div>
                {cardPosts.map((post, index) => (
                  <Fragment key={post.id}>
                    <PostCardFull
                      post={post}
                      index={index}
                      comments={commentsData[post.id] || []}
                      isLiked={likedPosts.includes(post.id)}
                      isDisliked={dislikedPosts.includes(post.id)}
                      isFollowed={followedUsers.includes(post.name)}
                      isCommentsExpanded={expandedComments.includes(post.id)}
                      commentInput={commentInputs[post.id] || ""}
                      replyingTo={replyingTo}
                      replyInputs={replyInputs}
                      likedComments={likedComments}
                      dislikedComments={dislikedComments}
                      followedUsers={followedUsers}
                      highlightedComment={highlightedComment}
                      commentRefs={commentRefs}
                      onLike={() => handleLike(post.id)}
                      onDislike={() => handleDislike(post.id)}
                      onFollow={handleFollow}
                      onToggleComments={() => handleToggleComments(post.id)}
                      onShowGiftPopup={handleShowGiftPopup}
                      onShowProfile={() => handleShowProfile(post)}
                      onCommentInputChange={(value) =>
                        handleCommentInputChange(post.id, value)
                      }
                      onSubmitComment={() => handleSubmitComment(post.id)}
                      onCommentLike={handleCommentLike}
                      onCommentDislike={handleCommentDislike}
                      onCommentGift={(key) => setShowCommentGiftPopup(key)}
                      onStartReply={handleStartReply}
                      onCancelReply={handleCancelReply}
                      onReplyInputChange={handleReplyInputChange}
                      onSubmitReply={(commentId) =>
                        handleSubmitReply(post.id, commentId)
                      }
                      onScrollToComment={(commentId) =>
                        handleScrollToComment(post.id, commentId)
                      }
                    />
                    {/* 첫 번째 게시글 뒤에 광고 */}
                    {index === 0 && <AdCard ad={cardAd} index={index + 1} />}
                  </Fragment>
                ))}
              </div>

              {/* 무한스크롤 로딩 영역 */}
              <div ref={loadMoreRef} className="py-8 flex justify-center">
                {isLoading ? (
                  <div className="flex items-center gap-2 text-gray-400">
                    <svg
                      className="w-5 h-5 animate-spin"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    <span className="text-[14px]">불러오는 중...</span>
                  </div>
                ) : hasMoreCards ? (
                  <p className="text-[14px] text-gray-400">
                    스크롤하여 더 보기
                  </p>
                ) : (
                  <p className="text-[14px] text-gray-400">
                    모든 게시글을 불러왔어요
                  </p>
                )}
              </div>
            </>
          ) : (
            <>
              {/* 목록형 (페이지네이션) */}
              <div className="pt-3 flex flex-col gap-3">
                {paginatedPosts.map((post, index) => (
                  <Fragment key={post.id}>
                    <PostListItem
                      post={post}
                      index={index}
                      isFollowed={followedPosts.includes(post.id)}
                      isLiked={likedPosts.includes(post.id)}
                      isDisliked={dislikedPosts.includes(post.id)}
                      onFollow={() => handleFollowPost(post.id)}
                      onLike={() => handleLike(post.id)}
                      onDislike={() => handleDislike(post.id)}
                      onComment={() => handlePostClick(post)}
                      onGift={handleShowGiftPopup}
                      onClick={() => handlePostClick(post)}
                      getRelativeTime={getRelativeTime}
                    />
                    {/* 첫 번째 게시글 뒤에 광고 */}
                    {index === 0 && (
                      <AdListItem ad={listAd} index={index + 1} />
                    )}
                  </Fragment>
                ))}
              </div>

              {/* 페이지네이션 */}
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
                onSearch={handleSearch}
              />
            </>
          )}
        </>
      )}

      {/* 선물 팝업 */}
      {showGiftPopup && (
        <GiftPopup type="post" onClose={() => setShowGiftPopup(false)} />
      )}

      {showCommentGiftPopup && (
        <GiftPopup
          type="comment"
          onClose={() => setShowCommentGiftPopup(null)}
        />
      )}

      {/* 프로필 팝업 (외부 핸들러 없을 때만) */}
      {!onProfileClick && showProfilePopup && profileTarget && (
        <ProfilePopup
          profile={profileTarget}
          isFollowed={followedUsers.includes(profileTarget.name)}
          onFollow={() => handleFollow(profileTarget.name)}
          onClose={() => setShowProfilePopup(false)}
        />
      )}
    </>
  );
}
