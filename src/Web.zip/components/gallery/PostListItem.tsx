import { useState } from "react";
import type { PostData } from "./types";
import LikeDislikeButton from "./LikeDislikeButton";
import DropdownMenu, { getPostMenuItems } from "./DropdownMenu";
import { useToast } from "./Toast";
import ConfirmPopup from "./ConfirmPopup";
import ReportPopup from "./ReportPopup";
import { FollowButton } from "./FollowButton";

interface PostListItemProps {
  post: PostData;
  index: number;
  isFollowed: boolean;
  isLiked: boolean;
  isDisliked: boolean;
  onFollow: () => void;
  onLike: () => void;
  onDislike: () => void;
  onComment: () => void;
  onGift: () => void;
  onClick?: () => void;
  getRelativeTime: (timestamp: number) => string;
  displayCategory?: string;
  isResident?: boolean;
}

export default function PostListItem({
  post,
  index,
  isFollowed,
  isLiked,
  isDisliked,
  onFollow,
  onLike,
  onDislike,
  onComment,
  onGift,
  onClick,
  getRelativeTime,
  displayCategory,
  isResident = false,
}: PostListItemProps) {
  const { showToast } = useToast();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showBlockPopup, setShowBlockPopup] = useState(false);
  const [showReportPopup, setShowReportPopup] = useState(false);

  // 클릭 이벤트 전파 방지 래퍼
  const stopPropagation = (e: React.MouseEvent, callback: () => void) => {
    e.stopPropagation();
    callback();
  };

  return (
    <div
      className="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-gray-200 transition-all animate-fadeUp relative cursor-pointer"
      style={{
        animationDelay: `${index * 30}ms`,
        zIndex: isMenuOpen ? 30 : 1,
      }}
      onClick={onClick}
    >
      {/* 프로필 */}
      <div className="flex flex-col items-center gap-0.5 shrink-0">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-lg cursor-pointer hover:scale-105 transition-transform"
          style={{ background: post.avatarBg }}
          onClick={(e) => e.stopPropagation()}
        >
          {post.avatar}
        </div>
        {isResident && (
          <span className="text-[9px] text-[#72C2FF] font-bold">주민</span>
        )}
      </div>

      {/* 콘텐츠 영역 */}
      <div className="flex-1 min-w-0">
        {/* 첫째 줄: 제목 + 버튼들 */}
        <div className="flex items-center gap-2 mb-1.5">
          <p className="text-[15px] font-bold text-gray-900 truncate flex-1 flex items-center gap-1.5">
            {post.isVerified && (
              <img
                src="https://ssalmuk.com/images/img_commu/cm_list_adminmark_size22.svg"
                alt="인증글"
                className="w-5 h-5 shrink-0"
              />
            )}
            {post.title}
          </p>

          {/* 더보기 메뉴 */}
          <DropdownMenu
            size="lg"
            zIndex={50}
            stopPropagation={true}
            onOpenChange={setIsMenuOpen}
            items={getPostMenuItems({
              onShare: () => showToast("링크를 복사했어요", { type: "link" }),
              onSave: () => showToast(`${post.name}님의 글을 저장했어요.`),
              onBlock: () => setShowBlockPopup(true),
              onReport: () => setShowReportPopup(true),
            })}
          />

          {/* 팔로우 버튼 */}
          <FollowButton
            name={post.name}
            isFollowed={isFollowed}
            onFollow={onFollow}
          />
        </div>

        {/* 둘째 줄: 메타 정보 */}
        <div className="flex items-center gap-1.5 text-[12px] text-gray-400 mb-2">
          <span className="text-gray-500">{post.name}</span>
          <span>·</span>
          <span>{displayCategory || post.boardId || "자유"}</span>
          <span>·</span>
          <span>{getRelativeTime(post.createdAt || Date.now())}</span>
        </div>

        {/* 셋째 줄: 액션 버튼들 */}
        <div className="flex items-center gap-4 text-[12px] text-gray-400">
          {/* 좋아요/싫어요 */}
          <LikeDislikeButton
            likes={post.likes}
            dislikes={post.dislikes || 0}
            isLiked={isLiked}
            isDisliked={isDisliked}
            onLike={onLike}
            onDislike={onDislike}
            size="sm"
          />

          {/* 댓글 */}
          <button
            className="flex items-center gap-1 hover:text-gray-600 transition-colors"
            onClick={(e) => stopPropagation(e, onComment)}
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              />
            </svg>
            {post.comments}
          </button>

          {/* 조회수 */}
          <span className="flex items-center gap-1">
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
              />
            </svg>
            {post.views.toLocaleString()}
          </span>

          {/* 후원 */}
          <button
            className="flex items-center gap-1 hover:text-amber-500 transition-colors"
            onClick={(e) => stopPropagation(e, onGift)}
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* 차단 확인 팝업 */}
      {showBlockPopup && (
        <ConfirmPopup
          title={`${post.name}님을 차단할까요?`}
          description={`앞으로 ${post.name}님의 글을 볼 수 없고, ${post.name}님도 내 글을 볼 수 없어요.`}
          confirmText="차단하기"
          cancelText="닫기"
          isDestructive
          onConfirm={() => {
            showToast(`${post.name}님을 차단했어요`, { type: "block" });
            setShowBlockPopup(false);
          }}
          onCancel={() => setShowBlockPopup(false)}
        />
      )}

      {/* 신고 사유 선택 팝업 */}
      {showReportPopup && (
        <ReportPopup
          targetType="글"
          onReport={(reason) => {
            console.log("신고 사유:", reason);
            showToast("신고가 접수되었습니다");
            setShowReportPopup(false);
          }}
          onCancel={() => setShowReportPopup(false)}
        />
      )}
    </div>
  );
}
