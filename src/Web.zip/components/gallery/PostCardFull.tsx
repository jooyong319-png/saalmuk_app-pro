import { useState } from "react";
import type { PostData, Comment, ReplyTarget, ContentBlock } from "./types";
import CommentSection from "./CommentSection";
import LikeDislikeButton from "./LikeDislikeButton";
import DropdownMenu, { getPostMenuItems } from "./DropdownMenu";
import { useToast, TOAST_MESSAGES } from "./Toast";
import ConfirmPopup from "./ConfirmPopup";
import ReportPopup from "./ReportPopup";
import { FollowButton } from "./FollowButton";

interface PostCardFullProps {
  post: PostData;
  index: number;
  comments: Comment[];
  isLiked: boolean;
  isDisliked: boolean;
  isFollowed: boolean;
  isCommentsExpanded: boolean;
  commentInput: string;
  replyingTo: ReplyTarget | null;
  replyInputs: { [key: string]: string };
  likedComments: string[];
  dislikedComments: string[];
  followedUsers: string[];
  highlightedComment: string | null;
  commentRefs: React.MutableRefObject<{ [key: string]: HTMLDivElement | null }>;
  onLike: () => void;
  onDislike: () => void;
  onFollow: (name: string) => void;
  onToggleComments: () => void;
  onShowGiftPopup: () => void;
  onShowProfile: () => void;
  onCommentInputChange: (value: string) => void;
  onSubmitComment: () => void;
  onCommentLike: (key: string) => void;
  onCommentDislike: (key: string) => void;
  onCommentGift: (key: string) => void;
  onStartReply: (key: string, author: string) => void;
  onCancelReply: () => void;
  onReplyInputChange: (key: string, value: string) => void;
  onSubmitReply: (commentId: number) => void;
  onScrollToComment: (commentId: number) => void;
  displayCategory?: string;
  isResident?: boolean; // 갤러리 주민 여부
}

export default function PostCardFull({
  post,
  index,
  comments,
  isLiked,
  isDisliked,
  isFollowed,
  isCommentsExpanded,
  commentInput,
  replyingTo,
  replyInputs,
  likedComments,
  dislikedComments,
  followedUsers,
  highlightedComment,
  commentRefs,
  onLike,
  onDislike,
  onFollow,
  onToggleComments,
  onShowGiftPopup,
  onShowProfile,
  onCommentInputChange,
  onSubmitComment,
  onCommentLike,
  onCommentDislike,
  onCommentGift,
  onStartReply,
  onCancelReply,
  onReplyInputChange,
  onSubmitReply,
  onScrollToComment,
  displayCategory,
  isResident = false,
}: PostCardFullProps) {
  const { showToast } = useToast();

  const [isBodyExpanded, setIsBodyExpanded] = useState(false);
  const [showBlockPopup, setShowBlockPopup] = useState(false);
  const [showReportPopup, setShowReportPopup] = useState(false);

  // 투표 상태 관리
  const [pollState, setPollState] = useState(post.poll);

  // 투표 클릭 핸들러
  const handleVote = (optionIndex: number) => {
    if (!pollState || pollState.votedOption !== undefined) return;

    setPollState({
      ...pollState,
      options: pollState.options.map((opt, idx) =>
        idx === optionIndex ? { ...opt, votes: opt.votes + 1 } : opt,
      ),
      totalVotes: pollState.totalVotes + 1,
      votedOption: optionIndex,
    });
    showToast("투표 완료!");
  };

  // body가 블록 배열인지 확인
  const isBlockBody = Array.isArray(post.body);
  const bodyBlocks = isBlockBody ? (post.body as ContentBlock[]) : null;
  const bodyString = !isBlockBody ? (post.body as string) : null;

  // 본문이 긴지 확인
  const isLongBody = isBlockBody
    ? bodyBlocks!.length > 3 ||
      bodyBlocks!.some(
        (b) => b.type === "text" && (b.content?.length || 0) > 150,
      )
    : (bodyString?.length || 0) > 150 ||
      (bodyString?.split("\n").length || 0) > 3;

  // 이미지 블록 개수
  const imageBlockCount =
    bodyBlocks?.filter((b) => b.type === "image").length || 0;
  const hasMultipleImages = isBlockBody
    ? imageBlockCount > 1
    : post.images && post.images.length > 1;

  // 블록 렌더링 함수
  const renderBlock = (
    block: ContentBlock,
    idx: number,
    isCollapsed: boolean = false,
  ) => {
    if (block.type === "text") {
      return (
        <p
          key={idx}
          className={`text-[15px] text-gray-700 leading-[1.6] whitespace-pre-wrap ${
            isCollapsed ? "line-clamp-3" : ""
          }`}
          style={{ fontWeight: 500 }}
        >
          {block.content}
        </p>
      );
    } else if (block.type === "image") {
      return (
        <div
          key={idx}
          className="relative bg-gray-100 rounded-xl overflow-hidden my-3"
        >
          <img
            src={block.src}
            alt={block.alt || `이미지 ${idx + 1}`}
            loading="lazy"
            decoding="async"
            className="w-full h-auto max-h-[500px] object-contain cursor-pointer hover:opacity-95 transition-opacity rounded-xl"
          />
        </div>
      );
    }
    return null;
  };

  // 접힌 상태의 콘텐츠 렌더링
  const renderCollapsedContent = () => {
    if (!bodyBlocks) return null;

    // 텍스트만 먼저 표시
    const textBlocks = bodyBlocks.filter((b) => b.type === "text").slice(0, 2);
    const imageBlocks = bodyBlocks.filter((b) => b.type === "image");

    return (
      <>
        {textBlocks.map((block, idx) => (
          <p
            key={idx}
            className="text-[15px] text-gray-700 leading-[1.6] whitespace-pre-wrap line-clamp-2"
            style={{ fontWeight: 500 }}
          >
            {block.content}
          </p>
        ))}

        {/* 이미지 썸네일 미리보기 */}
        {imageBlocks.length > 0 && (
          <div className="flex gap-2 mt-3">
            {imageBlocks.slice(0, 3).map((block, idx) => (
              <div
                key={idx}
                className="relative w-64 h-64 rounded-lg overflow-hidden bg-gray-100 shrink-0 cursor-pointer"
                onClick={() => setIsBodyExpanded(true)}
              >
                <img
                  src={block.src}
                  alt={block.alt || `미리보기 ${idx + 1}`}
                  className="w-full h-full object-cover"
                />
                {idx === 2 && imageBlocks.length > 3 && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="text-white text-[13px] font-bold">
                      +{imageBlocks.length - 3}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </>
    );
  };

  return (
    <div
      className="py-4 border-b border-gray-100 animate-fadeUp"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* 작성자 정보 */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center gap-0.5">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center text-lg cursor-pointer hover:scale-105 transition-transform shrink-0"
              style={{ background: post.avatarBg }}
              onClick={onShowProfile}
            >
              {post.avatar}
            </div>
            {isResident && (
              <span className="text-[9px] text-[#72C2FF] font-bold">주민</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p
                className="text-[15px] font-semibold text-gray-900 cursor-pointer hover:underline"
                onClick={onShowProfile}
              >
                {post.name}
              </p>
              {post.badge && (
                <span className="text-[11px] px-1.5 py-0.5 rounded bg-[#E8F4FD] text-[#72C2FF] font-medium">
                  {post.badge}
                </span>
              )}
            </div>
            <p className="text-[13px] text-gray-400">
              {displayCategory
                ? post.meta?.split("·")[0]?.trim() + " · " + displayCategory
                : post.meta}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* 더보기 메뉴 */}
          <DropdownMenu
            size="lg"
            zIndex={50}
            items={getPostMenuItems({
              onShare: () => showToast("링크를 복사했어요", { type: "link" }),
              onSave: () => showToast(`${post.name}님의 글을 저장했어요.`),
              onBlock: () => setShowBlockPopup(true),
              onReport: () => setShowReportPopup(true),
            })}
          />
          <FollowButton
            name={post.name}
            isFollowed={isFollowed}
            onFollow={() => onFollow(post.name)}
          />
        </div>
      </div>

      {/* 게시글 내용 */}
      <div>
        {/* 제목 */}
        <h3 className="text-[16px] font-bold text-gray-900 mb-2 leading-snug flex items-center gap-1.5">
          {post.isVerified && (
            <img
              src="https://ssalmuk.com/images/img_commu/cm_list_adminmark_size22.svg"
              alt="인증글"
              className="w-5 h-5 shrink-0"
            />
          )}
          {post.title}
        </h3>

        {/* 본문 */}
        <div className="relative">
          {isBlockBody ? (
            // 블록 배열 형태
            isBodyExpanded ? (
              // 펼친 상태: 모든 블록 표시
              <>{bodyBlocks!.map((block, idx) => renderBlock(block, idx))}</>
            ) : (
              // 접힌 상태: 일부만 표시
              renderCollapsedContent()
            )
          ) : (
            // 기존 문자열 형태
            <>
              <p
                className={`text-[15px] text-gray-700 leading-[1.6] whitespace-pre-wrap ${
                  !isBodyExpanded && isLongBody ? "line-clamp-3" : ""
                }`}
                style={{ fontWeight: 500 }}
              >
                {bodyString}
              </p>

              {/* 기존 이미지 배열 (body가 string일 때) */}
              {post.images && post.images.length > 0 && !isBodyExpanded && (
                <div className="flex gap-2 mt-3">
                  {post.images.slice(0, 3).map((img, idx) => (
                    <div
                      key={idx}
                      className="relative w-64 h-64 rounded-lg overflow-hidden bg-gray-100 shrink-0 cursor-pointer"
                      onClick={() => setIsBodyExpanded(true)}
                    >
                      <img
                        src={img}
                        alt={`미리보기 ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                      {idx === 2 && post.images!.length > 3 && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                          <span className="text-white text-[13px] font-bold">
                            +{post.images!.length - 3}
                          </span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* 펼친 상태에서만 전체 이미지 표시 */}
              {post.images && post.images.length > 0 && isBodyExpanded && (
                <div className="space-y-3 mt-3">
                  {post.images.map((img, idx) => (
                    <div
                      key={idx}
                      className="relative bg-gray-100 rounded-xl overflow-hidden"
                    >
                      <img
                        src={img}
                        alt={`이미지 ${idx + 1}`}
                        className="w-full h-auto max-h-[500px] object-contain rounded-xl"
                      />
                    </div>
                  ))}
                </div>
              )}

              {/* 투표 UI */}
              {pollState && (
                <div className="mt-4 p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-2 mb-3">
                    <svg
                      className="w-5 h-5 text-[#72C2FF]"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      viewBox="0 0 24 24"
                    >
                      <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" />
                      <rect x="9" y="3" width="6" height="4" rx="1" />
                      <path d="M9 14l2 2 4-4" />
                    </svg>
                    <span className="text-[14px] font-semibold text-gray-700">
                      투표
                    </span>
                  </div>
                  <div className="space-y-2">
                    {pollState.options.map((option, idx) => {
                      const percentage =
                        pollState.totalVotes > 0
                          ? Math.round(
                              (option.votes / pollState.totalVotes) * 100,
                            )
                          : 0;
                      const isVoted = pollState.votedOption === idx;
                      const hasVoted = pollState.votedOption !== undefined;

                      return (
                        <button
                          key={idx}
                          onClick={() => handleVote(idx)}
                          className={`w-full relative overflow-hidden rounded-lg border transition-all ${
                            isVoted
                              ? "border-[#72C2FF] bg-[#E8F4FD]"
                              : hasVoted
                                ? "border-gray-200 bg-white"
                                : "border-gray-200 bg-white hover:border-[#72C2FF] hover:bg-[#F8FCFF] cursor-pointer"
                          }`}
                          disabled={hasVoted}
                        >
                          {/* 진행률 바 */}
                          {hasVoted && (
                            <div
                              className={`absolute inset-y-0 left-0 transition-all duration-500 ${
                                isVoted ? "bg-[#72C2FF]/20" : "bg-gray-100"
                              }`}
                              style={{ width: `${percentage}%` }}
                            />
                          )}
                          <div className="relative flex items-center justify-between px-4 py-3">
                            <span
                              className={`text-[14px] ${isVoted ? "font-semibold text-[#72C2FF]" : "text-gray-700"}`}
                            >
                              {option.text}
                            </span>
                            {hasVoted && (
                              <span
                                className={`text-[13px] font-semibold ${isVoted ? "text-[#72C2FF]" : "text-gray-500"}`}
                              >
                                {percentage}%
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  {/* 하단 참여 인원 - 항상 표시 */}
                  <p className="mt-3 text-[12px] text-gray-400 text-left flex items-center gap-1">
                    <span>ⓘ</span>
                    <span>
                      투표 {pollState.totalVotes.toLocaleString()}명 참여 중
                    </span>
                  </p>
                </div>
              )}
            </>
          )}

          {/* 더보기 버튼 */}
          {(isLongBody || hasMultipleImages) && !isBodyExpanded && (
            <button
              className="text-[14px] text-[#72C2FF] font-semibold mt-2 hover:underline"
              onClick={() => setIsBodyExpanded(true)}
            >
              ...더보기
            </button>
          )}
        </div>

        {/* 접기 버튼 */}
        {isBodyExpanded && (isLongBody || hasMultipleImages) && (
          <button
            className="text-[14px] text-gray-400 font-medium mt-3 hover:text-gray-600"
            onClick={() => setIsBodyExpanded(false)}
          >
            접기 ▲
          </button>
        )}
      </div>

      {/* 액션 버튼 */}
      <div className="flex items-center justify-between text-gray-400 mt-3">
        <div className="flex items-center gap-1">
          {/* 좋아요/싫어요 */}
          <LikeDislikeButton
            likes={post.likes}
            dislikes={post.dislikes || 0}
            isLiked={isLiked}
            isDisliked={isDisliked}
            onLike={onLike}
            onDislike={onDislike}
            size="md"
          />

          {/* 댓글 */}
          <button
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors ${
              isCommentsExpanded ? "text-[#72C2FF]" : ""
            }`}
            onClick={onToggleComments}
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              />
            </svg>
            <span className="text-[13px]">{post.comments}</span>
          </button>

          {/* 조회수 */}
          <span className="flex items-center gap-1 px-2 py-1.5 text-[13px] text-gray-400">
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
              />
            </svg>
            {post.views.toLocaleString()}
          </span>

          {/* 선물 */}
          <button
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={onShowGiftPopup}
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* 댓글 섹션 */}
      {isCommentsExpanded && (
        <CommentSection
          postId={post.id}
          comments={comments}
          commentInput={commentInput}
          replyingTo={replyingTo}
          replyInputs={replyInputs}
          likedComments={likedComments}
          dislikedComments={dislikedComments}
          followedUsers={followedUsers}
          highlightedComment={highlightedComment}
          commentRefs={commentRefs}
          onCommentInputChange={onCommentInputChange}
          onSubmitComment={onSubmitComment}
          onCommentLike={onCommentLike}
          onCommentDislike={onCommentDislike}
          onCommentGift={onCommentGift}
          onFollow={onFollow}
          onStartReply={onStartReply}
          onCancelReply={onCancelReply}
          onReplyInputChange={onReplyInputChange}
          onSubmitReply={onSubmitReply}
          onScrollToComment={onScrollToComment}
        />
      )}

      {/* 차단 확인 팝업 */}
      {showBlockPopup && (
        <ConfirmPopup
          title={`${post.name}님을 차단할까요?`}
          description={`앞으로 ${post.name}님의 글을 볼 수 없고, ${post.name}님도 내 글을 볼 수 없어요.`}
          confirmText="차단하기"
          cancelText="닫기"
          isDestructive
          onConfirm={() => {
            showToast(`${post.name}님을 차단했어요`, { type: "block" });
            setShowBlockPopup(false);
          }}
          onCancel={() => setShowBlockPopup(false)}
        />
      )}

      {/* 신고 사유 선택 팝업 */}
      {showReportPopup && (
        <ReportPopup
          targetType="글"
          onReport={(reason) => {
            console.log("신고 사유:", reason);
            showToast(TOAST_MESSAGES.REPORTED);
            setShowReportPopup(false);
          }}
          onCancel={() => setShowReportPopup(false)}
        />
      )}
    </div>
  );
}
