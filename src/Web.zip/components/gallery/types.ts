// ===== 갤러리 아이템 데이터 =====
export interface GalleryItemData {
  id: number;
  icon: string;
  name: string;
  desc: string;
  description?: string;
  color: string;
}

// ===== 본문 콘텐츠 블록 =====
export interface ContentBlock {
  type: "text" | "image";
  content?: string;
  src?: string;
  alt?: string;
}

// ===== 게시글 데이터 =====
export interface PostData {
  id: number;
  avatar: string;
  avatarBg: string;
  name: string;
  author?: string; // name의 alias
  badge?: string;
  meta: string;
  title: string;
  body: string | ContentBlock[];
  likes: number;
  dislikes?: number;
  comments: number;
  views: number;
  boardId?: string;
  authorId?: string;
  isVerified?: boolean;
  createdAt?: number;
  images?: string[];
  category?: string;
  poll?: {
    options: { text: string; votes: number }[];
    totalVotes: number;
    votedOption?: number;
  };
}

// ===== 대댓글 =====
export interface Reply {
  id: number;
  author: string;
  avatar: string;
  avatarBg?: string;
  content: string;
  time: string;
  likes: number;
  dislikes?: number;
  replyTo?: string;
  replies?: Reply[];
}

// ===== 댓글 =====
export interface Comment {
  id: number;
  author: string;
  avatar: string;
  avatarBg?: string;
  content: string;
  time: string;
  likes: number;
  dislikes?: number;
  isBest?: boolean;
  replies?: Reply[];
}

// ===== 답글 대상 =====
export interface ReplyTarget {
  key: string;
  author: string;
}

// ===== 탭 아이템 =====
export interface TabItem {
  name: string;
  emoji: string;
  type?: "board" | "user";
}

// ===== 리스트 아이템 =====
export interface ListItemData {
  avatar: string;
  avatarBg: string;
  title: string;
  hasImage?: boolean;
  commentCount: number;
  author: string;
  tag: string;
  time: string;
  views: number;
  likes: number;
}

// ===== 뉴스 기사 =====
export interface NewsArticle {
  id: number;
  source: string;
  sourceIcon: string;
  sourceBg: string;
  badge?: string;
  time: string;
  title: string;
  summary: string;
  thumbnail?: string;
  likes: number;
  comments: number;
  views: number;
  category: "게임뉴스" | "업계동향" | "쌀먹정보";
  isVerified?: boolean;
}

// ===== 랭킹 아이템 =====
export interface RankingItem {
  rank: number;
  name: string;
  avatar: string;
  followers: string;
  points?: string;
}

// ===== 관심 그룹 =====
export interface InterestGroup {
  id: string;
  name: string;
  emoji: string;
  galleryIds: string[];
}