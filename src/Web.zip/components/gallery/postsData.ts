import type { PostData, ContentBlock } from "./types";

export const gameImages = [
  "https://ssalmuk.com/crosseditor/binary/images/000131/aW1hZ2U=_62.png",
  "https://ssalmuk.com/crosseditor/binary/images/000131/aW1hZ2U=_65.png",
  "https://ssalmuk.com/crosseditor/binary/images/000187/aW1hZ2U=_18.png",
  "https://ssalmuk.com/crosseditor/binary/images/000180/aW1hZ2U=_7.png",
  "https://ssalmuk.com/crosseditor/binary/images/000180/aW1hZ2U=_9.png",
  "https://ssalmuk.com/crosseditor/binary/images/000180/aW1hZ2U=_13.png",
  "https://ssalmuk.com/crosseditor/binary/images/000110/aW1hZ2U=_51.png",
  "https://ssalmuk.com/crosseditor/binary/images/000120/aW1hZ2U=_86.png",
  "https://ssalmuk.com/crosseditor/binary/images/000120/aW1hZ2U=_18.png",
  "https://ssalmuk.com/crosseditor/binary/images/000120/aW1hZ2U=_42.png",
];

export const initialPosts: PostData[] = [
  {
    id: 1,
    avatar: "🍁",
    avatarBg: "linear-gradient(135deg,#F59E0B,#D97706)",
    name: "메이플고수",
    badge: "레벨링 장인",
    meta: "방금 전 · 메이플스토리",
    title: "드디어 275 달성했습니다!! 🎉",
    body: "3년 만에 드디어 275 찍었어요... 감격스럽네요 ㅠㅠ 다들 포기하지 마세요!",
    likes: 342,
    dislikes: 12,
    comments: 89,
    views: 15420,
    boardId: "메이플스토리",
    authorId: "메이플고수",
    isVerified: true,
    createdAt: Date.now(),
    images: [gameImages[0]],
  },
  {
    id: 2,
    avatar: "⚔️",
    avatarBg: "linear-gradient(135deg,#8B5CF6,#7C3AED)",
    name: "발악군단장",
    badge: "공략왕",
    meta: "10분 전 · 리니지M",
    title: "린클 수동 쌀먹시즈? 시세도 개 박살이 나고 있습니다!",
    body: [
      { type: 'text', content: `안녕하세요 발악군단장 입니다~!

린클 수동 쌀먹시즈? 시세도 개 박살이 나고 있습니다!
모든 아이템은 빠르게 판매 하시는게 정답입니다~!

저는 장사 캐릭을 4개 운영 중이라고 말씀드렸어요. 한캐릭 예시로 장사쌀먹 하는법 알려드립니다.
이미 수많은 고수분들은 생각보다 더 많은 수익을 올렸습니다.

제 기준으로 설명드릴게요. 방법은 제가말씀드린것 이외에도 무궁무진합니다.` },
      { type: 'image', src: gameImages[3], alt: '캐릭터 정보' },
      { type: 'text', content: `제 캐릭의 렙은 5입니다. 사냥 한번 조금 들려봤나? 그냥 막 했습니다.

결제는 정액권 3달짜리 7만원, 그리고 3만원 박스 결제 총 10만원 과금계획입니다.
박스를 까니 젬이 2장이 나왔습니다. 바로 판매에서 자본금을 챙겼습니다.

간단한 예시를 보여드릴게요.

상점을 오픈하고, 상점가보다 저렴하게 매집을 진행합니다. 자본과 무게가 중요합니다.` },
      { type: 'image', src: gameImages[4], alt: '상점 화면' },
      { type: 'text', content: `이렇게 상점에 팔면 400아덴을 하는 용기름, 300원에 매입합니다.

누가 파나싶죠? 팝니다. 저도 왜 파는지 모르겠는데....팔아요....

거래 수수료가 없는 리니지클래식의 장점을 이용해서, 100원따기 장사를합니다.
400개까지 구매가 가능하니, 하루종일 켜놓고 400개가 사져있으면 40,000아덴 버는거에요.

단편적인 예시를 보여 드린것이고, 이러한 아이템들이 여러개 있습니다.

그렇게 전 벌었습니다.` },
      { type: 'image', src: gameImages[5], alt: '수익 인증' },
      { type: 'text', content: `총 31만 아덴! 본전은 이미 뽑았습니다!
일단 본전은 완료 했으니, 천천히 벌어볼생각입니다.

다들 도전해보세요!` },
    ] as ContentBlock[],
    likes: 892,
    dislikes: 34,
    comments: 234,
    views: 45600,
    boardId: "리니지M",
    authorId: "발악군단장",
    isVerified: true,
    createdAt: Date.now() - 600000,
  },
  {
    id: 3,
    avatar: "💰",
    avatarBg: "linear-gradient(135deg,#10B981,#059669)",
    name: "김쌀먹",
    badge: "쌀먹러",
    meta: "30분 전 · 메이플스토리",
    title: "이번 주 메이플 쌀먹 수익 인증 💵",
    body: "메이플로 이번 주 3만원 벌었습니다! 꾸준히 하니까 되네요 ㅎㅎ",
    likes: 234,
    dislikes: 8,
    comments: 56,
    views: 8900,
    boardId: "메이플스토리",
    authorId: "김쌀먹",
    isVerified: true,
    createdAt: Date.now() - 1800000,
    images: [gameImages[3]],
  },
  {
    id: 4,
    avatar: "🎮",
    avatarBg: "linear-gradient(135deg,#6366F1,#4F46E5)",
    name: "게임마스터",
    badge: "인기 크리에이터",
    meta: "1시간 전 · 메이플스토리",
    title: "신규 보스 공략법 총정리 📋 (패턴분석 + 추천직업 + 필수템)",
    body: [
      { type: 'text', content: `이번 업데이트로 추가된 신규 보스의 패턴과 공략법을 정리했습니다.

📌 1단계 패턴
- 기본 공격: 전방 3연타 (회피 가능)
- 특수 공격: 전체 맵 장판 (점프로 회피)
- 분노 패턴: HP 70% 이하 시 발동` },
      { type: 'image', src: gameImages[1], alt: '1단계 패턴' },
      { type: 'text', content: `📌 2단계 패턴  
- 분신 소환: 4방향에서 동시 공격
- 즉사기: 바닥 빨간색 표시 후 3초 뒤 발동
- 회복 차단: 30초간 포션 사용 불가` },
      { type: 'image', src: gameImages[2], alt: '2단계 패턴' },
      { type: 'text', content: `📌 추천 직업
1. 아크메이지(썬,콜) - 원거리 딜링 유리
2. 나이트로드 - 회피기 다수 보유
3. 팔라딘 - 파티 생존기 제공

📌 필수 준비물
- 명예의 훈장 (생존률 상승)
- 비샵 버프 (필수)
- 길드 스킬 활성화` },
      { type: 'image', src: gameImages[5], alt: '추천 세팅' },
      { type: 'text', content: `📌 예상 드랍템
- 보스 결정석 (개당 3천만)
- 전용 장비 설계도
- 칭호 아이템

다들 화이팅하세요! 질문은 댓글로 남겨주세요 🙌` },
    ] as ContentBlock[],
    likes: 567,
    dislikes: 15,
    comments: 142,
    views: 32450,
    boardId: "메이플스토리",
    authorId: "게임마스터",
    isVerified: false,
    createdAt: Date.now() - 3600000,
  },
  {
    id: 5,
    avatar: "🍁",
    avatarBg: "#FFE4B5",
    name: "초보메이플러",
    meta: "1시간 전 · 메이플스토리",
    title: "뉴비인데 직업 추천 좀요...",
    body: "메이플 처음 시작하는데 어떤 직업이 좋을까요? 쌀먹하기 좋은 직업 추천해주세요!",
    likes: 12,
    dislikes: 2,
    comments: 45,
    views: 890,
    boardId: "메이플스토리",
    isVerified: false,
    createdAt: Date.now() - 3600000,
  },
  {
    id: 6,
    avatar: "⚔️",
    avatarBg: "linear-gradient(135deg,#8B5CF6,#7C3AED)",
    name: "리니지황제",
    badge: "정보통",
    meta: "15분 전 · 리니지M",
    title: "드디어 +20 무기 성공!! 🗡️",
    body: "50번 만에 드디어 성공했습니다... 손이 떨리네요",
    likes: 567,
    dislikes: 23,
    comments: 123,
    views: 28900,
    boardId: "리니지M",
    isVerified: true,
    createdAt: Date.now() - 900000,
    images: [gameImages[4]],
  },
  {
    id: 7,
    avatar: "🏰",
    avatarBg: "linear-gradient(135deg,#EC4899,#DB2777)",
    name: "혈맹장",
    meta: "2시간 전 · 리니지M",
    title: "혈맹원 모집합니다 (상위 10위권)",
    body: "저희 혈맹에서 활동적인 혈맹원을 모집합니다. 레벨 85 이상, 전투력 500만 이상",
    likes: 34,
    dislikes: 5,
    comments: 67,
    views: 2340,
    boardId: "리니지M",
    isVerified: false,
    createdAt: Date.now() - 7200000,
  },
  {
    id: 8,
    avatar: "🏰",
    avatarBg: "linear-gradient(135deg,#F43F5E,#E11D48)",
    name: "로아장인",
    badge: "쌀먹 장인",
    meta: "20분 전 · 로스트아크",
    title: "카멘 하드 버스 후기 🔥",
    body: [
      { type: 'text', content: `드디어 카멘 하드 클리어했습니다! 4관문 진짜 어렵네요... 버스비 아깝지 않았음

오늘 드디어 카멘하드 4관문 클리어 했습니다.
3관문까지는 어찌저찌 했는데 4관문에서 계속 막히더라구요.` },
      { type: 'image', src: gameImages[5], alt: '클리어 화면' },
      { type: 'text', content: `결국 버스 태워서 클리어했는데 버스비 15만골드 들었어요.
근데 드랍이 대박...! 카멘의 창이 떴습니다 ㄷㄷ` },
      { type: 'image', src: gameImages[6], alt: '드랍 아이템' },
      { type: 'text', content: `4관문 팁 드리자면:
1. 검은 구슬 패턴때 무조건 뒤로 빠지세요
2. 칼 휘두르기는 왼쪽으로 피하면 됩니다
3. 궁극기 쓸때 무적기 아끼세요

다음 주에는 직접 트라이 해볼 예정입니다!` },
    ] as ContentBlock[],
    likes: 423,
    dislikes: 15,
    comments: 87,
    views: 19200,
    boardId: "로스트아크",
    authorId: "로아장인",
    isVerified: true,
    createdAt: Date.now() - 1200000,
  },
  {
    id: 9,
    avatar: "⚡",
    avatarBg: "linear-gradient(135deg,#FBBF24,#F59E0B)",
    name: "슬레이어장인",
    meta: "45분 전 · 로스트아크",
    title: "슬레이어 세팅 질문이요",
    body: "슬레이어 1620인데 세팅 어떻게 하면 좋을까요? 특성 비율이랑 각인 추천해주세요",
    likes: 28,
    dislikes: 3,
    comments: 34,
    views: 1560,
    boardId: "로스트아크",
    isVerified: false,
    createdAt: Date.now() - 2700000,
  },
  {
    id: 10,
    avatar: "🎯",
    avatarBg: "linear-gradient(135deg,#EF4444,#DC2626)",
    name: "발로마스터",
    badge: "핵인싸",
    meta: "5분 전 · 발로란트",
    title: "레디언트 달성 후기 ✨",
    body: [
      { type: 'text', content: `솔로큐로 레디언트 찍었습니다! 팁 공유할게요.

🎯 에임보다 포지셔닝이 중요해요
많은 분들이 에임 연습에만 집중하시는데, 사실 다이아 이상부터는 포지셔닝이 더 중요합니다.` },
      { type: 'image', src: gameImages[8], alt: '레디언트 달성' },
      { type: 'text', content: `📍 추천 포지션
- 어택커: 엔트리 프래거 or 세컨 엔트리
- 디펜더: 앵커 or 로테이터

🔫 무기 선택
- 밴달 vs 팬텀은 개인 취향
- 저는 밴달 추천 (원탭 가능)

💡 멘탈 관리
- 지면 쉬고 다음 판
- 팀원 탓 금지
- 항상 긍정적으로

화이팅하세요! 질문 있으면 댓글로~` },
    ] as ContentBlock[],
    likes: 678,
    dislikes: 34,
    comments: 156,
    views: 34500,
    boardId: "발로란트",
    authorId: "발로마스터",
    isVerified: true,
    createdAt: Date.now() - 300000,
  },
  {
    id: 11,
    avatar: "🔫",
    avatarBg: "linear-gradient(135deg,#8B5CF6,#6D28D9)",
    name: "제트원트릭",
    meta: "1시간 전 · 발로란트",
    title: "제트 너프 언제 풀리나요...",
    body: "제트 원트릭인데 너프 이후로 너무 힘드네요 ㅠㅠ 다른 요원 추천해주세요",
    likes: 89,
    dislikes: 12,
    comments: 78,
    views: 4560,
    boardId: "발로란트",
    isVerified: false,
    createdAt: Date.now() - 3600000,
  },
  {
    id: 12,
    avatar: "🚗",
    avatarBg: "linear-gradient(135deg,#3B82F6,#2563EB)",
    name: "카트신",
    badge: "갤주민",
    meta: "25분 전 · 카트라이더",
    title: "신맵 무한부스터 루트 공개 🏎️",
    body: "새로 나온 맵 최적 루트 찾았습니다! 영상으로 정리해봤어요",
    likes: 234,
    dislikes: 8,
    comments: 45,
    views: 8900,
    boardId: "카트라이더",
    authorId: "카트신",
    isVerified: true,
    createdAt: Date.now() - 1500000,
    images: [gameImages[9], gameImages[0]],
  },
  {
    id: 13,
    avatar: "🏁",
    avatarBg: "linear-gradient(135deg,#10B981,#059669)",
    name: "드리프트킹",
    meta: "3시간 전 · 카트라이더",
    title: "드리프트 잘하는 법 알려드림",
    body: "드리프트 타이밍이랑 부스터 연계하는 방법 설명해드릴게요. 초보분들 필독!",
    likes: 156,
    dislikes: 4,
    comments: 67,
    views: 5670,
    boardId: "카트라이더",
    isVerified: false,
    createdAt: Date.now() - 10800000,
  },
  {
    id: 14,
    avatar: "⚡",
    avatarBg: "linear-gradient(135deg,#FBBF24,#D97706)",
    name: "Pokemon마스터",
    badge: "수다쟁이",
    meta: "40분 전 · 포켓몬고",
    title: "뮤츠 레이드 100% 잡았다!! ⚡",
    body: "드디어 100% 뮤츠 겟! 레이드 50번 만에 나왔네요 ㅠㅠ",
    likes: 345,
    dislikes: 18,
    comments: 89,
    views: 12340,
    boardId: "포켓몬고",
    authorId: "Pokemon마스터",
    isVerified: true,
    createdAt: Date.now() - 2400000,
    images: [gameImages[1]],
  },
  {
    id: 15,
    avatar: "🎒",
    avatarBg: "linear-gradient(135deg,#EC4899,#BE185D)",
    name: "Pokemon트레이너",
    meta: "2시간 전 · 포켓몬고",
    title: "이번 커뮤니티데이 뭐 나오나요?",
    body: "다음 커뮤니티데이 정보 아시는 분? 색이 포켓몬 뭐가 나올까요",
    likes: 45,
    dislikes: 2,
    comments: 34,
    views: 2340,
    boardId: "포켓몬고",
    isVerified: false,
    createdAt: Date.now() - 7200000,
  },
  {
    id: 16,
    avatar: "💎",
    avatarBg: "linear-gradient(135deg,#06B6D4,#0891B2)",
    name: "김쌀먹",
    badge: "쌀먹러",
    meta: "1시간 전 · 리니지M",
    title: "리니지M 월 수익 200만원 달성 💰",
    body: [
      { type: 'text', content: `드디어 리니지로 월 200 찍었습니다! 비결은 꾸준함과 시세 분석이에요.

💰 수익 구조
1. 아이템 거래: 120만원
2. 보스 드랍: 50만원  
3. 재료 파밍: 30만원` },
      { type: 'image', src: gameImages[2], alt: '수익 내역' },
      { type: 'text', content: `📊 시세 분석 팁
- 매일 아침 9시에 시세 체크
- 주말에 가격 변동 큼
- 업데이트 전후 주목` },
      { type: 'image', src: gameImages[3], alt: '시세 분석' },
      { type: 'text', content: `⏰ 플레이 시간
- 평일: 2시간
- 주말: 4시간

꾸준히 하면 누구나 가능합니다!` },
    ] as ContentBlock[],
    likes: 892,
    dislikes: 45,
    comments: 234,
    views: 45600,
    boardId: "리니지M",
    authorId: "김쌀먹",
    isVerified: true,
    createdAt: Date.now() - 3600000,
  },
  {
    id: 17,
    avatar: "🎮",
    avatarBg: "linear-gradient(135deg,#A855F7,#9333EA)",
    name: "게임마스터",
    badge: "인기 크리에이터",
    meta: "35분 전 · 로스트아크",
    title: "이번 주 쌀먹 효율 TOP5 컨텐츠",
    body: "이번 주 골드 효율 좋은 컨텐츠 정리했습니다. 카오스던전 > 가디언토벌 > 어비스던전 순이에요",
    likes: 567,
    dislikes: 23,
    comments: 123,
    views: 23400,
    boardId: "로스트아크",
    authorId: "게임마스터",
    isVerified: false,
    createdAt: Date.now() - 2100000,
    images: [gameImages[4]],
  },
  {
    id: 18,
    avatar: "🌟",
    avatarBg: "linear-gradient(135deg,#F472B6,#EC4899)",
    name: "럭키걸",
    badge: "행운아",
    meta: "50분 전 · 메이플스토리",
    title: "큐브 1방에 레전드리 뜸 ㄷㄷ",
    body: "진짜 운 다 쓴 것 같아요... 레드큐브 1방에 레전 22% 떴습니다",
    likes: 234,
    dislikes: 56,
    comments: 89,
    views: 8900,
    boardId: "메이플스토리",
    isVerified: true,
    createdAt: Date.now() - 3000000,
    images: [gameImages[5]],
  },
  {
    id: 19,
    avatar: "🔥",
    avatarBg: "linear-gradient(135deg,#F97316,#EA580C)",
    name: "불족발",
    meta: "4시간 전 · 발로란트",
    title: "실버에서 골드 가는 법",
    body: "실버 탈출 못하시는 분들 보세요! 맵 이해도랑 스모크 활용만 잘해도 골드 가능합니다",
    likes: 123,
    dislikes: 8,
    comments: 56,
    views: 4560,
    boardId: "발로란트",
    isVerified: false,
    createdAt: Date.now() - 14400000,
  },
  {
    id: 20,
    avatar: "👑",
    avatarBg: "linear-gradient(135deg,#EAB308,#CA8A04)",
    name: "메이플고수",
    badge: "시세분석가",
    meta: "2시간 전 · 메이플스토리",
    title: "보스 결정석 시세 분석 📊",
    body: "이번 달 보스 결정석 시세 추이 분석해봤습니다. 다음 주에 오를 것 같아요",
    likes: 345,
    dislikes: 12,
    comments: 78,
    views: 12300,
    boardId: "메이플스토리",
    authorId: "메이플고수",
    isVerified: true,
    createdAt: Date.now() - 7200000,
    images: [gameImages[6], gameImages[7], gameImages[8], gameImages[9]],
  },
  {
    id: 21,
    avatar: "🎁",
    avatarBg: "linear-gradient(135deg,#14B8A6,#0D9488)",
    name: "이벤트헌터",
    meta: "30분 전 · 메이플스토리",
    title: "이번 주 꿀이벤트 정리 🍯",
    body: "놓치면 안되는 이벤트들 정리했어요! 출석체크 보상이 특히 좋습니다",
    likes: 189,
    dislikes: 5,
    comments: 45,
    views: 6780,
    boardId: "메이플스토리",
    isVerified: false,
    createdAt: Date.now() - 1800000,
  },
  // ─── 🔥 지금 핫한 게시글 ───
  {
    id: 22,
    avatar: "🔥",
    avatarBg: "linear-gradient(135deg,#EF4444,#B91C1C)",
    name: "속보맨",
    badge: "속보러",
    meta: "방금 전 · 메이플스토리",
    title: "[속보] 메이플 서버 긴급점검 보상 역대급으로 풀림 ㄷㄷ",
    body: "방금 공지 떴는데 레전큐브 10개 + 메소 10억 준다고 함 ㅋㅋㅋ 넥슨 실화냐",
    likes: 2341,
    dislikes: 23,
    comments: 567,
    views: 89000,
    boardId: "메이플스토리",
    authorId: "속보맨",
    isVerified: true,
    createdAt: Date.now() - 60000,
  },
  {
    id: 23,
    avatar: "💸",
    avatarBg: "linear-gradient(135deg,#10B981,#047857)",
    name: "쌀먹킹",
    badge: "쌀먹 달인",
    meta: "3분 전 · 리니지M",
    title: "ㅁㅊ 오늘 하루만에 50만원 벌었다 실화임",
    body: [
      { type: 'text', content: `아니 진짜 믿기지가 않는데 오늘 대박남

서버 합병 이슈로 템 시세가 폭등했는데 미리 사둔거 다 팔았음` },
      { type: 'image', src: gameImages[2], alt: '거래 내역' },
      { type: 'text', content: `2주 전에 싸게 매집해둔 재료템들 오늘 전부 처분

매입가 대비 3배 이상 올랐음 ㄹㅇ 개이득

이래서 정보력이 중요한거임...` },
    ] as ContentBlock[],
    likes: 3456,
    dislikes: 89,
    comments: 892,
    views: 156000,
    boardId: "리니지M",
    authorId: "쌀먹킹",
    isVerified: true,
    createdAt: Date.now() - 180000,
  },
  {
    id: 24,
    avatar: "😱",
    avatarBg: "linear-gradient(135deg,#8B5CF6,#6D28D9)",
    name: "로아러",
    meta: "7분 전 · 로스트아크",
    title: "에키드나 레이드 세계 최초 클리어 떴다!!!",
    body: "방금 한국 길드에서 에키드나 하드 세계 최초 클리어함 ㄷㄷㄷ 트위치 난리남",
    likes: 4521,
    dislikes: 34,
    comments: 1234,
    views: 234000,
    boardId: "로스트아크",
    isVerified: false,
    createdAt: Date.now() - 420000,
    images: [gameImages[5]],
  },
  {
    id: 25,
    avatar: "🎮",
    avatarBg: "linear-gradient(135deg,#F59E0B,#D97706)",
    name: "겜알못",
    meta: "12분 전 · 발로란트",
    title: "T1 발로 우승했다!!! 🏆🏆🏆",
    body: "결승전 3:0 클린 스윕 ㅋㅋㅋㅋ 페이커 만큼 대단한거 아님?? 축하합니다!!",
    likes: 8923,
    dislikes: 156,
    comments: 2341,
    views: 456000,
    boardId: "발로란트",
    isVerified: false,
    createdAt: Date.now() - 720000,
  },
  {
    id: 26,
    avatar: "💀",
    avatarBg: "linear-gradient(135deg,#1F2937,#111827)",
    name: "버그헌터",
    badge: "제보러",
    meta: "15분 전 · 메이플스토리",
    title: "[긴급] 무한 메소 버그 발견됨 지금 바로 막힐듯",
    body: "특정 퀘스트 반복하면 메소 무한 복사되는 버그 있음. 악용하지 말고 신고하세요. 곧 롤백 예상",
    likes: 5678,
    dislikes: 234,
    comments: 1567,
    views: 345000,
    boardId: "메이플스토리",
    authorId: "버그헌터",
    isVerified: true,
    createdAt: Date.now() - 900000,
  },
  {
    id: 27,
    avatar: "🤯",
    avatarBg: "linear-gradient(135deg,#EC4899,#BE185D)",
    name: "카트매니아",
    badge: "게임덕후",
    meta: "20분 전 · 카트라이더",
    title: "신캐릭터 스킬 개사기임 ㄹㅇ 너프 1순위",
    body: [
      { type: 'text', content: `방금 신캐 뽑아서 써봤는데 이건 좀 아닌듯...

부스터 지속시간 2배 + 쿨감 50%?? 

경쟁전 다 이거임 ㅋㅋ` },
      { type: 'image', src: gameImages[9], alt: '신캐릭터' },
      { type: 'text', content: `솔직히 재밌긴 한데 밸런스 붕괴 수준

다음 패치에 무조건 너프될듯

지금 뽑아서 경쟁전 점수 올리셈 ㄹㅇ` },
    ] as ContentBlock[],
    likes: 2134,
    dislikes: 456,
    comments: 678,
    views: 87000,
    boardId: "카트라이더",
    authorId: "카트매니아",
    isVerified: true,
    createdAt: Date.now() - 1200000,
  },
  {
    id: 28,
    avatar: "📢",
    avatarBg: "linear-gradient(135deg,#3B82F6,#1D4ED8)",
    name: "공식계정",
    badge: "공식",
    meta: "25분 전 · 리니지M",
    title: "[공지] 서버 합병 일정 안내 - 3월 1일 예정",
    body: "안녕하세요. 3월 1일 서버 합병이 진행됩니다. 자세한 보상 내역은 본문 확인 바랍니다.",
    likes: 1234,
    dislikes: 567,
    comments: 2345,
    views: 178000,
    boardId: "리니지M",
    authorId: "공식계정",
    isVerified: true,
    createdAt: Date.now() - 1500000,
  },
  {
    id: 29,
    avatar: "😭",
    avatarBg: "linear-gradient(135deg,#6366F1,#4338CA)",
    name: "울보게이머",
    meta: "32분 전 · 로스트아크",
    title: "강화 17→18 실패 23연속 중입니다 위로해주세요",
    body: "골드 300만 날렸어요... 확률 조작 아니냐고요 ㅠㅠㅠㅠㅠ 17강이 제일 어려움",
    likes: 3421,
    dislikes: 45,
    comments: 892,
    views: 67000,
    boardId: "로스트아크",
    isVerified: false,
    createdAt: Date.now() - 1920000,
    images: [gameImages[4]],
  },
  {
    id: 30,
    avatar: "🐣",
    avatarBg: "linear-gradient(135deg,#FBBF24,#D97706)",
    name: "Pokemon트레이너",
    badge: "포켓몬덕후",
    meta: "40분 전 · 포켓몬고",
    title: "색이 뮤츠 드디어 잡음!!!! 1/450 확률 뚫음",
    body: [
      { type: 'text', content: `ㅁㅊ ㅁㅊ ㅁㅊ ㅁㅊ ㅁㅊ

레이드 450번만에 드디어 색이 뮤츠 나옴 ㅠㅠㅠㅠ

손 떨려서 캡쳐 3번 놓침 ㅋㅋㅋㅋ` },
      { type: 'image', src: gameImages[1], alt: '색이 뮤츠' },
      { type: 'text', content: `IV도 96%라 거의 완벽함

인생 운 다 쓴듯... 오늘 집 안나감` },
    ] as ContentBlock[],
    likes: 5678,
    dislikes: 123,
    comments: 1234,
    views: 234000,
    boardId: "포켓몬고",
    authorId: "Pokemon트레이너",
    isVerified: true,
    createdAt: Date.now() - 2400000,
  },
  {
    id: 31,
    avatar: "🎯",
    avatarBg: "linear-gradient(135deg,#EF4444,#B91C1C)",
    name: "에임신",
    badge: "FPS 고수",
    meta: "55분 전 · 발로란트",
    title: "1v5 클러치 에이스 했는데 떨려서 녹화 못함",
    body: "레디언트 경쟁전에서 1v5 에이스 했는데 너무 떨려서 녹화를 안 눌렀어요... 인생샷 날림 ㅠㅠ",
    likes: 2345,
    dislikes: 67,
    comments: 456,
    views: 45000,
    boardId: "발로란트",
    authorId: "에임신",
    isVerified: true,
    createdAt: Date.now() - 3300000,
  },
  // ─── 💰 생활테크 갤러리 게시글 ───
  {
    id: 101,
    avatar: "💰",
    avatarBg: "linear-gradient(135deg,#10B981,#059669)",
    name: "앱테크마스터",
    badge: "앱테크 고수",
    meta: "5분 전 · 생활테크",
    title: "[네이버페이] 오늘의 퀴즈 정답 공유 🎯",
    body: `오늘 네이버페이 퀴즈 정답입니다!

Q. 네이버페이 포인트 적립 최대 혜택은?
A. 최대 5%

빠르게 참여하세요! 선착순 마감됩니다.`,
    likes: 342,
    dislikes: 5,
    comments: 89,
    views: 15420,
    boardId: "생활테크",
    authorId: "앱테크마스터",
    isVerified: true,
    createdAt: Date.now() - 300000,
  },
  {
    id: 102,
    avatar: "🎁",
    avatarBg: "linear-gradient(135deg,#8B5CF6,#7C3AED)",
    name: "이벤트헌터",
    badge: "이벤트 사냥꾼",
    meta: "12분 전 · 생활테크",
    title: "[한국지식재산보호원] 특허 상식 퀴즈 이벤트 🏆",
    body: `특허청 주관 퀴즈 이벤트 참여하세요!

📅 기간: ~3월 31일
🎁 경품: 스타벅스 기프티콘 500명

정답: 특허권 존속기간은 출원일로부터 20년`,
    likes: 234,
    dislikes: 8,
    comments: 56,
    views: 8900,
    boardId: "생활테크",
    authorId: "이벤트헌터",
    isVerified: true,
    createdAt: Date.now() - 720000,
  },
  {
    id: 103,
    avatar: "📱",
    avatarBg: "linear-gradient(135deg,#3B82F6,#2563EB)",
    name: "포인트왕",
    badge: "쌀먹러",
    meta: "25분 전 · 생활테크",
    title: "[국가보훈처] 온라인 채널 반짝퀴즈 참여 후기",
    body: `국가보훈처 퀴즈 다들 참여하셨나요?

정답 맞추면 바로 포인트 지급됩니다!
저는 500P 받았어요 ㅎㅎ

꿀팁: 검색하면 바로 나옴`,
    likes: 189,
    dislikes: 12,
    comments: 45,
    views: 6780,
    boardId: "생활테크",
    authorId: "포인트왕",
    isVerified: false,
    createdAt: Date.now() - 1500000,
  },
  {
    id: 104,
    avatar: "🎨",
    avatarBg: "linear-gradient(135deg,#EC4899,#DB2777)",
    name: "문화덕후",
    badge: "문화인",
    meta: "38분 전 · 생활테크",
    title: "[한국문화영상진흥원] 넌센텅의 색, 미(美) OX퀴즈",
    body: `문화진흥원 퀴즈 정답 공유합니다!

1번: O
2번: X  
3번: O

전원 당첨이라 꼭 참여하세요!`,
    likes: 156,
    dislikes: 3,
    comments: 34,
    views: 4560,
    boardId: "생활테크",
    authorId: "문화덕후",
    isVerified: true,
    createdAt: Date.now() - 2280000,
  },
  {
    id: 105,
    avatar: "🎄",
    avatarBg: "linear-gradient(135deg,#EF4444,#DC2626)",
    name: "퀴즈마스터",
    badge: "퀴즈왕",
    meta: "52분 전 · 생활테크",
    title: "[군인공제회] 크리스마스 꿀팁 OX퀴즈 정답",
    body: `군인공제회 이벤트 정답입니다~

Q1. 군인공제회 설립연도는 1984년이다 → O
Q2. 적금 최대 금리는 5%이다 → X (4.5%)

경품: BBQ 치킨 세트 100명`,
    likes: 278,
    dislikes: 15,
    comments: 67,
    views: 9800,
    boardId: "생활테크",
    authorId: "퀴즈마스터",
    isVerified: true,
    createdAt: Date.now() - 3120000,
  },
  {
    id: 106,
    avatar: "💳",
    avatarBg: "linear-gradient(135deg,#F59E0B,#D97706)",
    name: "카드고수",
    badge: "금융전문가",
    meta: "1시간 전 · 생활테크",
    title: "3월 신용카드 캐시백 이벤트 총정리 💳",
    body: [
      { type: 'text', content: `3월 카드사별 캐시백 정리했어요!

📌 삼성카드: 생활비 5만원 이상 시 5천원
📌 신한카드: 첫 이용 시 1만원
📌 KB국민: 적립금 2배 이벤트
📌 현대카드: M포인트 10% 추가` },
      { type: 'image', src: gameImages[2], alt: '카드 이벤트' },
      { type: 'text', content: `신규 발급자 혜택이 가장 좋으니 참고하세요!

저는 이번 달에 3장 발급받아서 캐시백만 5만원 받음 ㅎㅎ` },
    ] as ContentBlock[],
    likes: 567,
    dislikes: 23,
    comments: 142,
    views: 23400,
    boardId: "생활테크",
    authorId: "카드고수",
    isVerified: true,
    createdAt: Date.now() - 3600000,
  },
  {
    id: 107,
    avatar: "🛒",
    avatarBg: "linear-gradient(135deg,#14B8A6,#0D9488)",
    name: "쿠폰수집가",
    badge: "할인왕",
    meta: "1시간 전 · 생활테크",
    title: "편의점 1+1 행사 정보 (GS/CU/세븐) 🏪",
    body: `이번 주 편의점 1+1 정리!

🟢 GS25
- 빙그레 바나나맛우유
- 농심 새우깡

🟠 CU
- 코카콜라 500ml
- 해태 에이스

🔵 세븐일레븐
- 델몬트 주스
- 롯데 빼빼로

직접 돌아다니며 확인한거라 정확합니다!`,
    likes: 423,
    dislikes: 8,
    comments: 98,
    views: 18700,
    boardId: "생활테크",
    authorId: "쿠폰수집가",
    isVerified: false,
    createdAt: Date.now() - 4200000,
  },
  {
    id: 108,
    avatar: "📊",
    avatarBg: "linear-gradient(135deg,#6366F1,#4F46E5)",
    name: "설문왕",
    badge: "설문 고수",
    meta: "2시간 전 · 생활테크",
    title: "이번 주 고수익 설문조사 리스트 📝",
    body: [
      { type: 'text', content: `고수익 설문 정리했습니다!

1️⃣ 패널나우 - 3000P (10분)
2️⃣ 엠브레인 - 2500P (15분)
3️⃣ 틸리언패널 - 2000P (8분)
4️⃣ 한국리서치 - 3500P (20분)` },
      { type: 'image', src: gameImages[3], alt: '설문 목록' },
      { type: 'text', content: `저는 이번 주에 설문만으로 2만원 벌었어요!

꿀팁: 아침 9시에 새 설문 많이 올라옴` },
    ] as ContentBlock[],
    likes: 892,
    dislikes: 34,
    comments: 234,
    views: 45600,
    boardId: "생활테크",
    authorId: "설문왕",
    isVerified: true,
    createdAt: Date.now() - 7200000,
  },
  {
    id: 109,
    avatar: "🎯",
    avatarBg: "linear-gradient(135deg,#A855F7,#9333EA)",
    name: "앱테크초보",
    meta: "3시간 전 · 생활테크",
    title: "앱테크 시작하려는데 추천 앱 있나요?",
    body: `앱테크 처음인데 어떤 앱으로 시작하면 좋을까요?

많이들 하시는거 추천해주세요!
하루에 얼마나 벌 수 있는지도 궁금합니다.`,
    likes: 45,
    dislikes: 2,
    comments: 89,
    views: 2340,
    boardId: "생활테크",
    authorId: "앱테크초보",
    isVerified: false,
    createdAt: Date.now() - 10800000,
  },
  {
    id: 110,
    avatar: "🏆",
    avatarBg: "linear-gradient(135deg,#FBBF24,#D97706)",
    name: "쌀먹달인",
    badge: "명예의 전당",
    meta: "4시간 전 · 생활테크",
    title: "【종합】 2024년 3월 앱테크 수익 인증 💵",
    body: [
      { type: 'text', content: `3월 앱테크 수익 인증합니다!

📱 토스: 32,000원
📱 캐시슬라이드: 15,000원
📱 리브메이트: 8,000원
📱 OK캐쉬백: 12,000원
📱 네이버페이: 25,000원

총 92,000원!` },
      { type: 'image', src: gameImages[5], alt: '수익 인증' },
      { type: 'text', content: `꾸준히 하면 한달에 10만원은 거뜬히 벌어요

초보분들 질문 받습니다~` },
    ] as ContentBlock[],
    likes: 1234,
    dislikes: 56,
    comments: 345,
    views: 67800,
    boardId: "생활테크",
    authorId: "쌀먹달인",
    isVerified: true,
    createdAt: Date.now() - 14400000,
  },
];