import { useState } from "react";
import type { ListItemData } from "./types";
import DropdownMenu, { getPostMenuItems } from "./DropdownMenu";

// ─── 목록형 아이템 ───

interface ListItemProps {
  item: ListItemData;
}

export default function ListItem({ item }: ListItemProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div
      className="flex items-center gap-3 p-4 border border-gray-200 rounded-xl mb-2 cursor-pointer hover:bg-gray-50 hover:border-gray-400 transition-colors bg-white relative"
      style={{ zIndex: isMenuOpen ? 30 : 1 }}
    >
      {/* 아바타 */}
      <div
        className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white shrink-0"
        style={{ background: item.avatarBg }}
      >
        {item.avatar}
      </div>

      {/* 본문 */}
      <div className="flex-1 min-w-0">
        <div className="text-[15px] font-semibold truncate flex items-center gap-1.5">
          {item.title}
          {item.hasImage && <span className="text-gray-400">🖼</span>}
          <span className="text-[#4AABF5] font-bold">
            [{item.commentCount}]
          </span>
        </div>
        <div className="flex items-center gap-2 text-[12px] text-gray-400 mt-0.5 flex-wrap">
          <span>{item.author}</span>
          <span className="px-2 py-0.5 bg-gray-100 rounded-full font-semibold">
            {item.tag}
          </span>
          <span>{item.time}</span>
          <span>👁 {item.views}</span>
          <span>♡ {item.likes}</span>
          <span className="opacity-35">🎁</span>
        </div>
      </div>

      {/* 더보기 메뉴 - onOpenChange로 카드 zIndex 조절 */}
      <DropdownMenu
        size="md"
        stopPropagation={true}
        zIndex={50}
        onOpenChange={setIsMenuOpen}
        items={getPostMenuItems({
          onShare: () => console.log("공유"),
          onSave: () => console.log("저장"),
          onBlock: () => console.log("차단"),
          onReport: () => console.log("신고"),
        })}
      />
    </div>
  );
}
