import { useState } from "react";
import GalleryCard from "./GalleryCard";
import type { GalleryItemData } from "./types";

const animationStyles = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
`;

interface RecentVisitContentProps {
  onSelectGallery?: (gallery: GalleryItemData) => void;
}

export default function RecentVisitContent({
  onSelectGallery,
}: RecentVisitContentProps) {
  // 최근 방문한 갤러리 (실제로는 로컬스토리지 or 상태관리에서 가져옴)
  const recentItems: GalleryItemData[] = [
    {
      id: 7,
      icon: "🎮",
      name: "메이플스토리",
      desc: "메이플 유저들의 커뮤니티",
      color: "bg-amber-100 text-amber-600",
    },
    {
      id: 8,
      icon: "⚔️",
      name: "리니지M",
      desc: "리니지M 정보 공유",
      color: "bg-purple-100 text-purple-600",
    },
    {
      id: 3,
      icon: "B",
      name: "비트코인",
      desc: "암호화폐라는 혁신적인 세계!",
      color: "bg-blue-100 text-blue-600",
    },
  ];

  const [followedGalleries, setFollowedGalleries] = useState<number[]>([]);

  const toggleFollow = (id: number) => {
    setFollowedGalleries((prev) =>
      prev.includes(id) ? prev.filter((gid) => gid !== id) : [...prev, id],
    );
  };

  return (
    <>
      <style>{animationStyles}</style>

      <div className="py-5">
        <h2 className="text-[18px] font-extrabold text-[#1A1A2E] py-4">
          최근 방문한 갤러리
        </h2>

        {recentItems.length > 0 ? (
          <div className="grid grid-cols-3 gap-3">
            {recentItems.map((item, index) => (
              <div
                key={item.id}
                className="animate-fadeUp cursor-pointer"
                style={{ animationDelay: `${index * 50}ms` }}
                onClick={() => onSelectGallery?.(item)}
              >
                <GalleryCard
                  item={item}
                  isFollowed={followedGalleries.includes(item.id)}
                  onToggleFollow={() => toggleFollow(item.id)}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="py-20 text-center">
            <p className="text-5xl mb-4">🕐</p>
            <p className="text-[16px] font-semibold text-gray-500 mb-2">
              최근 방문한 갤러리가 없어요
            </p>
            <p className="text-[14px] text-gray-400">갤러리를 둘러보세요!</p>
          </div>
        )}
      </div>
    </>
  );
}
