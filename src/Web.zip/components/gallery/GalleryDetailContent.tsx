import { useState, useRef, useEffect, useCallback, Fragment } from "react";
import { Star } from "lucide-react";
import type {
  PostData,
  Comment,
  Reply,
  ReplyTarget,
  ContentBlock,
  GalleryItemData,
} from "./types";
import { initialComments } from "./commentsData";
import { initialPosts } from "./postsData";
import PostCardFull from "./PostCardFull";
import PostListItem from "./PostListItem";
import PostDetail from "./PostDetail";
import Pagination from "./Pagination";
import GiftPopup from "./GiftPopup";
import ProfilePopup from "./ProfilePopup";
import WritePostModal from "./WritePostModal";
import GalleryManagementPopup from "./GalleryManagementPopup";
import AdCard from "./AdCard";
import AdListItem from "./AdListItem";
import { useToast } from "./Toast";

// ─── 애니메이션 스타일 ───
const animationStyles = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes highlight {
    0%, 100% { background-color: transparent; }
    50% { background-color: #FEF3C7; }
  }
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
  .animate-highlight { animation: highlight 1s ease-in-out; }
`;

// ─── 광고 데이터 ───
const cardAd = {
  id: "ad-card-1",
  avatar: "🇺🇸",
  avatarBg: "#E5E7EB",
  name: "히어로 키우기",
  time: "27분",
  media: {
    type: "video" as const,
    src: "https://example.com/ad-video.mp4",
    thumbnail: "https://picsum.photos/800/450?random=ad1",
  },
  title: "히어로 키우기",
  link: "https://example.com",
};

const listAd = {
  id: "ad-list-1",
  thumbnail: "https://picsum.photos/100/100?random=ad2",
  name: "히어로키우기",
  description:
    "언어 학습 앱은 정답 하나만 가르쳐주지만, 인생은 그렇지 않습니다. Preply 튜터와 함께 연습을 시작하고 첫날부터 자신감을 키워보세요.",
  link: "https://example.com",
};

// ─── 본문 텍스트 추출 함수 ───
const getBodyText = (body: string | ContentBlock[]): string => {
  if (typeof body === "string") {
    return body;
  }
  return body
    .filter((block) => block.type === "text")
    .map((block) => block.content || "")
    .join(" ");
};

// ─── 서브탭 ───
const subTabs = ["인증글", "베스트", "전체글"];

// ─── 갤러리 내 카테고리 (게시글 표시용) ───
const galleryCategories = ["수다", "공략,팁", "질문", "스샷,자랑", "거래"];

// ─── 게시글 ID로 카테고리 결정 ───
const getPostCategory = (postId: number): string => {
  return galleryCategories[postId % galleryCategories.length];
};

// ─── 갤러리 주민 여부 결정 (랜덤) ───
const isPostResident = (postId: number): boolean => {
  // 대략 40% 확률로 주민 표시
  return postId % 5 < 2;
};

// ─── Props ───
interface GalleryDetailContentProps {
  gallery: GalleryItemData;
  activeCategory: string;
  onCategoryChange?: (category: string) => void;
  onBack: () => void;
  initialPostId?: number | null;
  onPostOpened?: () => void;
  onShowInterestSheet?: () => void;
  onProfileClick?: (name: string, avatar: string, avatarBg?: string) => void;
}

// ─── 갤러리 상세 헤더 ───
function GalleryHeader({
  gallery,
  isFollowed,
  isInterested,
  onToggleFollow,
  onToggleInterest,
  onShowManagement,
}: {
  gallery: GalleryItemData;
  isFollowed: boolean;
  isInterested: boolean;
  onToggleFollow: () => void;
  onToggleInterest: () => void;
  onShowManagement: () => void;
}) {
  return (
    <div className="bg-white border-b border-gray-200 animate-fadeUp">
      <div className="py-4">
        <div className="flex items-center gap-4">
          {/* 아이콘 */}
          <div
            className={`w-14 h-14 rounded-xl flex items-center justify-center text-2xl font-bold shrink-0 ${gallery.color}`}
          >
            {gallery.icon}
          </div>

          {/* 정보 */}
          <div className="flex-1 min-w-0">
            <h1 className="text-[20px] font-bold text-[#1A1A2E]">
              {gallery.name}
            </h1>
            <p
              className="text-[13px] text-gray-500 mt-1 cursor-pointer hover:text-[#72C2FF] transition-colors"
              onClick={onShowManagement}
            >
              매니저 우라마이싱 | 부매니저 김고로게, 나요티... &gt;
            </p>
            <p className="text-[13px] text-gray-400 mt-0.5">
              {gallery.description || "게임 소개를 작성해주세요."}
            </p>
          </div>

          {/* 관심 버튼 */}
          <button
            onClick={onToggleInterest}
            className={`p-2 rounded-lg transition-colors ${
              isInterested
                ? "text-[#72C2FF] bg-[#72C2FF]/10"
                : "text-gray-400 hover:text-[#72C2FF] hover:bg-gray-100"
            }`}
            title={isInterested ? "관심 해제" : "관심 등록"}
          >
            <Star size={22} fill={isInterested ? "#72C2FF" : "none"} />
          </button>

          {/* 팔로우 버튼 */}
          <button
            onClick={onToggleFollow}
            className={`px-4 py-2 text-[13px] font-bold rounded-lg transition-colors ${
              isFollowed
                ? "bg-gray-100 text-gray-500 hover:bg-gray-200"
                : "bg-[#72C2FF] text-white hover:bg-[#5BB0F0]"
            }`}
          >
            {isFollowed ? "팔로잉" : "팔로우"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── 메인 컴포넌트 ───
export default function GalleryDetailContent({
  gallery,
  activeCategory,
  // onCategoryChange,
  // onBack,
  initialPostId,
  onPostOpened,
  onShowInterestSheet,
  onProfileClick,
}: GalleryDetailContentProps) {
  const { showToast } = useToast();

  // ─── 상태 ───
  const [subTab, setSubTab] = useState("베스트");
  const [viewMode, setViewMode] = useState<"card" | "list">("card");
  const [showViewDropdown, setShowViewDropdown] = useState(false);
  const [showCountDropdown, setShowCountDropdown] = useState(false);

  // ─── 갤러리 팔로우 상태 ───
  const [isGalleryFollowed, setIsGalleryFollowed] = useState(false);

  // ─── 갤러리 관심 상태 ───
  const [isGalleryInterested, setIsGalleryInterested] = useState(false);

  // ─── 게시글 상태 ───
  const [posts, setPosts] = useState<PostData[]>(initialPosts);
  const [selectedPost, setSelectedPost] = useState<PostData | null>(null);
  const [showWriteModal, setShowWriteModal] = useState(false);

  // ─── initialPostId로 게시글 자동 선택 ───
  useEffect(() => {
    if (initialPostId) {
      const post = posts.find((p) => p.id === initialPostId);
      if (post) {
        setSelectedPost(post);
        onPostOpened?.();
      }
    }
  }, [initialPostId, posts, onPostOpened]);

  // ─── 무한스크롤 상태 (카드형) ───
  const [displayCount, setDisplayCount] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const loadMoreRef = useRef<HTMLDivElement>(null);

  // ─── 페이지네이션 상태 (목록형) ───
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(50);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [searchType, setSearchType] = useState("title");

  // 상호작용 상태
  const [likedPosts, setLikedPosts] = useState<number[]>([]);
  const [dislikedPosts, setDislikedPosts] = useState<number[]>([]);
  const [followedUsers, setFollowedUsers] = useState<string[]>(["김쌀먹"]);
  const [expandedComments, setExpandedComments] = useState<number[]>([]);

  // 댓글 상태
  const [commentInputs, setCommentInputs] = useState<{ [key: number]: string }>(
    {},
  );
  const [commentsState, setCommentsState] = useState<{
    [key: number]: Comment[];
  }>(initialComments);
  const [likedComments, setLikedComments] = useState<string[]>([]);
  const [dislikedComments, setDislikedComments] = useState<string[]>([]);
  const [replyingTo, setReplyingTo] = useState<ReplyTarget | null>(null);
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: string }>({});
  const [highlightedComment, setHighlightedComment] = useState<string | null>(
    null,
  );

  // 팝업 상태
  const [showGiftPopup, setShowGiftPopup] = useState(false);
  const [showCommentGiftPopup, setShowCommentGiftPopup] = useState<
    string | null
  >(null);
  const [selectedProfile, setSelectedProfile] = useState<PostData | null>(null);
  const [showManagementPopup, setShowManagementPopup] = useState(false);

  // Refs
  const commentRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  // boardId 매핑
  const getBoardIdFromGallery = (galleryName: string): string => {
    const mapping: { [key: string]: string } = {
      메이플스토리: "메이플스토리",
      메이플스토리M: "메이플스토리",
      리니지M: "리니지M",
      "리니지 클래식": "리니지M",
      로스트아크: "로스트아크",
      발로란트: "발로란트",
      아이온2: "메이플스토리",
    };
    return mapping[galleryName] || galleryName;
  };

  // ─── 필터링 ───
  const filteredPosts = posts
    .filter((post) => {
      const targetBoardId = getBoardIdFromGallery(gallery.name);
      // 새로 작성한 글이거나 해당 갤러리 글인 경우
      if (post.boardId !== targetBoardId && post.boardId !== gallery.name)
        return false;

      if (subTab === "인증글" && !post.isVerified) return false;
      if (
        subTab === "베스트" &&
        !(post.views >= 5000 || post.likes >= 100 || post.comments >= 50)
      )
        return false;

      if (searchKeyword) {
        const keyword = searchKeyword.toLowerCase();
        const bodyText = getBodyText(post.body);
        switch (searchType) {
          case "title":
            return post.title.toLowerCase().includes(keyword);
          case "content":
            return bodyText.toLowerCase().includes(keyword);
          case "author":
            return post.name.toLowerCase().includes(keyword);
          case "title_content":
            return (
              post.title.toLowerCase().includes(keyword) ||
              bodyText.toLowerCase().includes(keyword)
            );
          default:
            return true;
        }
      }
      return true;
    })
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  // ─── 무한스크롤 ───
  const cardPosts = filteredPosts.slice(0, displayCount);
  const hasMoreCards = displayCount < filteredPosts.length;

  const loadMore = useCallback(() => {
    if (isLoading || !hasMoreCards) return;
    setIsLoading(true);
    setTimeout(() => {
      setDisplayCount((prev) => Math.min(prev + 10, filteredPosts.length));
      setIsLoading(false);
    }, 500);
  }, [isLoading, hasMoreCards, filteredPosts.length]);

  useEffect(() => {
    if (viewMode !== "card" || selectedPost) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMoreCards && !isLoading) {
          loadMore();
        }
      },
      { threshold: 0.1 },
    );

    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current);
    }

    return () => observer.disconnect();
  }, [viewMode, hasMoreCards, isLoading, loadMore, selectedPost]);

  // 카테고리나 서브탭 변경 시 리셋
  useEffect(() => {
    setDisplayCount(10);
    setCurrentPage(1);
  }, [subTab, searchKeyword, gallery, activeCategory]);

  // ─── 페이지네이션 ───
  const totalPages = Math.max(
    1,
    Math.ceil(filteredPosts.length / itemsPerPage),
  );
  const paginatedPosts = filteredPosts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  // ─── 글쓰기 핸들러 ───
  const handleWritePost = (newPost: PostData) => {
    setPosts((prev) => [newPost, ...prev]);
    setShowWriteModal(false);
    // 새 글 작성 시 전체글 탭으로 이동
    setSubTab("전체글");
    showToast("글이 등록되었습니다");
  };

  // ─── 갤러리 팔로우 핸들러 ───
  const handleToggleGalleryFollow = () => {
    if (isGalleryFollowed) {
      showToast(`${gallery.name} 갤러리 팔로우를 취소했어요`);
    } else {
      showToast(`${gallery.name} 갤러리에 새 글이 올라오면 알려드릴게요`);
    }
    setIsGalleryFollowed(!isGalleryFollowed);
  };

  // ─── 갤러리 관심 핸들러 ───
  const handleToggleGalleryInterest = useCallback(() => {
    if (isGalleryInterested) {
      setIsGalleryInterested(false);
      showToast(`${gallery.name} 관심 해제했어요`);
    } else {
      // 관심 그룹 시트 열기 또는 바로 추가
      if (onShowInterestSheet) {
        onShowInterestSheet();
      } else {
        setIsGalleryInterested(true);
        showToast(`${gallery.name}을(를) 관심 갤러리에 추가했어요`);
      }
    }
  }, [isGalleryInterested, gallery.name, showToast, onShowInterestSheet]);

  // ─── 핸들러들 ───
  const toggleLike = (postId: number) => {
    if (dislikedPosts.includes(postId))
      setDislikedPosts((prev) => prev.filter((id) => id !== postId));
    setLikedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
  };

  const toggleDislike = (postId: number) => {
    if (likedPosts.includes(postId))
      setLikedPosts((prev) => prev.filter((id) => id !== postId));
    setDislikedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
  };

  const toggleFollow = (userName: string) => {
    setFollowedUsers((prev) =>
      prev.includes(userName)
        ? prev.filter((u) => u !== userName)
        : [...prev, userName],
    );
  };

  const toggleComments = (postId: number) => {
    setExpandedComments((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
  };

  const toggleCommentLike = (key: string) => {
    if (dislikedComments.includes(key))
      setDislikedComments((prev) => prev.filter((k) => k !== key));
    setLikedComments((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
  };

  const toggleCommentDislike = (key: string) => {
    if (likedComments.includes(key))
      setLikedComments((prev) => prev.filter((k) => k !== key));
    setDislikedComments((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
  };

  const submitComment = (postId: number) => {
    const input = commentInputs[postId];
    if (input?.trim()) {
      const newComment: Comment = {
        id: Date.now(),
        author: "나",
        avatar: "🍚",
        avatarBg: "linear-gradient(135deg,#72C2FF,#4AABF5)",
        content: input,
        time: "방금 전",
        likes: 0,
        dislikes: 0,
        replies: [],
      };
      setCommentsState((prev) => ({
        ...prev,
        [postId]: [newComment, ...(prev[postId] || [])],
      }));
      setCommentInputs((prev) => ({ ...prev, [postId]: "" }));
      if (!expandedComments.includes(postId)) {
        setExpandedComments((prev) => [...prev, postId]);
      }
      showToast("댓글이 등록되었습니다");
    }
  };

  const submitReply = (
    postId: number,
    commentId: number,
    parentReplyId?: number,
  ) => {
    const key = parentReplyId
      ? `${postId}-${commentId}-${parentReplyId}`
      : `${postId}-${commentId}`;
    const input = replyInputs[key];
    if (input?.trim() && replyingTo) {
      const newReply: Reply = {
        id: Date.now(),
        author: "나",
        avatar: "🍚",
        avatarBg: "linear-gradient(135deg,#72C2FF,#4AABF5)",
        content: input,
        time: "방금 전",
        likes: 0,
        dislikes: 0,
        replyTo: replyingTo.author,
      };

      setCommentsState((prev) => {
        const comments = [...(prev[postId] || [])];
        const commentIndex = comments.findIndex((c) => c.id === commentId);
        if (commentIndex !== -1) {
          const updatedComment = { ...comments[commentIndex] };
          updatedComment.replies = [
            ...(updatedComment.replies || []),
            newReply,
          ];
          comments[commentIndex] = updatedComment;
        }
        return { ...prev, [postId]: comments };
      });

      setReplyInputs((prev) => ({ ...prev, [key]: "" }));
      setReplyingTo(null);
      showToast("답글이 등록되었습니다");

      setTimeout(() => {
        const newKey = `${postId}-${commentId}-reply-${newReply.id}`;
        setHighlightedComment(newKey);
        setTimeout(() => setHighlightedComment(null), 1500);
      }, 100);
    }
  };

  const scrollToComment = (
    postId: number,
    commentId: number,
    replyId?: number,
  ) => {
    const key = replyId
      ? `${postId}-${commentId}-reply-${replyId}`
      : `${postId}-${commentId}`;
    const element = commentRefs.current[key];
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
      setHighlightedComment(key);
      setTimeout(() => setHighlightedComment(null), 1500);
    }
  };

  // 상대 시간 함수
  const getRelativeTime = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (minutes < 1) return "방금 전";
    if (minutes < 60) return `${minutes}분 전`;
    if (hours < 24) return `${hours}시간 전`;
    if (days < 7) return `${days}일 전`;
    const date = new Date(timestamp);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  };

  // ─── 게시글 상세 보기 ───
  if (selectedPost) {
    return (
      <>
        <style>{animationStyles}</style>

        {/* 헤더 */}
        <GalleryHeader
          gallery={gallery}
          isFollowed={isGalleryFollowed}
          isInterested={isGalleryInterested}
          onToggleFollow={handleToggleGalleryFollow}
          onToggleInterest={handleToggleGalleryInterest}
          onShowManagement={() => setShowManagementPopup(true)}
        />

        {/* 게시글 상세 */}
        <PostDetail
          post={selectedPost}
          comments={commentsState[selectedPost.id] || []}
          isLiked={likedPosts.includes(selectedPost.id)}
          isDisliked={dislikedPosts.includes(selectedPost.id)}
          isFollowed={followedUsers.includes(selectedPost.name)}
          commentInput={commentInputs[selectedPost.id] || ""}
          replyingTo={replyingTo}
          replyInputs={replyInputs}
          likedComments={likedComments}
          dislikedComments={dislikedComments}
          followedUsers={followedUsers}
          highlightedComment={highlightedComment}
          commentRefs={commentRefs}
          onBack={() => setSelectedPost(null)}
          onLike={() => toggleLike(selectedPost.id)}
          onDislike={() => toggleDislike(selectedPost.id)}
          onFollow={toggleFollow}
          onShowGiftPopup={() => setShowGiftPopup(true)}
          onShowProfile={() => {
            if (onProfileClick) {
              onProfileClick(
                selectedPost.author || selectedPost.name,
                selectedPost.avatar,
                selectedPost.avatarBg,
              );
            } else {
              setSelectedProfile(selectedPost);
            }
          }}
          onCommentInputChange={(value) =>
            setCommentInputs((prev) => ({ ...prev, [selectedPost.id]: value }))
          }
          onSubmitComment={() => submitComment(selectedPost.id)}
          onCommentLike={toggleCommentLike}
          onCommentDislike={toggleCommentDislike}
          onCommentGift={(key) => setShowCommentGiftPopup(key)}
          onStartReply={(key, author) => setReplyingTo({ key, author })}
          onCancelReply={() => setReplyingTo(null)}
          onReplyInputChange={(key, value) =>
            setReplyInputs((prev) => ({ ...prev, [key]: value }))
          }
          onSubmitReply={(commentId) => submitReply(selectedPost.id, commentId)}
          onScrollToComment={(commentId) =>
            scrollToComment(selectedPost.id, commentId)
          }
          displayCategory={
            selectedPost.category || getPostCategory(selectedPost.id)
          }
          isResident={isPostResident(selectedPost.id)}
        />

        {/* 팝업들 */}
        {showGiftPopup && (
          <GiftPopup type="post" onClose={() => setShowGiftPopup(false)} />
        )}
        {showCommentGiftPopup && (
          <GiftPopup
            type="comment"
            onClose={() => setShowCommentGiftPopup(null)}
          />
        )}
        {!onProfileClick && selectedProfile && (
          <ProfilePopup
            profile={selectedProfile}
            isFollowed={followedUsers.includes(selectedProfile.name)}
            onClose={() => setSelectedProfile(null)}
            onFollow={() => toggleFollow(selectedProfile.name)}
          />
        )}
      </>
    );
  }

  // ─── 게시글 목록 ───
  return (
    <>
      <style>{animationStyles}</style>

      {/* 헤더 */}
      <GalleryHeader
        gallery={gallery}
        isFollowed={isGalleryFollowed}
        isInterested={isGalleryInterested}
        onToggleFollow={handleToggleGalleryFollow}
        onToggleInterest={handleToggleGalleryInterest}
        onShowManagement={() => setShowManagementPopup(true)}
      />

      {/* 글쓰기 입력창 */}
      <div className="py-4 border-b border-gray-200">
        <div
          onClick={() => setShowWriteModal(true)}
          className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-200 cursor-pointer hover:border-[#72C2FF] transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
            <svg
              width="16"
              height="16"
              fill="none"
              stroke="#9CA3AF"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <circle cx="12" cy="8" r="4" />
              <path d="M20 21a8 8 0 1 0-16 0" />
            </svg>
          </div>
          <span className="text-[14px] text-gray-400 flex-1">
            지금 무슨 생각을 하고 있나요?
          </span>
          <div className="flex items-center gap-2">
            <button className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors">
              <svg
                width="18"
                height="18"
                fill="none"
                stroke="#9CA3AF"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <path d="m21 15-5-5L5 21" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* 현재 카테고리 표시 + 서브탭 + 뷰모드 */}
      <div className="py-3 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* 현재 카테고리 */}
          <span className="text-[14px] font-bold text-[#1A1A2E]">
            {activeCategory}
          </span>
          <div className="w-px h-4 bg-gray-300" />

          {/* 서브탭 */}
          <div className="flex items-center gap-1">
            {subTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setSubTab(tab)}
                className={`px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors flex items-center gap-1 ${
                  subTab === tab
                    ? "bg-[#72C2FF] text-white"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                {tab === "인증글" && (
                  <img
                    src="https://ssalmuk.com/images/img_commu/cm_list_adminmark_size22.svg"
                    alt=""
                    className="w-4 h-4"
                  />
                )}
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* 개수 드롭다운 (목록형) */}
          {viewMode === "list" && (
            <div className="relative">
              <button
                onClick={() => setShowCountDropdown(!showCountDropdown)}
                className="flex items-center gap-1 px-3 py-1.5 text-[13px] text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                {itemsPerPage}개씩
                <svg
                  width="12"
                  height="12"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                >
                  <path d="m6 9 6 6 6-6" />
                </svg>
              </button>
              {showCountDropdown && (
                <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-10 py-1">
                  {[30, 50, 100].map((count) => (
                    <button
                      key={count}
                      onClick={() => {
                        setItemsPerPage(count);
                        setShowCountDropdown(false);
                        setCurrentPage(1);
                      }}
                      className={`w-full px-4 py-2 text-left text-[13px] hover:bg-gray-50 ${
                        itemsPerPage === count
                          ? "text-[#72C2FF] font-medium"
                          : "text-gray-600"
                      }`}
                    >
                      {count}개씩
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
          {/* 뷰모드 드롭다운 */}
          <div className="relative">
            <button
              onClick={() => setShowViewDropdown(!showViewDropdown)}
              className="flex items-center gap-1 px-3 py-1.5 text-[13px] text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {viewMode === "card" ? "카드형" : "목록형"}
              <svg
                width="12"
                height="12"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>
            {showViewDropdown && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-10 py-1 min-w-[100px]">
                {["card", "list"].map((mode) => (
                  <button
                    key={mode}
                    onClick={() => {
                      setViewMode(mode as "card" | "list");
                      setShowViewDropdown(false);
                    }}
                    className={`w-full px-3 py-2 text-left text-[13px] hover:bg-gray-50 ${
                      viewMode === mode
                        ? "text-[#72C2FF] font-medium"
                        : "text-gray-600"
                    }`}
                  >
                    {mode === "card" ? "카드형" : "목록형"}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 게시글 목록 */}
      <div>
        {filteredPosts.length === 0 ? (
          <div className="py-20 text-center">
            <p className="text-5xl mb-4">📭</p>
            <p className="text-[16px] font-semibold text-gray-500 mb-2">
              게시글이 없어요
            </p>
            <p className="text-[14px] text-gray-400">
              첫 번째 글을 작성해보세요!
            </p>
          </div>
        ) : viewMode === "card" ? (
          // 카드형 (무한스크롤)
          <div className="py-4 space-y-4">
            {cardPosts.map((post, index) => (
              <Fragment key={post.id}>
                <div
                  className="animate-fadeUp"
                  style={{ animationDelay: `${index * 30}ms` }}
                >
                  <PostCardFull
                    post={post}
                    index={index + 1}
                    comments={commentsState[post.id] || []}
                    isLiked={likedPosts.includes(post.id)}
                    isDisliked={dislikedPosts.includes(post.id)}
                    isFollowed={followedUsers.includes(post.name)}
                    isCommentsExpanded={expandedComments.includes(post.id)}
                    commentInput={commentInputs[post.id] || ""}
                    replyingTo={replyingTo}
                    replyInputs={replyInputs}
                    likedComments={likedComments}
                    dislikedComments={dislikedComments}
                    followedUsers={followedUsers}
                    highlightedComment={highlightedComment}
                    commentRefs={commentRefs}
                    onLike={() => toggleLike(post.id)}
                    onDislike={() => toggleDislike(post.id)}
                    onFollow={toggleFollow}
                    onToggleComments={() => toggleComments(post.id)}
                    onShowGiftPopup={() => setShowGiftPopup(true)}
                    onShowProfile={() => {
                      if (onProfileClick) {
                        onProfileClick(
                          post.author || post.name,
                          post.avatar,
                          post.avatarBg,
                        );
                      } else {
                        setSelectedProfile(post);
                      }
                    }}
                    onCommentInputChange={(value) =>
                      setCommentInputs((prev) => ({
                        ...prev,
                        [post.id]: value,
                      }))
                    }
                    onSubmitComment={() => submitComment(post.id)}
                    onCommentLike={toggleCommentLike}
                    onCommentDislike={toggleCommentDislike}
                    onCommentGift={(key) => setShowCommentGiftPopup(key)}
                    onStartReply={(key, author) =>
                      setReplyingTo({ key, author })
                    }
                    onCancelReply={() => setReplyingTo(null)}
                    onReplyInputChange={(key, value) =>
                      setReplyInputs((prev) => ({ ...prev, [key]: value }))
                    }
                    onSubmitReply={(commentId) =>
                      submitReply(post.id, commentId)
                    }
                    onScrollToComment={(commentId) =>
                      scrollToComment(post.id, commentId)
                    }
                    displayCategory={post.category || getPostCategory(post.id)}
                    isResident={isPostResident(post.id)}
                  />
                </div>
                {/* 첫 번째 게시글 뒤에 광고 */}
                {index === 0 && <AdCard ad={cardAd} index={index + 1} />}
              </Fragment>
            ))}

            {/* 로딩/더보기 */}
            <div ref={loadMoreRef} className="py-8 text-center">
              {isLoading ? (
                <div className="flex items-center justify-center gap-2 text-gray-400">
                  <div className="w-5 h-5 border-2 border-gray-300 border-t-[#72C2FF] rounded-full animate-spin" />
                  <span className="text-[14px]">로딩 중...</span>
                </div>
              ) : hasMoreCards ? (
                <p className="text-[14px] text-gray-400">스크롤하여 더 보기</p>
              ) : (
                <p className="text-[14px] text-gray-400">
                  모든 게시글을 불러왔어요
                </p>
              )}
            </div>
          </div>
        ) : (
          // 목록형 (페이지네이션)
          <>
            <div className="pt-3 flex flex-col gap-3">
              {paginatedPosts.map((post, index) => (
                <Fragment key={post.id}>
                  <PostListItem
                    post={post}
                    index={(currentPage - 1) * itemsPerPage + index + 1}
                    isFollowed={followedUsers.includes(post.name)}
                    isLiked={likedPosts.includes(post.id)}
                    isDisliked={dislikedPosts.includes(post.id)}
                    onFollow={() => toggleFollow(post.name)}
                    onLike={() => toggleLike(post.id)}
                    onDislike={() => toggleDislike(post.id)}
                    onComment={() => toggleComments(post.id)}
                    onGift={() => setShowGiftPopup(true)}
                    onClick={() => setSelectedPost(post)}
                    getRelativeTime={getRelativeTime}
                    displayCategory={post.category || getPostCategory(post.id)}
                    isResident={isPostResident(post.id)}
                  />
                  {/* 첫 번째 게시글 뒤에 광고 */}
                  {index === 0 && <AdListItem ad={listAd} index={index + 1} />}
                </Fragment>
              ))}
            </div>

            {/* 페이지네이션 */}
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              onSearch={(keyword, type) => {
                setSearchKeyword(keyword);
                setSearchType(type);
              }}
            />
          </>
        )}
      </div>

      {/* 팝업들 */}
      {showGiftPopup && (
        <GiftPopup type="post" onClose={() => setShowGiftPopup(false)} />
      )}
      {showCommentGiftPopup && (
        <GiftPopup
          type="comment"
          onClose={() => setShowCommentGiftPopup(null)}
        />
      )}
      {!onProfileClick && selectedProfile && (
        <ProfilePopup
          profile={selectedProfile}
          isFollowed={followedUsers.includes(selectedProfile.name)}
          onClose={() => setSelectedProfile(null)}
          onFollow={() => toggleFollow(selectedProfile.name)}
        />
      )}

      {/* 글쓰기 모달 */}
      {showWriteModal && (
        <WritePostModal
          galleryName={gallery.name}
          onClose={() => setShowWriteModal(false)}
          onSubmit={handleWritePost}
        />
      )}

      {/* 갤러리 관리 내역 팝업 */}
      {showManagementPopup && (
        <GalleryManagementPopup
          galleryName={gallery.name}
          onClose={() => setShowManagementPopup(false)}
        />
      )}
    </>
  );
}
