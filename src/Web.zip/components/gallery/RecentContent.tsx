import GalleryCard from "./GalleryCard";
import type { GalleryItemData } from "./types";

// ─── 애니메이션 스타일 ───
const animationStyles = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
`;

// ─── 최근방문 콘텐츠 ───

export default function RecentContent() {
  // 최근 방문한 갤러리 (방문 시간 포함)
  const recentItems: (GalleryItemData & { visitedAt: string })[] = [
    {
      id: 1,
      icon: "🎮",
      name: "메이플스토리",
      desc: "메이플 유저들의 커뮤니티",
      color: "bg-amber-100 text-amber-600",
      visitedAt: "방금 전",
    },
    {
      id: 2,
      icon: "⚔️",
      name: "리니지M",
      desc: "리니지M 정보 공유",
      color: "bg-purple-100 text-purple-600",
      visitedAt: "10분 전",
    },
    {
      id: 3,
      icon: "🏰",
      name: "로스트아크",
      desc: "로아 공략 및 팁",
      color: "bg-sky-100 text-sky-600",
      visitedAt: "30분 전",
    },
    {
      id: 4,
      icon: "📈",
      name: "주식",
      desc: "투자 및 거래에 대한 통찰력.",
      color: "bg-green-100 text-green-600",
      visitedAt: "1시간 전",
    },
    {
      id: 5,
      icon: "🇺🇸",
      name: "미국주식이야기",
      desc: "미국 주식 정보 공유",
      color: "bg-blue-100 text-blue-600",
      visitedAt: "2시간 전",
    },
    {
      id: 6,
      icon: "🌏",
      name: "한국여행",
      desc: "음식부터 나이트라이프까지",
      color: "bg-teal-100 text-teal-600",
      visitedAt: "3시간 전",
    },
    {
      id: 7,
      icon: "🎯",
      name: "발로란트",
      desc: "발로란트 게이머 모임",
      color: "bg-rose-100 text-rose-600",
      visitedAt: "5시간 전",
    },
    {
      id: 8,
      icon: "B",
      name: "비트코인",
      desc: "암호화폐라는 혁신적인 세계!",
      color: "bg-blue-100 text-blue-600",
      visitedAt: "어제",
    },
    {
      id: 9,
      icon: "🚗",
      name: "카트라이더",
      desc: "카트 유저들의 공간",
      color: "bg-cyan-100 text-cyan-600",
      visitedAt: "어제",
    },
    {
      id: 10,
      icon: "⚡",
      name: "포켓몬고",
      desc: "포켓몬 마스터가 되자!",
      color: "bg-yellow-100 text-yellow-600",
      visitedAt: "2일 전",
    },
    {
      id: 11,
      icon: "♻",
      name: "검소한",
      desc: "알뜰하게 생활하고 풍족하게",
      color: "bg-red-100 text-red-600",
      visitedAt: "3일 전",
    },
    {
      id: 12,
      icon: "🅱",
      name: "버트코인",
      desc: "버트코인(ButtCoin). 사기입니다.",
      color: "bg-orange-100 text-orange-600",
      visitedAt: "1주일 전",
    },
  ];

  return (
    <>
      <style>{animationStyles}</style>
      {/* 섹션 제목 */}
      <div className="text-[20px] font-extrabold py-5 flex items-center gap-2 animate-fadeUp">
        🕐 최근 방문
      </div>

      {/* 안내 문구 */}
      <p
        className="text-[14px] text-gray-500 pb-4 animate-fadeUp"
        style={{ animationDelay: "50ms" }}
      >
        최근에 방문한 갤러리입니다. 자주 방문하는 갤러리는 팔로우 해보세요!
      </p>

      {/* 갤러리 그리드 */}
      <div className="grid grid-cols-3 gap-3 pb-6">
        {recentItems.map((item, index) => (
          <div
            key={item.id}
            className="relative animate-fadeUp"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <GalleryCard item={item} />
            {/* 방문 시간 뱃지 */}
            <span className="absolute top-2 right-2 text-[10px] font-medium text-gray-400 bg-white/90 px-2 py-0.5 rounded-full border border-gray-100">
              {item.visitedAt}
            </span>
          </div>
        ))}
      </div>

      {/* 비어있을 때 */}
      {recentItems.length === 0 && (
        <div className="py-20 text-center">
          <p className="text-5xl mb-4">🕐</p>
          <p className="text-[16px] font-semibold text-gray-500 mb-2">
            최근 방문한 갤러리가 없어요
          </p>
          <p className="text-[14px] text-gray-400">
            갤러리를 둘러보고 관심있는 곳에 가입해보세요!
          </p>
        </div>
      )}
    </>
  );
}
