import { useState, useCallback, type ReactNode } from "react";
import {
  ChevronDown,
  ChevronRight,
  Star,
  TrendingUp,
  Flame,
  Grid3X3,
} from "lucide-react";
import type { GalleryItemData } from "./types";

// ===== 메뉴 구조 타입 =====
interface SubMenu {
  id: string;
  label: string;
}

interface MenuItem {
  id: string;
  label: string;
  icon: ReactNode;
  subMenus?: SubMenu[];
}

// ===== Props =====
interface LeftSidebarProps {
  activeMenu: string;
  activeSubMenu?: string;
  onMenuChange: (menu: string, subMenu?: string) => void;
  selectedGallery?: GalleryItemData | null;
  activeCategory?: string;
  onCategoryChange?: (category: string) => void;
  onBackToList?: () => void;
}

// ===== 메뉴 구조 데이터 =====
const menuStructure: MenuItem[] = [
  {
    id: "피드",
    label: "피드",
    icon: <Flame size={18} />,
    subMenus: [
      { id: "지금핫한", label: "지금핫한" },
      { id: "팔로잉", label: "팔로잉" },
      { id: "뉴스", label: "뉴스" },
    ],
  },
  {
    id: "갤러리",
    label: "갤러리",
    icon: <Grid3X3 size={18} />,
  },
  {
    id: "관심",
    label: "관심",
    icon: <Star size={18} />,
  },
  {
    id: "순위",
    label: "순위",
    icon: <TrendingUp size={18} />,
  },
];

// ===== 갤러리 상세 모드 카테고리 =====
const defaultCategoryTabs = ["전체", "공략,팁", "질문", "스샷,자랑", "거래"];

// ===== 컴포넌트 =====
export default function LeftSidebar({
  activeMenu,
  activeSubMenu,
  onMenuChange,
  selectedGallery,
  activeCategory = "전체",
  onCategoryChange,
  onBackToList,
}: LeftSidebarProps) {
  // 확장된 메뉴 상태 관리
  const [expandedMenus, setExpandedMenus] = useState<string[]>(["피드"]);

  // 메뉴 확장/축소 토글 (useCallback으로 메모이제이션)
  const toggleExpand = useCallback((menuId: string) => {
    setExpandedMenus((prev) =>
      prev.includes(menuId)
        ? prev.filter((id) => id !== menuId)
        : [...prev, menuId],
    );
  }, []);

  // 메뉴 클릭 핸들러 (useCallback)
  const handleMenuClick = useCallback(
    (menu: MenuItem) => {
      if (menu.subMenus) {
        toggleExpand(menu.id);
        // 확장되면서 첫 번째 서브메뉴 선택
        if (!expandedMenus.includes(menu.id) && menu.subMenus.length > 0) {
          onMenuChange(menu.id, menu.subMenus[0].id);
        }
      } else {
        onMenuChange(menu.id);
      }
    },
    [expandedMenus, onMenuChange, toggleExpand],
  );

  // 서브메뉴 클릭 핸들러 (useCallback)
  const handleSubMenuClick = useCallback(
    (menuId: string, subMenuId: string) => {
      onMenuChange(menuId, subMenuId);
    },
    [onMenuChange],
  );

  // 활성 상태 체크 (useCallback으로 최적화)
  const isMenuActive = useCallback(
    (menuId: string) => activeMenu === menuId,
    [activeMenu],
  );

  const isSubMenuActive = useCallback(
    (menuId: string, subMenuId: string) =>
      activeMenu === menuId && activeSubMenu === subMenuId,
    [activeMenu, activeSubMenu],
  );

  // ─── 갤러리 상세 모드 렌더링 ───
  if (selectedGallery) {
    return (
      <nav className="flex flex-col gap-1">
        {/* 뒤로가기 */}
        <button
          onClick={onBackToList}
          className="flex items-center gap-2 px-4 py-2.5 text-left text-[14px] text-gray-500 hover:text-[#1A1A2E] hover:bg-gray-100 rounded-lg transition-colors mb-2"
        >
          <ChevronRight size={16} className="rotate-180" />
          갤러리 목록
        </button>

        {/* 갤러리 정보 */}
        <div className="flex items-center gap-3 px-4 py-3 mb-2">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold shrink-0 ${selectedGallery.color}`}
          >
            {selectedGallery.icon}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[14px] font-bold text-[#1A1A2E] truncate">
              {selectedGallery.name}
            </p>
            <p className="text-[11px] text-gray-400 truncate">
              {selectedGallery.desc}
            </p>
          </div>
        </div>

        {/* 구분선 */}
        <div className="h-px bg-gray-200 mx-4 mb-2" />

        {/* 카테고리 메뉴 */}
        {defaultCategoryTabs.map((cat) => (
          <button
            key={cat}
            onClick={() => onCategoryChange?.(cat)}
            className={`px-4 py-2.5 text-left text-[14px] font-medium rounded-lg transition-colors ${
              activeCategory === cat
                ? "text-[#1A1A2E] font-bold bg-gray-100"
                : "text-gray-500 hover:bg-gray-100 hover:text-[#1A1A2E]"
            }`}
          >
            {cat}
          </button>
        ))}

        {/* 광고 배너 */}
        <AdBanner />
      </nav>
    );
  }

  // ─── 기본 4메뉴 구조 렌더링 ───
  return (
    <nav className="flex flex-col gap-0.5">
      {menuStructure.map((menu) => (
        <div key={menu.id}>
          {/* 메인 메뉴 */}
          <button
            onClick={() => handleMenuClick(menu)}
            className={`w-full flex items-center justify-between px-4 py-2.5 text-left text-[15px] font-medium rounded-lg transition-colors ${
              isMenuActive(menu.id) && !menu.subMenus
                ? "text-[#1A1A2E] font-bold bg-gray-100"
                : isMenuActive(menu.id)
                  ? "text-[#1A1A2E] font-bold"
                  : "text-gray-500 hover:bg-gray-100 hover:text-[#1A1A2E]"
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span
                className={
                  isMenuActive(menu.id) ? "text-[#72C2FF]" : "text-gray-400"
                }
              >
                {menu.icon}
              </span>
              {menu.label}
            </span>
            {menu.subMenus && (
              <span className="text-gray-400">
                {expandedMenus.includes(menu.id) ? (
                  <ChevronDown size={16} />
                ) : (
                  <ChevronRight size={16} />
                )}
              </span>
            )}
          </button>

          {/* 서브메뉴 (애니메이션 적용) */}
          {menu.subMenus && expandedMenus.includes(menu.id) && (
            <div className="ml-4 mt-0.5 flex flex-col gap-0.5 animate-fadeIn">
              {menu.subMenus.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => handleSubMenuClick(menu.id, sub.id)}
                  className={`px-4 py-2 text-left text-[14px] rounded-lg transition-colors ${
                    isSubMenuActive(menu.id, sub.id)
                      ? "text-[#72C2FF] font-semibold bg-[#72C2FF]/10"
                      : "text-gray-500 hover:bg-gray-100 hover:text-[#1A1A2E]"
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}

      {/* 광고 배너 */}
      <AdBanner />

      {/* 애니메이션 스타일 */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-5px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn { animation: fadeIn 0.2s ease-out; }
      `}</style>
    </nav>
  );
}

// ===== 광고 배너 (분리된 컴포넌트) =====
function AdBanner() {
  return (
    <div className="mt-6 px-2">
      <a
        href="#"
        className="block rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
        onClick={(e) => e.preventDefault()}
      >
        <img
          src="https://i.pinimg.com/736x/e6/c7/77/e6c777962e2034c840f560b73a2f3a6b.jpg"
          alt="광고"
          className="w-full h-auto object-cover"
        />
      </a>
      <p className="text-[10px] text-gray-300 text-center mt-1">AD</p>
    </div>
  );
}
