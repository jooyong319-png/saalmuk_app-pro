import { useState } from "react";
import type { GalleryItemData } from "./types";
import GalleryCard from "./GalleryCard";

const animationStyles = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
`;

interface GalleryContentProps {
  onSelectGallery?: (gallery: GalleryItemData) => void;
  onNavigateToHot?: () => void;
}

export default function GalleryContent({
  onSelectGallery,
  onNavigateToHot,
}: GalleryContentProps) {
  const [activeTab, setActiveTab] = useState("주요채널");
  const [followedGalleries, setFollowedGalleries] = useState<number[]>([]);
  const [expandedCategories, setExpandedCategories] = useState<number[]>([]);

  const tabs = ["주요채널", "일반채널"];

  const categories = [
    {
      title: "쌀먹 정보",
      items: [
        {
          id: 1,
          icon: "🔥",
          name: "지금 핫한",
          desc: "실시간 인기 게임 정보",
          description:
            "실시간으로 인기있는 게임들의 정보와 공략을 공유하는 공간입니다.",
          color: "bg-orange-100 text-orange-600",
        },
        {
          id: 2,
          icon: "📢",
          name: "사전예약, 신서버",
          desc: "신규 게임 및 서버 오픈",
          description:
            "새로 출시되는 게임 사전예약과 신서버 오픈 정보를 공유합니다.",
          color: "bg-purple-100 text-purple-600",
        },
        {
          id: 3,
          icon: "💬",
          name: "쌀먹 라운지",
          desc: "자유로운 수다 공간",
          description:
            "게임 이야기부터 일상까지 자유롭게 소통하는 라운지입니다.",
          color: "bg-blue-100 text-blue-600",
        },
        {
          id: 4,
          icon: "🖥️",
          name: "쌀먹정비 세팅",
          desc: "PC 및 장비 세팅 정보",
          description: "게임을 위한 PC 사양과 장비 세팅 정보를 공유합니다.",
          color: "bg-gray-100 text-gray-600",
        },
      ],
    },
    {
      title: "모바일 게임",
      items: [
        {
          id: 101,
          icon: "⚔️",
          name: "아이온2",
          desc: "MMORPG",
          description:
            "엔씨소프트에서 개발한 모바일 MMORPG. 천족과 마족의 대립을 배경으로 한 판타지 게임.",
          color: "bg-blue-100 text-blue-600",
        },
        {
          id: 102,
          icon: "🗡️",
          name: "로드나인",
          desc: "MMORPG",
          description:
            "넥슨에서 서비스하는 모바일 MMORPG. 화려한 액션과 대규모 전투가 특징.",
          color: "bg-red-100 text-red-600",
        },
        {
          id: 103,
          icon: "🛡️",
          name: "오딘",
          desc: "발할라 라이징",
          description: "카카오게임즈에서 서비스하는 북유럽 신화 기반 MMORPG.",
          color: "bg-purple-100 text-purple-600",
        },
        {
          id: 104,
          icon: "⚔️",
          name: "리니지M",
          desc: "MMORPG",
          description:
            "엔씨소프트의 리니지 IP를 기반으로 한 모바일 MMORPG의 원조.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 105,
          icon: "🏹",
          name: "아키펙트",
          desc: "MMORPG",
          description: "카카오게임즈에서 서비스하는 3D 오픈월드 MMORPG.",
          color: "bg-green-100 text-green-600",
        },
        {
          id: 106,
          icon: "🍁",
          name: "메이플스토리M",
          desc: "MMORPG",
          description: "넥슨의 메이플스토리를 모바일로 구현한 사이드뷰 MMORPG.",
          color: "bg-orange-100 text-orange-600",
        },
        {
          id: 107,
          icon: "🤖",
          name: "RF온라인넥스트",
          desc: "SF MMORPG",
          description: "SF 세계관을 배경으로 한 3종족 대규모 전쟁 MMORPG.",
          color: "bg-red-100 text-red-600",
        },
        {
          id: 108,
          icon: "🦇",
          name: "나이트크로우",
          desc: "MMORPG",
          description: "위메이드에서 서비스하는 중세 다크 판타지 MMORPG.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 109,
          icon: "🧛",
          name: "뱀파이어",
          desc: "MMORPG",
          description: "뱀파이어 세계관을 배경으로 한 다크 판타지 MMORPG.",
          color: "bg-red-100 text-red-600",
        },
        {
          id: 110,
          icon: "📖",
          name: "프라시아이야기",
          desc: "MMORPG",
          description: "캐주얼한 그래픽의 힐링 감성 MMORPG.",
          color: "bg-teal-100 text-teal-600",
        },
        {
          id: 111,
          icon: "🐦",
          name: "레이븐2",
          desc: "액션 RPG",
          description: "넷마블에서 서비스하는 하드코어 액션 RPG.",
          color: "bg-purple-100 text-purple-600",
        },
        {
          id: 112,
          icon: "⭐",
          name: "더스타라이트",
          desc: "MMORPG",
          description: "스타라이트 세계관의 판타지 MMORPG.",
          color: "bg-yellow-100 text-yellow-600",
        },
        {
          id: 113,
          icon: "⚓",
          name: "아키에이지워",
          desc: "MMORPG",
          description: "아키에이지 IP 기반의 대규모 해상 전투 MMORPG.",
          color: "bg-blue-100 text-blue-600",
        },
        {
          id: 114,
          icon: "❄️",
          name: "이미르",
          desc: "MMORPG",
          description: "북유럽 신화 세계관의 모바일 MMORPG.",
          color: "bg-cyan-100 text-cyan-600",
        },
        {
          id: 115,
          icon: "🌑",
          name: "에오스 블랙",
          desc: "MMORPG",
          description: "블루홀에서 개발한 다크 판타지 MMORPG.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 116,
          icon: "🏰",
          name: "어나더던전",
          desc: "던전 RPG",
          description: "던전 탐험 중심의 핵앤슬래시 액션 RPG.",
          color: "bg-indigo-100 text-indigo-600",
        },
        {
          id: 117,
          icon: "🌙",
          name: "달빛조각사",
          desc: "MMORPG",
          description: "소설 '달빛조각사'를 원작으로 한 모바일 MMORPG.",
          color: "bg-blue-100 text-blue-600",
        },
        {
          id: 118,
          icon: "🏔️",
          name: "아스달 연대기",
          desc: "MMORPG",
          description: "드라마 '아스달 연대기'를 기반으로 한 MMORPG.",
          color: "bg-amber-100 text-amber-600",
        },
        {
          id: 119,
          icon: "🎵",
          name: "마비노기 모바일",
          desc: "MMORPG",
          description: "넥슨의 마비노기를 모바일로 구현한 힐링 MMORPG.",
          color: "bg-green-100 text-green-600",
        },
        {
          id: 120,
          icon: "👑",
          name: "DK모바일리본",
          desc: "MMORPG",
          description: "다크 세계관의 하드코어 액션 MMORPG.",
          color: "bg-red-100 text-red-600",
        },
        {
          id: 121,
          icon: "🗡️",
          name: "로한2",
          desc: "MMORPG",
          description: "로한 온라인의 후속작 모바일 MMORPG.",
          color: "bg-purple-100 text-purple-600",
        },
        {
          id: 122,
          icon: "🎮",
          name: "펀타임",
          desc: "캐주얼 게임",
          description: "다양한 캐주얼 미니게임을 즐길 수 있는 플랫폼.",
          color: "bg-pink-100 text-pink-600",
        },
        {
          id: 123,
          icon: "📱",
          name: "그 외(모바일)",
          desc: "기타 모바일 게임",
          description: "기타 모바일 게임들에 대해 이야기하는 공간입니다.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 124,
          icon: "🐉",
          name: "드래곤라자오리진",
          desc: "MMORPG",
          description: "드래곤라자 세계관의 판타지 MMORPG.",
          color: "bg-orange-100 text-orange-600",
        },
      ],
    },
    {
      title: "PC 게임",
      items: [
        {
          id: 201,
          icon: "⚔️",
          name: "리니지 클래식",
          desc: "MMORPG",
          description: "엔씨소프트의 클래식 감성 리니지 온라인.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 202,
          icon: "🍁",
          name: "메이플스토리",
          desc: "MMORPG",
          description: "넥슨의 대표 사이드뷰 MMORPG.",
          color: "bg-orange-100 text-orange-600",
        },
        {
          id: 203,
          icon: "🏰",
          name: "로스트아크",
          desc: "액션 RPG",
          description: "스마일게이트의 쿼터뷰 액션 MMORPG.",
          color: "bg-amber-100 text-amber-600",
        },
        {
          id: 204,
          icon: "🎵",
          name: "마비노기",
          desc: "MMORPG",
          description: "넥슨의 힐링 감성 생활형 MMORPG.",
          color: "bg-green-100 text-green-600",
        },
        {
          id: 205,
          icon: "👊",
          name: "던전앤파이터",
          desc: "액션 RPG",
          description: "넥슨의 벨트스크롤 액션 RPG.",
          color: "bg-blue-100 text-blue-600",
        },
        {
          id: 206,
          icon: "💀",
          name: "패스오브엑자일2",
          desc: "핵앤슬래시",
          description: "GGG의 하드코어 핵앤슬래시 ARPG 후속작.",
          color: "bg-red-100 text-red-600",
        },
        {
          id: 207,
          icon: "🖥️",
          name: "그 외(PC)",
          desc: "기타 PC 게임",
          description: "기타 PC 게임들에 대해 이야기하는 공간입니다.",
          color: "bg-gray-100 text-gray-600",
        },
      ],
    },
    {
      title: "P2E 게임",
      items: [
        {
          id: 301,
          icon: "🌐",
          name: "디센트럴랜드",
          desc: "메타버스 P2E",
          description: "이더리움 기반 메타버스 플랫폼. 가상 부동산 거래 가능.",
          color: "bg-red-100 text-red-600",
        },
        {
          id: 302,
          icon: "🟦",
          name: "로블록스",
          desc: "메타버스 P2E",
          description:
            "유저가 직접 게임을 만들고 수익을 창출하는 메타버스 플랫폼.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 303,
          icon: "📦",
          name: "샌드박스",
          desc: "메타버스 P2E",
          description: "복셀 기반 메타버스 게임. NFT 에셋 거래 가능.",
          color: "bg-blue-100 text-blue-600",
        },
        {
          id: 304,
          icon: "🍄",
          name: "메이플스토리N",
          desc: "블록체인 RPG",
          description: "넥슨의 메이플스토리 IP 기반 블록체인 게임.",
          color: "bg-orange-100 text-orange-600",
        },
        {
          id: 305,
          icon: "🐾",
          name: "액시인피니티",
          desc: "P2E 게임",
          description: "액시 캐릭터를 수집하고 배틀하는 P2E 게임의 원조.",
          color: "bg-cyan-100 text-cyan-600",
        },
        {
          id: 306,
          icon: "🦅",
          name: "나이트크로우글로벌",
          desc: "P2E MMORPG",
          description: "나이트크로우의 글로벌 P2E 버전.",
          color: "bg-purple-100 text-purple-600",
        },
        {
          id: 307,
          icon: "⏰",
          name: "빅타임",
          desc: "P2E RPG",
          description: "시간여행 테마의 액션 RPG P2E 게임.",
          color: "bg-yellow-100 text-yellow-600",
        },
        {
          id: 308,
          icon: "🐉",
          name: "MIR4",
          desc: "P2E MMORPG",
          description: "위메이드의 동양 판타지 P2E MMORPG.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 309,
          icon: "🅰️",
          name: "아카랜드",
          desc: "P2E 게임",
          description: "블록체인 기반 전략 P2E 게임.",
          color: "bg-gray-100 text-gray-600",
        },
        {
          id: 310,
          icon: "🌙",
          name: "이클립스",
          desc: "P2E 게임",
          description: "다크 판타지 세계관의 P2E 게임.",
          color: "bg-pink-100 text-pink-600",
        },
        {
          id: 311,
          icon: "🐹",
          name: "포켓팔즈",
          desc: "P2E 게임",
          description: "귀여운 캐릭터 수집형 P2E 게임.",
          color: "bg-orange-100 text-orange-600",
        },
        {
          id: 312,
          icon: "🎮",
          name: "그 외(P2E)",
          desc: "기타 P2E 게임",
          description: "기타 P2E 게임들에 대해 이야기하는 공간입니다.",
          color: "bg-gray-100 text-gray-600",
        },
      ],
    },
  ];

  const toggleFollow = (id: number) => {
    setFollowedGalleries((prev) =>
      prev.includes(id) ? prev.filter((gid) => gid !== id) : [...prev, id],
    );
  };

  return (
    <>
      <style>{animationStyles}</style>

      {/* 탭 */}
      <div className="flex items-center justify-between py-4 border-b border-gray-200 animate-fadeUp">
        <div className="flex items-center gap-2">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-[14px] font-semibold rounded-lg transition-all ${
                activeTab === tab
                  ? "bg-gray-900 text-white"
                  : "bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-700"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 text-gray-400 hover:bg-gray-200 hover:text-gray-600 transition-colors">
          <svg
            width="16"
            height="16"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            viewBox="0 0 24 24"
          >
            <path d="M9 18l6-6-6-6" />
          </svg>
        </button>
      </div>

      {/* 카테고리별 목록 */}
      <div className="py-4">
        {categories.map((category, catIdx) => (
          <div
            key={catIdx}
            className="mb-6 animate-fadeUp"
            style={{ animationDelay: `${catIdx * 100}ms` }}
          >
            <h3 className="text-[15px] font-bold text-gray-900 mb-3">
              {category.title}
            </h3>

            <div className="grid grid-cols-3 gap-3">
              {(expandedCategories.includes(catIdx)
                ? category.items
                : category.items.slice(0, 6)
              ).map((item, index) => (
                <div
                  key={item.id}
                  className="animate-fadeUp cursor-pointer"
                  style={{ animationDelay: `${index * 50}ms` }}
                  onClick={() => {
                    if (item.name === "지금 핫한" && onNavigateToHot) {
                      onNavigateToHot();
                    } else {
                      onSelectGallery?.(item);
                    }
                  }}
                >
                  <GalleryCard
                    item={item}
                    isFollowed={followedGalleries.includes(item.id)}
                    onToggleFollow={() => toggleFollow(item.id)}
                  />
                </div>
              ))}
            </div>

            {/* 더보기 / 접기 */}
            {category.items.length > 6 && (
              <div className="text-center mt-3">
                <button
                  onClick={() =>
                    setExpandedCategories((prev) =>
                      prev.includes(catIdx)
                        ? prev.filter((i) => i !== catIdx)
                        : [...prev, catIdx],
                    )
                  }
                  className="text-[13px] text-gray-400 hover:text-gray-600"
                >
                  {expandedCategories.includes(catIdx)
                    ? "접기 ↑"
                    : `더보기 (${category.items.length - 6}개) ↓`}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
