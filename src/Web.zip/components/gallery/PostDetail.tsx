import { useState } from "react";
import type { PostData, Comment, ReplyTarget, ContentBlock } from "./types";
import CommentSection from "./CommentSection";
import LikeDislikeButton from "./LikeDislikeButton";
import DropdownMenu, { getPostMenuItems } from "./DropdownMenu";
import { useToast } from "./Toast";
import ConfirmPopup from "./ConfirmPopup";
import ReportPopup from "./ReportPopup";
import { FollowButton } from "./FollowButton";

interface PostDetailProps {
  post: PostData;
  comments: Comment[];
  isLiked: boolean;
  isDisliked: boolean;
  isFollowed: boolean;
  commentInput: string;
  replyingTo: ReplyTarget | null;
  replyInputs: { [key: string]: string };
  likedComments: string[];
  dislikedComments: string[];
  followedUsers: string[];
  highlightedComment: string | null;
  commentRefs: React.MutableRefObject<{ [key: string]: HTMLDivElement | null }>;
  onBack: () => void;
  onLike: () => void;
  onDislike: () => void;
  onFollow: (name: string) => void;
  onShowGiftPopup: () => void;
  onShowProfile: () => void;
  onCommentInputChange: (value: string) => void;
  onSubmitComment: () => void;
  onCommentLike: (key: string) => void;
  onCommentDislike: (key: string) => void;
  onCommentGift: (key: string) => void;
  onStartReply: (key: string, author: string) => void;
  onCancelReply: () => void;
  onReplyInputChange: (key: string, value: string) => void;
  onSubmitReply: (commentId: number) => void;
  onScrollToComment: (commentId: number) => void;
  displayCategory?: string;
  isResident?: boolean; // 갤러리 주민 여부
}

export default function PostDetail({
  post,
  comments,
  isLiked,
  isDisliked,
  isFollowed,
  commentInput,
  replyingTo,
  replyInputs,
  likedComments,
  dislikedComments,
  followedUsers,
  highlightedComment,
  commentRefs,
  onBack,
  onLike,
  onDislike,
  onFollow,
  onShowGiftPopup,
  onShowProfile,
  onCommentInputChange,
  onSubmitComment,
  onCommentLike,
  onCommentDislike,
  onCommentGift,
  onStartReply,
  onCancelReply,
  onReplyInputChange,
  onSubmitReply,
  onScrollToComment,
  displayCategory,
  isResident = false,
}: PostDetailProps) {
  const { showToast } = useToast();
  const [showBlockPopup, setShowBlockPopup] = useState(false);
  const [showReportPopup, setShowReportPopup] = useState(false);

  // body가 블록 배열인지 확인
  const isBlockBody = Array.isArray(post.body);
  const bodyBlocks = isBlockBody ? (post.body as ContentBlock[]) : null;
  const bodyString = !isBlockBody ? (post.body as string) : null;

  // 블록 렌더링 함수
  const renderBlock = (block: ContentBlock, idx: number) => {
    if (block.type === "text") {
      return (
        <p
          key={idx}
          className="text-[15px] text-gray-700 leading-[1.7] whitespace-pre-wrap mb-4"
        >
          {block.content}
        </p>
      );
    } else if (block.type === "image") {
      return (
        <div
          key={idx}
          className="relative bg-gray-100 rounded-xl overflow-hidden my-4"
        >
          <img
            src={block.src}
            alt={block.alt || `이미지 ${idx + 1}`}
            loading="lazy"
            decoding="async"
            className="w-full h-auto max-h-[600px] object-contain cursor-pointer hover:opacity-95 transition-opacity rounded-xl"
          />
        </div>
      );
    }
    return null;
  };

  return (
    <div className="animate-fadeUp">
      {/* 헤더 */}
      <div className="flex items-center gap-3 pb-3 border-b border-gray-100 mb-4">
        <button
          onClick={onBack}
          className="p-1.5 -ml-1.5 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <svg
            className="w-5 h-5 text-gray-600"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
        </button>
        <span className="text-[15px] font-semibold text-gray-900">게시글</span>
      </div>

      {/* 작성자 정보 */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center gap-0.5">
            <div
              className="w-11 h-11 rounded-full flex items-center justify-center text-xl cursor-pointer hover:scale-105 transition-transform shrink-0"
              style={{ background: post.avatarBg }}
              onClick={onShowProfile}
            >
              {post.avatar}
            </div>
            {isResident && (
              <span className="text-[9px] text-[#72C2FF] font-bold">주민</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p
                className="text-[16px] font-semibold text-gray-900 cursor-pointer hover:underline"
                onClick={onShowProfile}
              >
                {post.name}
              </p>
              {post.badge && (
                <span className="text-[11px] px-1.5 py-0.5 rounded bg-[#E8F4FD] text-[#72C2FF] font-medium">
                  {post.badge}
                </span>
              )}
            </div>
            <p className="text-[13px] text-gray-400">
              {displayCategory
                ? post.meta?.split("·")[0]?.trim() + " · " + displayCategory
                : post.meta}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* 더보기 메뉴 */}
          <DropdownMenu
            size="lg"
            zIndex={50}
            items={getPostMenuItems({
              onShare: () => showToast("링크를 복사했어요", { type: "link" }),
              onSave: () => showToast(`${post.name}님의 글을 저장했어요.`),
              onBlock: () => setShowBlockPopup(true),
              onReport: () => setShowReportPopup(true),
            })}
          />
          <FollowButton
            name={post.name}
            isFollowed={isFollowed}
            onFollow={() => onFollow(post.name)}
          />
        </div>
      </div>

      {/* 게시글 내용 */}
      <div className="mb-4">
        {/* 제목 */}
        <h1 className="text-[18px] font-bold text-gray-900 mb-3 leading-snug flex items-center gap-1.5">
          {post.isVerified && (
            <img
              src="https://ssalmuk.com/images/img_commu/cm_list_adminmark_size22.svg"
              alt="인증글"
              className="w-5 h-5 shrink-0"
            />
          )}
          {post.title}
        </h1>

        {/* 본문 */}
        <div>
          {isBlockBody ? (
            // 블록 배열 형태: 모든 블록 렌더링
            bodyBlocks!.map((block, idx) => renderBlock(block, idx))
          ) : (
            // 기존 문자열 형태
            <>
              <p className="text-[15px] text-gray-700 leading-[1.7] whitespace-pre-wrap">
                {bodyString}
              </p>

              {/* 기존 이미지 배열 (body가 string일 때) */}
              {post.images && post.images.length > 0 && (
                <div className="mt-4 space-y-3">
                  {post.images.map((img, idx) => (
                    <div
                      key={idx}
                      className="relative bg-gray-100 rounded-xl overflow-hidden"
                    >
                      <img
                        src={img}
                        alt={`이미지 ${idx + 1}`}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-auto max-h-[600px] object-contain cursor-pointer hover:opacity-95 transition-opacity rounded-xl"
                      />
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* 액션 버튼 */}
      <div className="flex items-center text-gray-400 py-3 border-t border-b border-gray-100">
        <div className="flex items-center gap-1">
          {/* 좋아요/싫어요 */}
          <LikeDislikeButton
            likes={post.likes}
            dislikes={post.dislikes || 0}
            isLiked={isLiked}
            isDisliked={isDisliked}
            onLike={onLike}
            onDislike={onDislike}
            size="lg"
          />

          {/* 댓글 */}
          <div className="flex items-center gap-1.5 px-3 py-2 text-gray-400">
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              />
            </svg>
            <span className="text-[14px] font-medium">{post.comments}</span>
          </div>

          {/* 조회수 */}
          <span className="flex items-center gap-1.5 px-3 py-2 text-[14px] text-gray-400">
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
              />
            </svg>
            {post.views.toLocaleString()}
          </span>

          {/* 선물 */}
          <button
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={onShowGiftPopup}
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* 댓글 섹션 */}
      <div className="mt-4">
        <CommentSection
          postId={post.id}
          comments={comments}
          commentInput={commentInput}
          replyingTo={replyingTo}
          replyInputs={replyInputs}
          likedComments={likedComments}
          dislikedComments={dislikedComments}
          followedUsers={followedUsers}
          highlightedComment={highlightedComment}
          commentRefs={commentRefs}
          onCommentInputChange={onCommentInputChange}
          onSubmitComment={onSubmitComment}
          onCommentLike={onCommentLike}
          onCommentDislike={onCommentDislike}
          onCommentGift={onCommentGift}
          onFollow={onFollow}
          onStartReply={onStartReply}
          onCancelReply={onCancelReply}
          onReplyInputChange={onReplyInputChange}
          onSubmitReply={onSubmitReply}
          onScrollToComment={onScrollToComment}
        />
      </div>

      {/* 차단 확인 팝업 */}
      {showBlockPopup && (
        <ConfirmPopup
          title={`${post.name}님을 차단할까요?`}
          description={`앞으로 ${post.name}님의 글을 볼 수 없고, ${post.name}님도 내 글을 볼 수 없어요.`}
          confirmText="차단하기"
          cancelText="닫기"
          isDestructive
          onConfirm={() => {
            showToast(`${post.name}님을 차단했어요`, { type: "block" });
            setShowBlockPopup(false);
          }}
          onCancel={() => setShowBlockPopup(false)}
        />
      )}

      {/* 신고 사유 선택 팝업 */}
      {showReportPopup && (
        <ReportPopup
          targetType="글"
          onReport={(reason) => {
            console.log("신고 사유:", reason);
            showToast("신고가 접수되었습니다");
            setShowReportPopup(false);
          }}
          onCancel={() => setShowReportPopup(false)}
        />
      )}
    </div>
  );
}
