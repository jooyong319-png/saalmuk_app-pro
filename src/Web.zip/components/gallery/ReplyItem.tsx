import { useState } from "react";
import type { Reply } from "./types";
import LikeDislikeButton from "./LikeDislikeButton";
import { useToast } from "./Toast";
import ConfirmPopup from "./ConfirmPopup";
import ReportPopup from "./ReportPopup";

interface ReplyItemProps {
  reply: Reply;
  postId: number;
  commentId: number;
  depth?: number;
  likedComments: string[];
  dislikedComments: string[];
  followedUsers: string[];
  replyingToKey: string | null;
  replyInputs: { [key: string]: string };
  onLike: (key: string) => void;
  onDislike: (key: string) => void;
  onFollow: (name: string) => void;
  onGift: (key: string) => void;
  onStartReply: (key: string, author: string) => void;
  onCancelReply: () => void;
  onReplyInputChange: (key: string, value: string) => void;
  onSubmitReply: () => void;
}

export default function ReplyItem({
  reply,
  postId,
  commentId,
  depth = 0,
  likedComments,
  dislikedComments,
  followedUsers,
  replyingToKey,
  replyInputs,
  onLike,
  onDislike,
  onFollow,
  onGift,
  onStartReply,
  onCancelReply,
  onReplyInputChange,
  onSubmitReply,
}: ReplyItemProps) {
  const { showToast } = useToast();
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showUnfollowPopup, setShowUnfollowPopup] = useState(false);
  const [showBlockPopup, setShowBlockPopup] = useState(false);
  const [showReportPopup, setShowReportPopup] = useState(false);
  const replyKey = `${postId}-${commentId}-${reply.id}`;
  const isLiked = likedComments.includes(replyKey);
  const isDisliked = dislikedComments.includes(replyKey);
  const isReplying = replyingToKey === replyKey;
  const isFollowed = followedUsers.includes(reply.author);

  return (
    <div>
      <div className="flex items-start gap-2 py-2">
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center text-sm shrink-0"
          style={{ background: reply.avatarBg || "#E5E7EB" }}
        >
          {reply.avatar}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-[12px] font-semibold text-gray-900">
              {reply.author}
            </span>
            <span className="text-[11px] text-gray-400">{reply.time}</span>
          </div>
          <p className="text-[13px] text-gray-700 mb-1">
            {reply.replyTo && (
              <span className="text-gray-400  font-semibold">
                @{reply.replyTo}{" "}
              </span>
            )}
            {reply.content}
          </p>
          <div className="flex items-center gap-2">
            {/* 좋아요/싫어요 */}
            <LikeDislikeButton
              likes={reply.likes}
              dislikes={reply.dislikes || 0}
              isLiked={isLiked}
              isDisliked={isDisliked}
              onLike={() => onLike(replyKey)}
              onDislike={() => onDislike(replyKey)}
              size="xs"
            />

            {/* 후원 */}
            <button
              className="flex items-center gap-1 px-1 py-0.5 rounded text-[11px] text-gray-400 hover:bg-gray-100 hover:text-[#72C2FF]"
              onClick={() => onGift(replyKey)}
            >
              <svg
                className="w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
                />
              </svg>
            </button>

            {/* 답글 */}
            <button
              className={`flex items-center gap-1 px-1 py-0.5 rounded text-[11px] hover:bg-gray-100 ${
                isReplying ? "text-[#72C2FF]" : "text-gray-400"
              }`}
              onClick={() => onStartReply(replyKey, reply.author)}
            >
              → 답글
            </button>
          </div>
        </div>

        {/* 더보기 메뉴 */}
        <div className="relative shrink-0">
          <button
            className="p-0.5 text-gray-300 hover:text-gray-500 transition-colors"
            onClick={() => setShowMoreMenu(!showMoreMenu)}
          >
            <svg
              className="w-3.5 h-3.5"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
            </svg>
          </button>
          {showMoreMenu && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setShowMoreMenu(false)}
              />
              <div className="absolute right-0 top-5 bg-white rounded-xl shadow-lg border border-gray-100 py-1.5 min-w-[120px] z-20">
                <button
                  className="w-full px-3 py-1.5 flex items-center gap-2 text-[12px] text-gray-700 hover:bg-gray-50"
                  onClick={() => {
                    if (isFollowed) {
                      setShowUnfollowPopup(true);
                    } else {
                      onFollow(reply.author);
                      showToast(`${reply.author}님이 새 글을 올리거나 거래할 때 알려드릴게요`);
                    }
                    setShowMoreMenu(false);
                  }}
                >
                  <svg
                    className="w-3 h-3"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"
                    />
                  </svg>
                  {isFollowed ? "팔로우 취소" : "팔로우"}
                </button>
                <button
                  className="w-full px-3 py-1.5 flex items-center gap-2 text-[12px] text-gray-700 hover:bg-gray-50"
                  onClick={() => {
                    setShowBlockPopup(true);
                    setShowMoreMenu(false);
                  }}
                >
                  <svg
                    className="w-3 h-3"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"
                    />
                  </svg>
                  차단
                </button>
                <button
                  className="w-full px-3 py-1.5 flex items-center gap-2 text-[12px] text-gray-700 hover:bg-gray-50"
                  onClick={() => {
                    setShowReportPopup(true);
                    setShowMoreMenu(false);
                  }}
                >
                  <svg
                    className="w-3 h-3"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    />
                  </svg>
                  신고
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* 답글 입력창 */}
      {isReplying && (
        <div className="ml-8 mb-2 flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-white text-xs shrink-0">
            🍚
          </div>
          <div className="flex-1 flex items-center bg-gray-100 rounded-full px-3 py-1.5">
            <input
              type="text"
              placeholder={`@${reply.author}에게 답글...`}
              value={replyInputs[replyKey] || ""}
              onChange={(e) => onReplyInputChange(replyKey, e.target.value)}
              className="flex-1 bg-transparent text-[13px] outline-none"
              onKeyDown={(e) => e.key === "Enter" && onSubmitReply()}
              autoFocus
            />
          </div>
          <button
            className="px-3 py-1.5 bg-[#72C2FF] text-white text-[12px] font-semibold rounded-full hover:bg-[#5AB0F0] transition-colors"
            onClick={onSubmitReply}
          >
            등록
          </button>
          <button
            className="px-2 py-1.5 text-[12px] text-gray-400 hover:text-gray-600"
            onClick={onCancelReply}
          >
            취소
          </button>
        </div>
      )}

      {/* 중첩 대댓글 재귀 렌더링 */}
      {reply.replies && reply.replies.length > 0 && (
        <div className="ml-3 pl-3">
          {reply.replies.map((childReply) => (
            <ReplyItem
              key={childReply.id}
              reply={childReply}
              postId={postId}
              commentId={commentId}
              depth={depth + 1}
              likedComments={likedComments}
              dislikedComments={dislikedComments}
              followedUsers={followedUsers}
              replyingToKey={replyingToKey}
              replyInputs={replyInputs}
              onLike={onLike}
              onDislike={onDislike}
              onFollow={onFollow}
              onGift={onGift}
              onStartReply={onStartReply}
              onCancelReply={onCancelReply}
              onReplyInputChange={onReplyInputChange}
              onSubmitReply={onSubmitReply}
            />
          ))}
        </div>
      )}

      {/* 팔로우 취소 확인 팝업 */}
      {showUnfollowPopup && (
        <ConfirmPopup
          title="팔로우를 취소할까요?"
          description={`팔로우를 취소하면 ${reply.author}님이 글을 올리거나 거래할 때 알림을 받을 수 없어요.`}
          confirmText="팔로우 취소"
          cancelText="닫기"
          isDestructive
          onConfirm={() => {
            onFollow(reply.author);
            showToast(`${reply.author}님 팔로우를 취소했어요`);
            setShowUnfollowPopup(false);
          }}
          onCancel={() => setShowUnfollowPopup(false)}
        />
      )}

      {/* 차단 확인 팝업 */}
      {showBlockPopup && (
        <ConfirmPopup
          title={`${reply.author}님을 차단할까요?`}
          description={`앞으로 ${reply.author}님의 글을 볼 수 없고, ${reply.author}님도 내 글을 볼 수 없어요.`}
          confirmText="차단하기"
          cancelText="닫기"
          isDestructive
          onConfirm={() => {
            showToast(`${reply.author}님을 차단했어요`, { type: "block" });
            setShowBlockPopup(false);
          }}
          onCancel={() => setShowBlockPopup(false)}
        />
      )}

      {/* 신고 사유 선택 팝업 */}
      {showReportPopup && (
        <ReportPopup
          targetType="댓글"
          onReport={(reason) => {
            console.log("신고 사유:", reason);
            showToast("신고가 접수되었습니다");
            setShowReportPopup(false);
          }}
          onCancel={() => setShowReportPopup(false)}
        />
      )}
    </div>
  );
}
