import { useState, useCallback, useMemo, useEffect } from "react";
import { X, Check, Plus, ChevronRight } from "lucide-react";
import { useInterest } from "./InterestContext";

// ===== Props =====
interface InterestGroupSheetProps {
  galleryId: string;
  onClose: () => void;
  onComplete?: () => void;
}

// ===== 이모지 선택지 =====
const emojiOptions = [
  "🎮",
  "⚔️",
  "🏆",
  "💰",
  "📱",
  "🖥️",
  "🎯",
  "🔥",
  "⭐",
  "💎",
  "🎲",
  "🃏",
];

// ===== 메인 컴포넌트 =====
export default function InterestGroupSheet({
  galleryId,
  onClose,
  onComplete,
}: InterestGroupSheetProps) {
  const { groups, addGroup, addToGroup, removeFromGroup, getGroupsForGallery } =
    useInterest();

  // 선택된 그룹 ID들 (useState)
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);

  // 새 그룹 생성 모드 (useState)
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupEmoji, setNewGroupEmoji] = useState("🎮");

  // 초기 선택 상태 설정 (useEffect)
  useEffect(() => {
    const initialGroups = getGroupsForGallery(galleryId);
    setSelectedGroupIds(initialGroups.map((g) => g.id));
  }, [galleryId, getGroupsForGallery]);

  // 그룹 토글 (useCallback)
  const handleToggleGroup = useCallback((groupId: string) => {
    setSelectedGroupIds((prev) =>
      prev.includes(groupId)
        ? prev.filter((id) => id !== groupId)
        : [...prev, groupId],
    );
  }, []);

  // 새 그룹 생성 (useCallback)
  const handleCreateGroup = useCallback(() => {
    if (newGroupName.trim()) {
      const newId = `group_${Date.now()}`;
      // addGroup({
      //   id: newId,
      //   name: newGroupName.trim(),
      //   emoji: newGroupEmoji,
      //   galleryIds: [],
      // });
      // 생성한 그룹 자동 선택
      setSelectedGroupIds((prev) => [...prev, newId]);
      // 초기화
      setNewGroupName("");
      setNewGroupEmoji("🎮");
      setIsCreatingGroup(false);
    }
  }, [newGroupName, newGroupEmoji, addGroup]);

  // 완료 처리 (useCallback)
  const handleComplete = useCallback(() => {
    // 기존 그룹에서 제거
    groups.forEach((group) => {
      if (
        group.galleryIds.includes(galleryId) &&
        !selectedGroupIds.includes(group.id)
      ) {
        removeFromGroup(group.id, galleryId);
      }
    });

    // 새로 선택된 그룹에 추가
    selectedGroupIds.forEach((groupId) => {
      addToGroup(groupId, galleryId);
    });

    onComplete?.();
    onClose();
  }, [
    groups,
    galleryId,
    selectedGroupIds,
    removeFromGroup,
    addToGroup,
    onComplete,
    onClose,
  ]);

  // 선택된 그룹 개수 (useMemo)
  const selectedCount = useMemo(
    () => selectedGroupIds.length,
    [selectedGroupIds],
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      {/* 백드롭 */}
      <div
        className="absolute inset-0 bg-black/40 animate-fadeIn"
        onClick={onClose}
      />

      {/* 시트 */}
      <div className="relative w-full max-w-[500px] bg-white rounded-t-2xl shadow-xl animate-slideUp">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-[17px] font-bold text-gray-900">
            관심 그룹에 추가
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* 그룹 목록 */}
        <div className="px-5 py-4 max-h-[50vh] overflow-y-auto">
          {groups.length > 0 ? (
            <div className="space-y-2">
              {groups.map((group) => (
                <GroupItem
                  key={group.id}
                  group={group}
                  isSelected={selectedGroupIds.includes(group.id)}
                  onToggle={() => handleToggleGroup(group.id)}
                />
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-400 py-6">
              그룹이 없어요. 새 그룹을 만들어보세요!
            </p>
          )}

          {/* 새 그룹 생성 */}
          {isCreatingGroup ? (
            <NewGroupForm
              name={newGroupName}
              emoji={newGroupEmoji}
              onNameChange={setNewGroupName}
              onEmojiChange={setNewGroupEmoji}
              onCreate={handleCreateGroup}
              onCancel={() => setIsCreatingGroup(false)}
            />
          ) : (
            <button
              onClick={() => setIsCreatingGroup(true)}
              className="w-full flex items-center justify-center gap-2 mt-4 py-3 border border-dashed border-gray-300 rounded-xl text-[14px] font-medium text-gray-400 hover:border-[#72C2FF] hover:text-[#72C2FF] transition-colors"
            >
              <Plus size={18} />새 그룹 만들기
            </button>
          )}
        </div>

        {/* 하단 버튼 */}
        <div className="px-5 pb-5 pt-2">
          <button
            onClick={handleComplete}
            className="w-full py-3.5 rounded-xl bg-[#72C2FF] text-white font-semibold text-[15px] hover:bg-[#5AB0F0] transition-colors flex items-center justify-center gap-2"
          >
            <Check size={18} />
            {selectedCount > 0 ? `${selectedCount}개 그룹에 추가` : "완료"}
          </button>
        </div>
      </div>

      {/* 애니메이션 스타일 */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slideUp {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-fadeIn { animation: fadeIn 0.2s ease-out; }
        .animate-slideUp { animation: slideUp 0.3s ease-out; }
      `}</style>
    </div>
  );
}

// ===== 그룹 아이템 컴포넌트 =====
interface GroupItemProps {
  group: { id: string; name: string; emoji: string; galleryIds: string[] };
  isSelected: boolean;
  onToggle: () => void;
}

function GroupItem({ group, isSelected, onToggle }: GroupItemProps) {
  return (
    <button
      onClick={onToggle}
      className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all ${
        isSelected
          ? "border-[#72C2FF] bg-[#72C2FF]/5"
          : "border-gray-100 hover:border-gray-200"
      }`}
    >
      {/* 이모지 */}
      <span className="text-2xl">{group.emoji}</span>

      {/* 정보 */}
      <div className="flex-1 text-left">
        <p className="text-[15px] font-medium text-gray-900">{group.name}</p>
        <p className="text-[12px] text-gray-400">
          {group.galleryIds.length}개 갤러리
        </p>
      </div>

      {/* 체크박스 */}
      <div
        className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
          isSelected ? "bg-[#72C2FF] text-white" : "bg-gray-100"
        }`}
      >
        {isSelected && <Check size={14} />}
      </div>
    </button>
  );
}

// ===== 새 그룹 생성 폼 컴포넌트 =====
interface NewGroupFormProps {
  name: string;
  emoji: string;
  onNameChange: (name: string) => void;
  onEmojiChange: (emoji: string) => void;
  onCreate: () => void;
  onCancel: () => void;
}

function NewGroupForm({
  name,
  emoji,
  onNameChange,
  onEmojiChange,
  onCreate,
  onCancel,
}: NewGroupFormProps) {
  // 이모지 선택 상태
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // 이모지 선택 핸들러
  const handleSelectEmoji = useCallback(
    (selectedEmoji: string) => {
      onEmojiChange(selectedEmoji);
      setShowEmojiPicker(false);
    },
    [onEmojiChange],
  );

  return (
    <div className="mt-4 p-4 bg-gray-50 rounded-xl space-y-3">
      {/* 이모지 선택 */}
      <div className="relative">
        <button
          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
          className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-lg hover:border-[#72C2FF] transition-colors"
        >
          <span className="text-xl">{emoji}</span>
          <ChevronRight
            size={16}
            className={`text-gray-400 transition-transform ${
              showEmojiPicker ? "rotate-90" : ""
            }`}
          />
        </button>

        {/* 이모지 선택 드롭다운 */}
        {showEmojiPicker && (
          <div className="absolute top-full left-0 mt-2 p-2 bg-white border border-gray-200 rounded-xl shadow-lg z-10 grid grid-cols-6 gap-1">
            {emojiOptions.map((e) => (
              <button
                key={e}
                onClick={() => handleSelectEmoji(e)}
                className={`w-9 h-9 rounded-lg text-xl hover:bg-gray-100 transition-colors ${
                  emoji === e ? "bg-[#72C2FF]/10" : ""
                }`}
              >
                {e}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 이름 입력 */}
      <input
        type="text"
        value={name}
        onChange={(e) => onNameChange(e.target.value)}
        placeholder="그룹 이름을 입력하세요"
        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-[14px] placeholder:text-gray-400 focus:outline-none focus:border-[#72C2FF] transition-colors"
        autoFocus
      />

      {/* 버튼 */}
      <div className="flex gap-2">
        <button
          onClick={onCancel}
          className="flex-1 py-2.5 bg-gray-100 text-gray-600 text-[14px] font-medium rounded-lg hover:bg-gray-200 transition-colors"
        >
          취소
        </button>
        <button
          onClick={onCreate}
          disabled={!name.trim()}
          className="flex-1 py-2.5 bg-[#72C2FF] text-white text-[14px] font-medium rounded-lg hover:bg-[#5AB0F0] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          만들기
        </button>
      </div>
    </div>
  );
}
