import { useState, useMemo, useCallback } from "react";
import { Info, TrendingUp, Award, Users, Sparkles, Crown } from "lucide-react";
import { useFollow } from "./FollowContext";

// ===== 아바타 이미지 =====
const avatarImages = [
  "https://edge.ssalmuk.com/editorImage/164433adf1f74f30adf6d65de1bcf631.png",
  "https://edge.ssalmuk.com/editorImage/628e9422ca0d4d0a9c4676b282e8f370.png",
  "https://edge.ssalmuk.com/editorImage/d13662afec0a4b36b490a27aa0e44d5f.png",
  "https://edge.ssalmuk.com/editorImage/452483c1a34849f19fdd91b084f6cc6d.png",
  "https://edge.ssalmuk.com/editorImage/a5d026e2b1e74974b7291b9b0720c5c8.png",
  "https://edge.ssalmuk.com/editorImage/93460ed22a3a4a1180c5b1558d3475ae.png",
  "https://edge.ssalmuk.com/editorImage/636ec77257614b1eafd00eb6852984cd.png",
  "https://edge.ssalmuk.com/editorImage/ed19af783aad472ba506c749c1894e4a.png",
  "https://edge.ssalmuk.com/editorImage/1503bab4d1a84925883922dd3c6962e0.png",
  "https://edge.ssalmuk.com/editorImage/0490382f65a84ad584dc1d36b1336b04.png",
  "https://edge.ssalmuk.com/editorImage/c5de86eaadef4674bbe044bfec7dacfc.png",
  "https://edge.ssalmuk.com/editorImage/1c58b4cbb5914bd0bba0ae27e6dd1175.png",
  "https://edge.ssalmuk.com/editorImage/9fd9b23d0f8b47149c3a9e720d81e29c.png",
];

// ===== 랭킹 데이터 타입 =====
interface RankingItem {
  rank: number;
  name: string;
  avatar: string;
  followers: string;
  points?: string;
}

// ===== 탭 타입 =====
type TabType = "추천상위" | "리워드상위" | "팔로워급상승" | "인플루언서" | "크리에이터";

// ===== 랭킹 데이터 =====
const rankingData: Record<TabType, RankingItem[]> = {
  추천상위: [
    { rank: 1, name: "팔고나서야깨달았어", avatar: avatarImages[0], followers: "1.1만" },
    { rank: 2, name: "에펜시아", avatar: avatarImages[1], followers: "6.3천" },
    { rank: 3, name: "금손e", avatar: avatarImages[2], followers: "3.8천" },
    { rank: 4, name: "쿠우우잉", avatar: avatarImages[3], followers: "2.3천" },
    { rank: 5, name: "저평가사냥꾼", avatar: avatarImages[4], followers: "1.8천" },
    { rank: 6, name: "큰거있게사고장투", avatar: avatarImages[5], followers: "1.9천" },
    { rank: 7, name: "배당성장주민", avatar: avatarImages[6], followers: "5.5천" },
    { rank: 8, name: "Wafi와피", avatar: avatarImages[7], followers: "4.4천" },
    { rank: 9, name: "코뿔소는소일까", avatar: avatarImages[8], followers: "9.2천" },
    { rank: 10, name: "대대대대대대대대", avatar: avatarImages[9], followers: "1.2천" },
  ],
  리워드상위: [
    { rank: 1, name: "쌀먹마스터", avatar: avatarImages[10], followers: "8.2만", points: "1,523,400" },
    { rank: 2, name: "리워드헌터", avatar: avatarImages[11], followers: "5.1만", points: "1,287,200" },
    { rank: 3, name: "사전예약킹", avatar: avatarImages[12], followers: "3.7만", points: "985,600" },
    { rank: 4, name: "이벤트수집가", avatar: avatarImages[0], followers: "2.9만", points: "872,300" },
    { rank: 5, name: "무과금의정석", avatar: avatarImages[1], followers: "2.1만", points: "654,800" },
    { rank: 6, name: "꿀팁대장", avatar: avatarImages[2], followers: "1.8만", points: "543,200" },
    { rank: 7, name: "알뜰게이머", avatar: avatarImages[3], followers: "1.5만", points: "432,100" },
    { rank: 8, name: "쌀먹러123", avatar: avatarImages[4], followers: "1.2만", points: "387,500" },
    { rank: 9, name: "보상왕", avatar: avatarImages[5], followers: "9.8천", points: "298,700" },
    { rank: 10, name: "게임부자", avatar: avatarImages[6], followers: "8.5천", points: "245,300" },
  ],
  팔로워급상승: [
    { rank: 1, name: "신규스타", avatar: avatarImages[7], followers: "2.3만" },
    { rank: 2, name: "급상승러", avatar: avatarImages[8], followers: "1.8만" },
    { rank: 3, name: "떠오르는별", avatar: avatarImages[9], followers: "1.5만" },
    { rank: 4, name: "핫루키", avatar: avatarImages[10], followers: "1.2만" },
    { rank: 5, name: "뉴페이스", avatar: avatarImages[11], followers: "9.8천" },
    { rank: 6, name: "신예게이머", avatar: avatarImages[12], followers: "8.5천" },
    { rank: 7, name: "차세대스타", avatar: avatarImages[0], followers: "7.2천" },
    { rank: 8, name: "성장중", avatar: avatarImages[1], followers: "6.1천" },
    { rank: 9, name: "주목받는자", avatar: avatarImages[2], followers: "5.3천" },
    { rank: 10, name: "기대주", avatar: avatarImages[3], followers: "4.7천" },
  ],
  인플루언서: [
    { rank: 1, name: "게임킹", avatar: avatarImages[4], followers: "52.3만" },
    { rank: 2, name: "프로게이머A", avatar: avatarImages[5], followers: "48.1만" },
    { rank: 3, name: "유명스트리머", avatar: avatarImages[6], followers: "35.7만" },
    { rank: 4, name: "게임유튜버", avatar: avatarImages[7], followers: "28.9만" },
    { rank: 5, name: "인기BJ", avatar: avatarImages[8], followers: "21.2만" },
    { rank: 6, name: "공략마스터", avatar: avatarImages[9], followers: "18.5만" },
    { rank: 7, name: "리뷰전문가", avatar: avatarImages[10], followers: "15.2만" },
    { rank: 8, name: "겜덕후", avatar: avatarImages[11], followers: "12.8만" },
    { rank: 9, name: "게임칼럼니스트", avatar: avatarImages[12], followers: "10.1만" },
    { rank: 10, name: "e스포츠해설", avatar: avatarImages[0], followers: "8.7만" },
  ],
  크리에이터: [
    { rank: 1, name: "공략장인", avatar: avatarImages[1], followers: "15.8만" },
    { rank: 2, name: "팁스터", avatar: avatarImages[2], followers: "12.3만" },
    { rank: 3, name: "영상제작자", avatar: avatarImages[3], followers: "9.8만" },
    { rank: 4, name: "일러스트작가", avatar: avatarImages[4], followers: "8.5만" },
    { rank: 5, name: "콘텐츠메이커", avatar: avatarImages[5], followers: "7.2만" },
    { rank: 6, name: "게임아티스트", avatar: avatarImages[6], followers: "6.1만" },
    { rank: 7, name: "정보요정", avatar: avatarImages[7], followers: "5.3만" },
    { rank: 8, name: "뉴스봇", avatar: avatarImages[8], followers: "4.7만" },
    { rank: 9, name: "이벤트알리미", avatar: avatarImages[9], followers: "3.9만" },
    { rank: 10, name: "꿀정보러", avatar: avatarImages[10], followers: "3.2만" },
  ],
};

// ===== 탭 설정 =====
const tabs: TabType[] = ["추천상위", "리워드상위", "팔로워급상승", "인플루언서", "크리에이터"];

const tabIcons: Record<TabType, React.ReactNode> = {
  추천상위: <TrendingUp size={14} />,
  리워드상위: <Award size={14} />,
  팔로워급상승: <Sparkles size={14} />,
  인플루언서: <Crown size={14} />,
  크리에이터: <Users size={14} />,
};

// ===== Props =====
interface RankingContentProps {
  onProfileClick?: (userName: string) => void;
}

// ===== 메인 컴포넌트 =====
export default function RankingContent({ onProfileClick }: RankingContentProps) {
  const [activeTab, setActiveTab] = useState<TabType>("추천상위");
  const [showInfoPopup, setShowInfoPopup] = useState(false);
  const { isFollowing, toggleFollow } = useFollow();

  // 현재 탭 데이터 (useMemo)
  const currentData = useMemo(() => rankingData[activeTab], [activeTab]);

  // 탭 변경 핸들러 (useCallback)
  const handleTabChange = useCallback((tab: TabType) => {
    setActiveTab(tab);
  }, []);

  // 팔로우 토글 핸들러 (useCallback)
  const handleToggleFollow = useCallback(
    (userName: string) => {
      toggleFollow(userName);
    },
    [toggleFollow]
  );

  // 프로필 클릭 핸들러 (useCallback)
  const handleProfileClick = useCallback(
    (userName: string) => {
      onProfileClick?.(userName);
    },
    [onProfileClick]
  );

  return (
    <div className="flex flex-col h-full">
      {/* 헤더 */}
      <div className="flex items-center justify-between px-1 py-3">
        <h2 className="text-[18px] font-bold text-[#1A1A2E]">
          주간 커뮤니티 프로필 랭킹
        </h2>
        <button
          onClick={() => setShowInfoPopup(true)}
          className="p-1.5 text-gray-400 hover:text-[#72C2FF] hover:bg-gray-100 rounded-lg transition-colors"
        >
          <Info size={18} />
        </button>
      </div>

      {/* 탭 */}
      <div className="flex items-center gap-2 pb-4 overflow-x-auto hide-scrollbar">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => handleTabChange(tab)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-colors ${
              activeTab === tab
                ? "bg-[#72C2FF] text-white"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {tabIcons[tab]}
            {tab}
          </button>
        ))}
      </div>

      {/* 순위 리스트 */}
      <div className="flex-1 overflow-y-auto">
        <div className="bg-white rounded-xl border border-gray-100 divide-y divide-gray-100">
          {currentData.map((item) => (
            <RankingItemRow
              key={`${activeTab}-${item.rank}`}
              item={item}
              activeTab={activeTab}
              isFollowing={isFollowing(item.name)}
              onToggleFollow={handleToggleFollow}
              onProfileClick={handleProfileClick}
            />
          ))}
        </div>

        {/* 하단 안내 */}
        <p className="text-[11px] text-gray-400 text-center py-4">
          매일 오전/오후 6시 집계 (최근 7일 기준)
        </p>
      </div>

      {/* 안내 팝업 */}
      {showInfoPopup && (
        <InfoPopup onClose={() => setShowInfoPopup(false)} />
      )}

      {/* 스크롤바 숨김 스타일 */}
      <style>{`
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}

// ===== 랭킹 아이템 Row 컴포넌트 =====
interface RankingItemRowProps {
  item: RankingItem;
  activeTab: TabType;
  isFollowing: boolean;
  onToggleFollow: (userName: string) => void;
  onProfileClick: (userName: string) => void;
}

function RankingItemRow({
  item,
  activeTab,
  isFollowing,
  onToggleFollow,
  onProfileClick,
}: RankingItemRowProps) {
  return (
    <div className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors">
      {/* 순위 */}
      <div
        className={`w-7 text-center text-[15px] font-bold ${
          item.rank <= 3 ? "text-[#72C2FF]" : "text-gray-400"
        }`}
      >
        {item.rank}
      </div>

      {/* 프로필 이미지 */}
      <div
        className="w-11 h-11 rounded-full overflow-hidden bg-gray-100 flex-shrink-0 cursor-pointer hover:ring-2 hover:ring-[#72C2FF] transition-all"
        onClick={() => onProfileClick(item.name)}
      >
        <img
          src={item.avatar}
          alt={item.name}
          className="w-full h-full object-cover"
        />
      </div>

      {/* 정보 */}
      <div className="flex-1 min-w-0">
        <h3
          className="text-[15px] font-medium text-gray-900 truncate cursor-pointer hover:text-[#72C2FF] transition-colors"
          onClick={() => onProfileClick(item.name)}
        >
          {item.name}
        </h3>
        <p className="text-[13px] text-gray-400">
          {activeTab === "리워드상위" && item.points
            ? `${item.points}P 획득`
            : `팔로워 ${item.followers}`}
        </p>
      </div>

      {/* 팔로우 버튼 */}
      <button
        onClick={() => onToggleFollow(item.name)}
        className={`px-4 py-1.5 text-[13px] font-medium rounded-full transition-all ${
          isFollowing
            ? "bg-gray-100 text-gray-500 hover:bg-gray-200"
            : "bg-[#72C2FF] text-white hover:bg-[#5AB0F0]"
        }`}
      >
        {isFollowing ? "팔로잉" : "팔로우"}
      </button>
    </div>
  );
}

// ===== 안내 팝업 컴포넌트 =====
interface InfoPopupProps {
  onClose: () => void;
}

function InfoPopup({ onClose }: InfoPopupProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 백드롭 */}
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />

      {/* 팝업 */}
      <div className="relative bg-white rounded-2xl mx-6 max-w-[400px] w-full max-h-[80vh] overflow-y-auto shadow-xl">
        <div className="p-5">
          {/* 타이틀 */}
          <h2 className="text-[17px] font-bold text-gray-900 mb-4">
            프로필 랭킹 안내
          </h2>

          {/* 안내 텍스트 */}
          <div className="text-[13px] text-gray-600 space-y-1 mb-6">
            <p>
              * 모든 랭킹은 매일 오전 6시, 오후 6시 2회, 해당일자 최근 7일
              기준으로 집계됩니다.
            </p>
            <p>* 랭킹은 사용자 활동 데이터를 기준으로 산출됩니다.</p>
            <p>
              * 일부 데이터는 집계 시점에 따라 실시간과 차이가 있을 수 있습니다.
            </p>
            <p>
              * 이용규칙에 따라 이용 정지된 프로필은 랭킹에 포함되지 않습니다.
            </p>
          </div>

          {/* 랭킹별 기준 */}
          <h3 className="text-[15px] font-bold text-gray-900 mb-3">
            프로필 랭킹별 기준
          </h3>

          <div className="space-y-4 text-[13px]">
            <div>
              <p className="font-semibold text-gray-800">* 추천 상위</p>
              <p className="text-gray-500 ml-2">
                최근 7일동안 추천 점수가 높은 순으로 보여줍니다.
              </p>
            </div>

            <div>
              <p className="font-semibold text-gray-800">* 리워드 상위</p>
              <p className="text-gray-500 ml-2">
                최근 7일동안 획득한 리워드가 많은 순으로 보여줍니다.
              </p>
            </div>

            <div>
              <p className="font-semibold text-gray-800">* 팔로워 급상승</p>
              <p className="text-gray-500 ml-2">
                최근 7일동안 팔로워가 가장 많이 증가한 순으로 보여줍니다.
              </p>
            </div>

            <div>
              <p className="font-semibold text-gray-800">* 인플루언서</p>
              <p className="text-gray-500 ml-2">
                누적 팔로워 수가 많은 순으로 보여줍니다.
              </p>
            </div>

            <div>
              <p className="font-semibold text-gray-800">* 크리에이터</p>
              <p className="text-gray-500 ml-2">
                유튜버 등 최근 7일동안 추천 점수가 높은 순으로 보여줍니다.
              </p>
            </div>
          </div>
        </div>

        {/* 확인 버튼 */}
        <div className="px-5 pb-5">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-[#72C2FF] text-white font-semibold text-[15px] hover:bg-[#5AB0F0] transition-colors"
          >
            확인
          </button>
        </div>
      </div>
    </div>
  );
}
