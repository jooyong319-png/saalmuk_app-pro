import type { PostData, Comment, ReplyTarget } from "./types";
import CommentSection from "./CommentSection";
import DropdownMenu, { getPostMenuItems } from "./DropdownMenu";

interface PostCardFullProps {
  post: PostData;
  index: number;
  comments: Comment[];
  isLiked: boolean;
  isDisliked: boolean;
  isFollowed: boolean;
  isCommentsExpanded: boolean;
  commentInput: string;
  replyingTo: ReplyTarget | null;
  replyInputs: { [key: string]: string };
  likedComments: string[];
  dislikedComments: string[];
  followedUsers: string[];
  highlightedComment: string | null;
  commentRefs: React.MutableRefObject<{ [key: string]: HTMLDivElement | null }>;
  onLike: () => void;
  onDislike: () => void;
  onFollow: (name: string) => void;
  onToggleComments: () => void;
  onShowGiftPopup: () => void;
  onShowProfile: () => void;
  onCommentInputChange: (value: string) => void;
  onSubmitComment: () => void;
  onCommentLike: (key: string) => void;
  onCommentDislike: (key: string) => void;
  onCommentGift: (key: string) => void;
  onStartReply: (key: string, author: string) => void;
  onCancelReply: () => void;
  onReplyInputChange: (key: string, value: string) => void;
  onSubmitReply: (commentId: number) => void;
  onScrollToComment: (commentId: number) => void;
}

export default function PostCardFull({
  post,
  index,
  comments,
  isLiked,
  isDisliked,
  isFollowed,
  isCommentsExpanded,
  commentInput,
  replyingTo,
  replyInputs,
  likedComments,
  dislikedComments,
  followedUsers,
  highlightedComment,
  commentRefs,
  onLike,
  onDislike,
  onFollow,
  onToggleComments,
  onShowGiftPopup,
  onShowProfile,
  onCommentInputChange,
  onSubmitComment,
  onCommentLike,
  onCommentDislike,
  onCommentGift,
  onStartReply,
  onCancelReply,
  onReplyInputChange,
  onSubmitReply,
  onScrollToComment,
}: PostCardFullProps) {
  return (
    <div
      className="py-4 border-b border-gray-100 animate-fadeUp"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* 작성자 정보 */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-lg cursor-pointer hover:scale-105 transition-transform"
            style={{ background: post.avatarBg }}
            onClick={onShowProfile}
          >
            {post.avatar}
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <p
                className="text-[14px] font-semibold text-gray-900 cursor-pointer hover:underline"
                onClick={onShowProfile}
              >
                {post.name}
              </p>
              {post.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-600 font-medium">
                  {post.badge}
                </span>
              )}
            </div>
            <p className="text-[12px] text-gray-400">{post.meta}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* 더보기 메뉴 - DropdownMenu 적용 */}
          <DropdownMenu
            size="lg"
            items={getPostMenuItems({
              onShare: () => console.log("공유"),
              onSave: () => console.log("저장"),
              onBlock: () => console.log("차단"),
              onReport: () => console.log("신고"),
            })}
          />
          <button
            className={`text-[13px] font-semibold px-3 py-1 rounded-full transition-colors ${
              isFollowed
                ? "text-gray-400 bg-gray-100"
                : "text-[#72C2FF] bg-[#E8F4FD]"
            }`}
            onClick={() => onFollow(post.name)}
          >
            {isFollowed ? "팔로잉" : "팔로우"}
          </button>
        </div>
      </div>

      {/* 게시글 내용 */}
      <div>
        <h3 className="text-[15px] font-bold text-gray-900 mb-2 leading-snug">
          {post.title}
        </h3>
        <p className="text-[14px] text-gray-600 mb-3 line-clamp-2">
          {typeof post.body === "string"
            ? post.body
            : post.body
                .filter((b) => b.type === "text")
                .map((b) => b.content)
                .join(" ")}
        </p>
      </div>

      {/* 액션 버튼 */}
      <div className="flex items-center justify-between text-gray-400">
        <div className="flex items-center gap-1">
          {/* 좋아요 */}
          <button
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors ${
              isLiked ? "text-blue-500" : ""
            }`}
            onClick={onLike}
          >
            <svg
              className="w-5 h-5"
              fill={isLiked ? "currentColor" : "none"}
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3zM7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3"
              />
            </svg>
            <span className="text-[13px]">
              {isLiked ? post.likes + 1 : post.likes}
            </span>
          </button>

          {/* 싫어요 */}
          <button
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors ${
              isDisliked ? "text-red-400" : ""
            }`}
            onClick={onDislike}
          >
            <svg
              className="w-5 h-5"
              fill={isDisliked ? "currentColor" : "none"}
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M10 15v4a3 3 0 003 3l4-9V2H5.72a2 2 0 00-2 1.7l-1.38 9a2 2 0 002 2.3zm7-13h2.67A2.31 2.31 0 0122 4v7a2.31 2.31 0 01-2.33 2H17"
              />
            </svg>
            <span className="text-[13px]">
              {isDisliked ? (post.dislikes || 0) + 1 : post.dislikes || 0}
            </span>
          </button>

          {/* 댓글 */}
          <button
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors ${
              isCommentsExpanded ? "text-[#72C2FF]" : ""
            }`}
            onClick={onToggleComments}
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              />
            </svg>
            <span className="text-[13px]">{post.comments}</span>
          </button>

          {/* 선물 */}
          <button
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={onShowGiftPopup}
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
              />
            </svg>
          </button>
        </div>

        {/* 조회수 */}
        <span className="flex items-center gap-1 text-[13px] text-gray-400">
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
            />
          </svg>
          {post.views.toLocaleString()}
        </span>
      </div>

      {/* 댓글 섹션 */}
      {isCommentsExpanded && (
        <CommentSection
          postId={post.id}
          comments={comments}
          commentInput={commentInput}
          replyingTo={replyingTo}
          replyInputs={replyInputs}
          likedComments={likedComments}
          dislikedComments={dislikedComments}
          followedUsers={followedUsers}
          highlightedComment={highlightedComment}
          commentRefs={commentRefs}
          onCommentInputChange={onCommentInputChange}
          onSubmitComment={onSubmitComment}
          onCommentLike={onCommentLike}
          onCommentDislike={onCommentDislike}
          onCommentGift={onCommentGift}
          onFollow={onFollow}
          onStartReply={onStartReply}
          onCancelReply={onCancelReply}
          onReplyInputChange={onReplyInputChange}
          onSubmitReply={onSubmitReply}
          onScrollToComment={onScrollToComment}
        />
      )}
    </div>
  );
}
