// ===== Context Providers =====
export { InterestProvider, useInterest } from "./InterestContext";
export { RecentProvider, useRecent } from "./RecentContext";
export { FollowProvider, useFollow } from "./FollowContext";

// ===== 신규 컴포넌트 =====
export { default as LeftSidebar } from "./LeftSidebar";
export { default as NewsContent } from "./NewsContent";
export { default as InterestContent } from "./InterestContent";
export { default as RankingContent } from "./RankingContent";
export { default as GalleryDetailContent } from "./GalleryDetailContent";
export { default as InterestGroupSheet } from "./InterestGroupSheet";
export { default as GalleryPage } from "../../pages/GalleryPage";
export { default as ProfilePage } from "../../pages/ProfilePage";

// ===== 데이터 =====
export {
  galleries,
  galleryTabs,
  galleryCategories,
  defaultCategoryTabs,
  getGalleryById,
  getGalleryByName,
  getGalleriesByCategory,
  getAllGalleries,
  searchGalleries,
  getGalleryIdByName,
  getGalleryCategoryTabs,
  getGallerySortType,
} from "./galleryData";
export type { GalleryData, GalleryCategory } from "./galleryData";

// ===== 타입 =====
export * from "./types";