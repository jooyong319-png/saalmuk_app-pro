import { useState, useRef } from "react";
import type { PostData } from "./types";

// ─── 갤러리 내 카테고리 ───
const galleryCategories = ["수다", "공략,팁", "질문", "스샷,자랑", "거래"];

interface WritePostModalProps {
  galleryName: string;
  onClose: () => void;
  onSubmit: (post: PostData) => void;
}

export default function WritePostModal({
  galleryName,
  onClose,
  onSubmit,
}: WritePostModalProps) {
  const [category, setCategory] = useState(galleryCategories[0]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 투표 상태
  const [showPoll, setShowPoll] = useState(false);
  const [pollOptions, setPollOptions] = useState<string[]>(["", ""]);

  const MAX_CONTENT_LENGTH = 2000;
  const MIN_POLL_OPTIONS = 2;
  const MAX_POLL_OPTIONS = 5;

  // 이미지 추가
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setImages((prev) => [...prev, event.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  // 이미지 제거
  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  // 투표 선택지 변경
  const handlePollOptionChange = (index: number, value: string) => {
    const newOptions = [...pollOptions];
    newOptions[index] = value;
    setPollOptions(newOptions);
  };

  // 투표 선택지 추가
  const addPollOption = () => {
    if (pollOptions.length < MAX_POLL_OPTIONS) {
      setPollOptions([...pollOptions, ""]);
    }
  };

  // 투표 선택지 삭제
  const removePollOption = (index: number) => {
    if (pollOptions.length > MIN_POLL_OPTIONS) {
      setPollOptions(pollOptions.filter((_, i) => i !== index));
    }
  };

  // 투표 삭제
  const removePoll = () => {
    setShowPoll(false);
    setPollOptions(["", ""]);
  };

  // 글 작성
  const handleSubmit = () => {
    if (!title.trim() || !content.trim()) return;

    setIsSubmitting(true);

    // 투표 데이터 생성
    const pollData = showPoll && pollOptions.filter(opt => opt.trim()).length >= 2
      ? {
          options: pollOptions
            .filter(opt => opt.trim())
            .map(text => ({ text: text.trim(), votes: 0 })),
          totalVotes: 0,
        }
      : undefined;

    const newPost: PostData = {
      id: Date.now(),
      avatar: "🍚",
      avatarBg: "linear-gradient(135deg,#72C2FF,#4AABF5)",
      name: "나",
      badge: "",
      meta: `방금 전 · ${category}`,
      title: title.trim(),
      body: content.trim(),
      likes: 0,
      dislikes: 0,
      comments: 0,
      views: 0,
      boardId: galleryName,
      authorId: "me",
      isVerified: false,
      createdAt: Date.now(),
      images: images.length > 0 ? images : undefined,
      category: category,
      poll: pollData,
    };

    setTimeout(() => {
      onSubmit(newPost);
      setIsSubmitting(false);
    }, 300);
  };

  // 제목, 내용 1글자 이상이면 활성화
  const isValid = title.trim().length >= 1 && content.trim().length >= 1;
  const remainingChars = MAX_CONTENT_LENGTH - content.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 배경 오버레이 */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* 모달 */}
      <div className="relative w-full max-w-[600px] max-h-[90vh] bg-white rounded-xl shadow-2xl flex flex-col animate-fadeUp mx-4">
        {/* 헤더 */}
        <div className="flex items-center justify-center px-5 py-4 border-b border-gray-100 relative">
          <button
            onClick={onClose}
            className="absolute left-5 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <svg
              width="24"
              height="24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <path d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <h2 className="text-[16px] font-bold text-gray-900">글쓰기</h2>
        </div>

        {/* 본문 */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-5 space-y-4">
          {/* 갤러리 정보 */}
          <div className="flex items-center gap-1 text-[14px]">
            <span className="font-semibold text-gray-900">{galleryName}</span>
            <span className="text-gray-400">갤러리에 글 작성</span>
          </div>

          {/* 카테고리 선택 */}
          <div className="flex flex-wrap gap-2">
            {galleryCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-4 py-2 text-[13px] font-medium rounded-full transition-colors ${
                  category === cat
                    ? "bg-[#72C2FF] text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* 제목 입력 */}
          <input
            type="text"
            placeholder="제목을 입력하세요"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={100}
            className="w-full px-4 py-3.5 text-[15px] bg-gray-100 border-0 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#72C2FF]/30 focus:bg-white transition-all placeholder:text-gray-400"
          />

          {/* 내용 입력 + 투표 통합 영역 */}
          <div className="bg-gray-100 rounded-xl overflow-hidden">
            <textarea
              placeholder="내용을 입력하세요"
              value={content}
              onChange={(e) => {
                if (e.target.value.length <= MAX_CONTENT_LENGTH) {
                  setContent(e.target.value);
                }
              }}
              rows={showPoll ? 4 : 10}
              className="w-full px-4 py-3.5 text-[15px] bg-transparent border-0 focus:outline-none transition-all placeholder:text-gray-400 resize-none"
            />

            {/* 투표 UI - 내용 영역 안 */}
            {showPoll && (
              <div className="px-4 pb-4 space-y-2">
                {/* 선택지 목록 */}
                {pollOptions.map((option, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder={`선택지 ${index + 1}`}
                      value={option}
                      onChange={(e) =>
                        handlePollOptionChange(index, e.target.value)
                      }
                      maxLength={50}
                      className="flex-1 px-4 py-3 text-[14px] bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-[#72C2FF] transition-all placeholder:text-gray-400"
                    />
                    {pollOptions.length > MIN_POLL_OPTIONS && (
                      <button
                        onClick={() => removePollOption(index)}
                        className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-white rounded-xl transition-colors"
                      >
                        <svg
                          width="18"
                          height="18"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.5"
                          viewBox="0 0 24 24"
                        >
                          <path d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    )}
                  </div>
                ))}

                {/* 하단: 선택지 추가 + 삭제 */}
                <div className="flex items-center justify-between pt-1">
                  {pollOptions.length < MAX_POLL_OPTIONS ? (
                    <button
                      onClick={addPollOption}
                      className="flex items-center gap-1 text-[13px] text-[#72C2FF] hover:text-[#5BB0F0] font-medium transition-colors"
                    >
                      <svg
                        width="14"
                        height="14"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 5v14m-7-7h14" />
                      </svg>
                      선택지 추가
                    </button>
                  ) : (
                    <span className="text-[12px] text-gray-400">
                      최대 {MAX_POLL_OPTIONS}개
                    </span>
                  )}
                  <button
                    onClick={removePoll}
                    className="text-[13px] text-gray-400 hover:text-red-500 transition-colors"
                  >
                    삭제
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 이미지 미리보기 */}
          {images.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {images.map((img, index) => (
                <div key={index} className="relative group">
                  <img
                    src={img}
                    alt={`업로드 이미지 ${index + 1}`}
                    className="w-24 h-24 object-cover rounded-lg border border-gray-200"
                  />
                  <button
                    onClick={() => removeImage(index)}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <svg
                      width="12"
                      height="12"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                    >
                      <path d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 하단 툴바 */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-gray-100 bg-white rounded-b-xl">
          <div className="flex items-center gap-1">
            {/* 이미지 첨부 */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              multiple
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="group relative flex items-center gap-1 p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <svg
                width="20"
                height="20"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                viewBox="0 0 24 24"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <path d="m21 15-5-5L5 21" />
              </svg>
              {/* 호버 툴팁 - 아래로 */}
              <span className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-2.5 py-1.5 text-[12px] text-gray-700 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50">
                사진
              </span>
            </button>

            {/* 이모지 */}
            <button className="group relative flex items-center gap-1 p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
              <svg
                width="20"
                height="20"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                viewBox="0 0 24 24"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M8 14s1.5 2 4 2 4-2 4-2" />
                <line x1="9" y1="9" x2="9.01" y2="9" />
                <line x1="15" y1="9" x2="15.01" y2="9" />
              </svg>
              {/* 호버 툴팁 - 아래로 */}
              <span className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-2.5 py-1.5 text-[12px] text-gray-700 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50">
                이모지
              </span>
            </button>

            {/* 투표 */}
            <button
              onClick={() => setShowPoll(!showPoll)}
              className={`group relative flex items-center gap-1 p-2 rounded-lg transition-colors ${
                showPoll
                  ? "text-[#72C2FF] bg-[#E8F4FD]"
                  : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
              }`}
            >
              <svg
                width="20"
                height="20"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                viewBox="0 0 24 24"
              >
                <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" />
                <rect x="9" y="3" width="6" height="4" rx="1" />
                <path d="M9 14l2 2 4-4" />
              </svg>
              {/* 호버 툴팁 - 아래로 */}
              <span className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-2.5 py-1.5 text-[12px] text-gray-700 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50">
                투표
              </span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            {/* 남은 글자 수 */}
            <span
              className={`text-[13px] ${remainingChars < 100 ? "text-red-500" : "text-gray-400"}`}
            >
              {remainingChars.toLocaleString()}
            </span>

            {/* 남기기 버튼 */}
            <button
              onClick={handleSubmit}
              disabled={!isValid || isSubmitting}
              className={`px-5 py-2 text-[14px] font-semibold rounded-lg transition-all ${
                isValid && !isSubmitting
                  ? "bg-[#72C2FF] text-white hover:bg-[#5BB0F0]"
                  : "bg-gray-200 text-gray-400 cursor-not-allowed"
              }`}
            >
              {isSubmitting ? "등록 중..." : "남기기"}
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeUp { animation: fadeUp 0.3s ease-out both; }
      `}</style>
    </div>
  );
}
