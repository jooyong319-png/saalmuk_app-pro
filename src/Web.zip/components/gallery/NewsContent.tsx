import { useState, useRef, useEffect, useCallback, Fragment } from "react";
import PostCardFull from "./PostCardFull";
import PostListItem from "./PostListItem";
import PostDetail from "./PostDetail";
import GiftPopup from "./GiftPopup";
import ProfilePopup from "./ProfilePopup";
import AdCard from "./AdCard";
import AdListItem from "./AdListItem";
import { useToast } from "./Toast";
import type { PostData, Comment, ReplyTarget, Reply } from "./types";

// ─── 상대 시간 계산 ───
const getRelativeTime = (timestamp: number): string => {
  const now = Date.now();
  const diff = now - timestamp;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return "방금 전";
  if (minutes < 60) return `${minutes}분 전`;
  if (hours < 24) return `${hours}시간 전`;
  if (days < 7) return `${days}일 전`;
  return new Date(timestamp).toLocaleDateString("ko-KR");
};

// ─── 애니메이션 스타일 ───
const animationStyles = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeUp { animation: fadeUp 0.5s ease-out both; }
  .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  .hide-scrollbar::-webkit-scrollbar { display: none; }
`;

// ─── 광고 데이터 ───
const cardAd = {
  id: "ad-news-card-1",
  avatar: "📰",
  avatarBg: "#E8F4FD",
  name: "게임뉴스 프리미엄",
  time: "광고",
  media: {
    type: "image" as const,
    src: "https://picsum.photos/800/450?random=newsad1",
  },
  title: "게임 뉴스를 가장 빠르게! 프리미엄 구독으로 광고 없이 즐기세요",
  link: "https://example.com",
};

const listAd = {
  id: "ad-news-list-1",
  thumbnail: "https://picsum.photos/100/100?random=newsad2",
  name: "게임뉴스 프리미엄",
  description:
    "프리미엄 구독 시 모든 기사 광고 없이 읽기, 독점 인터뷰, 얼리 액세스 제공",
  link: "https://example.com",
};

// ─── 뉴스 기사 데이터 ───
const newsArticles: PostData[] = [
  {
    id: 2001,
    name: "게임조선",
    avatar: "📰",
    avatarBg: "#E8F4FD",
    badge: "공식 미디어",
    meta: "2시간 전",
    createdAt: Date.now() - 2 * 60 * 60 * 1000,
    title:
      "넥슨, 신작 MMORPG '더 퍼스트 디센던트' 글로벌 동시 접속자 100만 돌파",
    body: "넥슨의 신작 루터슈터 '더 퍼스트 디센던트'가 출시 첫 주 글로벌 동시 접속자 100만 명을 돌파했다. 스팀 차트 기준 최고 동시 접속자는 26만 명을 기록했으며, PS5와 Xbox 시리즈 X|S에서도 폭발적인 반응을 얻고 있다. 넥슨 관계자는 '예상을 뛰어넘는 성과'라며 추가 콘텐츠 업데이트 계획을 밝혔다.",
    images: ["https://picsum.photos/800/450?random=news1"],
    likes: 1520,
    dislikes: 23,
    comments: 342,
    views: 125400,
    category: "게임뉴스",
  },
  {
    id: 2002,
    name: "게임인사이트",
    avatar: "📊",
    avatarBg: "#FEF3E2",
    badge: "게임 전문지",
    meta: "3시간 전",
    createdAt: Date.now() - 3 * 60 * 60 * 1000,
    title: "2024년 상반기 모바일 게임 매출 순위 발표... 리니지M 1위 수성",
    body: "한국 모바일 게임 시장에서 리니지M이 올해 상반기에도 1위 자리를 지켰다. 2위는 리니지W, 3위는 오딘: 발할라 라이징이 차지했으며 신작 게임들의 약진도 두드러졌다. 특히 신작 '승리의 여신: 니케'가 4위로 급상승하며 새로운 강자로 떠올랐다.",
    images: ["https://picsum.photos/800/450?random=news2"],
    likes: 892,
    dislikes: 15,
    comments: 256,
    views: 89200,
    category: "업계동향",
  },
  {
    id: 2003,
    name: "쌀먹닷컴",
    avatar: "🍚",
    avatarBg: "#E8F8E8",
    badge: "쌀먹 공식",
    meta: "4시간 전",
    createdAt: Date.now() - 4 * 60 * 60 * 1000,
    title: "[꿀팁] 이번 주 사전예약 보상 총정리! 최대 30만원 상당 혜택",
    body: "이번 주 진행 중인 사전예약 이벤트를 총정리했습니다. '프로젝트 문라이트' 사전예약 시 SSR 캐릭터 교환권, '블레이드 앤 소울2'는 레전더리 무기 세트 지급, '아키에이지2'는 30일 프리미엄 이용권을 제공합니다. 놓치지 마세요!",
    images: ["https://picsum.photos/800/450?random=news3"],
    likes: 3241,
    dislikes: 8,
    comments: 892,
    views: 203100,
    category: "쌀먹정보",
    isVerified: true,
  },
  {
    id: 2004,
    name: "게임메카",
    avatar: "🎮",
    avatarBg: "#F3E8FD",
    badge: "공식 미디어",
    meta: "5시간 전",
    createdAt: Date.now() - 5 * 60 * 60 * 1000,
    title:
      "엘든 링 DLC '그림자나무의 숲' 스팀 역대급 호평... 동시접속 90만 돌파",
    body: "프롬소프트웨어의 '엘든 링' 첫 DLC '그림자나무의 숲'이 출시와 동시에 스팀 동시 접속자 90만 명을 돌파했다. 유저 평가는 '압도적 긍정적'으로, 본편의 명성을 이어가고 있다. 미야자키 히데타카 디렉터는 '팬들의 기대에 부응하기 위해 최선을 다했다'고 소감을 밝혔다.",
    images: ["https://picsum.photos/800/450?random=news4"],
    likes: 2103,
    dislikes: 45,
    comments: 521,
    views: 156800,
    category: "게임뉴스",
  },
  {
    id: 2005,
    name: "게임포커스",
    avatar: "🔍",
    avatarBg: "#FDE8E8",
    badge: "게임 전문지",
    meta: "6시간 전",
    createdAt: Date.now() - 6 * 60 * 60 * 1000,
    title: "마이크로소프트, 베데스다 신작 '스타필드' 확장팩 9월 출시 확정",
    body: "마이크로소프트가 베데스다 게임 스튜디오의 '스타필드' 첫 번째 대규모 확장팩 '쉐터드 스페이스'를 오는 9월 30일 출시한다고 발표했다. 새로운 행성, 스토리, 장비가 추가되며 게임패스 가입자는 무료로 이용 가능하다.",
    images: ["https://picsum.photos/800/450?random=news5"],
    likes: 756,
    dislikes: 32,
    comments: 189,
    views: 78300,
    category: "업계동향",
  },
  {
    id: 2006,
    name: "쌀먹닷컴",
    avatar: "🍚",
    avatarBg: "#E8F8E8",
    badge: "쌀먹 공식",
    meta: "7시간 전",
    createdAt: Date.now() - 7 * 60 * 60 * 1000,
    title: "[속보] 카카오게임즈, 신규 유저 대상 100연차 무료 이벤트 진행",
    body: "카카오게임즈가 자사 인기 게임 '우마무스메'에서 신규 유저를 대상으로 100연차 무료 소환 이벤트를 진행한다. 이벤트 기간은 7월 1일부터 7월 31일까지이며, 복귀 유저에게도 50연차가 제공된다. 지금 바로 시작하세요!",
    images: ["https://picsum.photos/800/450?random=news6"],
    likes: 4521,
    dislikes: 12,
    comments: 1243,
    views: 312500,
    category: "쌀먹정보",
    isVerified: true,
  },
  {
    id: 2007,
    name: "게임샷",
    avatar: "📸",
    avatarBg: "#E8F4FD",
    badge: "공식 미디어",
    meta: "8시간 전",
    createdAt: Date.now() - 8 * 60 * 60 * 1000,
    title:
      "라이엇게임즈, '발로란트' 신규 에이전트 '클로브' 공개... 자가 부활 스킬 탑재",
    body: "라이엇게임즈가 '발로란트'의 25번째 에이전트 '클로브'를 공개했다. 클로브는 컨트롤러 역할로, 특이하게도 사망 후 자가 부활이 가능한 궁극기를 보유하고 있다. 프로 선수들 사이에서 메타 변화에 대한 기대와 우려가 동시에 나오고 있다.",
    images: ["https://picsum.photos/800/450?random=news7"],
    likes: 1876,
    dislikes: 28,
    comments: 432,
    views: 145200,
    category: "게임뉴스",
  },
  {
    id: 2008,
    name: "게임동아",
    avatar: "📈",
    avatarBg: "#FEF3E2",
    badge: "게임 전문지",
    meta: "9시간 전",
    createdAt: Date.now() - 9 * 60 * 60 * 1000,
    title: "한국 게임 시장 규모 20조원 돌파 전망... e스포츠 산업도 급성장",
    body: "한국콘텐츠진흥원에 따르면 올해 국내 게임 시장 규모가 사상 처음으로 20조원을 돌파할 것으로 전망된다. 특히 e스포츠 산업은 전년 대비 25% 성장하며 글로벌 시장에서 한국의 위상을 높이고 있다. 정부도 게임 산업 지원 정책을 확대할 예정이다.",
    images: ["https://picsum.photos/800/450?random=news8"],
    likes: 543,
    dislikes: 18,
    comments: 156,
    views: 67900,
    category: "업계동향",
  },
  {
    id: 2009,
    name: "게임조선",
    avatar: "📰",
    avatarBg: "#E8F4FD",
    badge: "공식 미디어",
    meta: "10시간 전",
    createdAt: Date.now() - 10 * 60 * 60 * 1000,
    title: "닌텐도 스위치2, 내년 3월 출시 유력... 4K 지원 및 역호환 탑재",
    body: "닌텐도의 차세대 콘솔 '스위치2'가 내년 3월 출시될 것으로 보인다. 업계 소식통에 따르면 4K 출력 지원과 기존 스위치 게임 역호환 기능이 탑재될 예정이며, 출시 타이틀로 '젤다의 전설' 신작이 준비 중이라는 소문도 있다.",
    images: ["https://picsum.photos/800/450?random=news9"],
    likes: 2341,
    dislikes: 56,
    comments: 678,
    views: 198700,
    category: "게임뉴스",
  },
  {
    id: 2010,
    name: "쌀먹닷컴",
    avatar: "🍚",
    avatarBg: "#E8F8E8",
    badge: "쌀먹 공식",
    meta: "11시간 전",
    createdAt: Date.now() - 11 * 60 * 60 * 1000,
    title: "[분석] 7월 출시 예정 신작 게임 쌀먹 포인트 비교 분석",
    body: "7월에 출시 예정인 신작 게임들의 사전예약 보상과 쌀먹 포인트를 비교 분석했습니다. '프로젝트 L'이 가장 높은 보상을, '아키에이지2'가 가장 다양한 혜택을 제공합니다. 자세한 비교표는 본문을 확인하세요!",
    images: ["https://picsum.photos/800/450?random=news10"],
    likes: 1567,
    dislikes: 5,
    comments: 423,
    views: 145600,
    category: "쌀먹정보",
    isVerified: true,
  },
];

// ─── 샘플 댓글 데이터 ───
const initialCommentsData: { [postId: number]: Comment[] } = {
  2001: [
    {
      id: 101,
      author: "게임러버",
      avatar: "🎮",
      avatarBg: "#E8F4FD",
      content: "와 진짜 대박이네요! 기대됩니다 ㅎㅎ",
      time: "1시간 전",
      likes: 42,
      dislikes: 2,
      isBest: true,
      replies: [],
    },
    {
      id: 102,
      author: "쌀먹마스터",
      avatar: "🍚",
      avatarBg: "#E8F8E8",
      content: "좋은 정보 감사합니다!",
      time: "2시간 전",
      likes: 28,
      dislikes: 1,
      replies: [],
    },
  ],
};

// ─── Props 타입 ───
interface NewsContentProps {
  onProfileClick?: (name: string, avatar: string, avatarBg?: string) => void;
}

// ─── 메인 컴포넌트 ───
export default function NewsContent({ onProfileClick }: NewsContentProps) {
  const { showToast } = useToast();

  // ─── 상태 ───
  const [sortType, setSortType] = useState<"latest" | "popular">("latest");
  const [viewMode, setViewMode] = useState<"card" | "list">("card");
  const [showViewPopup, setShowViewPopup] = useState(false);

  // 게시글 상세
  const [selectedPost, setSelectedPost] = useState<PostData | null>(null);

  // 무한스크롤 (카드형)
  const [displayCount, setDisplayCount] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const loadMoreRef = useRef<HTMLDivElement>(null);

  // 상호작용 상태
  const [likedPosts, setLikedPosts] = useState<number[]>([]);
  const [dislikedPosts, setDislikedPosts] = useState<number[]>([]);
  const [followedUsers, setFollowedUsers] = useState<string[]>([]);
  const [followedPosts, setFollowedPosts] = useState<number[]>([]);
  const [expandedComments, setExpandedComments] = useState<number[]>([]);

  // 댓글 상태
  const [commentsData, setCommentsData] = useState<{
    [postId: number]: Comment[];
  }>(initialCommentsData);
  const [commentInputs, setCommentInputs] = useState<{ [key: number]: string }>(
    {},
  );
  const [replyingTo, setReplyingTo] = useState<ReplyTarget | null>(null);
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: string }>({});
  const [likedComments, setLikedComments] = useState<string[]>([]);
  const [dislikedComments, setDislikedComments] = useState<string[]>([]);
  const [highlightedComment, setHighlightedComment] = useState<string | null>(
    null,
  );
  const commentRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  // 팝업 상태
  const [showGiftPopup, setShowGiftPopup] = useState(false);
  const [showCommentGiftPopup, setShowCommentGiftPopup] = useState<
    string | null
  >(null);
  const [showProfilePopup, setShowProfilePopup] = useState(false);
  const [profileTarget, setProfileTarget] = useState<PostData | null>(null);

  // ─── 필터링 & 정렬 ───
  const filteredPosts = [...newsArticles].sort((a, b) => {
    if (sortType === "latest") {
      return (b.createdAt || 0) - (a.createdAt || 0);
    } else {
      return b.views - a.views;
    }
  });

  const cardPosts = filteredPosts.slice(0, displayCount);
  const hasMoreCards = displayCount < filteredPosts.length;

  // ─── 무한스크롤 ───
  const loadMore = useCallback(() => {
    if (isLoading || !hasMoreCards) return;
    setIsLoading(true);
    setTimeout(() => {
      setDisplayCount((prev) => Math.min(prev + 10, filteredPosts.length));
      setIsLoading(false);
    }, 500);
  }, [isLoading, hasMoreCards, filteredPosts.length]);

  useEffect(() => {
    if (viewMode !== "card" || selectedPost) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMoreCards && !isLoading) {
          loadMore();
        }
      },
      { threshold: 0.1 },
    );

    if (loadMoreRef.current) observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [viewMode, hasMoreCards, isLoading, loadMore, selectedPost]);

  useEffect(() => {
    setDisplayCount(10);
  }, [sortType]);

  // ─── 핸들러 ───
  const handleLike = (id: number) => {
    setLikedPosts((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
    setDislikedPosts((prev) => prev.filter((x) => x !== id));
  };

  const handleDislike = (id: number) => {
    setDislikedPosts((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
    setLikedPosts((prev) => prev.filter((x) => x !== id));
  };

  const handleFollow = (name: string) => {
    setFollowedUsers((prev) =>
      prev.includes(name) ? prev.filter((x) => x !== name) : [...prev, name],
    );
  };

  const handleToggleFollowPost = (postId: number) => {
    setFollowedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((x) => x !== postId)
        : [...prev, postId],
    );
  };

  const handleShowGiftPopup = () => {
    setShowGiftPopup(true);
  };

  const handleShowProfile = (post: PostData) => {
    if (onProfileClick) {
      onProfileClick(post.author || post.name, post.avatar, post.avatarBg);
    } else {
      setProfileTarget(post);
      setShowProfilePopup(true);
    }
  };

  const handlePostClick = (post: PostData) => {
    setSelectedPost(post);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBackFromDetail = () => {
    setSelectedPost(null);
  };

  const handleToggleComments = (postId: number) => {
    setExpandedComments((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId],
    );
  };

  // ─── 카드 댓글 핸들러 (postId 기반) ───
  const handleCardCommentInputChange = (postId: number, value: string) => {
    setCommentInputs((prev) => ({ ...prev, [postId]: value }));
  };

  const handleCardSubmitComment = (postId: number) => {
    const input = commentInputs[postId]?.trim();
    if (!input) return;

    const newComment: Comment = {
      id: Date.now(),
      author: "나",
      avatar: "👤",
      content: input,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replies: [],
    };

    setCommentsData((prev) => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment],
    }));
    setCommentInputs((prev) => ({ ...prev, [postId]: "" }));
    showToast("댓글이 등록되었습니다");
  };

  const addReplyToNested = (
    replies: Reply[],
    targetId: number,
    newReply: Reply,
  ): Reply[] => {
    return replies.map((reply) => {
      if (reply.id === targetId) {
        return {
          ...reply,
          replies: [...(reply.replies || []), newReply],
        };
      }
      if (reply.replies && reply.replies.length > 0) {
        return {
          ...reply,
          replies: addReplyToNested(reply.replies, targetId, newReply),
        };
      }
      return reply;
    });
  };

  const handleCardSubmitReply = (postId: number, commentId: number) => {
    if (!replyingTo) return;

    const key = replyingTo.key;
    const input = replyInputs[key]?.trim();
    if (!input) return;

    const newReply: Reply = {
      id: Date.now(),
      author: "나",
      avatar: "👤",
      content: input,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replyTo: replyingTo.author,
      replies: [],
    };

    const keyParts = key.split("-");

    if (keyParts.length === 2) {
      setCommentsData((prev) => ({
        ...prev,
        [postId]: (prev[postId] || []).map((comment) =>
          comment.id === commentId
            ? { ...comment, replies: [...(comment.replies || []), newReply] }
            : comment,
        ),
      }));
    } else {
      const targetReplyId = parseInt(keyParts[keyParts.length - 1]);
      setCommentsData((prev) => ({
        ...prev,
        [postId]: (prev[postId] || []).map((comment) =>
          comment.id === commentId
            ? {
                ...comment,
                replies: addReplyToNested(
                  comment.replies || [],
                  targetReplyId,
                  newReply,
                ),
              }
            : comment,
        ),
      }));
    }

    setReplyInputs((prev) => ({ ...prev, [key]: "" }));
    setReplyingTo(null);
    showToast("답글이 등록되었습니다");
  };

  const handleCardScrollToComment = (postId: number, commentId: number) => {
    const key = `${postId}-${commentId}`;
    setHighlightedComment(key);
    setTimeout(() => setHighlightedComment(null), 2000);

    const el = commentRefs.current[key];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  // ─── 상세 댓글 핸들러 ───
  const handleCommentInputChange = (value: string) => {
    if (!selectedPost) return;
    setCommentInputs((prev) => ({ ...prev, [selectedPost.id]: value }));
  };

  const handleSubmitComment = () => {
    if (!selectedPost) return;
    const input = commentInputs[selectedPost.id]?.trim();
    if (!input) return;

    const newComment: Comment = {
      id: Date.now(),
      author: "나",
      avatar: "👤",
      content: input,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replies: [],
    };

    setCommentsData((prev) => ({
      ...prev,
      [selectedPost.id]: [...(prev[selectedPost.id] || []), newComment],
    }));
    setCommentInputs((prev) => ({ ...prev, [selectedPost.id]: "" }));
    showToast("댓글이 등록되었습니다");
  };

  const handleCommentLike = (key: string) => {
    setLikedComments((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
    setDislikedComments((prev) => prev.filter((k) => k !== key));
  };

  const handleCommentDislike = (key: string) => {
    setDislikedComments((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
    setLikedComments((prev) => prev.filter((k) => k !== key));
  };

  const handleStartReply = (key: string, author: string) => {
    setReplyingTo({ key, author });
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
  };

  const handleReplyInputChange = (key: string, value: string) => {
    setReplyInputs((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmitReply = (commentId: number) => {
    if (!replyingTo || !selectedPost) return;

    const key = replyingTo.key;
    const input = replyInputs[key]?.trim();
    if (!input) return;

    const newReply: Reply = {
      id: Date.now(),
      author: "나",
      avatar: "👤",
      content: input,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replyTo: replyingTo.author,
      replies: [],
    };

    const keyParts = key.split("-");

    if (keyParts.length === 2) {
      setCommentsData((prev) => ({
        ...prev,
        [selectedPost.id]: (prev[selectedPost.id] || []).map((comment) =>
          comment.id === commentId
            ? { ...comment, replies: [...(comment.replies || []), newReply] }
            : comment,
        ),
      }));
    } else {
      const targetReplyId = parseInt(keyParts[keyParts.length - 1]);
      setCommentsData((prev) => ({
        ...prev,
        [selectedPost.id]: (prev[selectedPost.id] || []).map((comment) =>
          comment.id === commentId
            ? {
                ...comment,
                replies: addReplyToNested(
                  comment.replies || [],
                  targetReplyId,
                  newReply,
                ),
              }
            : comment,
        ),
      }));
    }

    setReplyInputs((prev) => ({ ...prev, [key]: "" }));
    setReplyingTo(null);
    showToast("답글이 등록되었습니다");
  };

  const handleScrollToComment = (commentId: number) => {
    if (!selectedPost) return;
    const key = `${selectedPost.id}-${commentId}`;
    setHighlightedComment(key);
    setTimeout(() => setHighlightedComment(null), 2000);

    const el = commentRefs.current[key];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  // ─── 렌더링 ───
  return (
    <>
      <style>{animationStyles}</style>

      {/* 게시글 상세 모드 */}
      {selectedPost ? (
        <PostDetail
          post={selectedPost}
          comments={commentsData[selectedPost.id] || []}
          isLiked={likedPosts.includes(selectedPost.id)}
          isDisliked={dislikedPosts.includes(selectedPost.id)}
          isFollowed={followedUsers.includes(selectedPost.name)}
          onBack={handleBackFromDetail}
          onLike={() => handleLike(selectedPost.id)}
          onDislike={() => handleDislike(selectedPost.id)}
          onFollow={handleFollow}
          onShowGiftPopup={handleShowGiftPopup}
          onShowProfile={() => handleShowProfile(selectedPost)}
          // 댓글 관련 props
          commentInput={commentInputs[selectedPost.id] || ""}
          replyingTo={replyingTo}
          replyInputs={replyInputs}
          likedComments={likedComments}
          dislikedComments={dislikedComments}
          followedUsers={followedUsers}
          highlightedComment={highlightedComment}
          commentRefs={commentRefs}
          onCommentInputChange={handleCommentInputChange}
          onSubmitComment={handleSubmitComment}
          onCommentLike={handleCommentLike}
          onCommentDislike={handleCommentDislike}
          onCommentGift={(key) => setShowCommentGiftPopup(key)}
          onStartReply={handleStartReply}
          onCancelReply={handleCancelReply}
          onReplyInputChange={handleReplyInputChange}
          onSubmitReply={handleSubmitReply}
          onScrollToComment={handleScrollToComment}
        />
      ) : (
        <>
          {/* 정렬 + 보기 전환 */}
          <div className="flex items-center gap-2 py-3 border-b border-gray-200">
            {/* 최신순/인기순 토글 */}
            <button
              onClick={() =>
                setSortType(sortType === "latest" ? "popular" : "latest")
              }
              className="flex items-center gap-1 text-[14px] text-gray-600 hover:text-gray-900"
            >
              {sortType === "latest" ? "최신순" : "인기순"}
              <svg
                className="w-4 h-4 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"
                />
              </svg>
            </button>

            <div className="flex-1" />

            {/* 보기 전환 */}
            <div className="relative">
              <button
                onClick={() => setShowViewPopup(!showViewPopup)}
                className="flex items-center gap-1 px-3 py-1.5 text-[14px] text-gray-500 rounded-lg hover:bg-gray-100 transition-colors"
              >
                {viewMode === "card" ? "카드형" : "목록형"}
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>
              {showViewPopup && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setShowViewPopup(false)}
                  />
                  <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg py-1.5 min-w-[100px] z-20">
                    {["card", "list"].map((mode) => (
                      <button
                        key={mode}
                        className={`w-full flex items-center gap-2 px-3 py-2 text-[14px] font-medium transition-colors ${
                          viewMode === mode
                            ? "text-[#72C2FF] bg-blue-50"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                        onClick={() => {
                          setViewMode(mode as "card" | "list");
                          setShowViewPopup(false);
                        }}
                      >
                        {viewMode === mode && (
                          <svg
                            className="w-4 h-4"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        )}
                        {mode === "card" ? "카드형" : "목록형"}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* 게시글 리스트 */}
          <div className="py-2">
            {filteredPosts.length === 0 ? (
              <div className="py-20 text-center">
                <p className="text-5xl mb-4">📰</p>
                <p className="text-[16px] font-semibold text-gray-500 mb-2">
                  뉴스가 없어요
                </p>
                <p className="text-[14px] text-gray-400">
                  다른 탭을 선택해보세요!
                </p>
              </div>
            ) : viewMode === "card" ? (
              // 카드형
              <>
                {cardPosts.map((post, index) => (
                  <Fragment key={post.id}>
                    <PostCardFull
                      post={post}
                      index={index}
                      comments={commentsData[post.id] || []}
                      isLiked={likedPosts.includes(post.id)}
                      isDisliked={dislikedPosts.includes(post.id)}
                      isFollowed={followedUsers.includes(post.name)}
                      isCommentsExpanded={expandedComments.includes(post.id)}
                      commentInput={commentInputs[post.id] || ""}
                      replyingTo={replyingTo}
                      replyInputs={replyInputs}
                      likedComments={likedComments}
                      dislikedComments={dislikedComments}
                      followedUsers={followedUsers}
                      highlightedComment={highlightedComment}
                      commentRefs={commentRefs}
                      onLike={() => handleLike(post.id)}
                      onDislike={() => handleDislike(post.id)}
                      onFollow={handleFollow}
                      onToggleComments={() => handleToggleComments(post.id)}
                      onShowGiftPopup={handleShowGiftPopup}
                      onShowProfile={() => handleShowProfile(post)}
                      onCommentInputChange={(value) =>
                        handleCardCommentInputChange(post.id, value)
                      }
                      onSubmitComment={() => handleCardSubmitComment(post.id)}
                      onCommentLike={handleCommentLike}
                      onCommentDislike={handleCommentDislike}
                      onCommentGift={(key) => setShowCommentGiftPopup(key)}
                      onStartReply={handleStartReply}
                      onCancelReply={handleCancelReply}
                      onReplyInputChange={handleReplyInputChange}
                      onSubmitReply={(commentId) =>
                        handleCardSubmitReply(post.id, commentId)
                      }
                      onScrollToComment={(commentId) =>
                        handleCardScrollToComment(post.id, commentId)
                      }
                    />
                    {/* 첫 게시글 뒤 광고 */}
                    {index === 0 && <AdCard ad={cardAd} index={index + 1} />}
                  </Fragment>
                ))}

                {/* 로딩 / 더보기 */}
                {hasMoreCards && (
                  <div ref={loadMoreRef} className="py-8 flex justify-center">
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-gray-300 border-t-[#72C2FF] rounded-full animate-spin" />
                    ) : (
                      <button
                        onClick={loadMore}
                        className="px-6 py-2 text-[14px] font-semibold text-gray-500 bg-gray-100 rounded-full hover:bg-gray-200"
                      >
                        더보기
                      </button>
                    )}
                  </div>
                )}
              </>
            ) : (
              // 목록형
              <div className="space-y-2">
                {filteredPosts.map((post, index) => (
                  <Fragment key={post.id}>
                    <PostListItem
                      post={post}
                      index={index}
                      isLiked={likedPosts.includes(post.id)}
                      isDisliked={dislikedPosts.includes(post.id)}
                      isFollowed={followedPosts.includes(post.id)}
                      onLike={() => handleLike(post.id)}
                      onDislike={() => handleDislike(post.id)}
                      onFollow={() => handleToggleFollowPost(post.id)}
                      onComment={() => handlePostClick(post)}
                      onGift={handleShowGiftPopup}
                      onClick={() => handlePostClick(post)}
                      getRelativeTime={getRelativeTime}
                    />
                    {index === 0 && (
                      <AdListItem ad={listAd} index={index + 1} />
                    )}
                  </Fragment>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* 선물 팝업 */}
      {showGiftPopup && (
        <GiftPopup type="post" onClose={() => setShowGiftPopup(false)} />
      )}

      {/* 댓글 선물 팝업 */}
      {showCommentGiftPopup && (
        <GiftPopup
          type="comment"
          onClose={() => setShowCommentGiftPopup(null)}
        />
      )}

      {/* 프로필 팝업 */}
      {!onProfileClick && showProfilePopup && profileTarget && (
        <ProfilePopup
          profile={profileTarget}
          isFollowed={followedUsers.includes(profileTarget.name)}
          onClose={() => setShowProfilePopup(false)}
          onFollow={() => handleFollow(profileTarget.name)}
        />
      )}
    </>
  );
}
