import { useState } from "react";
import RightSideIcons from "../components/gamedetail/RightSideIcons";
import LeftSidebar from "../components/gamedetail/LeftSidebar";
import RightSidebar from "../components/gamedetail/RightSidebar";
import ReviewCard, { type ReviewData } from "../components/gamedetail/ReviewCard";

// ─── 메인 컴포넌트 ───
export default function GameDetailPage() {
  const [activeTab, setActiveTab] = useState("평가글");
  const [isLiked, setIsLiked] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [reviewTab, setReviewTab] = useState("유저평가");
  const [expandedReviews, setExpandedReviews] = useState<number[]>([]);
  const [showGiftPopup, setShowGiftPopup] = useState(false);
  const [showAwardHistory, setShowAwardHistory] = useState(false);
  const [showReviewPopup, setShowReviewPopup] = useState(false);
  const [reviewStars, setReviewStars] = useState(0);
  const [reviewReward, setReviewReward] = useState("");
  const [reviewComment, setReviewComment] = useState("");
  const [showSnsPopup, setShowSnsPopup] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const [mediaIndex, setMediaIndex] = useState(0);

  const mediaItems = [
    {
      type: "video",
      src: "https://sgimage.netmarble.com/images/netmarble/rfnext/20250121/ro4j1737451863887.mp4",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/d99c79ec564545cc8f6f4333a9eefbb3.jpg",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/93b0fb0121864408a97d86e23226176d.jpg",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/81c5661e8c6b439ab14d3e6c83051739.jpg",
    },
  ];

  const tabs = [
    "소개",
    "평가글",
    "게임이벤트",
    "게임쿠폰",
    "쌀먹점수",
    "코인시세",
    "커뮤니티",
  ];

  const reviews: ReviewData[] = [
    {
      id: 1,
      name: "소보로",
      level: 7,
      date: "2025-01-30",
      rating: 4.0,
      stars: "★★★★☆",
      image:
        "https://edge.ssalmuk.com/editorImage/8daa1b53fba545ffb56d1cac5517407b.png",
      content: [
        "게임이라기 보단 메타월드죠.",
        "가상 공간에 내 땅사고, 임대로 받고 그런느낌.",
      ],
      likes: 12,
      comments: 3,
      views: 124,
    },
    {
      id: 2,
      name: "게임러버",
      level: 12,
      date: "2025-01-28",
      rating: 3.0,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/d2008bde9fe541edabc5762d18b04e7b.png",
      content: ["초반 진입장벽이 좀 있어요.", "근데 익숙해지면 꽤 재밌습니다."],
      likes: 8,
      comments: 1,
      views: 89,
    },
    {
      id: 3,
      name: "쌀먹마스터",
      level: 25,
      date: "2025-01-25",
      rating: 5.0,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/daa326b1f7d141dbb6f42473312e562c.jfif",
      content: [
        "P2E 게임 중에서는 최고입니다!",
        "꾸준히 하면 수익 나와요.",
        "초보자도 쉽게 시작할 수 있어요.",
      ],
      likes: 25,
      comments: 7,
      views: 256,
    },
    {
      id: 4,
      name: "메타버스탐험가",
      level: 18,
      date: "2025-01-24",
      rating: 4.5,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif",
      content: [
        "가상 부동산 투자에 관심있다면 추천!",
        "MANA 토큰 시세도 나쁘지 않아요.",
      ],
      likes: 19,
      comments: 5,
      views: 178,
    },
    {
      id: 5,
      name: "블록체인뉴비",
      level: 3,
      date: "2025-01-22",
      rating: 2.5,
      stars: "★★☆☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/935049a546e744a98c0c77e1d498ae18.png",
      content: ["진입장벽이 너무 높아요.", "처음 시작하기 어렵습니다."],
      likes: 4,
      comments: 2,
      views: 67,
    },
    {
      id: 6,
      name: "크립토킹",
      level: 31,
      date: "2025-01-20",
      rating: 4.0,
      stars: "★★★★☆",
      image:
        "https://edge.ssalmuk.com/editorImage/8340a446068d4799a60acbf85f415e28.jpg",
      content: [
        "장기 투자로 접근하면 괜찮아요.",
        "단기 수익은 기대하기 어렵습니다.",
      ],
      likes: 15,
      comments: 4,
      views: 143,
    },
    {
      id: 7,
      name: "NFT수집가",
      level: 22,
      date: "2025-01-18",
      rating: 5.0,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/145ef9589b8047169888e2f0c232b3d4.jpg",
      content: [
        "웨어러블 NFT 수집이 너무 재밌어요!",
        "다양한 이벤트도 많이 열립니다.",
      ],
      likes: 22,
      comments: 6,
      views: 198,
    },
    {
      id: 8,
      name: "게임분석가",
      level: 15,
      date: "2025-01-16",
      rating: 3.5,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/f85655d36efc44aaaf692cbef435271d.jpg",
      content: [
        "그래픽은 아쉽지만 컨셉이 좋아요.",
        "메타버스 입문용으로 추천합니다.",
      ],
      likes: 11,
      comments: 3,
      views: 112,
    },
    {
      id: 9,
      name: "디파이고수",
      level: 28,
      date: "2025-01-14",
      rating: 4.5,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/56ce60fa47784514b73aa0afafbecc99.jpg",
      content: [
        "LAND 스테이킹으로 패시브 인컴 가능!",
        "초기 투자금이 좀 필요합니다.",
      ],
      likes: 28,
      comments: 9,
      views: 287,
    },
    {
      id: 10,
      name: "캐주얼게이머",
      level: 5,
      date: "2025-01-12",
      rating: 3.0,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/26850577efbf4dcd9ae8df48b75d4e7a.jpg",
      content: ["가볍게 즐기기엔 좋아요.", "수익 목적보다는 체험용으로 추천."],
      likes: 6,
      comments: 1,
      views: 54,
    },
  ];

  const quickLinks = [
    { icon: "🏠", label: "홈페이지" },
    { icon: "📋", label: "업데이트" },
    { icon: "📖", label: "가이드북" },
    { icon: "💬", label: "커뮤니티" },
  ];

  const snsLinks = [
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/discord35.svg",
      name: "디스코드",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/facebook35.svg",
      name: "페이스북",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/reddit35.svg",
      name: "레딧",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/twitter35.svg",
      name: "트위터",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/youtube35.svg",
      name: "유튜브",
    },
  ];

  const coupons = [
    {
      id: 1,
      avatar:
        "https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif",
      nickname: "쿠폰다내꺼",
      code: "U323KSK3K1K23K",
      period: "2025-10-30 ~ 정보없음",
      rewards: "물약100개, 초보자 방어구 세트",
    },
    {
      id: 2,
      avatar:
        "https://edge.ssalmuk.com/editorImage/935049a546e744a98c0c77e1d498ae18.png",
      nickname: "꽝우실러취요",
      code: "WELCOME2025NEW",
      period: "2025-09-16 ~ 정보없음",
      rewards: "물약100개, 초보자 방어구 세트",
    },
    {
      id: 3,
      avatar:
        "https://edge.ssalmuk.com/editorImage/8daa1b53fba545ffb56d1cac5517407b.png",
      nickname: "게임마스터",
      code: "SSALMUK7777GG",
      period: "2025-12-31 ~ 2026-03-31",
      rewards: "골드 5000, 프리미엄 상자 1개",
    },
  ];

  const handleLikeToggle = () => {
    setIsLiked(!isLiked);
    if (!isLiked) {
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2000);
    }
  };

  const toggleReviewExpand = (id: number) => {
    setExpandedReviews((prev) =>
      prev.includes(id) ? prev.filter((rid) => rid !== id) : [...prev, id],
    );
  };

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: "#F5F6F8" }}
    >
      <RightSideIcons />

      <div className="max-w-[1280px] mx-auto w-full grid grid-cols-1 lg:grid-cols-[200px_1fr_280px] gap-6 p-6">
        {/* Left Sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-24">
            <LeftSidebar />
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex flex-col gap-4 min-w-0">
          {/* 게임 정보 헤더 */}
          <div
            className="rounded-2xl p-6 bg-cover bg-center animate-fadeUp"
            style={{
              backgroundImage:
                "url('https://ssalmuk.com/images/img_ranking_detail/detail_banner.svg')",
            }}
          >
            <div className="flex gap-5">
              {/* 게임 아이콘 */}
              <img
                src="https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif"
                alt="디센트럴랜드"
                className="w-28 h-28 rounded-2xl object-cover shadow-lg"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h1 className="text-2xl font-bold text-white">
                    디센트럴랜드
                  </h1>
                  <button
                    onClick={handleLikeToggle}
                    className={`p-2 rounded-full transition-all ${
                      isLiked
                        ? "bg-red-50 text-[#FF4757]"
                        : "bg-white/10 text-white/60 hover:bg-white/20"
                    }`}
                  >
                    <svg
                      className="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                    </svg>
                  </button>
                </div>
                <div className="flex gap-2 mt-2">
                  <span className="bg-white/20 text-white text-xs px-2.5 py-1 rounded-full font-medium">
                    메타버스
                  </span>
                  <span className="bg-white/20 text-white text-xs px-2.5 py-1 rounded-full font-medium">
                    소셜
                  </span>
                  <span className="bg-white/20 text-white text-xs px-2.5 py-1 rounded-full font-medium">
                    P2E
                  </span>
                </div>

                {/* 퀵 링크 */}
                <div className="flex gap-4 mt-4">
                  {quickLinks.map((link, idx) => (
                    <div
                      key={idx}
                      className="flex flex-col items-center cursor-pointer group"
                    >
                      <div className="w-12 h-12 bg-white/90 rounded-xl flex items-center justify-center text-xl group-hover:bg-white transition-colors">
                        {link.icon}
                      </div>
                      <span className="text-[10px] text-white/70 mt-1.5">
                        {link.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 순위 & SNS */}
            <div className="bg-white rounded-xl p-4 mt-5 flex items-center">
              <div className="text-center px-8">
                <p className="text-xs text-gray-400">국내순위</p>
                <p className="font-bold text-[#1A1A2E] text-lg">
                  1위 <span className="text-gray-400 text-sm">(-)</span>
                </p>
              </div>
              <div className="w-px h-12 bg-gray-200"></div>
              <div className="flex-1 text-center">
                <p className="text-xs text-gray-400 mb-2">활성화된 SNS 채널</p>
                <div className="flex gap-2 justify-center">
                  {snsLinks.map((sns, idx) => (
                    <img
                      key={idx}
                      src={sns.icon}
                      alt={sns.name}
                      className="w-6 h-6 rounded cursor-pointer hover:scale-110 transition-transform"
                    />
                  ))}
                </div>
              </div>
              <button
                className="text-gray-400 text-2xl px-4 hover:text-[#4AABF5] transition-colors"
                onClick={() => setShowSnsPopup(true)}
              >
                →
              </button>
            </div>
          </div>

          {/* 탭 메뉴 */}
          <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeUp delay-1">
            <div className="flex border-b border-gray-100 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                    activeTab === tab
                      ? "text-[#1A1A2E] font-bold border-b-2 border-[#72C2FF]"
                      : "text-gray-400 hover:text-gray-600"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* 탭 컨텐츠 */}
            <div className="p-5">
              {/* 소개 탭 */}
              {activeTab === "소개" && (
                <div className="animate-fadeIn">
                  {/* 미디어 슬라이더 */}
                  <div className="relative">
                    {/* 좌측 화살표 */}
                    {mediaIndex > 0 && (
                      <button
                        onClick={() => setMediaIndex(mediaIndex - 1)}
                        className="absolute left-[-28px] top-1/2 -translate-y-1/2 w-14 h-14 bg-white rounded-full shadow-lg flex items-center justify-center hover:text-[#4AABF5] transition-colors z-10"
                      >
                        <svg
                          className="w-6 h-6 text-black"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={2}
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M15 19l-7-7 7-7"
                          />
                        </svg>
                      </button>
                    )}

                    {/* 우측 화살표 */}
                    {mediaIndex < mediaItems.length - 2 && (
                      <button
                        onClick={() => setMediaIndex(mediaIndex + 1)}
                        className="absolute right-[-28px] top-1/2 -translate-y-1/2 w-14 h-14 bg-white rounded-full shadow-lg flex items-center justify-center hover:text-[#4AABF5] transition-colors z-10"
                      >
                        <svg
                          className="w-6 h-6 text-black"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={2}
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M9 5l7 7-7 7"
                          />
                        </svg>
                      </button>
                    )}

                    {/* 슬라이더 컨테이너 */}
                    <div className="overflow-hidden">
                      <div
                        className="flex gap-5 transition-transform duration-500 ease-out"
                        style={{
                          transform: `translateX(-${mediaIndex * 52}%)`,
                        }}
                      >
                        {mediaItems.map((item, i) => (
                          <div
                            key={i}
                            className="w-[60%] shrink-0 rounded-2xl overflow-hidden shadow-lg cursor-pointer group"
                          >
                            {item.type === "video" ? (
                              <video
                                src={item.src}
                                className="w-full aspect-[16/10] object-cover"
                                muted
                                loop
                                playsInline
                                controls
                                onClick={() => setLightboxIndex(i)} // ✅ 추가
                              />
                            ) : (
                              <img
                                src={item.src}
                                alt={`스크린샷${i}`}
                                className="w-full aspect-[16/10] object-cover group-hover:scale-105 transition-transform duration-500"
                                onClick={() => setLightboxIndex(i)} // ✅ 추가
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 설명 */}
                  <div className="mt-6 space-y-3 text-[15px] text-gray-700 leading-relaxed">
                    <p className="font-bold text-[#1A1A2E]">
                      🌐 디센트럴랜드 - 가상 세계의 새로운 경험!
                    </p>
                    <p>
                      디센트럴랜드는 이더리움 블록체인 기반의 가상 현실
                      플랫폼입니다.
                    </p>
                    <p>
                      사용자가 직접 콘텐츠와 애플리케이션을 만들고, 체험하고,
                      수익화할 수 있습니다.
                    </p>
                    <p className="font-medium text-[#4AABF5]">■ 주요 특징</p>
                    <p>• 가상 부동산 LAND를 구매하고 개발할 수 있습니다</p>
                    <p>• MANA 토큰으로 게임 내 아이템을 거래할 수 있습니다</p>
                    <p>• 다양한 이벤트와 소셜 경험을 즐길 수 있습니다</p>
                  </div>
                </div>
              )}

              {/* 평가글 탭 */}
              {activeTab === "평가글" && (
                <div className="animate-fadeIn">
                  {/* 탭 버튼 */}
                  <div className="flex gap-2 mb-5">
                    <button
                      className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                        reviewTab === "유저평가"
                          ? "bg-[#72C2FF] text-white"
                          : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                      }`}
                      onClick={() => setReviewTab("유저평가")}
                    >
                      유저평가
                    </button>
                    <button
                      className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                        reviewTab === "평가단평가"
                          ? "bg-[#72C2FF] text-white"
                          : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                      }`}
                      onClick={() => setReviewTab("평가단평가")}
                    >
                      평가단평가
                    </button>
                  </div>

                  {/* 플레이 보상체감 */}
                  <div className="flex items-center justify-between mb-5 p-4 bg-gray-50 rounded-xl">
                    <span className="text-gray-700 font-medium">
                      플레이 보상체감
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-yellow-400 text-lg">★★★☆☆</span>
                      <span className="text-[#1A1A2E] font-bold text-xl">
                        3.4
                      </span>
                      <span className="text-gray-400 text-sm">점</span>
                    </div>
                  </div>

                  {/* 상세평가 바 */}
                  <div className="mb-6 p-4 bg-gray-50 rounded-xl">
                    <p className="text-gray-700 font-medium mb-4">
                      플레이 보상 상세평가
                    </p>
                    {[
                      { label: "매우 높음", value: 5.88 },
                      { label: "높음", value: 11.76 },
                      { label: "보통", value: 35.29 },
                      { label: "낮음", value: 29.41 },
                      { label: "매우 낮음", value: 17.65 },
                    ].map((item) => (
                      <div
                        key={item.label}
                        className="flex items-center gap-3 mb-2"
                      >
                        <span className="text-xs text-gray-500 w-16">
                          {item.label}
                        </span>
                        <div className="flex-1 h-2.5 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[#72C2FF]"
                            style={{ width: `${item.value}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-400 w-12 text-right">
                          {item.value}%
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* 평가 참여 버튼 */}
                  <button
                    className="w-full py-3.5 bg-[#72C2FF] hover:bg-[#4AABF5] text-white rounded-xl font-medium mb-6 transition-colors"
                    onClick={() => setShowReviewPopup(true)}
                  >
                    게임 평가 참여하기
                  </button>

                  {/* 리뷰 리스트 */}
                  <div className="flex flex-col gap-4">
                    {reviews.map((review) => (
                      <ReviewCard
                        key={review.id}
                        review={review}
                        expanded={expandedReviews.includes(review.id)}
                        onToggleExpand={() => toggleReviewExpand(review.id)}
                        onShowGift={() => setShowGiftPopup(true)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* 게임쿠폰 탭 */}
              {activeTab === "게임쿠폰" && (
                <div className="animate-fadeIn space-y-4">
                  {coupons.map((coupon) => (
                    <div
                      key={coupon.id}
                      className="border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={coupon.avatar}
                            alt=""
                            className="w-10 h-10 rounded-full object-cover"
                          />
                          <span className="text-sm text-gray-500">
                            {coupon.nickname}
                          </span>
                        </div>
                        <button
                          className="px-5 py-2 rounded-lg text-sm font-medium text-white bg-[#72C2FF] hover:bg-[#4AABF5] transition-colors"
                          onClick={() =>
                            navigator.clipboard?.writeText(coupon.code)
                          }
                        >
                          복사
                        </button>
                      </div>
                      <p className="text-base font-bold text-[#1A1A2E] mb-2">
                        쿠폰번호 {coupon.code}
                      </p>
                      <p className="text-sm text-gray-500 mb-1">
                        기간 {coupon.period}
                      </p>
                      <p className="text-sm text-[#4AABF5] font-medium">
                        {coupon.rewards}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* 쌀먹점수 탭 */}
              {activeTab === "쌀먹점수" && (
                <div className="animate-fadeIn">
                  {/* 기간 선택 */}
                  <div className="flex justify-end mb-5">
                    <div className="flex bg-gray-100 rounded-full p-1">
                      {["7D", "1M", "3M", "6M", "1Y", "ALL"].map(
                        (period, i) => (
                          <button
                            key={period}
                            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                              i === 0
                                ? "bg-[#72C2FF] text-white"
                                : "text-gray-500 hover:text-gray-700"
                            }`}
                          >
                            {period}
                          </button>
                        ),
                      )}
                    </div>
                  </div>

                  {/* 차트 */}
                  <div className="bg-gray-50 rounded-xl p-5">
                    <div className="flex">
                      <div className="flex flex-col justify-between text-xs text-gray-400 pr-3 py-2">
                        {["12.5k", "10k", "7.5k", "5k", "2.5k", "0"].map(
                          (label) => (
                            <span key={label}>{label}</span>
                          ),
                        )}
                      </div>
                      <div className="flex-1 h-48 relative">
                        <svg
                          className="w-full h-full"
                          viewBox="0 0 300 150"
                          preserveAspectRatio="none"
                        >
                          {[0, 30, 60, 90, 120, 150].map((y) => (
                            <line
                              key={y}
                              x1="0"
                              y1={y}
                              x2="300"
                              y2={y}
                              stroke="#e5e7eb"
                              strokeWidth="1"
                            />
                          ))}
                          <path
                            d="M0,35 L50,35 L100,36 L150,38 L175,32 L200,30 L250,33 L300,35"
                            fill="none"
                            stroke="#72C2FF"
                            strokeWidth="3"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-400 mt-3 pl-10">
                      {[
                        "01-25",
                        "01-26",
                        "01-27",
                        "01-28",
                        "01-29",
                        "01-30",
                        "01-31",
                      ].map((date) => (
                        <span key={date}>{date}</span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 코인시세 탭 */}
              {activeTab === "코인시세" && (
                <div className="animate-fadeIn">
                  {/* 통화 선택 */}
                  <div className="flex justify-end mb-5">
                    <div className="flex bg-gray-100 rounded-full p-1">
                      <button className="px-5 py-1.5 rounded-full text-sm font-medium bg-[#72C2FF] text-white">
                        KRW
                      </button>
                      <button className="px-5 py-1.5 rounded-full text-sm font-medium text-gray-500">
                        USD
                      </button>
                    </div>
                  </div>

                  {/* 코인 정보 */}
                  <div className="flex items-start gap-5 mb-6 p-5 bg-gray-50 rounded-xl">
                    <img
                      src="https://edge.ssalmuk.com/network/202305/02_UNKWON/b52ea909ad3d44738dddf71f5e324bc5.jpg"
                      alt="Decentraland"
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-xl font-bold text-[#1A1A2E]">
                          Decentraland
                        </span>
                        <span className="text-xl font-medium text-gray-700">
                          ₩213.97
                        </span>
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-green-500">▼</span>
                        <span className="text-green-500 text-sm">-2.46%</span>
                      </div>
                      <div className="mt-3">
                        <p className="text-gray-500 text-sm">거래량 (24시간)</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[#1A1A2E] font-medium">
                            ₩24,639,005,627
                          </span>
                          <span className="text-green-500 text-sm">
                            +15.66%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 기간 선택 */}
                  <div className="flex justify-end mb-5">
                    <div className="flex bg-gray-100 rounded-full p-1">
                      {["7D", "1M", "3M", "6M", "1Y", "ALL"].map(
                        (period, i) => (
                          <button
                            key={period}
                            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                              i === 0
                                ? "bg-[#72C2FF] text-white"
                                : "text-gray-500 hover:text-gray-700"
                            }`}
                          >
                            {period}
                          </button>
                        ),
                      )}
                    </div>
                  </div>

                  {/* 차트 */}
                  <div className="bg-gray-50 rounded-xl p-5">
                    <div className="flex">
                      <div className="flex flex-col justify-between text-xs text-gray-400 pr-3 py-2">
                        {["300", "250", "200", "150", "100", "50"].map(
                          (label) => (
                            <span key={label}>{label}</span>
                          ),
                        )}
                      </div>
                      <div className="flex-1 h-48 relative">
                        <svg
                          className="w-full h-full"
                          viewBox="0 0 300 150"
                          preserveAspectRatio="none"
                        >
                          {[0, 30, 60, 90, 120, 150].map((y) => (
                            <line
                              key={y}
                              x1="0"
                              y1={y}
                              x2="300"
                              y2={y}
                              stroke="#e5e7eb"
                              strokeWidth="1"
                            />
                          ))}
                          <path
                            d="M0,60 L50,55 L100,70 L150,65 L175,50 L200,45 L250,55 L300,50"
                            fill="none"
                            stroke="#72C2FF"
                            strokeWidth="3"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 게임이벤트 / 커뮤니티 탭 */}
              {(activeTab === "게임이벤트" || activeTab === "커뮤니티") && (
                <div className="animate-fadeIn text-center py-12">
                  <span className="text-5xl mb-4 block">🚧</span>
                  <p className="text-gray-500">준비 중입니다.</p>
                </div>
              )}
            </div>
          </div>
        </main>

        {/* Right Sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-24">
            <RightSidebar />
          </div>
        </aside>
      </div>

      {/* 토스트 메시지 */}
      {showToast && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-gray-800 text-white px-5 py-3 rounded-full flex items-center gap-2 z-50 animate-fadeIn">
          <span className="text-green-400">✓</span>
          <span className="text-sm">관심목록에 추가되었습니다</span>
        </div>
      )}

      {/* SNS 팝업 */}
      {showSnsPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setShowSnsPopup(false)}
          />
          <div className="relative z-10 bg-white rounded-2xl p-6 mx-4 w-full max-w-sm animate-scaleIn">
            <h2 className="text-lg font-bold text-[#1A1A2E] text-center mb-6">
              활성화된 SNS 채널
            </h2>
            <div className="space-y-4">
              {snsLinks.map((sns, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={sns.icon}
                      alt={sns.name}
                      className="w-10 h-10 rounded-lg"
                    />
                    <span className="text-gray-700 font-medium">
                      {sns.name}
                    </span>
                  </div>
                  <span className="text-gray-400">→</span>
                </div>
              ))}
            </div>
            <button
              className="mt-6 w-full py-3 bg-[#72C2FF] hover:bg-[#4AABF5] text-white rounded-xl font-medium transition-colors"
              onClick={() => setShowSnsPopup(false)}
            >
              확인
            </button>
          </div>
        </div>
      )}

      {/* 선물 팝업 */}
      {showGiftPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => {
              setShowGiftPopup(false);
              setShowAwardHistory(false);
            }}
          />
          <div className="relative z-10 bg-white rounded-2xl w-full max-w-md mx-4 animate-scaleIn">
            {showAwardHistory ? (
              // 수상내역 화면
              <>
                <div className="flex items-center justify-between p-5 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setShowAwardHistory(false)}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      ←
                    </button>
                    <span className="text-lg font-bold">수상내역</span>
                  </div>
                  <button
                    onClick={() => {
                      setShowGiftPopup(false);
                      setShowAwardHistory(false);
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ✕
                  </button>
                </div>

                <div className="p-5">
                  <div className="flex items-center justify-center gap-8 bg-gray-50 rounded-xl p-5 mb-5">
                    <div className="text-center">
                      <p className="text-xs text-gray-500 mb-1">총 수상</p>
                      <div className="flex items-center gap-1 justify-center">
                        <span className="text-xl">🏅</span>
                        <span className="text-2xl font-bold">26</span>
                      </div>
                    </div>
                    <div className="w-px h-12 bg-gray-200" />
                    <div className="text-center">
                      <p className="text-xs text-gray-500 mb-1">총 포인트</p>
                      <p className="text-2xl font-bold text-[#4AABF5]">2850P</p>
                    </div>
                  </div>

                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {[
                      {
                        icon: "🏆",
                        name: "논 한마지기",
                        count: 2,
                        points: "1000P",
                        bg: "bg-emerald-100",
                        text: "text-emerald-600",
                      },
                      {
                        icon: "⭐",
                        name: "황금쌀",
                        count: 19,
                        points: "500P",
                        bg: "bg-cyan-100",
                        text: "text-cyan-600",
                      },
                      {
                        icon: "🎁",
                        name: "쌀가마",
                        count: 2,
                        points: "100P",
                        bg: "bg-pink-100",
                        text: "text-pink-600",
                      },
                      {
                        icon: "🍚",
                        name: "밥 한공기",
                        count: 2,
                        points: "50P",
                        bg: "bg-orange-100",
                        text: "text-orange-600",
                      },
                      {
                        icon: "🌾",
                        name: "쌀 한톨",
                        count: 1,
                        points: "10P",
                        bg: "bg-green-100",
                        text: "text-green-600",
                      },
                    ].map((award) => (
                      <div
                        key={award.name}
                        className="flex items-center justify-between p-3 border border-gray-100 rounded-xl"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-12 h-12 rounded-xl ${award.bg} flex flex-col items-center justify-center`}
                          >
                            <span className="text-xl">{award.icon}</span>
                            <span
                              className={`text-[9px] ${award.text} font-medium`}
                            >
                              {award.name}
                            </span>
                          </div>
                          <span className="text-lg font-medium">
                            {award.count}
                          </span>
                        </div>
                        <span className="text-gray-700 font-medium">
                          {award.points}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              // 선물하기 화면
              <>
                <div className="flex items-center justify-between p-5 border-b border-gray-100">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                      <span className="text-white text-xl">🍚</span>
                    </div>
                    <div>
                      <p className="text-lg font-bold">532P</p>
                      <p className="text-xs text-gray-400">내 포인트</p>
                    </div>
                  </div>
                  <button
                    className="flex flex-col items-center p-3 rounded-xl bg-amber-50 hover:bg-amber-100 transition-colors"
                    onClick={() => setShowAwardHistory(true)}
                  >
                    <span className="text-2xl">🏆</span>
                    <span className="text-xs text-gray-500">
                      14개 보기 &gt;
                    </span>
                  </button>
                  <button
                    onClick={() => setShowGiftPopup(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ✕
                  </button>
                </div>

                <div className="p-5">
                  <p className="font-bold text-[#1A1A2E] mb-4">
                    상을 선택하세요
                  </p>
                  <div className="flex gap-2 overflow-x-auto pb-3">
                    {[
                      {
                        icon: "🌾",
                        name: "쌀 한톨",
                        points: "10P",
                        bg: "bg-green-100",
                        text: "text-green-600",
                      },
                      {
                        icon: "🍚",
                        name: "밥 한공기",
                        points: "50P",
                        bg: "bg-orange-100",
                        text: "text-orange-600",
                        selected: true,
                      },
                      {
                        icon: "🎁",
                        name: "쌀가마",
                        points: "100P",
                        bg: "bg-pink-100",
                        text: "text-pink-600",
                      },
                      {
                        icon: "⭐",
                        name: "황금쌀",
                        points: "500P",
                        bg: "bg-cyan-100",
                        text: "text-cyan-600",
                      },
                      {
                        icon: "🏆",
                        name: "논 한마지기",
                        points: "1000P",
                        bg: "bg-emerald-100",
                        text: "text-emerald-600",
                      },
                    ].map((award) => (
                      <button
                        key={award.name}
                        className={`flex flex-col items-center min-w-[80px] p-3 rounded-xl ${award.bg} ${
                          award.selected ? "ring-2 ring-orange-400" : ""
                        } hover:scale-105 transition-transform`}
                      >
                        <span className="text-3xl mb-1">{award.icon}</span>
                        <span className="text-xs font-medium text-gray-700">
                          {award.name}
                        </span>
                        <span className={`text-xs ${award.text} font-medium`}>
                          {award.points}
                        </span>
                      </button>
                    ))}
                  </div>

                  <p className="text-sm text-gray-700 mt-4 mb-3">
                    콘텐츠 작성자는 <span className="font-bold">상</span>을 받을
                    자격이 있습니다.
                  </p>

                  <div className="flex items-center justify-between border border-gray-200 rounded-xl px-4 py-3 mb-3">
                    <input
                      type="text"
                      placeholder="메시지를 추가하세요"
                      className="flex-1 text-sm outline-none"
                    />
                    <span className="text-xs text-gray-400">0/100</span>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer mb-5">
                    <input
                      type="checkbox"
                      className="w-5 h-5 rounded border-gray-300 accent-[#72C2FF]"
                    />
                    <span className="text-sm text-gray-700">
                      익명으로 기부하기
                    </span>
                  </label>

                  <button
                    className="w-full py-4 rounded-full bg-[#72C2FF] hover:bg-[#4AABF5] text-white font-bold text-lg transition-colors"
                    onClick={() => setShowGiftPopup(false)}
                  >
                    상 주기
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
      {/* 이미지 라이트박스 */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-[200] bg-black/90 flex items-center justify-center"
          onClick={() => setLightboxIndex(null)}
        >
          {/* 좌측 화살표 */}
          {lightboxIndex > 0 && (
            <button
              className="absolute left-6 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(lightboxIndex - 1);
              }}
            >
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>
          )}

          {/* 이미지 또는 영상 */}
          {mediaItems[lightboxIndex].type === "video" ? (
            <video
              src={mediaItems[lightboxIndex].src}
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg animate-scaleIn"
              controls
              autoPlay
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <img
              src={mediaItems[lightboxIndex].src}
              alt="확대 이미지"
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg animate-scaleIn"
              onClick={(e) => e.stopPropagation()}
            />
          )}

          {/* 우측 화살표 */}
          {lightboxIndex < mediaItems.length - 1 && (
            <button
              className="absolute right-6 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(lightboxIndex + 1);
              }}
            >
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          )}

          {/* 인디케이터 */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            {mediaItems.map((_, i) => (
              <button
                key={i}
                className={`w-2 h-2 rounded-full transition-colors ${
                  i === lightboxIndex ? "bg-white" : "bg-white/40"
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  setLightboxIndex(i);
                }}
              />
            ))}
          </div>
        </div>
      )}
      {/* 게임 평가 팝업 */}
      {showReviewPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setShowReviewPopup(false)}
          />
          <div className="relative z-10 bg-white rounded-2xl w-full max-w-md mx-4 max-h-[85vh] overflow-y-auto animate-scaleIn">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 sticky top-0 bg-white">
              <div />
              <p className="text-base font-bold text-[#1A1A2E]">
                게임 평가하기
              </p>
              <button
                className="text-gray-400 text-xl hover:text-gray-600"
                onClick={() => setShowReviewPopup(false)}
              >
                ✕
              </button>
            </div>

            <div className="p-5">
              {/* 플레이 보상체감 */}
              <div className="mb-6">
                <p className="text-sm font-medium text-[#1A1A2E] mb-3">
                  플레이 보상체감 <span className="text-red-500">*</span>
                </p>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button key={star} onClick={() => setReviewStars(star)}>
                      <svg
                        className={`w-10 h-10 transition-colors ${star <= reviewStars ? "text-yellow-400" : "text-gray-200"}`}
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                      </svg>
                    </button>
                  ))}
                  <span className="text-sm text-gray-500 ml-2">
                    {reviewStars}점
                  </span>
                </div>
              </div>

              {/* 플레이 보상 상세평가 */}
              <div className="mb-6">
                <p className="text-sm font-medium text-[#1A1A2E] mb-3">
                  플레이 보상 상세평가 <span className="text-red-500">*</span>
                </p>
                <div className="flex gap-2 flex-wrap">
                  {["매우낮음", "낮음", "보통", "높음", "매우높음"].map(
                    (level) => (
                      <button
                        key={level}
                        className={`flex flex-col items-center gap-1`}
                        onClick={() => setReviewReward(level)}
                      >
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-colors ${
                            reviewReward === level
                              ? "border-[#72C2FF] bg-[#E8F4FD]"
                              : "border-gray-200 bg-white hover:border-gray-300"
                          }`}
                        >
                          <svg
                            className={`w-5 h-5 ${reviewReward === level ? "text-[#72C2FF]" : "text-gray-300"}`}
                            fill="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                          </svg>
                        </div>
                        <span
                          className={`text-[11px] ${reviewReward === level ? "text-[#4AABF5] font-medium" : "text-gray-400"}`}
                        >
                          {level}
                        </span>
                      </button>
                    ),
                  )}
                </div>
              </div>

              {/* 코멘트 */}
              <div className="mb-6">
                <p className="text-sm font-medium text-[#1A1A2E] mb-3">
                  코멘트 <span className="text-red-500">*</span>
                </p>
                <textarea
                  className="w-full border border-gray-200 rounded-xl p-4 text-sm outline-none resize-none min-h-[120px] focus:border-[#72C2FF] transition-colors"
                  placeholder="코멘트는 5자 이상 입력해 주세요."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                />
              </div>

              {/* 주의문구 */}
              <div className="flex items-start gap-3 mb-6 bg-amber-50 rounded-xl p-4">
                <span className="text-yellow-500 text-lg">⚠️</span>
                <p className="text-xs text-gray-600 leading-relaxed">
                  게임 평가하기는 게임 별 1일 1회 참여 가능하며 고의로 잘못된
                  정보를 지속 입력할 경우 경고 없이 유저가 획득한 모든 포인트를
                  회수합니다.
                </p>
              </div>
            </div>

            {/* 하단 버튼 */}
            <div className="flex border-t border-gray-100 sticky bottom-0 bg-white">
              <button
                className="flex-1 py-4 text-base font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                onClick={() => setShowReviewPopup(false)}
              >
                취소
              </button>
              <button
                className="flex-1 py-4 text-base font-medium text-white bg-[#72C2FF] hover:bg-[#4AABF5] transition-colors"
                onClick={() => {
                  setShowReviewPopup(false);
                  setReviewStars(0);
                  setReviewReward("");
                  setReviewComment("");
                }}
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
