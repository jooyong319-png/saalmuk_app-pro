// @ts-nocheck
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import type {
  LifeTechCtx,
  Event,
  Survey,
  MarketItem,
  PointSource,
} from "../components/lifetech/types_v2";
import {
  initialUserStats,
  initialCashHistory,
  events as eventsData,
  pointSources as pointSourcesData,
  surveys as surveysData,
  quickPolls as quickPollsData,
  marketItems as marketItemsData,
  posts,
  initialMyCoupons,
  initialMyTrades,
  getStatusBadge,
  getTypeBadge,
} from "../components/lifetech/data";
import EventModals from "../components/lifetech/modals/EventModals_v2";
import CashModals from "../components/lifetech/modals/CashModals_v2";
import MarketModals from "../components/lifetech/modals/MarketModals_v2";
import CouponModals from "../components/lifetech/modals/CouponModals";
import MiscModals from "../components/lifetech/modals/MiscModals";
import SurveyModal from "../components/lifetech/modals/SurveyModal";
import QuickPollCard from "../components/lifetech/cards/QuickPollCard";
import SurveyCard from "../components/lifetech/cards/SurveyCard";
import HeroSection from "../components/lifetech/HeroSection";
import LifeTechLeftSidebar from "../components/lifetech/LifeTechLeftSidebar";
import SubFilters from "../components/lifetech/SubFilters";
import SortFilterBar from "../components/lifetech/SortFilterBar";
import ListItem from "../components/lifetech/ListItem";
import CashCard from "../components/lifetech/CashCard";
import PopularPostsSection from "../components/lifetech/PopularPostsSection";
import QuickPollSection from "../components/lifetech/QuickPollSection";

export default function LifeTechPageFull() {
  const navigate = useNavigate();

  // ===== 유저 데이터 =====
  const [userStats, setUserStats] = useState(initialUserStats);
  const [myCoupons, setMyCoupons] = useState(initialMyCoupons);
  const [myTrades, setMyTrades] = useState(initialMyTrades);
  const cashHistory = initialCashHistory;
  const [pointSources, setPointSources] = useState(pointSourcesData);

  // ===== 탭 상태 =====
  const [activeTab, setActiveTab] = useState("이벤트");
  const [activeFilter, setActiveFilter] = useState("진행중");
  const [surveyMainTab, setSurveyMainTab] = useState("quick");
  const [surveyTab, setSurveyTab] = useState("설문");
  const [marketTab, setMarketTab] = useState("전체");
  const [communityTab, setCommunityTab] = useState("전체");
  const [quickPollFilter, setQuickPollFilter] = useState("all");
  const [quickPollVoted, setQuickPollVoted] = useState<Record<number, boolean>>({
    1: true,
  });

  // ===== 이벤트 필터 =====
  const [eventSort, setEventSort] = useState("latest");
  const [eventViewType, setEventViewType] = useState("card");
  const [eventFilters, setEventFilters] = useState({
    prizeTypes: [] as string[],
    entryTypes: [] as string[],
    platforms: [] as string[],
  });

  // ===== 쿠폰 모달 상태 =====
  const [showMyCoupon, setShowMyCoupon] = useState(false);
  const [couponTab, setCouponTab] = useState("unused");
  const [couponSort, setCouponSort] = useState("latest");
  const [selectedCoupon, setSelectedCoupon] = useState<any>(null);

  // ===== 이벤트 모달 상태 =====
  const [showWinnerRegister, setShowWinnerRegister] = useState(false);
  const [showCorrectionRequest, setShowCorrectionRequest] = useState(false);
  const [winnerAnnouncement, setWinnerAnnouncement] = useState<any>(null);
  const [entryTab, setEntryTab] = useState("progress");
  const [entrySort, setEntrySort] = useState("latest");

  // ===== 모달 상태 =====
  const [showEventDetail, setShowEventDetail] = useState<Event | null>(null);
  const [showMyEntries, setShowMyEntries] = useState(false);
  const [showEventFilter, setShowEventFilter] = useState(false);

  const [showMyCash, setShowMyCash] = useState(false);
  const [showChargeModal, setShowChargeModal] = useState(false);
  const [chargeStep, setChargeStep] = useState(1);
  const [chargeAmount, setChargeAmount] = useState(0);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawStep, setWithdrawStep] = useState(1);
  const [withdrawAmount, setWithdrawAmount] = useState(0);
  const [showCashHistory, setShowCashHistory] = useState(false);
  const [showBankChange, setShowBankChange] = useState(false);

  const [showProductDetail, setShowProductDetail] = useState<MarketItem | null>(null);
  const [showPurchaseFlow, setShowPurchaseFlow] = useState(false);
  const [purchaseStep, setPurchaseStep] = useState(1);
  const [selectedProduct, setSelectedProduct] = useState<MarketItem | null>(null);
  const [isSeller, setIsSeller] = useState(false);
  const [showSellFlow, setShowSellFlow] = useState(false);
  const [sellStep, setSellStep] = useState(1);
  const [showMyTrade, setShowMyTrade] = useState(false);
  const [myTradeTab, setMyTradeTab] = useState("buying");
  const [showChat, setShowChat] = useState(false);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatPartner, setChatPartner] = useState("");

  // ===== 장터 분쟁 상태 =====
  const [showDisputeModal, setShowDisputeModal] = useState(false);
  const [disputeReason, setDisputeReason] = useState("");
  const [disputeEtcText, setDisputeEtcText] = useState("");
  const [showTransactionDetail, setShowTransactionDetail] = useState(false);
  const [transactionStatus, setTransactionStatus] = useState("");

  // ===== 포인트 상세 =====
  const [showPointDetail, setShowPointDetail] = useState<PointSource | null>(null);

  // ===== 기타 모달 상태 =====
  const [showWriteModal, setShowWriteModal] = useState(false);
  const [writeStep, setWriteStep] = useState(1);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showNotification, setShowNotification] = useState(false);

  const [selectedSurvey, setSelectedSurvey] = useState<Survey | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);

  // ===== Context =====
  const ctx: LifeTechCtx = {
    userStats,
    setUserStats,
    myCoupons,
    setMyCoupons,
    myTrades,
    setMyTrades,
    cashHistory,
    mainTab: activeTab,
    setMainTab: setActiveTab,
    subTab: activeFilter,
    setSubTab: setActiveFilter,
    surveyMainTab,
    setSurveyMainTab,
    surveyTab,
    setSurveyTab,
    marketTab,
    setMarketTab,
    communityTab,
    setCommunityTab,
    quickPollFilter,
    setQuickPollFilter,
    eventSort,
    setEventSort,
    eventViewType,
    setEventViewType,
    eventFilters,
    setEventFilters,
    showMyCoupon,
    setShowMyCoupon,
    couponTab,
    setCouponTab,
    couponSort,
    setCouponSort,
    selectedCoupon,
    setSelectedCoupon,
    showEventDetail,
    setShowEventDetail,
    showMyEntries,
    setShowMyEntries,
    showEventFilter,
    setShowEventFilter,
    showWinnerRegister,
    setShowWinnerRegister,
    showCorrectionRequest,
    setShowCorrectionRequest,
    winnerAnnouncement,
    setWinnerAnnouncement,
    entryTab,
    setEntryTab,
    entrySort,
    setEntrySort,
    showMyCash,
    setShowMyCash,
    showChargeModal,
    setShowChargeModal,
    chargeStep,
    setChargeStep,
    chargeAmount,
    setChargeAmount,
    showWithdrawModal,
    setShowWithdrawModal,
    withdrawStep,
    setWithdrawStep,
    withdrawAmount,
    setWithdrawAmount,
    showCashHistory,
    setShowCashHistory,
    showBankChange,
    setShowBankChange,
    showProductDetail,
    setShowProductDetail,
    showPurchaseFlow,
    setShowPurchaseFlow,
    purchaseStep,
    setPurchaseStep,
    selectedProduct,
    setSelectedProduct,
    isSeller,
    setIsSeller,
    showSellFlow,
    setShowSellFlow,
    sellStep,
    setSellStep,
    showMyTrade,
    setShowMyTrade,
    myTradeTab,
    setMyTradeTab,
    showChat,
    setShowChat,
    chatMessages,
    setChatMessages,
    chatInput,
    setChatInput,
    chatPartner,
    setChatPartner,
    showDisputeModal,
    setShowDisputeModal,
    disputeReason,
    setDisputeReason,
    disputeEtcText,
    setDisputeEtcText,
    showTransactionDetail,
    setShowTransactionDetail,
    transactionStatus,
    setTransactionStatus,
    showPointDetail,
    setShowPointDetail,
    selectedSurvey,
    setSelectedSurvey,
    currentQuestion,
    setCurrentQuestion,
    quickPollVoted,
    setQuickPollVoted,
    showWriteModal,
    setShowWriteModal,
    writeStep,
    setWriteStep,
    showSearchModal,
    setShowSearchModal,
    showNotification,
    setShowNotification,
    events: eventsData,
    pointSources,
    setPointSources,
    surveys: surveysData,
    quickPolls: quickPollsData,
    marketItems: marketItemsData,
    posts,
    getStatusBadge,
    getTypeBadge,
    handleVote: (pollId: number, optionIndex: number) => {
      setQuickPollVoted((prev) => ({ ...prev, [pollId]: true }));
    },
  };

  // ===== 필터 설정 =====
  const getFilters = (tab?: string) => {
    const currentTab = tab || activeTab;
    switch (currentTab) {
      case "이벤트": return ["진행중", "오늘마감", "오늘발표", "발표완료", "내응모함"];
      case "앱테크": return ["전체", "포인트", "쿠폰", "기타"];
      case "설문조사": return [];
      case "장터": return ["판매중", "판매완료", "내거래함"];
      default: return [];
    }
  };

  const handleTabChange = (tab: string) => {
    if (tab === "커뮤니티") {
      navigate("/gallery?id=saenghwaltech");
      return;
    }
    setActiveTab(tab);
    const newFilters = getFilters(tab);
    setActiveFilter(newFilters[0] || "");
  };

  const filters = getFilters();

  // ===== 필터링된 데이터 =====
  const filteredEvents = eventsData.filter((e) => {
    if (activeFilter === "진행중") return e.status === "progress";
    if (activeFilter === "오늘마감") return e.dday === 0 || e.status === "today";
    if (activeFilter === "오늘발표") return e.status === "announce";
    if (activeFilter === "발표완료") return e.status === "ended";
    return true;
  });

  const progressCount = eventsData.filter((e) => e.status === "progress").length;
  const todayCount = eventsData.filter((e) => e.dday === 0).length;
  const marketTodayCount = marketItemsData.filter(
    (item) => item.createdAt?.includes("시간 전") || item.createdAt?.includes("분 전"),
  ).length;

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* 왼쪽 플로팅 사이드바 */}
      <aside
        className="fixed hidden xl:block w-[200px] py-6"
        style={{ left: "calc(50% - 640px - 216px)", top: "56px" }}
      >
        <LifeTechLeftSidebar activeTab={activeTab} onTabChange={handleTabChange} />
      </aside>

      <div className="max-w-[1280px] mx-auto px-6 py-6">
        <HeroSection eventsCount={progressCount} todayCount={todayCount} />

        <div className="grid grid-cols-[1fr_280px] gap-6 items-start">
          <main>
            {filters.length > 0 && (
              <SubFilters
                filters={filters}
                activeFilter={activeFilter}
                onFilterChange={setActiveFilter}
                onMyEntriesClick={() => setShowMyEntries(true)}
                onMyTradeClick={() => setShowMyTrade(true)}
                onWriteClick={() => setShowWriteModal(true)}
              />
            )}

            {(activeTab === "이벤트" || activeTab === "장터") && (
              <SortFilterBar
                sortValue={eventSort}
                onSortChange={setEventSort}
                onFilterClick={() => setShowEventFilter(true)}
                todayCount={activeTab === "이벤트" ? todayCount : marketTodayCount}
              />
            )}

            <div>
              {activeTab === "이벤트" && (
                <div className="space-y-3">
                  {filteredEvents.map((event) => (
                    <ListItem
                      key={event.id}
                      type="event"
                      item={event}
                      onClick={() => navigate(`/lifetech/event/${event.id}`)}
                    />
                  ))}
                </div>
              )}

              {activeTab === "앱테크" && (
                <div className="space-y-3">
                  {pointSources
                    .filter((item) => activeFilter === "전체" || item.category === activeFilter)
                    .map((item) => (
                      <ListItem
                        key={item.id}
                        type="apptech"
                        item={item}
                        onClick={() => navigate(`/lifetech/point/${item.id}`)}
                      />
                    ))}
                </div>
              )}

              {activeTab === "설문조사" && (
                <div className="space-y-4">
                  {/* 퀵설문 / 일반설문 서브탭 */}
                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      {["quick", "general"].map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setSurveyMainTab(tab)}
                          className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                            surveyMainTab === tab
                              ? "bg-[#72C2FF] text-white"
                              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                          }`}
                        >
                          {tab === "quick" ? "퀵설문" : "일반설문"}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={() => setShowWriteModal(true)}
                      className="flex items-center gap-1.5 px-4 py-1.5 bg-[#72C2FF] text-white text-sm font-semibold rounded-full hover:bg-[#5BA8E6] transition-colors"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                      등록하기
                    </button>
                  </div>

                  {surveyMainTab === "quick" && (
                    <>
                      <div className="flex gap-2">
                        {[
                          { key: "all", label: "전체" },
                          { key: "available", label: "참여가능" },
                          { key: "completed", label: "참여완료" },
                        ].map((tab) => (
                          <button
                            key={tab.key}
                            onClick={() => setQuickPollFilter(tab.key)}
                            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all border ${
                              quickPollFilter === tab.key
                                ? "border-[#72C2FF] text-[#72C2FF] bg-[#E8F4FD]"
                                : "border-gray-200 text-gray-500 bg-white hover:border-gray-300"
                            }`}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>

                      <div className="space-y-4">
                        {quickPollsData
                          .filter((poll) => {
                            const isVoted = quickPollVoted[poll.id] || poll.participated;
                            if (quickPollFilter === "available") return !isVoted;
                            if (quickPollFilter === "completed") return isVoted;
                            return true;
                          })
                          .map((poll) => (
                            <QuickPollCard
                              key={poll.id}
                              poll={poll}
                              voted={quickPollVoted[poll.id] || false}
                              onVote={(pollId) => {
                                setQuickPollVoted((prev) => ({ ...prev, [pollId]: true }));
                              }}
                            />
                          ))}
                        {quickPollsData.filter((poll) => {
                          const isVoted = quickPollVoted[poll.id] || poll.participated;
                          if (quickPollFilter === "available") return !isVoted;
                          if (quickPollFilter === "completed") return isVoted;
                          return true;
                        }).length === 0 && (
                          <div className="text-center py-12 text-gray-400">
                            {quickPollFilter === "available"
                              ? "참여 가능한 퀵설문이 없습니다"
                              : quickPollFilter === "completed"
                                ? "참여 완료한 퀵설문이 없습니다"
                                : "퀵설문이 없습니다"}
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {surveyMainTab === "general" && (
                    <div className="grid grid-cols-1 gap-3">
                      {surveysData.map((item) => (
                        <SurveyCard
                          key={item.id}
                          survey={item}
                          onSurveyClick={(survey) => {
                            navigate(`/lifetech/survey/${survey.id}`);
                          }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === "장터" && (
                <div className="space-y-3">
                  {marketItemsData
                    .filter((item) => {
                      if (activeFilter === "판매중") return item.status === "available";
                      if (activeFilter === "판매완료") return item.status === "sold";
                      return true;
                    })
                    .map((item) => (
                      <ListItem
                        key={item.id}
                        type="market"
                        item={item}
                        onClick={() => navigate(`/lifetech/market/${item.id}`)}
                      />
                    ))}
                </div>
              )}

              {activeTab === "커뮤니티" && (
                <div className="space-y-3">
                  {posts.map((item) => (
                    <ListItem key={item.id} type="community" item={item} />
                  ))}
                </div>
              )}
            </div>
          </main>

          {/* Right Sidebar */}
          <aside>
            <CashCard
              userStats={userStats}
              onChargeClick={() => {
                setChargeStep(1);
                setChargeAmount(0);
                setShowChargeModal(true);
              }}
              onWithdrawClick={() => {
                setWithdrawStep(1);
                setWithdrawAmount(0);
                setShowWithdrawModal(true);
              }}
              onDetailClick={() => setShowMyCash(true)}
              onCouponClick={() => setShowMyCoupon(true)}
            />
            <PopularPostsSection
              onPostClick={(postId) => {
                if (postId === 0) {
                  navigate("/gallery?id=saenghwaltech");
                } else {
                  navigate(`/gallery?id=saenghwaltech&post=${postId}`);
                }
              }}
            />
            <QuickPollSection
              quickPollVoted={quickPollVoted}
              setQuickPollVoted={setQuickPollVoted}
            />
          </aside>
        </div>
      </div>

      {/* 모달들 */}
      <EventModals ctx={ctx} />
      <CashModals ctx={ctx} />
      <MarketModals ctx={ctx} />
      <CouponModals ctx={ctx} />
      <MiscModals ctx={ctx} />
      {selectedSurvey && (
        <SurveyModal
          survey={selectedSurvey}
          currentQuestion={currentQuestion}
          setCurrentQuestion={setCurrentQuestion}
          onComplete={(reward: number) => {
            setUserStats((prev) => ({
              ...prev,
              ssalmukCash: prev.ssalmukCash + reward,
            }));
            setSelectedSurvey(null);
            setCurrentQuestion(0);
          }}
          onClose={() => {
            setSelectedSurvey(null);
            setCurrentQuestion(0);
          }}
        />
      )}
    </div>
  );
}
