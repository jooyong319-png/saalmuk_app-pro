import { useState, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  UserPlus,
  UserCheck,
  MessageCircle,
  ThumbsUp,
  Flag,
  Ban,
  FileText,
  Award,
  Eye,
} from "lucide-react";

// URL인지 이모지인지 판단
const isImageUrl = (str: string) => {
  return (
    str.startsWith("http") || str.startsWith("/") || str.startsWith("data:")
  );
};

export default function ProfilePage() {
  const navigate = useNavigate();
  const location = useLocation();

  // location.state에서 프로필 데이터 받기
  const profile = location.state?.profile || {
    name: "알 수 없음",
    avatar: "👤",
    avatarBg: "linear-gradient(135deg, #72C2FF, #5BA8E6)",
    badges: [],
    bio: "",
  };

  const [activeTab, setActiveTab] = useState("게시물");
  const [showReportModal, setShowReportModal] = useState(false);
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [following, setFollowing] = useState(false);

  const nickname = profile.author || profile.name || "알 수 없음";
  const hasImageAvatar = isImageUrl(profile.avatar);

  // 더미 통계
  const stats = {
    posts: 42,
    followers: 128,
    following: 89,
  };

  // 더미 게시물
  const posts = [
    {
      id: 1,
      date: "03.17",
      time: "10:24",
      channel: "리니지M",
      channelIcon: "⚔️",
      channelColor: "bg-purple-100",
      title: "이번 업데이트 진짜 대박이네요",
      content:
        "신규 던전 보상이 역대급입니다. 특히 레전더리 장비 드랍률이 2배로 올랐어요 👍",
      likes: 24,
      comments: 5,
      views: 342,
    },
    {
      id: 2,
      date: "03.17",
      time: "09:15",
      channel: "메이플스토리",
      channelIcon: "🍁",
      channelColor: "bg-orange-100",
      title: "오늘 이벤트 쿠폰 어디서 받나요?",
      content: "공홈에서 찾아봤는데 안보여서요... 혹시 아시는분?",
      likes: 8,
      comments: 12,
      views: 89,
    },
    {
      id: 3,
      date: "03.16",
      time: "18:30",
      channel: "로스트아크",
      channelIcon: "🏰",
      channelColor: "bg-amber-100",
      title: "카던 파티 구합니다!",
      content: "1490 서폿이요~ 쿠크 노말 가실분 구해요. 숙련자 우대!",
      likes: 15,
      comments: 3,
      views: 156,
    },
  ];

  // 더미 댓글
  const comments = [
    {
      id: 1,
      date: "03.17",
      time: "11:30",
      channel: "메이플스토리",
      channelIcon: "🍁",
      originalPost: "신규 유저 추천 직업 뭐가 좋을까요?",
      myComment: "아크 추천드려요! 초보자한테 딱입니다 👍",
      likes: 12,
    },
    {
      id: 2,
      date: "03.17",
      time: "08:45",
      channel: "로스트아크",
      channelIcon: "🏰",
      originalPost: "1520 세이지 카던 구해요",
      myComment: "저 1515 바드인데 같이 해도 될까요?",
      likes: 3,
    },
  ];

  // 배지 데이터
  const badges = [
    {
      emoji: "🎮",
      name: "게이머",
      desc: "첫 게임 플레이",
      rarity: "일반",
      obtained: true,
    },
    {
      emoji: "🏅",
      name: "랭커",
      desc: "랭킹 100위 달성",
      rarity: "레어",
      obtained: true,
    },
    {
      emoji: "💎",
      name: "다이아",
      desc: "누적 1000젬 획득",
      rarity: "에픽",
      obtained: true,
    },
    {
      emoji: "🔥",
      name: "인기인",
      desc: "좋아요 100개 달성",
      rarity: "레어",
      obtained: true,
    },
    {
      emoji: "⭐",
      name: "스타",
      desc: "팔로워 50명 달성",
      rarity: "레어",
      obtained: true,
    },
    {
      emoji: "📝",
      name: "작가",
      desc: "게시글 10개 작성",
      rarity: "일반",
      obtained: true,
    },
    {
      emoji: "👑",
      name: "전설",
      desc: "누적 10000젬",
      rarity: "전설",
      obtained: false,
    },
    {
      emoji: "🌟",
      name: "슈퍼스타",
      desc: "팔로워 1000명",
      rarity: "전설",
      obtained: false,
    },
  ];

  // 활동 갤러리
  const activeGalleries = [
    { icon: "⚔️", name: "리니지M", posts: 12, color: "bg-purple-100" },
    { icon: "🍁", name: "메이플스토리", posts: 8, color: "bg-orange-100" },
    { icon: "🏰", name: "로스트아크", posts: 15, color: "bg-amber-100" },
    { icon: "✨", name: "원신", posts: 7, color: "bg-blue-100" },
  ];

  const reportReasons = [
    "스팸/광고",
    "욕설/비방",
    "음란물",
    "사기/사칭",
    "기타",
  ];

  const handleFollowClick = useCallback(
    () => setFollowing((prev) => !prev),
    [],
  );

  // 채팅 버튼 클릭 - FloatingSidebar로 이벤트 전달
  const handleChatClick = useCallback(() => {
    // 커스텀 이벤트 발생 - 유저 정보 포함
    const event = new CustomEvent("openChat", {
      detail: {
        userId: nickname,
        userName: nickname,
        avatar: profile.avatar,
        avatarBg: profile.avatarBg,
      },
    });
    window.dispatchEvent(event);
  }, [nickname, profile.avatar, profile.avatarBg]);

  const handleReport = useCallback(
    (reason: string) => {
      setShowReportModal(false);
      alert(`${nickname}님을 신고했습니다. 사유: ${reason}`);
    },
    [nickname],
  );

  const handleBlock = useCallback(() => {
    setShowBlockConfirm(false);
    alert(`${nickname}님을 차단했습니다.`);
    navigate(-1);
  }, [nickname, navigate]);

  const getRarityStyle = (rarity: string) => {
    switch (rarity) {
      case "전설":
        return "from-amber-400 to-orange-500";
      case "에픽":
        return "from-purple-400 to-purple-600";
      case "레어":
        return "from-blue-400 to-blue-600";
      default:
        return "from-gray-300 to-gray-400";
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* 메인 */}
      <div className="max-w-[1200px] mx-auto px-6 py-6">
        <div className="grid grid-cols-[1fr_280px] gap-6">
          {/* 왼쪽 메인 */}
          <div className="space-y-6">
            {/* 프로필 카드 */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
              {/* 프로필 정보 */}
              <div className="px-6 py-6">
                <div className="flex items-center gap-5">
                  {/* 아바타 */}
                  {hasImageAvatar ? (
                    <img
                      src={profile.avatar}
                      alt={nickname}
                      className="w-20 h-20 rounded-2xl object-cover shadow-md"
                    />
                  ) : (
                    <div
                      className="w-20 h-20 rounded-2xl shadow-md flex items-center justify-center text-4xl"
                      style={{
                        background:
                          profile.avatarBg ||
                          "linear-gradient(135deg, #72C2FF, #5BA8E6)",
                      }}
                    >
                      {profile.avatar}
                    </div>
                  )}

                  {/* 닉네임 & 정보 */}
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <h1 className="text-xl font-bold text-gray-900">
                        {nickname}
                      </h1>
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-[11px] font-bold rounded-md">
                        🍙 쌀먹러
                      </span>
                    </div>
                    {profile.badges?.length > 0 && (
                      <div className="flex gap-1.5 mt-2">
                        {profile.badges.map((badge: string, idx: number) => (
                          <span
                            key={idx}
                            className="text-[11px] px-2 py-0.5 rounded-md bg-purple-50 text-purple-600"
                          >
                            {badge}
                          </span>
                        ))}
                      </div>
                    )}
                    <p className="text-[14px] text-gray-600 mt-2">
                      {profile.bio || "게임 좋아하는 평범한 유저입니다 🎮"}
                    </p>
                  </div>

                  {/* 버튼들 */}
                  <div className="flex gap-2">
                    <button
                      onClick={handleFollowClick}
                      className={`px-5 py-2 rounded-xl text-[14px] font-bold flex items-center gap-2 transition-all ${
                        following
                          ? "bg-gray-100 text-gray-600 hover:bg-gray-200"
                          : "bg-[#72C2FF] text-white hover:bg-[#5BA8E6]"
                      }`}
                    >
                      {following ? (
                        <>
                          <UserCheck size={18} />
                          팔로잉
                        </>
                      ) : (
                        <>
                          <UserPlus size={18} />
                          팔로우
                        </>
                      )}
                    </button>
                    <button
                      onClick={handleChatClick}
                      className="p-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200"
                    >
                      <MessageCircle size={18} />
                    </button>
                    <button
                      onClick={() => setShowReportModal(true)}
                      className="p-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200"
                    >
                      <Flag size={18} />
                    </button>
                    <button
                      onClick={() => setShowBlockConfirm(true)}
                      className="p-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200"
                    >
                      <Ban size={18} />
                    </button>
                  </div>
                </div>

                {/* 통계 */}
                <div className="flex items-center gap-8 mt-5 pt-5 border-t border-gray-100">
                  {[
                    { label: "게시물", value: stats.posts },
                    { label: "팔로워", value: stats.followers },
                    { label: "팔로잉", value: stats.following },
                  ].map((item) => (
                    <div key={item.label} className="text-center">
                      <p className="text-lg font-bold text-gray-900">
                        {item.value}
                      </p>
                      <p className="text-[12px] text-gray-500">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 탭 영역 */}
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="flex border-b border-gray-100">
                {[
                  { key: "게시물", icon: FileText },
                  { key: "댓글", icon: MessageCircle },
                  { key: "배지", icon: Award },
                ].map(({ key, icon: Icon }) => (
                  <button
                    key={key}
                    onClick={() => setActiveTab(key)}
                    className={`flex-1 py-3.5 text-[14px] font-medium flex items-center justify-center gap-2 relative ${
                      activeTab === key ? "text-gray-900" : "text-gray-400"
                    }`}
                  >
                    <Icon size={16} />
                    {key}
                    {activeTab === key && (
                      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-0.5 bg-[#72C2FF] rounded-full" />
                    )}
                  </button>
                ))}
              </div>

              <div className="min-h-[350px]">
                {/* 게시물 */}
                {activeTab === "게시물" && (
                  <div className="divide-y divide-gray-50">
                    {posts.map((post) => (
                      <div
                        key={post.id}
                        className="p-4 hover:bg-gray-50 cursor-pointer"
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-9 h-9 rounded-lg ${post.channelColor} flex items-center justify-center text-base shrink-0`}
                          >
                            {post.channelIcon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 text-[12px] text-gray-500 mb-1">
                              <span className="font-medium text-gray-700">
                                {post.channel}
                              </span>
                              <span>·</span>
                              <span>
                                {post.date} {post.time}
                              </span>
                            </div>
                            <h3 className="text-[14px] font-bold text-gray-900 mb-1">
                              {post.title}
                            </h3>
                            <p className="text-[13px] text-gray-600 line-clamp-1">
                              {post.content}
                            </p>
                            <div className="flex items-center gap-4 mt-2 text-[12px] text-gray-400">
                              <span className="flex items-center gap-1">
                                <ThumbsUp size={13} />
                                {post.likes}
                              </span>
                              <span className="flex items-center gap-1">
                                <MessageCircle size={13} />
                                {post.comments}
                              </span>
                              <span className="flex items-center gap-1">
                                <Eye size={13} />
                                {post.views}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 댓글 */}
                {activeTab === "댓글" && (
                  <div className="divide-y divide-gray-50">
                    {comments.map((c) => (
                      <div key={c.id} className="p-4">
                        <div className="flex items-center gap-2 text-[12px] text-gray-500 mb-2">
                          <span className="text-base">{c.channelIcon}</span>
                          <span className="font-medium text-gray-700">
                            {c.channel}
                          </span>
                          <span>·</span>
                          <span>
                            {c.date} {c.time}
                          </span>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-2.5 mb-2">
                          <p className="text-[12px] text-gray-500">
                            "{c.originalPost}"
                          </p>
                        </div>
                        <p className="text-[13px] text-gray-800">
                          {c.myComment}
                        </p>
                        <div className="flex items-center gap-3 mt-2 text-[12px] text-gray-400">
                          <span className="flex items-center gap-1">
                            <ThumbsUp size={13} />
                            {c.likes}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 배지 */}
                {activeTab === "배지" && (
                  <div className="p-5">
                    <div className="grid grid-cols-4 gap-3">
                      {badges.map((badge, idx) => (
                        <div
                          key={idx}
                          className={`relative flex flex-col items-center p-3 rounded-xl border ${
                            badge.obtained
                              ? "bg-white border-gray-100"
                              : "bg-gray-50 border-gray-100 opacity-50"
                          }`}
                        >
                          <div
                            className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl bg-gradient-to-br ${getRarityStyle(badge.rarity)}`}
                          >
                            {badge.emoji}
                          </div>
                          <span className="text-[12px] font-bold text-gray-800 mt-2">
                            {badge.name}
                          </span>
                          <span className="text-[10px] text-gray-500">
                            {badge.desc}
                          </span>
                          {!badge.obtained && (
                            <div className="absolute inset-0 flex items-center justify-center bg-white/70 rounded-xl">
                              <span className="text-[11px] text-gray-400">
                                미획득
                              </span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 오른쪽 사이드바 */}
          <div className="space-y-4">
            {/* 활동 갤러리 */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <h3 className="text-[13px] font-bold text-gray-900 mb-3">
                활동 갤러리
              </h3>
              <div className="space-y-2">
                {activeGalleries.map((g, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                  >
                    <div
                      className={`w-9 h-9 rounded-lg ${g.color} flex items-center justify-center text-base`}
                    >
                      {g.icon}
                    </div>
                    <div className="flex-1">
                      <p className="text-[13px] font-medium text-gray-800">
                        {g.name}
                      </p>
                      <p className="text-[11px] text-gray-500">
                        게시물 {g.posts}개
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 배지 요약 */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <h3 className="text-[13px] font-bold text-gray-900 mb-3">
                배지 현황
              </h3>
              <div className="grid grid-cols-4 gap-2">
                {badges
                  .filter((b) => b.obtained)
                  .slice(0, 8)
                  .map((b, idx) => (
                    <div
                      key={idx}
                      className="aspect-square rounded-lg bg-gray-50 flex items-center justify-center text-lg"
                      title={b.name}
                    >
                      {b.emoji}
                    </div>
                  ))}
              </div>
              <p className="text-[11px] text-gray-500 mt-2 text-center">
                총 {badges.filter((b) => b.obtained).length}개 획득
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 신고 모달 */}
      {showReportModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
          onClick={() => setShowReportModal(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="text-[15px] font-bold text-gray-900 text-center">
                신고하기
              </h3>
            </div>
            <div className="py-1">
              {reportReasons.map((r) => (
                <button
                  key={r}
                  onClick={() => handleReport(r)}
                  className="w-full px-5 py-3 text-left text-[14px] text-gray-700 hover:bg-gray-50"
                >
                  {r}
                </button>
              ))}
            </div>
            <div className="p-4 border-t border-gray-100">
              <button
                onClick={() => setShowReportModal(false)}
                className="w-full py-2.5 text-gray-500 font-medium"
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 차단 확인 */}
      {showBlockConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
          onClick={() => setShowBlockConfirm(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-6 text-center">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Ban size={24} className="text-red-500" />
              </div>
              <h3 className="text-[15px] font-bold text-gray-900 mb-1">
                {nickname}님을 차단할까요?
              </h3>
              <p className="text-[13px] text-gray-500">
                차단하면 이 유저의 게시물과 댓글이 보이지 않습니다.
              </p>
            </div>
            <div className="flex border-t border-gray-100">
              <button
                onClick={() => setShowBlockConfirm(false)}
                className="flex-1 py-3.5 text-gray-500 font-medium border-r border-gray-100"
              >
                취소
              </button>
              <button
                onClick={handleBlock}
                className="flex-1 py-3.5 text-red-500 font-semibold"
              >
                차단
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
