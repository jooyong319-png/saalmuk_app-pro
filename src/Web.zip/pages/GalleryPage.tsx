import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";

// Context Providers
import { InterestProvider } from "../components/gallery/InterestContext";
import { RecentProvider } from "../components/gallery/RecentContext";
import { FollowProvider } from "../components/gallery/FollowContext";

// Components
import LeftSidebar from "../components/gallery/LeftSidebar";
import RightSidebar from "../components/gallery/RightSidebar";
import FollowingContent from "../components/gallery/FollowingContent";
import HotContent from "../components/gallery/HotContent";
import NewsContent from "../components/gallery/NewsContent";
import GalleryContent from "../components/gallery/GalleryContent";
import GalleryDetailContent from "../components/gallery/GalleryDetailContent";
import InterestContent from "../components/gallery/InterestContent";
import RankingContent from "../components/gallery/RankingContent";
import InterestGroupSheet from "../components/gallery/InterestGroupSheet";
import { ToastProvider } from "../components/gallery/Toast";
import type { GalleryItemData } from "../components/gallery/types";
import { getGalleryById } from "../components/gallery/galleryData";

// ===== 갤러리 데이터 =====
const allGalleries: GalleryItemData[] = [
  // 쌀먹 정보
  {
    id: 1,
    icon: "🔥",
    name: "지금 핫한",
    desc: "실시간 인기 게임 정보",
    description:
      "실시간으로 인기있는 게임들의 정보와 공략을 공유하는 공간입니다.",
    color: "bg-orange-100 text-orange-600",
  },
  {
    id: 2,
    icon: "📢",
    name: "사전예약, 신서버",
    desc: "신규 게임 및 서버 오픈",
    description: "새로 출시되는 게임 사전예약과 신서버 오픈 정보를 공유합니다.",
    color: "bg-purple-100 text-purple-600",
  },
  {
    id: 3,
    icon: "💬",
    name: "쌀먹 라운지",
    desc: "자유로운 수다 공간",
    description: "게임 이야기부터 일상까지 자유롭게 소통하는 라운지입니다.",
    color: "bg-blue-100 text-blue-600",
  },
  {
    id: 4,
    icon: "🖥️",
    name: "쌀먹정비 세팅",
    desc: "PC 및 장비 세팅 정보",
    description: "게임을 위한 PC 사양과 장비 세팅 정보를 공유합니다.",
    color: "bg-gray-100 text-gray-600",
  },
  // 모바일 게임
  {
    id: 101,
    icon: "⚔️",
    name: "아이온2",
    desc: "MMORPG",
    description: "엔씨소프트에서 개발한 모바일 MMORPG.",
    color: "bg-blue-100 text-blue-600",
  },
  {
    id: 102,
    icon: "🗡️",
    name: "로드나인",
    desc: "MMORPG",
    description: "넥슨에서 서비스하는 모바일 MMORPG.",
    color: "bg-red-100 text-red-600",
  },
  {
    id: 103,
    icon: "🛡️",
    name: "오딘",
    desc: "발할라 라이징",
    description: "카카오게임즈에서 서비스하는 북유럽 신화 기반 MMORPG.",
    color: "bg-purple-100 text-purple-600",
  },
  {
    id: 104,
    icon: "⚔️",
    name: "리니지M",
    desc: "MMORPG",
    description: "엔씨소프트의 리니지 IP를 기반으로 한 모바일 MMORPG의 원조.",
    color: "bg-gray-100 text-gray-600",
  },
  {
    id: 105,
    icon: "🏹",
    name: "아키펙트",
    desc: "MMORPG",
    description: "카카오게임즈에서 서비스하는 3D 오픈월드 MMORPG.",
    color: "bg-green-100 text-green-600",
  },
  {
    id: 106,
    icon: "🍁",
    name: "메이플스토리M",
    desc: "MMORPG",
    description: "넥슨의 메이플스토리를 모바일로 구현한 사이드뷰 MMORPG.",
    color: "bg-orange-100 text-orange-600",
  },
  // PC 게임
  {
    id: 201,
    icon: "⚔️",
    name: "리니지 클래식",
    desc: "MMORPG",
    description: "엔씨소프트의 클래식 감성 리니지 온라인.",
    color: "bg-gray-100 text-gray-600",
  },
  {
    id: 202,
    icon: "🍁",
    name: "메이플스토리",
    desc: "MMORPG",
    description: "넥슨의 대표 사이드뷰 MMORPG.",
    color: "bg-orange-100 text-orange-600",
  },
  {
    id: 203,
    icon: "🏰",
    name: "로스트아크",
    desc: "액션 RPG",
    description: "스마일게이트의 쿼터뷰 액션 MMORPG.",
    color: "bg-amber-100 text-amber-600",
  },
  {
    id: 204,
    icon: "🎵",
    name: "마비노기",
    desc: "MMORPG",
    description: "넥슨의 판타지 라이프 MMORPG.",
    color: "bg-green-100 text-green-600",
  },
  {
    id: 205,
    icon: "🎲",
    name: "던전앤파이터",
    desc: "액션 RPG",
    description: "넥슨의 2D 횡스크롤 액션 RPG.",
    color: "bg-blue-100 text-blue-600",
  },
];

// ===== 메인 컴포넌트 =====
function GalleryPageContent() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  // 메뉴 상태: "피드" | "갤러리" | "관심" | "순위"
  const [activeMenu, setActiveMenu] = useState("피드");
  // 서브메뉴 상태 (피드용): "지금핫한" | "팔로잉" | "뉴스"
  const [activeSubMenu, setActiveSubMenu] = useState("지금핫한");

  // 갤러리 상태
  const [selectedGallery, setSelectedGallery] =
    useState<GalleryItemData | null>(null);
  const [activeCategory, setActiveCategory] = useState("전체");
  const [initialPostId, setInitialPostId] = useState<number | null>(null);

  // 관심 그룹 시트
  const [showInterestSheet, setShowInterestSheet] = useState(false);
  const [interestSheetGalleryId, setInterestSheetGalleryId] = useState<
    string | null
  >(null);

  // 프로필 페이지 이동 핸들러
  const handleProfileClick = (
    name: string,
    avatar: string,
    avatarBg?: string,
  ) => {
    navigate("/profile", {
      state: {
        profile: {
          name,
          avatar,
          avatarBg,
          badges: ["쌀먹러", "활동왕"],
          bio: "게임 좋아하는 평범한 유저입니다 🎮",
        },
      },
    });
  };

  // URL 파라미터 처리
  useEffect(() => {
    const galleryId = searchParams.get("id");
    const postId = searchParams.get("post");

    if (galleryId) {
      // 먼저 숫자 ID로 시도
      let gallery = allGalleries.find((g) => g.id === Number(galleryId));

      // 숫자 ID로 못 찾으면 galleryData.ts에서 문자열 ID로 검색
      if (!gallery) {
        const galleryData = getGalleryById(galleryId);
        if (galleryData) {
          gallery = {
            id: parseInt(galleryId) || 0,
            icon: galleryData.icon,
            name: galleryData.name,
            desc: galleryData.description,
            description: galleryData.description,
            color: galleryData.color,
          };
        }
      }

      if (gallery) {
        setSelectedGallery(gallery);
        setActiveMenu("갤러리");
        if (postId) {
          setInitialPostId(Number(postId));
        }
        setSearchParams({});
      }
    } else if (postId) {
      setInitialPostId(Number(postId));
      setActiveMenu("피드");
      setActiveSubMenu("지금핫한");
      setSearchParams({});
    }
  }, [searchParams, setSearchParams]);

  // 메뉴 변경 핸들러
  const handleMenuChange = (menu: string, subMenu?: string) => {
    setActiveMenu(menu);
    if (subMenu) {
      setActiveSubMenu(subMenu);
    }
    // 갤러리 메뉴가 아니면 선택 초기화
    if (menu !== "갤러리") {
      setSelectedGallery(null);
      setActiveCategory("전체");
    }
  };

  // 갤러리 선택
  const handleSelectGallery = (gallery: GalleryItemData) => {
    setSelectedGallery(gallery);
    setActiveCategory("전체");
    setActiveMenu("갤러리");
  };

  // 갤러리 목록으로 돌아가기
  const handleBackToList = () => {
    setSelectedGallery(null);
    setActiveCategory("전체");
  };

  // 관심 그룹 시트 열기
  const handleShowInterestSheet = (galleryId?: string) => {
    setInterestSheetGalleryId(
      galleryId || selectedGallery?.id?.toString() || null,
    );
    setShowInterestSheet(true);
  };

  // 3컬럼 여부
  const is3Column =
    activeMenu === "피드" ||
    (activeMenu === "갤러리" && selectedGallery) ||
    activeMenu === "관심";

  // 현재 콘텐츠 렌더링
  const renderContent = () => {
    switch (activeMenu) {
      case "피드":
        switch (activeSubMenu) {
          case "지금핫한":
            return <HotContent onProfileClick={handleProfileClick} initialPostId={initialPostId} onPostOpened={() => setInitialPostId(null)} />;
          case "팔로잉":
            return (
              <FollowingContent
                initialPostId={initialPostId}
                onPostOpened={() => setInitialPostId(null)}
                onProfileClick={handleProfileClick}
              />
            );
          case "뉴스":
            return <NewsContent onProfileClick={handleProfileClick} />;
          default:
            return <HotContent onProfileClick={handleProfileClick} />;
        }

      case "갤러리":
        if (selectedGallery) {
          return (
            <GalleryDetailContent
              gallery={selectedGallery}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
              onBack={handleBackToList}
              initialPostId={initialPostId}
              onPostOpened={() => setInitialPostId(null)}
              onShowInterestSheet={() => handleShowInterestSheet()}
              onProfileClick={handleProfileClick}
            />
          );
        }
        return (
          <GalleryContent
            onSelectGallery={handleSelectGallery}
            onNavigateToHot={() => {
              setActiveMenu("피드");
              setActiveSubMenu("지금핫한");
            }}
          />
        );

      case "관심":
        return (
          <InterestContent
            onGalleryClick={(galleryId: string) => {
              // galleryData.ts에서 갤러리 찾기
              const galleryData = getGalleryById(galleryId);
              if (galleryData) {
                // GalleryItemData 형태로 변환
                const gallery: GalleryItemData = {
                  id: parseInt(galleryId) || 0,
                  icon: galleryData.icon,
                  name: galleryData.name,
                  desc: galleryData.description,
                  description: galleryData.description,
                  color: galleryData.color,
                };
                handleSelectGallery(gallery);
              }
            }}
          />
        );

      case "순위":
        return (
          <RankingContent
            onProfileClick={(userName) => {
              handleProfileClick(
                userName,
                "😎",
                "linear-gradient(135deg, #72C2FF, #5BA8E6)",
              );
            }}
          />
        );

      default:
        return <HotContent />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* 왼쪽 플로팅 사이드바 */}
      {/* REVERT: 원래는 그리드 안 <aside className="py-6 pr-6 sticky top-14 self-start"> */}
      <aside
        className="fixed hidden xl:block w-[200px] py-6"
        style={{ left: "calc(50% - 640px - 216px)", top: "56px" }}
      >
        <LeftSidebar
          activeMenu={activeMenu}
          activeSubMenu={activeSubMenu}
          onMenuChange={handleMenuChange}
          selectedGallery={selectedGallery}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
          onBackToList={handleBackToList}
        />
      </aside>

      <div className="max-w-[1280px] mx-auto px-6">
        <div
          className={`grid min-h-[calc(100vh-56px)] ${
            is3Column ? "grid-cols-[1fr_280px]" : "grid-cols-1"
          }`}
        >
          {/* 메인 영역 */}
          <main className="bg-white border-l border-r border-gray-200 px-6 min-h-full mx-5">
            {renderContent()}
          </main>

          {/* 오른쪽 사이드바 */}
          {is3Column && (
            <aside className="py-6 self-start">
              <RightSidebar selectedGallery={selectedGallery} />
            </aside>
          )}
        </div>
      </div>

      {/* 관심 그룹 시트 */}
      {showInterestSheet && interestSheetGalleryId && (
        <InterestGroupSheet
          galleryId={interestSheetGalleryId}
          onClose={() => {
            setShowInterestSheet(false);
            setInterestSheetGalleryId(null);
          }}
          onComplete={() => {
            // 완료 후 처리
          }}
        />
      )}
    </div>
  );
}

// ===== Provider로 감싼 최종 컴포넌트 =====
export default function GalleryPage() {
  return (
    <ToastProvider>
      <InterestProvider>
        <RecentProvider>
          <FollowProvider>
            <GalleryPageContent />
          </FollowProvider>
        </RecentProvider>
      </InterestProvider>
    </ToastProvider>
  );
}
