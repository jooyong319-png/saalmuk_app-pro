import { useState } from "react";

// ─── Interfaces ───
interface ReviewData {
  id: number;
  name: string;
  level: number;
  date: string;
  rating: number;
  stars: string;
  image: string;
  content: string[];
  likes: number;
  comments: number;
  views: number;
}

// ─── 리뷰 카드 ───
function ReviewCard({
  review,
  expanded,
  onToggleExpand,
  onShowGift,
}: {
  review: ReviewData;
  expanded: boolean;
  onToggleExpand: () => void;
  onShowGift: () => void;
}) {
  return (
    <div className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100/50">
      <div className="flex items-start gap-5">
        <img
          src={review.image}
          alt="프로필"
          className="w-16 h-16 rounded-2xl object-cover shadow-md"
        />
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="font-bold text-gray-900 text-lg">
                {review.name}
              </span>
              <span className="bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white text-xs px-3 py-1 rounded-full font-semibold">
                Lv.{review.level}
              </span>
            </div>
            <span className="text-sm text-gray-400">{review.date}</span>
          </div>
          <div className="flex items-center gap-3 mt-3">
            <span className="text-yellow-400 text-lg tracking-wider">
              {review.stars}
            </span>
            <span className="font-bold text-lg text-gray-900">
              {review.rating}
            </span>
            <span className="text-gray-400">점</span>
          </div>
        </div>
      </div>

      <div className="mt-6 text-[15px] text-gray-600 leading-[1.8]">
        {expanded
          ? review.content.map((line, idx) => (
              <p key={idx} className={idx > 0 ? "mt-3" : ""}>
                {line}
              </p>
            ))
          : review.content.slice(0, 2).map((line, idx) => (
              <p key={idx} className={idx > 0 ? "mt-3" : ""}>
                {line}
              </p>
            ))}
        {review.content.length > 2 && (
          <button
            className="text-[#4AABF5] text-sm mt-4 hover:underline font-semibold"
            onClick={onToggleExpand}
          >
            {expanded ? "간략하게 ▲" : "더보기 ▼"}
          </button>
        )}
      </div>

      {/* 액션 버튼 */}
      <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
        <div className="flex items-center gap-8">
          <button className="flex items-center gap-2 text-gray-400 hover:text-rose-500 transition-colors">
            <span className="text-xl">❤️</span>
            <span className="text-sm font-medium">{review.likes}</span>
          </button>
          <button className="flex items-center gap-2 text-gray-400 hover:text-[#4AABF5] transition-colors">
            <span className="text-xl">💬</span>
            <span className="text-sm font-medium">{review.comments}</span>
          </button>
          <button className="text-xl text-gray-400 hover:text-[#4AABF5] transition-colors">
            🔗
          </button>
        </div>
        <button
          className="text-2xl text-gray-300 hover:text-amber-400 transition-colors hover:scale-110"
          onClick={onShowGift}
        >
          🎁
        </button>
      </div>
    </div>
  );
}

// ─── 메인 컴포넌트 ───
export default function GameDetailPage() {
  const [activeTab, setActiveTab] = useState("평가글");
  const [isLiked, setIsLiked] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [reviewTab, setReviewTab] = useState("유저평가");
  const [expandedReviews, setExpandedReviews] = useState<number[]>([]);
  const [showGiftPopup, setShowGiftPopup] = useState(false);
  const [showAwardHistory, setShowAwardHistory] = useState(false);
  const [showReviewPopup, setShowReviewPopup] = useState(false);
  const [reviewStars, setReviewStars] = useState(0);
  const [reviewReward, setReviewReward] = useState("");
  const [reviewComment, setReviewComment] = useState("");
  const [showSnsPopup, setShowSnsPopup] = useState(false);
  const [mediaIndex, setMediaIndex] = useState(0);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const tabs = [
    "소개",
    "평가글",
    "게임이벤트",
    "게임쿠폰",
    "쌀먹점수",
    "코인시세",
    "커뮤니티",
  ];

  const mediaItems = [
    {
      type: "video",
      src: "https://sgimage.netmarble.com/images/netmarble/rfnext/20250121/ro4j1737451863887.mp4",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/d99c79ec564545cc8f6f4333a9eefbb3.jpg",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/93b0fb0121864408a97d86e23226176d.jpg",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/81c5661e8c6b439ab14d3e6c83051739.jpg",
    },
  ];

  const reviews: ReviewData[] = [
    {
      id: 1,
      name: "소보로",
      level: 7,
      date: "2025-01-30",
      rating: 4.0,
      stars: "★★★★☆",
      image:
        "https://edge.ssalmuk.com/editorImage/8daa1b53fba545ffb56d1cac5517407b.png",
      content: [
        "게임이라기 보단 메타월드죠.",
        "가상 공간에 내 땅사고, 임대로 받고 그런느낌.",
      ],
      likes: 12,
      comments: 3,
      views: 124,
    },
    {
      id: 2,
      name: "게임러버",
      level: 12,
      date: "2025-01-28",
      rating: 3.0,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/d2008bde9fe541edabc5762d18b04e7b.png",
      content: ["초반 진입장벽이 좀 있어요.", "근데 익숙해지면 꽤 재밌습니다."],
      likes: 8,
      comments: 1,
      views: 89,
    },
    {
      id: 3,
      name: "쌀먹마스터",
      level: 25,
      date: "2025-01-25",
      rating: 5.0,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/daa326b1f7d141dbb6f42473312e562c.jfif",
      content: [
        "P2E 게임 중에서는 최고입니다!",
        "꾸준히 하면 수익 나와요.",
        "초보자도 쉽게 시작할 수 있어요.",
      ],
      likes: 25,
      comments: 7,
      views: 256,
    },
    {
      id: 4,
      name: "메타버스탐험가",
      level: 18,
      date: "2025-01-24",
      rating: 4.5,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif",
      content: [
        "가상 부동산 투자에 관심있다면 추천!",
        "MANA 토큰 시세도 나쁘지 않아요.",
      ],
      likes: 19,
      comments: 5,
      views: 178,
    },
    {
      id: 5,
      name: "블록체인뉴비",
      level: 3,
      date: "2025-01-22",
      rating: 2.5,
      stars: "★★☆☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/935049a546e744a98c0c77e1d498ae18.png",
      content: ["진입장벽이 너무 높아요.", "처음 시작하기 어렵습니다."],
      likes: 4,
      comments: 2,
      views: 67,
    },
    {
      id: 6,
      name: "크립토킹",
      level: 31,
      date: "2025-01-20",
      rating: 4.0,
      stars: "★★★★☆",
      image:
        "https://edge.ssalmuk.com/editorImage/8340a446068d4799a60acbf85f415e28.jpg",
      content: [
        "장기 투자로 접근하면 괜찮아요.",
        "단기 수익은 기대하기 어렵습니다.",
      ],
      likes: 15,
      comments: 4,
      views: 143,
    },
    {
      id: 7,
      name: "NFT수집가",
      level: 22,
      date: "2025-01-18",
      rating: 5.0,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/145ef9589b8047169888e2f0c232b3d4.jpg",
      content: [
        "웨어러블 NFT 수집이 너무 재밌어요!",
        "다양한 이벤트도 많이 열립니다.",
      ],
      likes: 22,
      comments: 6,
      views: 198,
    },
    {
      id: 8,
      name: "게임분석가",
      level: 15,
      date: "2025-01-16",
      rating: 3.5,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/f85655d36efc44aaaf692cbef435271d.jpg",
      content: [
        "그래픽은 아쉽지만 컨셉이 좋아요.",
        "메타버스 입문용으로 추천합니다.",
      ],
      likes: 11,
      comments: 3,
      views: 112,
    },
    {
      id: 9,
      name: "디파이고수",
      level: 28,
      date: "2025-01-14",
      rating: 4.5,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/56ce60fa47784514b73aa0afafbecc99.jpg",
      content: [
        "LAND 스테이킹으로 패시브 인컴 가능!",
        "초기 투자금이 좀 필요합니다.",
      ],
      likes: 28,
      comments: 9,
      views: 287,
    },
    {
      id: 10,
      name: "캐주얼게이머",
      level: 5,
      date: "2025-01-12",
      rating: 3.0,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/26850577efbf4dcd9ae8df48b75d4e7a.jpg",
      content: ["가볍게 즐기기엔 좋아요.", "수익 목적보다는 체험용으로 추천."],
      likes: 6,
      comments: 1,
      views: 54,
    },
  ];

  const quickLinks = [
    { icon: "🏠", label: "홈페이지" },
    { icon: "📋", label: "업데이트" },
    { icon: "📖", label: "가이드북" },
    { icon: "💬", label: "커뮤니티" },
  ];

  const snsLinks = [
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/discord35.svg",
      name: "디스코드",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/facebook35.svg",
      name: "페이스북",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/reddit35.svg",
      name: "레딧",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/twitter35.svg",
      name: "트위터",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/youtube35.svg",
      name: "유튜브",
    },
  ];

  const coupons = [
    {
      id: 1,
      avatar:
        "https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif",
      nickname: "쿠폰다내꺼",
      code: "U323KSK3K1K23K",
      period: "2025-10-30 ~ 정보없음",
      rewards: "물약100개, 초보자 방어구 세트",
    },
    {
      id: 2,
      avatar:
        "https://edge.ssalmuk.com/editorImage/935049a546e744a98c0c77e1d498ae18.png",
      nickname: "꽝우실러취요",
      code: "WELCOME2025NEW",
      period: "2025-09-16 ~ 정보없음",
      rewards: "물약100개, 초보자 방어구 세트",
    },
    {
      id: 3,
      avatar:
        "https://edge.ssalmuk.com/editorImage/8daa1b53fba545ffb56d1cac5517407b.png",
      nickname: "게임마스터",
      code: "SSALMUK7777GG",
      period: "2025-12-31 ~ 2026-03-31",
      rewards: "골드 5000, 프리미엄 상자 1개",
    },
  ];

  const handleLikeToggle = () => {
    setIsLiked(!isLiked);
    if (!isLiked) {
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2000);
    }
  };

  const toggleReviewExpand = (id: number) => {
    setExpandedReviews((prev) =>
      prev.includes(id) ? prev.filter((rid) => rid !== id) : [...prev, id],
    );
  };

  return (
    <div
      className="min-h-screen"
      style={{
        background: "linear-gradient(180deg, #E8F4FD 0%, #F8FBFF 100%)",
      }}
    >
      {/* 메인 컨테이너 */}
      <div className="max-w-[1300px] mx-auto px-6">
        {/* 게임 정보 헤더 */}
        <div
          className="rounded-b-[32px] p-10 mb-5 animate-fadeUp"
          style={{
            backgroundImage:
              "url('https://ssalmuk.com/images/img_ranking_detail/detail_banner.svg')",
          }}
        >
          <div className="flex gap-8 items-start">
            {/* 게임 아이콘 */}
            <img
              src="https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif"
              alt="디센트럴랜드"
              className="w-64 h-64 rounded-[28px] object-cover shadow-2xl ring-4 ring-white/30"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h1 className="text-4xl font-bold text-white tracking-tight">
                  디센트럴랜드
                </h1>
                <button
                  onClick={handleLikeToggle}
                  className={`p-4 rounded-2xl transition-all shadow-lg ${
                    isLiked
                      ? "bg-white text-rose-500"
                      : "bg-white/20 text-white hover:bg-white/30 backdrop-blur-sm"
                  }`}
                >
                  <svg
                    className="w-7 h-7"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                  </svg>
                </button>
              </div>

              <div className="flex gap-3 mt-5">
                {["메타버스", "소셜", "P2E"].map((tag) => (
                  <span
                    key={tag}
                    className="bg-white/25 backdrop-blur-sm text-white text-sm px-5 py-2 rounded-full font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* 퀵 링크 */}
              <div className="flex gap-6 mt-8">
                {quickLinks.map((link, idx) => (
                  <div
                    key={idx}
                    className="flex flex-col items-center cursor-pointer group"
                  >
                    <div className="w-16 h-16 bg-white/90 backdrop-blur rounded-2xl flex items-center justify-center text-2xl shadow-lg group-hover:scale-110 group-hover:shadow-xl transition-all">
                      {link.icon}
                    </div>
                    <span className="text-xs text-white/90 mt-3 font-medium">
                      {link.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 순위 & SNS */}
          <div className="bg-white/95 backdrop-blur rounded-3xl p-6 mt-8 flex items-center shadow-xl">
            <div className="text-center px-12">
              <p className="text-sm text-gray-500 mb-2">국내순위</p>
              <p className="font-bold text-gray-900 text-2xl">
                1위{" "}
                <span className="text-gray-400 text-sm font-normal">(-)</span>
              </p>
            </div>
            <div className="w-px h-16 bg-gray-200"></div>
            <div className="flex-1 text-center px-8">
              <p className="text-sm text-gray-500 mb-3">활성화된 SNS 채널</p>
              <div className="flex gap-4 justify-center">
                {snsLinks.map((sns, idx) => (
                  <img
                    key={idx}
                    src={sns.icon}
                    alt={sns.name}
                    className="w-8 h-8 rounded-lg cursor-pointer hover:scale-125 transition-transform"
                  />
                ))}
              </div>
            </div>
            <button
              className="text-gray-400 text-3xl px-8 hover:text-[#4AABF5] transition-colors"
              onClick={() => setShowSnsPopup(true)}
            >
              →
            </button>
          </div>
        </div>

        {/* 탭 메뉴 */}
        <div
          className="bg-white rounded-[28px] shadow-sm mb-5 animate-fadeUp"
          style={{ animationDelay: "0.1s" }}
        >
          <div className="flex border-b border-gray-100 px-4">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-8 py-6 text-[15px] font-medium whitespace-nowrap transition-all relative ${
                  activeTab === tab
                    ? "text-[#4AABF5] font-bold"
                    : "text-gray-400 hover:text-gray-600"
                }`}
              >
                {tab}
                {activeTab === tab && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] rounded-full" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* 탭 컨텐츠 */}
        <div
          className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-8 animate-fadeUp"
          style={{ animationDelay: "0.2s" }}
        >
          <div>
            {/* 소개 탭 */}
            {activeTab === "소개" && (
              <div className="space-y-10">
                {/* 미디어 슬라이더 */}
                <div className="relative bg-white rounded-[28px] p-8 shadow-sm">
                  {/* 좌측 화살표 */}
                  {mediaIndex > 0 && (
                    <button
                      onClick={() => setMediaIndex(mediaIndex - 1)}
                      className="absolute left-[-24px] top-1/2 -translate-y-1/2 w-14 h-14 bg-white rounded-full shadow-xl flex items-center justify-center hover:scale-110 transition-all z-10"
                    >
                      <svg
                        className="w-6 h-6 text-gray-700"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2.5}
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 19l-7-7 7-7"
                        />
                      </svg>
                    </button>
                  )}

                  {/* 우측 화살표 */}
                  {mediaIndex < mediaItems.length - 2 && (
                    <button
                      onClick={() => setMediaIndex(mediaIndex + 1)}
                      className="absolute right-[-24px] top-1/2 -translate-y-1/2 w-14 h-14 bg-white rounded-full shadow-xl flex items-center justify-center hover:scale-110 transition-all z-10"
                    >
                      <svg
                        className="w-6 h-6 text-gray-700"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2.5}
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </button>
                  )}

                  {/* 슬라이더 컨테이너 */}
                  <div className="overflow-hidden rounded-2xl">
                    <div
                      className="flex gap-6 transition-transform duration-500 ease-out"
                      style={{ transform: `translateX(-${mediaIndex * 52}%)` }}
                    >
                      {mediaItems.map((item, i) => (
                        <div
                          key={i}
                          className="w-[48%] shrink-0 rounded-2xl overflow-hidden shadow-lg cursor-pointer group"
                        >
                          {item.type === "video" ? (
                            <video
                              src={item.src}
                              className="w-full aspect-video object-cover"
                              muted
                              loop
                              playsInline
                              controls
                            />
                          ) : (
                            <img
                              src={item.src}
                              alt={`스크린샷${i}`}
                              className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500"
                              onClick={() => setLightboxIndex(i)}
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 설명 */}
                <div className="bg-white rounded-[28px] p-10 shadow-sm">
                  <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                    <span className="text-3xl">🌐</span>
                    디센트럴랜드 - 가상 세계의 새로운 경험!
                  </h2>
                  <div className="space-y-4 text-[16px] text-gray-600 leading-[1.9]">
                    <p>
                      디센트럴랜드는 이더리움 블록체인 기반의 가상 현실
                      플랫폼입니다.
                    </p>
                    <p>
                      사용자가 직접 콘텐츠와 애플리케이션을 만들고, 체험하고,
                      수익화할 수 있습니다.
                    </p>

                    <div className="mt-8 p-6 bg-gradient-to-r from-[#E8F4FD] to-[#F0F9FF] rounded-2xl">
                      <h3 className="font-bold text-[#4AABF5] text-lg mb-4">
                        ■ 주요 특징
                      </h3>
                      <ul className="space-y-3">
                        <li className="flex items-start gap-3">
                          <span className="w-2 h-2 rounded-full bg-[#4AABF5] mt-2 shrink-0"></span>
                          가상 부동산 LAND를 구매하고 개발할 수 있습니다
                        </li>
                        <li className="flex items-start gap-3">
                          <span className="w-2 h-2 rounded-full bg-[#72C2FF] mt-2 shrink-0"></span>
                          MANA 토큰으로 게임 내 아이템을 거래할 수 있습니다
                        </li>
                        <li className="flex items-start gap-3">
                          <span className="w-2 h-2 rounded-full bg-[#A8DAFF] mt-2 shrink-0"></span>
                          다양한 이벤트와 소셜 경험을 즐길 수 있습니다
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 평가글 탭 */}
            {activeTab === "평가글" && (
              <div className="space-y-8">
                {/* 상단 요약 카드 */}
                <div className="bg-white rounded-[28px] p-10 shadow-sm">
                  {/* 탭 버튼 */}
                  <div className="flex gap-4 mb-10">
                    {["유저평가", "평가단평가"].map((tab) => (
                      <button
                        key={tab}
                        className={`px-8 py-3 rounded-full text-[15px] font-semibold transition-all ${
                          reviewTab === tab
                            ? "bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white shadow-lg shadow-[#72C2FF]/30"
                            : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                        }`}
                        onClick={() => setReviewTab(tab)}
                      >
                        {tab}
                      </button>
                    ))}
                  </div>

                  {/* 플레이 보상체감 */}
                  <div className="flex items-center justify-between p-8 bg-gradient-to-r from-[#E8F4FD] to-[#F0F9FF] rounded-3xl mb-10">
                    <span className="text-gray-900 font-bold text-xl">
                      플레이 보상체감
                    </span>
                    <div className="flex items-center gap-4">
                      <span className="text-yellow-400 text-2xl tracking-wider">
                        ★★★☆☆
                      </span>
                      <span className="text-gray-900 font-bold text-4xl">
                        3.4
                      </span>
                      <span className="text-gray-400 text-lg">점</span>
                    </div>
                  </div>

                  {/* 상세평가 바 */}
                  <div className="mb-10">
                    <p className="text-gray-900 font-bold text-lg mb-6">
                      플레이 보상 상세평가
                    </p>
                    <div className="space-y-5">
                      {[
                        { label: "매우 높음", value: 5.88 },
                        { label: "높음", value: 11.76 },
                        { label: "보통", value: 35.29 },
                        { label: "낮음", value: 29.41 },
                        { label: "매우 낮음", value: 17.65 },
                      ].map((item) => (
                        <div
                          key={item.label}
                          className="flex items-center gap-5"
                        >
                          <span className="text-sm text-gray-500 w-24 font-medium">
                            {item.label}
                          </span>
                          <div className="flex-1 h-4 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-[#4AABF5] to-[#72C2FF]"
                              style={{ width: `${item.value}%` }}
                            />
                          </div>
                          <span className="text-sm text-gray-400 w-16 text-right font-semibold">
                            {item.value}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 평가 참여 버튼 */}
                  <button
                    className="w-full py-5 bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] hover:from-[#72C2FF] hover:to-[#4AABF5] text-white rounded-2xl font-bold text-lg transition-all shadow-lg shadow-[#72C2FF]/30 hover:shadow-xl hover:-translate-y-0.5"
                    onClick={() => setShowReviewPopup(true)}
                  >
                    게임 평가 참여하기
                  </button>
                </div>

                {/* 리뷰 리스트 */}
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <ReviewCard
                      key={review.id}
                      review={review}
                      expanded={expandedReviews.includes(review.id)}
                      onToggleExpand={() => toggleReviewExpand(review.id)}
                      onShowGift={() => setShowGiftPopup(true)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* 게임쿠폰 탭 */}
            {activeTab === "게임쿠폰" && (
              <div className="space-y-6">
                {coupons.map((coupon) => (
                  <div
                    key={coupon.id}
                    className="bg-white rounded-[28px] p-8 shadow-sm hover:shadow-xl transition-all"
                  >
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-5">
                        <img
                          src={coupon.avatar}
                          alt=""
                          className="w-14 h-14 rounded-2xl object-cover shadow-md"
                        />
                        <span className="text-[15px] text-gray-500 font-medium">
                          {coupon.nickname}
                        </span>
                      </div>
                      <button
                        className="px-8 py-3 rounded-2xl text-[15px] font-bold text-white bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] hover:shadow-lg transition-all"
                        onClick={() =>
                          navigator.clipboard?.writeText(coupon.code)
                        }
                      >
                        복사
                      </button>
                    </div>
                    <p className="text-xl font-bold text-gray-900 mb-3">
                      쿠폰번호 {coupon.code}
                    </p>
                    <p className="text-[15px] text-gray-500 mb-2">
                      기간 {coupon.period}
                    </p>
                    <p className="text-[15px] text-[#4AABF5] font-semibold">
                      {coupon.rewards}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* 쌀먹점수 탭 */}
            {activeTab === "쌀먹점수" && (
              <div className="bg-white rounded-[28px] p-10 shadow-sm">
                {/* 기간 선택 */}
                <div className="flex justify-end mb-10">
                  <div className="flex bg-gray-100 rounded-full p-2">
                    {["7D", "1M", "3M", "6M", "1Y", "ALL"].map((period, i) => (
                      <button
                        key={period}
                        className={`px-6 py-2.5 rounded-full text-sm font-semibold transition-all ${
                          i === 0
                            ? "bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white shadow-md"
                            : "text-gray-500 hover:text-gray-700"
                        }`}
                      >
                        {period}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 차트 */}
                <div className="bg-gradient-to-br from-[#E8F4FD] to-[#F0F9FF] rounded-3xl p-10">
                  <div className="flex">
                    <div className="flex flex-col justify-between text-sm text-gray-400 pr-6 py-2 font-medium">
                      {["12.5k", "10k", "7.5k", "5k", "2.5k", "0"].map(
                        (label) => (
                          <span key={label}>{label}</span>
                        ),
                      )}
                    </div>
                    <div className="flex-1 h-64 relative">
                      <svg
                        className="w-full h-full"
                        viewBox="0 0 300 150"
                        preserveAspectRatio="none"
                      >
                        {[0, 30, 60, 90, 120, 150].map((y) => (
                          <line
                            key={y}
                            x1="0"
                            y1={y}
                            x2="300"
                            y2={y}
                            stroke="#e5e7eb"
                            strokeWidth="1"
                          />
                        ))}
                        <path
                          d="M0,35 L50,35 L100,36 L150,38 L175,32 L200,30 L250,33 L300,35"
                          fill="none"
                          stroke="url(#gradient)"
                          strokeWidth="4"
                          strokeLinecap="round"
                        />
                        <defs>
                          <linearGradient
                            id="gradient"
                            x1="0%"
                            y1="0%"
                            x2="100%"
                            y2="0%"
                          >
                            <stop offset="0%" stopColor="#4AABF5" />
                            <stop offset="100%" stopColor="#72C2FF" />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm text-gray-400 mt-6 pl-16 font-medium">
                    {[
                      "01-25",
                      "01-26",
                      "01-27",
                      "01-28",
                      "01-29",
                      "01-30",
                      "01-31",
                    ].map((date) => (
                      <span key={date}>{date}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 코인시세 탭 */}
            {activeTab === "코인시세" && (
              <div className="space-y-8">
                {/* 코인 정보 */}
                <div className="bg-white rounded-[28px] p-10 shadow-sm">
                  <div className="flex justify-end mb-8">
                    <div className="flex bg-gray-100 rounded-full p-2">
                      <button className="px-6 py-2.5 rounded-full text-sm font-semibold bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white shadow-md">
                        KRW
                      </button>
                      <button className="px-6 py-2.5 rounded-full text-sm font-semibold text-gray-500">
                        USD
                      </button>
                    </div>
                  </div>

                  <div className="flex items-start gap-8 p-8 bg-gradient-to-r from-[#E8F4FD] to-[#F0F9FF] rounded-3xl">
                    <img
                      src="https://edge.ssalmuk.com/network/202305/02_UNKWON/b52ea909ad3d44738dddf71f5e324bc5.jpg"
                      alt="Decentraland"
                      className="w-24 h-24 rounded-3xl object-cover shadow-xl"
                    />
                    <div>
                      <div className="flex items-center gap-6">
                        <span className="text-3xl font-bold text-gray-900">
                          Decentraland
                        </span>
                        <span className="text-3xl font-bold text-gray-700">
                          ₩213.97
                        </span>
                      </div>
                      <div className="flex items-center gap-3 mt-3">
                        <span className="text-emerald-500 text-xl">▼</span>
                        <span className="text-emerald-500 text-lg font-semibold">
                          -2.46%
                        </span>
                      </div>
                      <div className="mt-6">
                        <p className="text-gray-500">거래량 (24시간)</p>
                        <div className="flex items-center gap-4 mt-2">
                          <span className="text-gray-900 font-bold text-xl">
                            ₩24,639,005,627
                          </span>
                          <span className="text-emerald-500 font-semibold">
                            +15.66%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 차트 */}
                <div className="bg-white rounded-[28px] p-10 shadow-sm">
                  <div className="flex justify-end mb-10">
                    <div className="flex bg-gray-100 rounded-full p-2">
                      {["7D", "1M", "3M", "6M", "1Y", "ALL"].map(
                        (period, i) => (
                          <button
                            key={period}
                            className={`px-6 py-2.5 rounded-full text-sm font-semibold transition-all ${
                              i === 0
                                ? "bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white shadow-md"
                                : "text-gray-500 hover:text-gray-700"
                            }`}
                          >
                            {period}
                          </button>
                        ),
                      )}
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-[#E8F4FD] to-[#F0F9FF] rounded-3xl p-10">
                    <div className="flex">
                      <div className="flex flex-col justify-between text-sm text-gray-400 pr-6 py-2 font-medium">
                        {["300", "250", "200", "150", "100", "50"].map(
                          (label) => (
                            <span key={label}>{label}</span>
                          ),
                        )}
                      </div>
                      <div className="flex-1 h-64 relative">
                        <svg
                          className="w-full h-full"
                          viewBox="0 0 300 150"
                          preserveAspectRatio="none"
                        >
                          {[0, 30, 60, 90, 120, 150].map((y) => (
                            <line
                              key={y}
                              x1="0"
                              y1={y}
                              x2="300"
                              y2={y}
                              stroke="#e5e7eb"
                              strokeWidth="1"
                            />
                          ))}
                          <path
                            d="M0,60 L50,55 L100,70 L150,65 L175,50 L200,45 L250,55 L300,50"
                            fill="none"
                            stroke="url(#gradient2)"
                            strokeWidth="4"
                            strokeLinecap="round"
                          />
                          <defs>
                            <linearGradient
                              id="gradient2"
                              x1="0%"
                              y1="0%"
                              x2="100%"
                              y2="0%"
                            >
                              <stop offset="0%" stopColor="#4AABF5" />
                              <stop offset="100%" stopColor="#72C2FF" />
                            </linearGradient>
                          </defs>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 게임이벤트 / 커뮤니티 탭 */}
            {(activeTab === "게임이벤트" || activeTab === "커뮤니티") && (
              <div className="bg-white rounded-[28px] p-20 shadow-sm text-center">
                <span className="text-7xl mb-8 block">🚧</span>
                <p className="text-gray-400 text-xl">준비 중입니다.</p>
              </div>
            )}
          </div>
          {/* 사이드 배너 */}
          <aside className="hidden lg:block">
            <div className="sticky top-28 space-y-6">
              {/* 배너 1 */}
              <div className="rounded-2xl overflow-hidden shadow-sm cursor-pointer hover:-translate-y-1 transition-transform">
                <img
                  src="https://i.pinimg.com/736x/e6/c7/77/e6c777962e2034c840f560b73a2f3a6b.jpg"
                  alt="광고 배너"
                  className="w-full h-auto object-cover"
                />
              </div>

              {/* 베스트 게시글 */}
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-4 text-[14px] font-bold text-gray-900 border-b border-gray-100 flex items-center gap-2">
                  🏆 디센트럴랜드 베스트
                </div>
                <div className="p-4 flex flex-col">
                  {[
                    { title: "초보자 가이드 총정리", views: 1234 },
                    { title: "이번 주 업데이트 내용", views: 892 },
                    { title: "땅 구매 꿀팁 공유", views: 756 },
                    { title: "신규 이벤트 보상 후기", views: 543 },
                  ].map((post, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0 cursor-pointer hover:bg-[#F0F9FF] transition-colors rounded-lg px-2 -mx-2"
                    >
                      <span className="text-[13px] text-gray-700 truncate flex-1">
                        {post.title}
                      </span>
                      <span className="text-[11px] text-gray-400 ml-3">
                        👁 {post.views}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* 토스트 메시지 */}
      {showToast && (
        <div className="fixed top-28 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-8 py-5 rounded-2xl flex items-center gap-4 z-50 animate-fadeIn shadow-2xl">
          <span className="text-emerald-400 text-xl">✓</span>
          <span className="text-[15px] font-medium">
            관심목록에 추가되었습니다
          </span>
        </div>
      )}

      {/* 이미지 라이트박스 */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center backdrop-blur-sm"
          onClick={() => setLightboxIndex(null)}
        >
          <button
            className="absolute top-10 right-10 w-16 h-16 bg-white/10 hover:bg-white/20 rounded-2xl flex items-center justify-center text-white text-3xl transition-colors"
            onClick={() => setLightboxIndex(null)}
          >
            ✕
          </button>

          {lightboxIndex > 0 && (
            <button
              className="absolute left-10 top-1/2 -translate-y-1/2 w-16 h-16 bg-white/10 hover:bg-white/20 rounded-2xl flex items-center justify-center transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(lightboxIndex - 1);
              }}
            >
              <svg
                className="w-8 h-8 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>
          )}

          {mediaItems[lightboxIndex].type === "video" ? (
            <video
              src={mediaItems[lightboxIndex].src}
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-3xl animate-scaleIn"
              controls
              autoPlay
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <img
              src={mediaItems[lightboxIndex].src}
              alt="확대 이미지"
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-3xl animate-scaleIn"
              onClick={(e) => e.stopPropagation()}
            />
          )}

          {lightboxIndex < mediaItems.length - 1 && (
            <button
              className="absolute right-10 top-1/2 -translate-y-1/2 w-16 h-16 bg-white/10 hover:bg-white/20 rounded-2xl flex items-center justify-center transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(lightboxIndex + 1);
              }}
            >
              <svg
                className="w-8 h-8 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          )}

          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-3">
            {mediaItems.map((_, i) => (
              <button
                key={i}
                className={`w-3 h-3 rounded-full transition-all ${
                  i === lightboxIndex
                    ? "bg-white w-8"
                    : "bg-white/40 hover:bg-white/60"
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  setLightboxIndex(i);
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* SNS 팝업 */}
      {showSnsPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowSnsPopup(false)}
          />
          <div className="relative z-10 bg-white rounded-[32px] p-10 w-full max-w-md animate-scaleIn shadow-2xl">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">
              활성화된 SNS 채널
            </h2>
            <div className="space-y-4">
              {snsLinks.map((sns, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-5 hover:bg-[#F0F9FF] rounded-2xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-5">
                    <img
                      src={sns.icon}
                      alt={sns.name}
                      className="w-14 h-14 rounded-xl shadow-md"
                    />
                    <span className="text-gray-900 font-semibold text-lg">
                      {sns.name}
                    </span>
                  </div>
                  <span className="text-gray-400 text-2xl">→</span>
                </div>
              ))}
            </div>
            <button
              className="mt-10 w-full py-5 bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white rounded-2xl font-bold text-lg transition-all hover:shadow-lg"
              onClick={() => setShowSnsPopup(false)}
            >
              확인
            </button>
          </div>
        </div>
      )}

      {/* 선물 팝업 */}
      {showGiftPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => {
              setShowGiftPopup(false);
              setShowAwardHistory(false);
            }}
          />
          <div className="relative z-10 bg-white rounded-[32px] w-full max-w-md animate-scaleIn shadow-2xl overflow-hidden">
            {showAwardHistory ? (
              <>
                <div className="flex items-center justify-between p-8 border-b border-gray-100">
                  <div className="flex items-center gap-5">
                    <button
                      onClick={() => setShowAwardHistory(false)}
                      className="text-gray-500 hover:text-gray-700 text-2xl"
                    >
                      ←
                    </button>
                    <span className="text-2xl font-bold text-gray-900">
                      수상내역
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setShowGiftPopup(false);
                      setShowAwardHistory(false);
                    }}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ✕
                  </button>
                </div>

                <div className="p-8">
                  <div className="flex items-center justify-center gap-12 bg-gradient-to-r from-[#E8F4FD] to-[#F0F9FF] rounded-3xl p-8 mb-8">
                    <div className="text-center">
                      <p className="text-sm text-gray-500 mb-3">총 수상</p>
                      <div className="flex items-center gap-3 justify-center">
                        <span className="text-3xl">🏅</span>
                        <span className="text-4xl font-bold text-gray-900">
                          26
                        </span>
                      </div>
                    </div>
                    <div className="w-px h-20 bg-gray-200" />
                    <div className="text-center">
                      <p className="text-sm text-gray-500 mb-3">총 포인트</p>
                      <p className="text-4xl font-bold text-[#4AABF5]">2850P</p>
                    </div>
                  </div>

                  <div className="space-y-4 max-h-72 overflow-y-auto">
                    {[
                      {
                        icon: "🏆",
                        name: "논 한마지기",
                        count: 2,
                        points: "1000P",
                        bg: "bg-emerald-50",
                        text: "text-emerald-600",
                      },
                      {
                        icon: "⭐",
                        name: "황금쌀",
                        count: 19,
                        points: "500P",
                        bg: "bg-cyan-50",
                        text: "text-cyan-600",
                      },
                      {
                        icon: "🎁",
                        name: "쌀가마",
                        count: 2,
                        points: "100P",
                        bg: "bg-pink-50",
                        text: "text-pink-600",
                      },
                      {
                        icon: "🍚",
                        name: "밥 한공기",
                        count: 2,
                        points: "50P",
                        bg: "bg-orange-50",
                        text: "text-orange-600",
                      },
                      {
                        icon: "🌾",
                        name: "쌀 한톨",
                        count: 1,
                        points: "10P",
                        bg: "bg-green-50",
                        text: "text-green-600",
                      },
                    ].map((award) => (
                      <div
                        key={award.name}
                        className="flex items-center justify-between p-5 border border-gray-100 rounded-2xl hover:border-[#72C2FF]/30 transition-colors"
                      >
                        <div className="flex items-center gap-5">
                          <div
                            className={`w-16 h-16 rounded-2xl ${award.bg} flex flex-col items-center justify-center`}
                          >
                            <span className="text-3xl">{award.icon}</span>
                          </div>
                          <div>
                            <span className="font-semibold text-gray-900">
                              {award.name}
                            </span>
                            <p className="text-sm text-gray-400">
                              x{award.count}
                            </p>
                          </div>
                        </div>
                        <span className={`font-bold ${award.text}`}>
                          {award.points}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between p-8 border-b border-gray-100">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4AABF5] to-[#72C2FF] flex items-center justify-center shadow-lg">
                      <span className="text-white text-3xl">🍚</span>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">532P</p>
                      <p className="text-sm text-gray-400">내 포인트</p>
                    </div>
                  </div>
                  <button
                    className="flex flex-col items-center p-4 rounded-2xl bg-amber-50 hover:bg-amber-100 transition-colors"
                    onClick={() => setShowAwardHistory(true)}
                  >
                    <span className="text-2xl">🏆</span>
                    <span className="text-xs text-gray-500 mt-1">
                      14개 보기
                    </span>
                  </button>
                  <button
                    onClick={() => setShowGiftPopup(false)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ✕
                  </button>
                </div>

                <div className="p-8">
                  <p className="font-bold text-gray-900 text-lg mb-6">
                    상을 선택하세요
                  </p>
                  <div className="flex gap-3 overflow-x-auto pb-4">
                    {[
                      {
                        icon: "🌾",
                        name: "쌀 한톨",
                        points: "10P",
                        bg: "bg-green-50",
                      },
                      {
                        icon: "🍚",
                        name: "밥 한공기",
                        points: "50P",
                        bg: "bg-orange-50",
                        selected: true,
                      },
                      {
                        icon: "🎁",
                        name: "쌀가마",
                        points: "100P",
                        bg: "bg-pink-50",
                      },
                      {
                        icon: "⭐",
                        name: "황금쌀",
                        points: "500P",
                        bg: "bg-cyan-50",
                      },
                      {
                        icon: "🏆",
                        name: "논 한마지기",
                        points: "1000P",
                        bg: "bg-emerald-50",
                      },
                    ].map((award) => (
                      <button
                        key={award.name}
                        className={`flex flex-col items-center min-w-[90px] p-5 rounded-2xl ${award.bg} ${
                          award.selected
                            ? "ring-2 ring-[#72C2FF] shadow-lg scale-105"
                            : ""
                        } hover:scale-105 transition-all`}
                      >
                        <span className="text-3xl mb-2">{award.icon}</span>
                        <span className="text-xs font-semibold text-gray-700">
                          {award.name}
                        </span>
                        <span className="text-xs text-[#4AABF5] font-bold mt-1">
                          {award.points}
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center border border-gray-200 rounded-2xl px-6 py-5 mt-6 mb-5 focus-within:border-[#72C2FF] transition-colors">
                    <input
                      type="text"
                      placeholder="메시지를 추가하세요"
                      className="flex-1 text-[15px] outline-none"
                    />
                    <span className="text-sm text-gray-400">0/100</span>
                  </div>

                  <label className="flex items-center gap-4 cursor-pointer mb-8">
                    <input
                      type="checkbox"
                      className="w-5 h-5 rounded-lg accent-[#72C2FF]"
                    />
                    <span className="text-[15px] text-gray-700">
                      익명으로 기부하기
                    </span>
                  </label>

                  <button
                    className="w-full py-5 rounded-2xl bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] text-white font-bold text-lg transition-all hover:shadow-lg"
                    onClick={() => setShowGiftPopup(false)}
                  >
                    상 주기
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 게임 평가 팝업 */}
      {showReviewPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowReviewPopup(false)}
          />
          <div className="relative z-10 bg-white rounded-[32px] w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scaleIn shadow-2xl">
            <div className="flex items-center justify-between px-8 py-6 border-b border-gray-100 sticky top-0 bg-white rounded-t-[32px]">
              <div />
              <p className="text-xl font-bold text-gray-900">게임 평가하기</p>
              <button
                className="text-gray-400 text-2xl hover:text-gray-600"
                onClick={() => setShowReviewPopup(false)}
              >
                ✕
              </button>
            </div>

            <div className="p-8">
              <div className="mb-10">
                <p className="text-lg font-semibold text-gray-900 mb-5">
                  플레이 보상체감 <span className="text-rose-500">*</span>
                </p>
                <div className="flex items-center gap-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button key={star} onClick={() => setReviewStars(star)}>
                      <svg
                        className={`w-14 h-14 transition-all ${star <= reviewStars ? "text-yellow-400 scale-110" : "text-gray-200"}`}
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                      </svg>
                    </button>
                  ))}
                  <span className="text-lg text-gray-500 ml-4 font-medium">
                    {reviewStars}점
                  </span>
                </div>
              </div>

              <div className="mb-10">
                <p className="text-lg font-semibold text-gray-900 mb-5">
                  플레이 보상 상세평가 <span className="text-rose-500">*</span>
                </p>
                <div className="flex gap-4 flex-wrap">
                  {["매우낮음", "낮음", "보통", "높음", "매우높음"].map(
                    (level) => (
                      <button
                        key={level}
                        className="flex flex-col items-center gap-3"
                        onClick={() => setReviewReward(level)}
                      >
                        <div
                          className={`w-16 h-16 rounded-2xl flex items-center justify-center border-2 transition-all ${
                            reviewReward === level
                              ? "border-[#72C2FF] bg-[#E8F4FD] scale-110"
                              : "border-gray-200 bg-white hover:border-gray-300"
                          }`}
                        >
                          <svg
                            className={`w-7 h-7 ${reviewReward === level ? "text-[#4AABF5]" : "text-gray-300"}`}
                            fill="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                          </svg>
                        </div>
                        <span
                          className={`text-sm font-medium ${reviewReward === level ? "text-[#4AABF5]" : "text-gray-400"}`}
                        >
                          {level}
                        </span>
                      </button>
                    ),
                  )}
                </div>
              </div>

              <div className="mb-10">
                <p className="text-lg font-semibold text-gray-900 mb-5">
                  코멘트 <span className="text-rose-500">*</span>
                </p>
                <textarea
                  className="w-full border border-gray-200 rounded-2xl p-6 text-[15px] outline-none resize-none min-h-[140px] focus:border-[#72C2FF] transition-colors"
                  placeholder="코멘트는 5자 이상 입력해 주세요."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                />
              </div>

              <div className="flex items-start gap-4 bg-amber-50 rounded-2xl p-6">
                <span className="text-yellow-500 text-2xl">⚠️</span>
                <p className="text-sm text-gray-600 leading-relaxed">
                  게임 평가하기는 게임 별 1일 1회 참여 가능하며 고의로 잘못된
                  정보를 지속 입력할 경우 경고 없이 유저가 획득한 모든 포인트를
                  회수합니다.
                </p>
              </div>
            </div>

            <div className="flex border-t border-gray-100 sticky bottom-0 bg-white rounded-b-[32px]">
              <button
                className="flex-1 py-6 text-lg font-semibold text-gray-500 hover:bg-gray-50 transition-colors rounded-bl-[32px]"
                onClick={() => setShowReviewPopup(false)}
              >
                취소
              </button>
              <button
                className="flex-1 py-6 text-lg font-semibold text-white bg-gradient-to-r from-[#4AABF5] to-[#72C2FF] hover:shadow-lg transition-all rounded-br-[32px]"
                onClick={() => {
                  setShowReviewPopup(false);
                  setReviewStars(0);
                  setReviewReward("");
                  setReviewComment("");
                }}
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
