import { useState } from "react";

// ─── Interfaces ───
interface ReviewData {
  id: number;
  name: string;
  level: number;
  date: string;
  rating: number;
  stars: string;
  image: string;
  content: string[];
  likes: number;
  comments: number;
  views: number;
}

// ─── 오른쪽 퀵 메뉴 ───
function RightSideIcons() {
  const icons = [
    { emoji: "🔔", label: "알림" },
    { emoji: "⏱️", label: "최근본" },
    { emoji: "💬", label: "문의" },
    { emoji: "📱", label: "QR" },
  ];

  return (
    <div className="fixed right-0 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-0.5 bg-white rounded-l-xl shadow-[-2px_0_8px_rgba(0,0,0,0.06)] py-2 hidden xl:flex animate-slideInRight delay-3">
      {icons.map((icon, i) => (
        <button
          key={i}
          className="w-12 h-12 flex flex-col items-center justify-center gap-0.5 text-[9px] text-[#9CA3AF] font-semibold hover:bg-[#E8F4FD] hover:text-[#4AABF5] transition-colors"
        >
          <span className="text-base">{icon.emoji}</span>
          {icon.label}
        </button>
      ))}
    </div>
  );
}

// ─── 오른쪽 사이드바 ───
function RightSidebar() {
  const hotPosts = [
    { title: "디센트럴랜드 초보자 가이드", views: 1234 },
    { title: "이번 주 업데이트 내용 정리", views: 892 },
    { title: "땅 구매 꿀팁 공유합니다", views: 756 },
    { title: "신규 이벤트 보상 후기", views: 543 },
  ];

  return (
    <div className="flex flex-col gap-5">
      {/* 배너 1 */}
      <div className="rounded-xl overflow-hidden cursor-pointer hover:-translate-y-0.5 transition-transform shadow-sm animate-fadeUp delay-1">
        <img
          src="https://i.pinimg.com/736x/3f/4b/99/3f4b99818ca444236c549c2ef8cd87de.jpg"
          alt="이벤트 배너"
          className="w-full h-auto object-cover"
        />
      </div>

      {/* 베스트 게시글 */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 animate-fadeUp delay-2">
        <div className="px-4 py-3 text-[13px] font-bold text-[#1A1A2E] border-b border-gray-100 flex items-center gap-1.5">
          🏆 디센트럴랜드 베스트 게시글
        </div>
        <div className="p-3 flex flex-col">
          {hotPosts.map((post, i) => (
            <div
              key={i}
              className="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0 cursor-pointer hover:bg-[#E8F4FD] transition-colors rounded px-2 -mx-2"
            >
              <span className="text-[13px] text-[#1A1A2E] truncate flex-1">
                {post.title}
              </span>
              <span className="text-[11px] text-gray-400 ml-2">
                👁 {post.views}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── 리뷰 카드 ───
function ReviewCard({
  review,
  expanded,
  onToggleExpand,
  onShowGift,
}: {
  review: ReviewData;
  expanded: boolean;
  onToggleExpand: () => void;
  onShowGift: () => void;
}) {
  return (
    <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-all">
      <div className="flex items-start gap-4">
        <img
          src={review.image}
          alt="프로필"
          className="w-12 h-12 rounded-xl object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#1A1A2E] text-[14px]">
                {review.name}
              </span>
              <span className="bg-[#E8F4FD] text-[#4AABF5] text-[11px] px-2 py-0.5 rounded-full font-semibold">
                Lv.{review.level}
              </span>
            </div>
            <span className="text-[12px] text-gray-400">{review.date}</span>
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-yellow-400 text-[14px]">{review.stars}</span>
            <span className="font-bold text-[14px] text-[#1A1A2E]">
              {review.rating}
            </span>
            <span className="text-gray-400 text-[12px]">점</span>
          </div>
        </div>
      </div>

      <div className="mt-4 text-[14px] text-gray-600 leading-relaxed">
        {expanded
          ? review.content.map((line, idx) => (
              <p key={idx} className={idx > 0 ? "mt-2" : ""}>
                {line}
              </p>
            ))
          : review.content.slice(0, 2).map((line, idx) => (
              <p key={idx} className={idx > 0 ? "mt-2" : ""}>
                {line}
              </p>
            ))}
        {review.content.length > 2 && (
          <button
            className="text-[#4AABF5] text-[13px] mt-2 hover:underline font-medium"
            onClick={onToggleExpand}
          >
            {expanded ? "간략하게 ▲" : "더보기 ▼"}
          </button>
        )}
      </div>

      {/* 액션 버튼 */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
        <div className="flex items-center gap-5">
          <button className="flex items-center gap-1.5 text-gray-400 hover:text-rose-500 transition-colors">
            <span>❤️</span>
            <span className="text-[12px] font-medium">{review.likes}</span>
          </button>
          <button className="flex items-center gap-1.5 text-gray-400 hover:text-[#4AABF5] transition-colors">
            <span>💬</span>
            <span className="text-[12px] font-medium">{review.comments}</span>
          </button>
          <button className="text-gray-400 hover:text-[#4AABF5] transition-colors">
            🔗
          </button>
        </div>
        <button
          className="text-lg text-gray-300 hover:text-amber-400 transition-colors"
          onClick={onShowGift}
        >
          🎁
        </button>
      </div>
    </div>
  );
}

// ─── 메인 컴포넌트 ───
export default function GameDetailPage() {
  const [activeTab, setActiveTab] = useState("평가글");
  const [isLiked, setIsLiked] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [reviewTab, setReviewTab] = useState("유저평가");
  const [expandedReviews, setExpandedReviews] = useState<number[]>([]);
  const [showGiftPopup, setShowGiftPopup] = useState(false);
  const [showAwardHistory, setShowAwardHistory] = useState(false);
  const [showReviewPopup, setShowReviewPopup] = useState(false);
  const [reviewStars, setReviewStars] = useState(0);
  const [reviewReward, setReviewReward] = useState("");
  const [reviewComment, setReviewComment] = useState("");
  const [showSnsPopup, setShowSnsPopup] = useState(false);
  const [mediaIndex, setMediaIndex] = useState(0);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const tabs = [
    "소개",
    "평가글",
    "게임이벤트",
    "게임쿠폰",
    "쌀먹점수",
    "코인시세",
    "커뮤니티",
  ];

  const mediaItems = [
    {
      type: "video",
      src: "https://sgimage.netmarble.com/images/netmarble/rfnext/20250121/ro4j1737451863887.mp4",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/d99c79ec564545cc8f6f4333a9eefbb3.jpg",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/93b0fb0121864408a97d86e23226176d.jpg",
    },
    {
      type: "image",
      src: "https://edge.ssalmuk.com/gameBanner/202304/20_dmin/81c5661e8c6b439ab14d3e6c83051739.jpg",
    },
  ];

  const reviews: ReviewData[] = [
    {
      id: 1,
      name: "소보로",
      level: 7,
      date: "2025-01-30",
      rating: 4.0,
      stars: "★★★★☆",
      image:
        "https://edge.ssalmuk.com/editorImage/8daa1b53fba545ffb56d1cac5517407b.png",
      content: [
        "게임이라기 보단 메타월드죠.",
        "가상 공간에 내 땅사고, 임대로 받고 그런느낌.",
      ],
      likes: 12,
      comments: 3,
      views: 124,
    },
    {
      id: 2,
      name: "게임러버",
      level: 12,
      date: "2025-01-28",
      rating: 3.0,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/d2008bde9fe541edabc5762d18b04e7b.png",
      content: ["초반 진입장벽이 좀 있어요.", "근데 익숙해지면 꽤 재밌습니다."],
      likes: 8,
      comments: 1,
      views: 89,
    },
    {
      id: 3,
      name: "쌀먹마스터",
      level: 25,
      date: "2025-01-25",
      rating: 5.0,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/daa326b1f7d141dbb6f42473312e562c.jfif",
      content: [
        "P2E 게임 중에서는 최고입니다!",
        "꾸준히 하면 수익 나와요.",
        "초보자도 쉽게 시작할 수 있어요.",
      ],
      likes: 25,
      comments: 7,
      views: 256,
    },
    {
      id: 4,
      name: "메타버스탐험가",
      level: 18,
      date: "2025-01-24",
      rating: 4.5,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif",
      content: [
        "가상 부동산 투자에 관심있다면 추천!",
        "MANA 토큰 시세도 나쁘지 않아요.",
      ],
      likes: 19,
      comments: 5,
      views: 178,
    },
    {
      id: 5,
      name: "블록체인뉴비",
      level: 3,
      date: "2025-01-22",
      rating: 2.5,
      stars: "★★☆☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/935049a546e744a98c0c77e1d498ae18.png",
      content: ["진입장벽이 너무 높아요.", "처음 시작하기 어렵습니다."],
      likes: 4,
      comments: 2,
      views: 67,
    },
    {
      id: 6,
      name: "크립토킹",
      level: 31,
      date: "2025-01-20",
      rating: 4.0,
      stars: "★★★★☆",
      image:
        "https://edge.ssalmuk.com/editorImage/8340a446068d4799a60acbf85f415e28.jpg",
      content: [
        "장기 투자로 접근하면 괜찮아요.",
        "단기 수익은 기대하기 어렵습니다.",
      ],
      likes: 15,
      comments: 4,
      views: 143,
    },
    {
      id: 7,
      name: "NFT수집가",
      level: 22,
      date: "2025-01-18",
      rating: 5.0,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/145ef9589b8047169888e2f0c232b3d4.jpg",
      content: [
        "웨어러블 NFT 수집이 너무 재밌어요!",
        "다양한 이벤트도 많이 열립니다.",
      ],
      likes: 22,
      comments: 6,
      views: 198,
    },
    {
      id: 8,
      name: "게임분석가",
      level: 15,
      date: "2025-01-16",
      rating: 3.5,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/f85655d36efc44aaaf692cbef435271d.jpg",
      content: [
        "그래픽은 아쉽지만 컨셉이 좋아요.",
        "메타버스 입문용으로 추천합니다.",
      ],
      likes: 11,
      comments: 3,
      views: 112,
    },
    {
      id: 9,
      name: "디파이고수",
      level: 28,
      date: "2025-01-14",
      rating: 4.5,
      stars: "★★★★★",
      image:
        "https://edge.ssalmuk.com/editorImage/56ce60fa47784514b73aa0afafbecc99.jpg",
      content: [
        "LAND 스테이킹으로 패시브 인컴 가능!",
        "초기 투자금이 좀 필요합니다.",
      ],
      likes: 28,
      comments: 9,
      views: 287,
    },
    {
      id: 10,
      name: "캐주얼게이머",
      level: 5,
      date: "2025-01-12",
      rating: 3.0,
      stars: "★★★☆☆",
      image:
        "https://edge.ssalmuk.com/editorImage/26850577efbf4dcd9ae8df48b75d4e7a.jpg",
      content: ["가볍게 즐기기엔 좋아요.", "수익 목적보다는 체험용으로 추천."],
      likes: 6,
      comments: 1,
      views: 54,
    },
  ];

  const quickLinks = [
    { icon: "🏠", label: "홈페이지" },
    { icon: "📋", label: "업데이트" },
    { icon: "📖", label: "가이드북" },
    { icon: "💬", label: "커뮤니티" },
  ];

  const snsLinks = [
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/discord35.svg",
      name: "디스코드",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/facebook35.svg",
      name: "페이스북",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/reddit35.svg",
      name: "레딧",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/twitter35.svg",
      name: "트위터",
    },
    {
      icon: "https://ssalmuk.com/images/img_ranking_detail/youtube35.svg",
      name: "유튜브",
    },
  ];

  const coupons = [
    {
      id: 1,
      avatar:
        "https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif",
      nickname: "쿠폰다내꺼",
      code: "U323KSK3K1K23K",
      period: "2025-10-30 ~ 정보없음",
      rewards: "물약100개, 초보자 방어구 세트",
    },
    {
      id: 2,
      avatar:
        "https://edge.ssalmuk.com/editorImage/935049a546e744a98c0c77e1d498ae18.png",
      nickname: "꽝우실러취요",
      code: "WELCOME2025NEW",
      period: "2025-09-16 ~ 정보없음",
      rewards: "물약100개, 초보자 방어구 세트",
    },
    {
      id: 3,
      avatar:
        "https://edge.ssalmuk.com/editorImage/8daa1b53fba545ffb56d1cac5517407b.png",
      nickname: "게임마스터",
      code: "SSALMUK7777GG",
      period: "2025-12-31 ~ 2026-03-31",
      rewards: "골드 5000, 프리미엄 상자 1개",
    },
  ];

  const handleLikeToggle = () => {
    setIsLiked(!isLiked);
    if (!isLiked) {
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2000);
    }
  };

  const toggleReviewExpand = (id: number) => {
    setExpandedReviews((prev) =>
      prev.includes(id) ? prev.filter((rid) => rid !== id) : [...prev, id],
    );
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <RightSideIcons />

      {/* 헤더 영역 - 프로필 더 크게 */}
      <div
        className="w-full bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url('https://ssalmuk.com/images/img_ranking_detail/detail_banner.svg')",
        }}
      >
        <div className="max-w-[1300px] mx-auto px-8 py-14">
          <div className="flex gap-10 items-start">
            {/* 게임 아이콘 - 더 크게 */}
            <img
              src="https://edge.ssalmuk.com/editorImage/31c1f862e4b14adb8498f40bdbb5c52b.jfif"
              alt="디센트럴랜드"
              className="w-64 h-64 rounded-[28px] object-cover shadow-2xl ring-4 ring-white/30"
            />
            <div className="flex-1">
              {/* 제목 + 좋아요 */}
              <div className="flex items-center justify-between">
                <h1 className="text-4xl font-bold text-white tracking-tight">
                  디센트럴랜드
                </h1>
                <button
                  onClick={handleLikeToggle}
                  className={`p-4 rounded-2xl transition-all shadow-lg ${
                    isLiked
                      ? "bg-white text-rose-500"
                      : "bg-white/20 text-white hover:bg-white/30"
                  }`}
                >
                  <svg
                    className="w-8 h-8"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                  </svg>
                </button>
              </div>

              {/* 태그 */}
              <div className="flex gap-3 mt-5">
                {["메타버스", "소셜", "P2E"].map((tag) => (
                  <span
                    key={tag}
                    className="bg-white/20 text-white text-[15px] px-6 py-2 rounded-full font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* 퀵 링크 */}
              <div className="flex gap-6 mt-8">
                {quickLinks.map((link, idx) => (
                  <div
                    key={idx}
                    className="flex flex-col items-center cursor-pointer group"
                  >
                    <div className="w-16 h-16 bg-white/90 rounded-2xl flex items-center justify-center text-2xl shadow-lg group-hover:scale-110 transition-transform">
                      {link.icon}
                    </div>
                    <span className="text-[12px] text-white/80 mt-2.5 font-medium">
                      {link.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 순위 & SNS 바 */}
          <div className="bg-white/95 backdrop-blur rounded-2xl p-6 mt-10 flex items-center shadow-xl">
            <div className="text-center px-12">
              <p className="text-[13px] text-gray-500 mb-1.5">국내순위</p>
              <p className="font-bold text-[#1A1A2E] text-3xl">
                1위{" "}
                <span className="text-gray-400 text-base font-normal">(-)</span>
              </p>
            </div>
            <div className="w-px h-16 bg-gray-200"></div>
            <div className="flex-1 text-center px-10">
              <p className="text-[13px] text-gray-500 mb-3">
                활성화된 SNS 채널
              </p>
              <div className="flex gap-5 justify-center">
                {snsLinks.map((sns, idx) => (
                  <img
                    key={idx}
                    src={sns.icon}
                    alt={sns.name}
                    className="w-9 h-9 rounded-lg cursor-pointer hover:scale-110 transition-transform"
                  />
                ))}
              </div>
            </div>
            <button
              className="text-gray-400 text-3xl px-8 hover:text-[#4AABF5] transition-colors"
              onClick={() => setShowSnsPopup(true)}
            >
              →
            </button>
          </div>
        </div>
      </div>

      {/* 메인 컨텐츠 - 2컬럼 */}
      <div className="max-w-[1300px] mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
          {/* 메인 콘텐츠 */}
          <main className="min-w-0">
            {/* 탭 메뉴 */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-5 animate-fadeUp">
              <div className="flex border-b border-gray-100 overflow-x-auto">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-6 py-4 text-[14px] font-medium whitespace-nowrap transition-all relative ${
                      activeTab === tab
                        ? "text-[#4AABF5] font-bold"
                        : "text-gray-400 hover:text-gray-600"
                    }`}
                  >
                    {tab}
                    {activeTab === tab && (
                      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-10 h-0.5 bg-[#4AABF5] rounded-full" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* 소개 탭 */}
            {activeTab === "소개" && (
              <div className="space-y-5 animate-fadeIn">
                {/* 미디어 슬라이더 */}
                <div className="relative bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                  {mediaIndex > 0 && (
                    <button
                      onClick={() => setMediaIndex(mediaIndex - 1)}
                      className="absolute left-[-16px] top-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-all z-10"
                    >
                      <svg
                        className="w-4 h-4 text-gray-700"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2.5}
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 19l-7-7 7-7"
                        />
                      </svg>
                    </button>
                  )}
                  {mediaIndex < mediaItems.length - 2 && (
                    <button
                      onClick={() => setMediaIndex(mediaIndex + 1)}
                      className="absolute right-[-16px] top-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-all z-10"
                    >
                      <svg
                        className="w-4 h-4 text-gray-700"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2.5}
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </button>
                  )}
                  <div className="overflow-hidden rounded-lg">
                    <div
                      className="flex gap-4 transition-transform duration-500 ease-out"
                      style={{ transform: `translateX(-${mediaIndex * 52}%)` }}
                    >
                      {mediaItems.map((item, i) => (
                        <div
                          key={i}
                          className="w-[48%] shrink-0 rounded-lg overflow-hidden shadow cursor-pointer group"
                        >
                          {item.type === "video" ? (
                            <video
                              src={item.src}
                              className="w-full aspect-video object-cover"
                              muted
                              loop
                              playsInline
                              controls
                            />
                          ) : (
                            <img
                              src={item.src}
                              alt={`스크린샷${i}`}
                              className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500"
                              onClick={() => setLightboxIndex(i)}
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 설명 */}
                <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                  <h2 className="text-[16px] font-bold text-[#1A1A2E] mb-4 flex items-center gap-2">
                    🌐 디센트럴랜드 - 가상 세계의 새로운 경험!
                  </h2>
                  <div className="space-y-2 text-[14px] text-gray-600 leading-relaxed">
                    <p>
                      디센트럴랜드는 이더리움 블록체인 기반의 가상 현실
                      플랫폼입니다.
                    </p>
                    <p>
                      사용자가 직접 콘텐츠와 애플리케이션을 만들고, 체험하고,
                      수익화할 수 있습니다.
                    </p>
                    <div className="mt-4 p-4 bg-[#E8F4FD] rounded-lg">
                      <h3 className="font-bold text-[#4AABF5] text-[13px] mb-2">
                        ■ 주요 특징
                      </h3>
                      <ul className="space-y-1.5 text-[13px]">
                        <li className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#4AABF5] mt-1.5 shrink-0"></span>
                          가상 부동산 LAND를 구매하고 개발할 수 있습니다
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#72C2FF] mt-1.5 shrink-0"></span>
                          MANA 토큰으로 게임 내 아이템을 거래할 수 있습니다
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#A8DAFF] mt-1.5 shrink-0"></span>
                          다양한 이벤트와 소셜 경험을 즐길 수 있습니다
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 평가글 탭 */}
            {activeTab === "평가글" && (
              <div className="space-y-5 animate-fadeIn">
                {/* 상단 요약 */}
                <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                  <div className="flex gap-2 mb-5">
                    {["유저평가", "평가단평가"].map((tab) => (
                      <button
                        key={tab}
                        className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition-all ${reviewTab === tab ? "bg-[#4AABF5] text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}
                        onClick={() => setReviewTab(tab)}
                      >
                        {tab}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center justify-between p-4 bg-[#E8F4FD] rounded-lg mb-5">
                    <span className="text-[#1A1A2E] font-bold text-[14px]">
                      플레이 보상체감
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-yellow-400 text-[16px]">★★★☆☆</span>
                      <span className="text-[#1A1A2E] font-bold text-xl">
                        3.4
                      </span>
                      <span className="text-gray-400 text-[13px]">점</span>
                    </div>
                  </div>
                  <div className="mb-5">
                    <p className="text-[#1A1A2E] font-bold text-[13px] mb-3">
                      플레이 보상 상세평가
                    </p>
                    <div className="space-y-2">
                      {[
                        { label: "매우 높음", value: 5.88 },
                        { label: "높음", value: 11.76 },
                        { label: "보통", value: 35.29 },
                        { label: "낮음", value: 29.41 },
                        { label: "매우 낮음", value: 17.65 },
                      ].map((item) => (
                        <div
                          key={item.label}
                          className="flex items-center gap-3"
                        >
                          <span className="text-[11px] text-gray-500 w-16 font-medium">
                            {item.label}
                          </span>
                          <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-[#4AABF5] to-[#72C2FF]"
                              style={{ width: `${item.value}%` }}
                            />
                          </div>
                          <span className="text-[11px] text-gray-400 w-10 text-right">
                            {item.value}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <button
                    className="w-full py-3 bg-[#4AABF5] hover:bg-[#3d9ae6] text-white rounded-lg font-bold text-[14px] transition-colors"
                    onClick={() => setShowReviewPopup(true)}
                  >
                    게임 평가 참여하기
                  </button>
                </div>

                {/* 리뷰 리스트 */}
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <ReviewCard
                      key={review.id}
                      review={review}
                      expanded={expandedReviews.includes(review.id)}
                      onToggleExpand={() => toggleReviewExpand(review.id)}
                      onShowGift={() => setShowGiftPopup(true)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* 게임쿠폰 탭 */}
            {activeTab === "게임쿠폰" && (
              <div className="space-y-4 animate-fadeIn">
                {coupons.map((coupon) => (
                  <div
                    key={coupon.id}
                    className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-all"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={coupon.avatar}
                          alt=""
                          className="w-10 h-10 rounded-lg object-cover"
                        />
                        <span className="text-[13px] text-gray-500 font-medium">
                          {coupon.nickname}
                        </span>
                      </div>
                      <button
                        className="px-4 py-1.5 rounded-lg text-[12px] font-bold text-white bg-[#4AABF5] hover:bg-[#3d9ae6] transition-colors"
                        onClick={() =>
                          navigator.clipboard?.writeText(coupon.code)
                        }
                      >
                        복사
                      </button>
                    </div>
                    <p className="text-[15px] font-bold text-[#1A1A2E] mb-1">
                      쿠폰번호 {coupon.code}
                    </p>
                    <p className="text-[12px] text-gray-500 mb-1">
                      기간 {coupon.period}
                    </p>
                    <p className="text-[12px] text-[#4AABF5] font-semibold">
                      {coupon.rewards}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* 쌀먹점수 탭 */}
            {activeTab === "쌀먹점수" && (
              <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 animate-fadeIn">
                <div className="flex justify-end mb-5">
                  <div className="flex bg-gray-100 rounded-lg p-1">
                    {["7D", "1M", "3M", "6M", "1Y", "ALL"].map((period, i) => (
                      <button
                        key={period}
                        className={`px-3 py-1 rounded text-[11px] font-semibold transition-all ${i === 0 ? "bg-[#4AABF5] text-white" : "text-gray-500 hover:text-gray-700"}`}
                      >
                        {period}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="bg-[#F8FAFC] rounded-lg p-5">
                  <div className="flex">
                    <div className="flex flex-col justify-between text-[10px] text-gray-400 pr-3 py-1">
                      {["12.5k", "10k", "7.5k", "5k", "2.5k", "0"].map(
                        (label) => (
                          <span key={label}>{label}</span>
                        ),
                      )}
                    </div>
                    <div className="flex-1 h-40 relative">
                      <svg
                        className="w-full h-full"
                        viewBox="0 0 300 150"
                        preserveAspectRatio="none"
                      >
                        {[0, 30, 60, 90, 120, 150].map((y) => (
                          <line
                            key={y}
                            x1="0"
                            y1={y}
                            x2="300"
                            y2={y}
                            stroke="#e5e7eb"
                            strokeWidth="1"
                          />
                        ))}
                        <path
                          d="M0,35 L50,35 L100,36 L150,38 L175,32 L200,30 L250,33 L300,35"
                          fill="none"
                          stroke="url(#gradient)"
                          strokeWidth="3"
                          strokeLinecap="round"
                        />
                        <defs>
                          <linearGradient
                            id="gradient"
                            x1="0%"
                            y1="0%"
                            x2="100%"
                            y2="0%"
                          >
                            <stop offset="0%" stopColor="#4AABF5" />
                            <stop offset="100%" stopColor="#72C2FF" />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-400 mt-3 pl-10">
                    {[
                      "01-25",
                      "01-26",
                      "01-27",
                      "01-28",
                      "01-29",
                      "01-30",
                      "01-31",
                    ].map((date) => (
                      <span key={date}>{date}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 코인시세 탭 */}
            {activeTab === "코인시세" && (
              <div className="space-y-5 animate-fadeIn">
                <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                  <div className="flex justify-end mb-4">
                    <div className="flex bg-gray-100 rounded-lg p-1">
                      <button className="px-3 py-1 rounded text-[11px] font-semibold bg-[#4AABF5] text-white">
                        KRW
                      </button>
                      <button className="px-3 py-1 rounded text-[11px] font-semibold text-gray-500">
                        USD
                      </button>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-4 bg-[#E8F4FD] rounded-lg">
                    <img
                      src="https://edge.ssalmuk.com/network/202305/02_UNKWON/b52ea909ad3d44738dddf71f5e324bc5.jpg"
                      alt="Decentraland"
                      className="w-14 h-14 rounded-xl object-cover shadow"
                    />
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-lg font-bold text-[#1A1A2E]">
                          Decentraland
                        </span>
                        <span className="text-lg font-bold text-gray-700">
                          ₩213.97
                        </span>
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-emerald-500">▼</span>
                        <span className="text-emerald-500 text-[13px] font-medium">
                          -2.46%
                        </span>
                      </div>
                      <div className="mt-2">
                        <p className="text-gray-500 text-[11px]">
                          거래량 (24시간)
                        </p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[#1A1A2E] font-bold text-[14px]">
                            ₩24,639,005,627
                          </span>
                          <span className="text-emerald-500 text-[12px] font-medium">
                            +15.66%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                  <div className="flex justify-end mb-5">
                    <div className="flex bg-gray-100 rounded-lg p-1">
                      {["7D", "1M", "3M", "6M", "1Y", "ALL"].map(
                        (period, i) => (
                          <button
                            key={period}
                            className={`px-3 py-1 rounded text-[11px] font-semibold transition-all ${i === 0 ? "bg-[#4AABF5] text-white" : "text-gray-500 hover:text-gray-700"}`}
                          >
                            {period}
                          </button>
                        ),
                      )}
                    </div>
                  </div>
                  <div className="bg-[#F8FAFC] rounded-lg p-5">
                    <div className="flex">
                      <div className="flex flex-col justify-between text-[10px] text-gray-400 pr-3 py-1">
                        {["300", "250", "200", "150", "100", "50"].map(
                          (label) => (
                            <span key={label}>{label}</span>
                          ),
                        )}
                      </div>
                      <div className="flex-1 h-40 relative">
                        <svg
                          className="w-full h-full"
                          viewBox="0 0 300 150"
                          preserveAspectRatio="none"
                        >
                          {[0, 30, 60, 90, 120, 150].map((y) => (
                            <line
                              key={y}
                              x1="0"
                              y1={y}
                              x2="300"
                              y2={y}
                              stroke="#e5e7eb"
                              strokeWidth="1"
                            />
                          ))}
                          <path
                            d="M0,60 L50,55 L100,70 L150,65 L175,50 L200,45 L250,55 L300,50"
                            fill="none"
                            stroke="url(#gradient2)"
                            strokeWidth="3"
                            strokeLinecap="round"
                          />
                          <defs>
                            <linearGradient
                              id="gradient2"
                              x1="0%"
                              y1="0%"
                              x2="100%"
                              y2="0%"
                            >
                              <stop offset="0%" stopColor="#4AABF5" />
                              <stop offset="100%" stopColor="#72C2FF" />
                            </linearGradient>
                          </defs>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 게임이벤트 / 커뮤니티 탭 */}
            {(activeTab === "게임이벤트" || activeTab === "커뮤니티") && (
              <div className="bg-white rounded-xl p-12 shadow-sm border border-gray-100 text-center animate-fadeIn">
                <span className="text-5xl mb-4 block">🚧</span>
                <p className="text-gray-400 text-[15px]">준비 중입니다.</p>
              </div>
            )}
          </main>

          {/* 오른쪽 사이드바 */}
          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <RightSidebar />
            </div>
          </aside>
        </div>
      </div>

      {/* 토스트 */}
      {showToast && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-xl flex items-center gap-3 z-50 animate-fadeIn shadow-xl">
          <span className="text-emerald-400">✓</span>
          <span className="text-[13px] font-medium">
            관심목록에 추가되었습니다
          </span>
        </div>
      )}

      {/* 라이트박스 */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center"
          onClick={() => setLightboxIndex(null)}
        >
          <button
            className="absolute top-8 right-8 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center text-white text-2xl"
            onClick={() => setLightboxIndex(null)}
          >
            ✕
          </button>
          {lightboxIndex > 0 && (
            <button
              className="absolute left-8 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center"
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(lightboxIndex - 1);
              }}
            >
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>
          )}
          {mediaItems[lightboxIndex].type === "video" ? (
            <video
              src={mediaItems[lightboxIndex].src}
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-xl animate-scaleIn"
              controls
              autoPlay
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <img
              src={mediaItems[lightboxIndex].src}
              alt="확대"
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-xl animate-scaleIn"
              onClick={(e) => e.stopPropagation()}
            />
          )}
          {lightboxIndex < mediaItems.length - 1 && (
            <button
              className="absolute right-8 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center"
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(lightboxIndex + 1);
              }}
            >
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          )}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
            {mediaItems.map((_, i) => (
              <button
                key={i}
                className={`w-2 h-2 rounded-full transition-all ${i === lightboxIndex ? "bg-white w-6" : "bg-white/40"}`}
                onClick={(e) => {
                  e.stopPropagation();
                  setLightboxIndex(i);
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* SNS 팝업 */}
      {showSnsPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setShowSnsPopup(false)}
          />
          <div className="relative z-10 bg-white rounded-2xl p-6 w-full max-w-sm animate-scaleIn shadow-2xl">
            <h2 className="text-lg font-bold text-[#1A1A2E] text-center mb-6">
              활성화된 SNS 채널
            </h2>
            <div className="space-y-2">
              {snsLinks.map((sns, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 hover:bg-[#E8F4FD] rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={sns.icon}
                      alt={sns.name}
                      className="w-10 h-10 rounded-lg"
                    />
                    <span className="text-[#1A1A2E] font-medium">
                      {sns.name}
                    </span>
                  </div>
                  <span className="text-gray-400">→</span>
                </div>
              ))}
            </div>
            <button
              className="mt-6 w-full py-3 bg-[#4AABF5] text-white rounded-xl font-bold transition-colors hover:bg-[#3d9ae6]"
              onClick={() => setShowSnsPopup(false)}
            >
              확인
            </button>
          </div>
        </div>
      )}

      {/* 선물 팝업 */}
      {showGiftPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => {
              setShowGiftPopup(false);
              setShowAwardHistory(false);
            }}
          />
          <div className="relative z-10 bg-white rounded-2xl w-full max-w-sm animate-scaleIn shadow-2xl overflow-hidden">
            {showAwardHistory ? (
              <>
                <div className="flex items-center justify-between p-5 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setShowAwardHistory(false)}
                      className="text-gray-500 hover:text-gray-700 text-xl"
                    >
                      ←
                    </button>
                    <span className="text-lg font-bold text-[#1A1A2E]">
                      수상내역
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setShowGiftPopup(false);
                      setShowAwardHistory(false);
                    }}
                    className="text-gray-400 hover:text-gray-600 text-xl"
                  >
                    ✕
                  </button>
                </div>
                <div className="p-5">
                  <div className="flex items-center justify-center gap-8 bg-[#E8F4FD] rounded-xl p-5 mb-5">
                    <div className="text-center">
                      <p className="text-[11px] text-gray-500 mb-1">총 수상</p>
                      <div className="flex items-center gap-2 justify-center">
                        <span className="text-2xl">🏅</span>
                        <span className="text-2xl font-bold text-[#1A1A2E]">
                          26
                        </span>
                      </div>
                    </div>
                    <div className="w-px h-12 bg-gray-200" />
                    <div className="text-center">
                      <p className="text-[11px] text-gray-500 mb-1">
                        총 포인트
                      </p>
                      <p className="text-2xl font-bold text-[#4AABF5]">2850P</p>
                    </div>
                  </div>
                  <div className="space-y-3 max-h-60 overflow-y-auto">
                    {[
                      {
                        icon: "🏆",
                        name: "논 한마지기",
                        count: 2,
                        points: "1000P",
                        bg: "bg-emerald-50",
                        text: "text-emerald-600",
                      },
                      {
                        icon: "⭐",
                        name: "황금쌀",
                        count: 19,
                        points: "500P",
                        bg: "bg-cyan-50",
                        text: "text-cyan-600",
                      },
                      {
                        icon: "🎁",
                        name: "쌀가마",
                        count: 2,
                        points: "100P",
                        bg: "bg-pink-50",
                        text: "text-pink-600",
                      },
                      {
                        icon: "🍚",
                        name: "밥 한공기",
                        count: 2,
                        points: "50P",
                        bg: "bg-orange-50",
                        text: "text-orange-600",
                      },
                      {
                        icon: "🌾",
                        name: "쌀 한톨",
                        count: 1,
                        points: "10P",
                        bg: "bg-green-50",
                        text: "text-green-600",
                      },
                    ].map((award) => (
                      <div
                        key={award.name}
                        className="flex items-center justify-between p-3 border border-gray-100 rounded-xl"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-12 h-12 rounded-xl ${award.bg} flex items-center justify-center`}
                          >
                            <span className="text-2xl">{award.icon}</span>
                          </div>
                          <div>
                            <span className="font-semibold text-[#1A1A2E] text-[13px]">
                              {award.name}
                            </span>
                            <p className="text-[11px] text-gray-400">
                              x{award.count}
                            </p>
                          </div>
                        </div>
                        <span className={`font-bold text-[13px] ${award.text}`}>
                          {award.points}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between p-5 border-b border-gray-100">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#4AABF5] to-[#72C2FF] flex items-center justify-center shadow">
                      <span className="text-white text-xl">🍚</span>
                    </div>
                    <div>
                      <p className="text-lg font-bold text-[#1A1A2E]">532P</p>
                      <p className="text-[11px] text-gray-400">내 포인트</p>
                    </div>
                  </div>
                  <button
                    className="flex flex-col items-center p-3 rounded-xl bg-amber-50 hover:bg-amber-100 transition-colors"
                    onClick={() => setShowAwardHistory(true)}
                  >
                    <span className="text-xl">🏆</span>
                    <span className="text-[10px] text-gray-500 mt-0.5">
                      14개 보기
                    </span>
                  </button>
                  <button
                    onClick={() => setShowGiftPopup(false)}
                    className="text-gray-400 hover:text-gray-600 text-xl"
                  >
                    ✕
                  </button>
                </div>
                <div className="p-5">
                  <p className="font-bold text-[#1A1A2E] text-[14px] mb-4">
                    상을 선택하세요
                  </p>
                  <div className="flex gap-2 overflow-x-auto pb-3">
                    {[
                      {
                        icon: "🌾",
                        name: "쌀 한톨",
                        points: "10P",
                        bg: "bg-green-50",
                      },
                      {
                        icon: "🍚",
                        name: "밥 한공기",
                        points: "50P",
                        bg: "bg-orange-50",
                        selected: true,
                      },
                      {
                        icon: "🎁",
                        name: "쌀가마",
                        points: "100P",
                        bg: "bg-pink-50",
                      },
                      {
                        icon: "⭐",
                        name: "황금쌀",
                        points: "500P",
                        bg: "bg-cyan-50",
                      },
                      {
                        icon: "🏆",
                        name: "논 한마지기",
                        points: "1000P",
                        bg: "bg-emerald-50",
                      },
                    ].map((award) => (
                      <button
                        key={award.name}
                        className={`flex flex-col items-center min-w-[70px] p-3 rounded-xl ${award.bg} ${award.selected ? "ring-2 ring-[#72C2FF] scale-105" : ""} hover:scale-105 transition-all`}
                      >
                        <span className="text-2xl mb-1">{award.icon}</span>
                        <span className="text-[10px] font-semibold text-gray-700">
                          {award.name}
                        </span>
                        <span className="text-[10px] text-[#4AABF5] font-bold">
                          {award.points}
                        </span>
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center border border-gray-200 rounded-xl px-4 py-3 mt-4 mb-3 focus-within:border-[#72C2FF]">
                    <input
                      type="text"
                      placeholder="메시지를 추가하세요"
                      className="flex-1 text-[13px] outline-none"
                    />
                    <span className="text-[11px] text-gray-400">0/100</span>
                  </div>
                  <label className="flex items-center gap-3 cursor-pointer mb-5">
                    <input
                      type="checkbox"
                      className="w-4 h-4 rounded accent-[#72C2FF]"
                    />
                    <span className="text-[13px] text-gray-700">
                      익명으로 기부하기
                    </span>
                  </label>
                  <button
                    className="w-full py-3 rounded-xl bg-[#4AABF5] text-white font-bold text-[14px] transition-colors hover:bg-[#3d9ae6]"
                    onClick={() => setShowGiftPopup(false)}
                  >
                    상 주기
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 평가 팝업 */}
      {showReviewPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setShowReviewPopup(false)}
          />
          <div className="relative z-10 bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-y-auto animate-scaleIn shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
              <div />
              <p className="text-lg font-bold text-[#1A1A2E]">게임 평가하기</p>
              <button
                className="text-gray-400 text-xl hover:text-gray-600"
                onClick={() => setShowReviewPopup(false)}
              >
                ✕
              </button>
            </div>
            <div className="p-5">
              <div className="mb-6">
                <p className="text-[14px] font-semibold text-[#1A1A2E] mb-3">
                  플레이 보상체감 <span className="text-rose-500">*</span>
                </p>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button key={star} onClick={() => setReviewStars(star)}>
                      <svg
                        className={`w-10 h-10 transition-all ${star <= reviewStars ? "text-yellow-400 scale-110" : "text-gray-200"}`}
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                      </svg>
                    </button>
                  ))}
                  <span className="text-[14px] text-gray-500 ml-2">
                    {reviewStars}점
                  </span>
                </div>
              </div>
              <div className="mb-6">
                <p className="text-[14px] font-semibold text-[#1A1A2E] mb-3">
                  플레이 보상 상세평가 <span className="text-rose-500">*</span>
                </p>
                <div className="flex gap-3 flex-wrap">
                  {["매우낮음", "낮음", "보통", "높음", "매우높음"].map(
                    (level) => (
                      <button
                        key={level}
                        className="flex flex-col items-center gap-2"
                        onClick={() => setReviewReward(level)}
                      >
                        <div
                          className={`w-12 h-12 rounded-xl flex items-center justify-center border-2 transition-all ${reviewReward === level ? "border-[#72C2FF] bg-[#E8F4FD] scale-110" : "border-gray-200 bg-white hover:border-gray-300"}`}
                        >
                          <svg
                            className={`w-5 h-5 ${reviewReward === level ? "text-[#4AABF5]" : "text-gray-300"}`}
                            fill="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                          </svg>
                        </div>
                        <span
                          className={`text-[11px] font-medium ${reviewReward === level ? "text-[#4AABF5]" : "text-gray-400"}`}
                        >
                          {level}
                        </span>
                      </button>
                    ),
                  )}
                </div>
              </div>
              <div className="mb-6">
                <p className="text-[14px] font-semibold text-[#1A1A2E] mb-3">
                  코멘트 <span className="text-rose-500">*</span>
                </p>
                <textarea
                  className="w-full border border-gray-200 rounded-xl p-4 text-[13px] outline-none resize-none min-h-[100px] focus:border-[#72C2FF]"
                  placeholder="코멘트는 5자 이상 입력해 주세요."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                />
              </div>
              <div className="flex items-start gap-3 bg-amber-50 rounded-xl p-4 mb-5">
                <span className="text-yellow-500 text-lg">⚠️</span>
                <p className="text-[12px] text-gray-600 leading-relaxed">
                  게임 평가하기는 게임 별 1일 1회 참여 가능하며 고의로 잘못된
                  정보를 지속 입력할 경우 경고 없이 유저가 획득한 모든 포인트를
                  회수합니다.
                </p>
              </div>
            </div>
            <div className="flex border-t border-gray-100 sticky bottom-0 bg-white rounded-b-2xl">
              <button
                className="flex-1 py-4 text-[14px] font-semibold text-gray-500 hover:bg-gray-50"
                onClick={() => setShowReviewPopup(false)}
              >
                취소
              </button>
              <button
                className="flex-1 py-4 text-[14px] font-semibold text-white bg-[#4AABF5] hover:bg-[#3d9ae6] rounded-br-2xl"
                onClick={() => {
                  setShowReviewPopup(false);
                  setReviewStars(0);
                  setReviewReward("");
                  setReviewComment("");
                }}
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
