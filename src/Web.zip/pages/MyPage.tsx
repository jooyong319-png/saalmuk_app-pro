import React, { useState } from "react";

// Components
import {
  ProfileHeader,
  Sidebar,
  PostsTab,
  CommentsTab,
  SavedTab,
  BadgesTab,
  FollowPopup,
  SocialLinkModal,
  ProfileEditPopup,
  AvatarDetailPopup,
  BadgeDetailPopup,
} from "../components/mypage";

import FamePopup from "../components/mypage/popups/FamePopup";

// Data & Types
import {
  SOCIAL_PLATFORMS,
  avatarItems,
  badgeItems,
  defaultUser,
  defaultPosts,
  defaultComments,
  defaultSavedPosts,
  defaultFollowers,
  defaultFollowingCommunities,
  defaultFollowingPeople,
  getPlatform,
  MAX_SOCIAL_LINKS,
} from "../components/mypage/data";

import type {
  SocialLink,
  AvatarItem,
  BadgeItem,
  PostItem,
} from "../components/mypage/types";

// ─── 마이페이지 ───
export default function MyPage() {
  // ─── 탭 상태 ───
  const [activeTab, setActiveTab] = useState("게시글");
  const tabs = ["게시글", "댓글", "저장됨", "배지"];

  // ─── 기본 상태 ───
  const [nickname, setNickname] = useState("쌀먹러");
  const [selectedAvatar, setSelectedAvatar] = useState(1);
  const [equippedBadge, setEquippedBadge] = useState(1);

  // ─── 저장된 게시글 (state로 관리) ───
  const [savedPosts, setSavedPosts] = useState<PostItem[]>(defaultSavedPosts);

  // ─── 팝업 상태 ───
  const [showEditPopup, setShowEditPopup] = useState(false);
  const [showAvatarDetail, setShowAvatarDetail] = useState<AvatarItem | null>(
    null,
  );
  const [selectedBadge, setSelectedBadge] = useState<BadgeItem | null>(null);
  const [showFollowPopup, setShowFollowPopup] = useState(false);
  const [followPopupTab, setFollowPopupTab] = useState<
    "follower" | "following"
  >("follower");
  const [followingTab, setFollowingTab] = useState<"community" | "people">(
    "community",
  );

  // ─── Fame 관련 상태 ───
  const [showFamePopup, setShowFamePopup] = useState(false);

  // ─── 소셜 링크 상태 ───
  const [showSocialModal, setShowSocialModal] = useState(false);
  const [socialModalStep, setSocialModalStep] = useState<"select" | "edit">(
    "select",
  );
  const [socialSearchQuery, setSocialSearchQuery] = useState("");
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([]);
  const [editingSocialLink, setEditingSocialLink] = useState<SocialLink | null>(
    null,
  );

  // ─── 유저 정보 ───
  const user = defaultUser;

  // ─── 핸들러: 팔로우 팝업 ───
  const openFollowerPopup = () => {
    setFollowPopupTab("follower");
    setShowFollowPopup(true);
  };

  const openFollowingPopup = () => {
    setFollowPopupTab("following");
    setShowFollowPopup(true);
  };

  // ─── 핸들러: 소셜 링크 ───
  const openSocialModal = () => {
    setSocialModalStep("select");
    setSocialSearchQuery("");
    setEditingSocialLink(null);
    setShowSocialModal(true);
  };

  const handlePlatformSelect = (platformId: string) => {
    // 커스텀이 아닌 경우에만 기존 링크 확인
    if (!platformId.startsWith("custom")) {
      const existingLink = socialLinks.find((l) => l.platformId === platformId);
      if (existingLink) {
        setEditingSocialLink({ ...existingLink });
      } else if (socialLinks.length < MAX_SOCIAL_LINKS) {
        setEditingSocialLink({
          platformId,
          displayText: getPlatform(platformId)?.name || "",
          url: "",
        });
      }
    }
    setSocialModalStep("edit");
  };

  const handleSaveSocialLink = () => {
    if (
      editingSocialLink &&
      editingSocialLink.url &&
      editingSocialLink.displayText
    ) {
      const existingIndex = socialLinks.findIndex(
        (link) => link.platformId === editingSocialLink.platformId,
      );
      if (existingIndex >= 0) {
        // 기존 링크 수정
        const updated = [...socialLinks];
        updated[existingIndex] = editingSocialLink;
        setSocialLinks(updated);
      } else {
        // 새 링크 추가
        setSocialLinks([...socialLinks, editingSocialLink]);
      }
      setSocialModalStep("select");
      setEditingSocialLink(null);
    }
  };

  const handleDeleteSocialLink = () => {
    if (editingSocialLink) {
      setSocialLinks(
        socialLinks.filter(
          (link) => link.platformId !== editingSocialLink.platformId,
        ),
      );
      setSocialModalStep("select");
      setEditingSocialLink(null);
    }
  };

  const filteredSocialPlatforms = SOCIAL_PLATFORMS.filter((platform) =>
    platform.name.toLowerCase().includes(socialSearchQuery.toLowerCase()),
  );

  // ─── 핸들러: 배지 ───
  const handleEquipBadge = (badgeId: number) => {
    setEquippedBadge(badgeId);
    setSelectedBadge(null);
  };

  // ─── 핸들러: 저장된 게시글 삭제 ───
  const handleRemoveSaved = (postId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedPosts((prev) => prev.filter((post) => post.id !== postId));
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      <div className="max-w-[1100px] mx-auto px-6 py-8">
        <div className="grid grid-cols-[1fr_280px] gap-6">
          {/* 왼쪽: 메인 콘텐츠 */}
          <div>
            {/* 프로필 헤더 */}
            <ProfileHeader
              user={user}
              socialLinks={socialLinks}
              onOpenFollowerPopup={openFollowerPopup}
              onOpenFollowingPopup={openFollowingPopup}
              onOpenSocialModal={openSocialModal}
              onOpenEditPopup={() => setShowEditPopup(true)}
              onOpenFameMenu={() => setShowFamePopup(true)}
            />

            {/* 탭 메뉴 & 콘텐츠 */}
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="flex border-b border-gray-100">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-4 text-sm font-semibold transition-colors relative ${
                      activeTab === tab
                        ? "text-[#72C2FF]"
                        : "text-gray-400 hover:text-gray-600"
                    }`}
                  >
                    {tab}
                    {activeTab === tab && (
                      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-[#72C2FF] rounded-full" />
                    )}
                  </button>
                ))}
              </div>

              {/* 탭 콘텐츠 */}
              {activeTab === "게시글" && <PostsTab posts={defaultPosts} />}
              {activeTab === "댓글" && (
                <CommentsTab comments={defaultComments} />
              )}
              {activeTab === "저장됨" && (
                <SavedTab
                  savedPosts={savedPosts}
                  onRemoveSaved={handleRemoveSaved}
                />
              )}
              {activeTab === "배지" && (
                <BadgesTab
                  badgeItems={badgeItems}
                  equippedBadge={equippedBadge}
                  onSelectBadge={setSelectedBadge}
                />
              )}
            </div>
          </div>

          {/* 오른쪽: 사이드바 */}
          <Sidebar user={user} />
        </div>
      </div>

      {/* ─── 팝업들 ─── */}

      {/* 팔로워/팔로잉 팝업 */}
      <FollowPopup
        show={showFollowPopup}
        onClose={() => setShowFollowPopup(false)}
        activeTab={followPopupTab}
        onTabChange={setFollowPopupTab}
        followingTab={followingTab}
        onFollowingTabChange={setFollowingTab}
        followers={defaultFollowers}
        followingCommunities={defaultFollowingCommunities}
        followingPeople={defaultFollowingPeople}
        nickname={user.nickname}
      />

      {/* 소셜 링크 모달 */}
      <SocialLinkModal
        show={showSocialModal}
        onClose={() => setShowSocialModal(false)}
        step={socialModalStep}
        onStepChange={setSocialModalStep}
        searchQuery={socialSearchQuery}
        onSearchChange={setSocialSearchQuery}
        socialLinks={socialLinks}
        filteredPlatforms={filteredSocialPlatforms}
        editingLink={editingSocialLink}
        onEditingLinkChange={setEditingSocialLink}
        onPlatformSelect={handlePlatformSelect}
        onSave={handleSaveSocialLink}
        onDelete={handleDeleteSocialLink}
      />

      {/* 프로필 편집 팝업 */}
      <ProfileEditPopup
        show={showEditPopup}
        onClose={() => setShowEditPopup(false)}
        nickname={nickname}
        onNicknameChange={setNickname}
        selectedAvatar={selectedAvatar}
        onAvatarSelect={setSelectedAvatar}
        avatarItems={avatarItems}
        onShowAvatarDetail={setShowAvatarDetail}
      />

      {/* 아바타 상세 팝업 */}
      <AvatarDetailPopup
        avatar={showAvatarDetail}
        onClose={() => setShowAvatarDetail(null)}
        userFame={user.fame}
      />

      {/* 배지 상세 팝업 */}
      <BadgeDetailPopup
        badge={selectedBadge}
        onClose={() => setSelectedBadge(null)}
        equippedBadge={equippedBadge}
        onEquipBadge={handleEquipBadge}
      />

      {/* Fame 통합 팝업 */}
      {showFamePopup && (
        <FamePopup
          onClose={() => setShowFamePopup(false)}
          totalFame={user.fame}
        />
      )}
    </div>
  );
}
