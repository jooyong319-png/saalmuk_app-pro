import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import LeftSidebar from "../components/gameranking/LeftSidebar";
import RightSidebar from "../components/gameranking/RightSidebar";
import RankingItem, { type GameData } from "../components/gameranking/RankingItem";

// ─── 메인 페이지 컴포넌트 ───
export default function GameRankingPage() {
  const navigate = useNavigate(); // ✅ 추가

  // ─── 상태 관리 (앱 버전 기능 추가) ───
  const [activeTab, setActiveTab] = useState("모바일 게임");
  const [activeFilter, setActiveFilter] = useState("소셜점수");
  const [showGenrePopup, setShowGenrePopup] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState("전체");
  const [showTooltip, setShowTooltip] = useState(false);
  const [likedGames, setLikedGames] = useState<number[]>([]);

  // ─── 탭별 필터 매핑 ───
  const filtersMap: Record<string, string[]> = {
    "모바일 게임": ["소셜점수", "구글순위", "지금핫한", "신규게임"],
    "PC 게임": ["소셜점수", "PC방순위", "지금핫한", "신규게임"],
    "P2E 게임": ["소셜점수", "코인순위", "지금핫한", "신규게임"],
  };
  const filters = filtersMap[activeTab];

  // ─── 장르 목록 ───
  const genres = [
    "전체",
    "RPG/슈팅",
    "어드벤쳐",
    "시뮬레이션",
    "수집형",
    "전략",
    "카드/보드",
    "육성/RPG",
    "방치형/RPG",
  ];

  // ─── 탭 변경 핸들러 ───
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setActiveFilter("소셜점수");
    setSelectedGenre("전체");
  };

  // ─── 하트 토글 ───
  const toggleLike = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    setLikedGames((prev) =>
      prev.includes(id)
        ? prev.filter((gameId) => gameId !== id)
        : [...prev, id],
    );
  };

  // ─── 아이템 클릭 핸들러 ───
  const [versionPopup, setVersionPopup] = useState<{
    id: number;
    name: string;
  } | null>(null);

  const handleItemClick = (id: number, name: string) => {
    setVersionPopup({ id, name });
  };

  // ─── 모바일 게임 랭킹 데이터 ───
  const mobileRankingData: GameData[] = [
    {
      id: 1,
      name: "아이온2",
      shortName: "아이온2",
      genre: "RPG/슈팅",
      rating: 4.9,
      salesRank: 18,
      score: 43863,
      scoreChange: -57.23,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/2ee9f32dc12b4ba9b5cdb55289bdd4c4.jfif",
    },
    {
      id: 2,
      name: "오딘: 발할라 라이징",
      shortName: "오딘",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 5,
      score: 27751,
      scoreChange: -26.5,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/174e967548d240289077708d0b3d57c5.jpg",
    },
    {
      id: 3,
      name: "뱀피르",
      shortName: "뱀피르",
      genre: "RPG/슈팅",
      rating: 4.5,
      salesRank: 17,
      score: 26049,
      scoreChange: -44.46,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/bad0847c72eb4b948364ed741bcf0c53.jfif",
    },
    {
      id: 4,
      name: "리니지 M",
      shortName: "리니지M",
      genre: "RPG/슈팅",
      rating: 3.7,
      salesRank: 7,
      score: 22952,
      scoreChange: -11.56,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/c95724c5a3f2403995112aaadf1289a8.jpg",
    },
    {
      id: 5,
      name: "메이플스토리M",
      shortName: "메이플M",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 32,
      score: 20229,
      scoreChange: -18.33,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/c3c0b437f87c429e95ccee93dbaee83f.jpg",
    },
    {
      id: 6,
      name: "아키텍트 랜드 오브 엑자일",
      shortName: "아키텍트",
      genre: "RPG/슈팅",
      rating: 4.9,
      salesRank: 34,
      score: 19457,
      scoreChange: -9.62,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/930b1d1e0d654dd99c1f51067cf5017c.jfif",
    },
    {
      id: 7,
      name: "삼국지 전략판",
      shortName: "삼국지",
      genre: "전략",
      rating: 3.8,
      salesRank: 0,
      score: 18080,
      scoreChange: 0.0,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/14e2c88737a14a2d96d07a67cfc8ad02.jpg",
    },
    {
      id: 8,
      name: "바람의 나라 : 연",
      shortName: "바람의나라",
      genre: "RPG/슈팅",
      rating: 3.8,
      salesRank: 0,
      score: 17950,
      scoreChange: 0.17,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/94cf755506c04ef2b9aabb332a399bd9.jpg",
    },
    {
      id: 9,
      name: "토치라이트 인피니트",
      shortName: "토치라이트",
      genre: "RPG/슈팅",
      rating: 4.0,
      salesRank: 0,
      score: 17440,
      scoreChange: 0.0,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/ad1502539f13436eb76b5fd0bd32ffe8.jpg",
    },
    {
      id: 10,
      name: "열혈강호:귀환",
      shortName: "열혈강호",
      genre: "RPG/슈팅",
      rating: 4.7,
      salesRank: 85,
      score: 15868,
      scoreChange: 0.0,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/afa4c567982f41b3afe18140ba32b477.jfif",
    },
    {
      id: 11,
      name: "로드나인",
      shortName: "로드나인",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 79,
      score: 14117,
      scoreChange: -68.45,
      rankChange: -8,
      img: "https://edge.ssalmuk.com/editorImage/31dfb963f0064106a30044bc7fe4262b.jpg",
    },
    {
      id: 12,
      name: "트라이워M",
      shortName: "트라이워M",
      genre: "육성/RPG",
      rating: 4.5,
      salesRank: 0,
      score: 7637,
      scoreChange: -0.39,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/a565264aca2140dabe35717b71af104c.png",
    },
    {
      id: 13,
      name: "십이지천M 더 원",
      shortName: "십이지천M",
      genre: "RPG/슈팅",
      rating: 3.2,
      salesRank: 0,
      score: 7127,
      scoreChange: -0.42,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/5edad4741efd40d390a6e8acfd8f72a3.jpg",
    },
    {
      id: 14,
      name: "RF 온라인 넥스트",
      shortName: "RF온라인",
      genre: "RPG/슈팅",
      rating: 4.5,
      salesRank: 46,
      score: 3980,
      scoreChange: -51.31,
      rankChange: -2,
      img: "https://edge.ssalmuk.com/editorImage/6f0ee3a64cd14ca293dd200cfdbdd918.jpg",
    },
    {
      id: 15,
      name: "마비노기 모바일",
      shortName: "마비노기M",
      genre: "RPG/슈팅",
      rating: 4.4,
      salesRank: 12,
      score: 1279,
      scoreChange: -68.1,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/fa8c45ace4f74c62922586fe9fc211a2.png",
    },
    {
      id: 16,
      name: "레전드 오브 이미르",
      shortName: "이미르",
      genre: "RPG/슈팅",
      rating: 4.6,
      salesRank: 0,
      score: 830,
      scoreChange: -31.97,
      rankChange: 4,
      img: "https://edge.ssalmuk.com/editorImage/6e67f2d8c46d489cacf0bd5686b0694f.jpg",
    },
    {
      id: 17,
      name: "나이트크로우",
      shortName: "나이트크로우",
      genre: "RPG/슈팅",
      rating: 3.6,
      salesRank: 54,
      score: 627,
      scoreChange: -77.42,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/7abbf5356a3d4eb78727c15c5fdacc65.jpg",
    },
    {
      id: 18,
      name: "어나더던전",
      shortName: "어나더던전",
      genre: "방치형/RPG",
      rating: 3.5,
      salesRank: 0,
      score: 450,
      scoreChange: -76.56,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/0f6e47e7f64c48469d6971f551278387.jpg",
    },
    {
      id: 19,
      name: "라스트 워:서바이벌",
      shortName: "라스트워",
      genre: "전략",
      rating: 0.5,
      salesRank: 2,
      score: 429,
      scoreChange: 7.52,
      rankChange: 7,
      img: "https://edge.ssalmuk.com/editorImage/7e33ccd92eeb404fa7957770c79bde56.jpg",
    },
    {
      id: 20,
      name: "메이플키우기",
      shortName: "메이플키우기",
      genre: "RPG/슈팅",
      rating: 0,
      salesRank: 1,
      score: 400,
      scoreChange: -2.44,
      rankChange: 5,
      img: "https://edge.ssalmuk.com/editorImage/dd27d60663f64f1b886569d5ff52667d.jfif",
    },
    {
      id: 21,
      name: "화이트아웃 서바이벌",
      shortName: "화이트아웃",
      genre: "시뮬레이션",
      rating: 3.5,
      salesRank: 3,
      score: 398,
      scoreChange: 0.0,
      rankChange: 6,
      img: "https://edge.ssalmuk.com/editorImage/2086a96c2eec44e59c45d54b75de3912.jpg",
    },
    {
      id: 22,
      name: "라스트 z:서바이벌 슈터",
      shortName: "라스트Z",
      genre: "RPG/슈팅",
      rating: 0,
      salesRank: 4,
      score: 397,
      scoreChange: 0.0,
      rankChange: 6,
      img: "https://edge.ssalmuk.com/editorImage/728b4a1de94147d7bec4cd196abd7750.webp",
    },
    {
      id: 23,
      name: "로블록스",
      shortName: "로블록스",
      genre: "어드벤쳐",
      rating: 4.0,
      salesRank: 6,
      score: 395,
      scoreChange: -13.19,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/9fee693175524869b862134b430e4835.jpg",
    },
    {
      id: 24,
      name: "킹샷",
      shortName: "킹샷",
      genre: "RPG/슈팅",
      rating: 0,
      salesRank: 8,
      score: 393,
      scoreChange: 0.0,
      rankChange: 5,
      img: "https://edge.ssalmuk.com/editorImage/b38ba2cf550242d7adfcd77026e4bbf4.jfif",
    },
    {
      id: 25,
      name: "로얄 매치",
      shortName: "로얄매치",
      genre: "카드/보드",
      rating: 5.0,
      salesRank: 9,
      score: 392,
      scoreChange: 0.0,
      rankChange: 5,
      img: "https://edge.ssalmuk.com/editorImage/2037da0b03554abea531a679860b4982.jpg",
    },
  ];

  // ─── PC 게임 랭킹 데이터 (25개) ───
  const pcRankingData: GameData[] = [
    {
      id: 101,
      name: "리그 오브 레전드",
      shortName: "롤",
      genre: "전략",
      rating: 4.5,
      salesRank: 1,
      score: 85000,
      scoreChange: 2.5,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/31dfb963f0064106a30044bc7fe4262b.jpg",
    },
    {
      id: 102,
      name: "배틀그라운드",
      shortName: "배그",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 2,
      score: 72000,
      scoreChange: -3.2,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/7e33ccd92eeb404fa7957770c79bde56.jpg",
    },
    {
      id: 103,
      name: "발로란트",
      shortName: "발로",
      genre: "RPG/슈팅",
      rating: 4.6,
      salesRank: 3,
      score: 68000,
      scoreChange: 5.8,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/2ee9f32dc12b4ba9b5cdb55289bdd4c4.jfif",
    },
    {
      id: 104,
      name: "피파 온라인 4",
      shortName: "피파4",
      genre: "시뮬레이션",
      rating: 3.8,
      salesRank: 4,
      score: 55000,
      scoreChange: -1.5,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/174e967548d240289077708d0b3d57c5.jpg",
    },
    {
      id: 105,
      name: "메이플스토리",
      shortName: "메이플",
      genre: "RPG/슈팅",
      rating: 4.0,
      salesRank: 5,
      score: 52000,
      scoreChange: 0.8,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/c3c0b437f87c429e95ccee93dbaee83f.jpg",
    },
    {
      id: 106,
      name: "오버워치 2",
      shortName: "오버워치",
      genre: "RPG/슈팅",
      rating: 4.3,
      salesRank: 6,
      score: 48000,
      scoreChange: 3.2,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/bad0847c72eb4b948364ed741bcf0c53.jfif",
    },
    {
      id: 107,
      name: "로스트아크",
      shortName: "로아",
      genre: "RPG/슈팅",
      rating: 4.1,
      salesRank: 7,
      score: 45000,
      scoreChange: -5.6,
      rankChange: -2,
      img: "https://edge.ssalmuk.com/editorImage/c95724c5a3f2403995112aaadf1289a8.jpg",
    },
    {
      id: 108,
      name: "던전앤파이터",
      shortName: "던파",
      genre: "RPG/슈팅",
      rating: 3.9,
      salesRank: 8,
      score: 42000,
      scoreChange: 1.2,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/930b1d1e0d654dd99c1f51067cf5017c.jfif",
    },
    {
      id: 109,
      name: "서든어택",
      shortName: "서든",
      genre: "RPG/슈팅",
      rating: 3.5,
      salesRank: 9,
      score: 38000,
      scoreChange: -2.8,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/14e2c88737a14a2d96d07a67cfc8ad02.jpg",
    },
    {
      id: 110,
      name: "스타크래프트",
      shortName: "스타",
      genre: "전략",
      rating: 4.8,
      salesRank: 10,
      score: 35000,
      scoreChange: 0.5,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/94cf755506c04ef2b9aabb332a399bd9.jpg",
    },
    {
      id: 111,
      name: "디아블로 4",
      shortName: "디아4",
      genre: "RPG/슈팅",
      rating: 4.4,
      salesRank: 11,
      score: 33000,
      scoreChange: 8.5,
      rankChange: 3,
      img: "https://edge.ssalmuk.com/editorImage/ad1502539f13436eb76b5fd0bd32ffe8.jpg",
    },
    {
      id: 112,
      name: "월드 오브 워크래프트",
      shortName: "와우",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 12,
      score: 31000,
      scoreChange: -1.2,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/afa4c567982f41b3afe18140ba32b477.jfif",
    },
    {
      id: 113,
      name: "카운터 스트라이크 2",
      shortName: "카스2",
      genre: "RPG/슈팅",
      rating: 4.5,
      salesRank: 13,
      score: 29000,
      scoreChange: 4.3,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/a565264aca2140dabe35717b71af104c.png",
    },
    {
      id: 114,
      name: "팀 파이트 택틱스",
      shortName: "롤토체스",
      genre: "전략",
      rating: 4.0,
      salesRank: 14,
      score: 27000,
      scoreChange: 1.8,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/5edad4741efd40d390a6e8acfd8f72a3.jpg",
    },
    {
      id: 115,
      name: "블레이드 앤 소울",
      shortName: "블소",
      genre: "RPG/슈팅",
      rating: 3.7,
      salesRank: 15,
      score: 25000,
      scoreChange: -3.5,
      rankChange: -2,
      img: "https://edge.ssalmuk.com/editorImage/6f0ee3a64cd14ca293dd200cfdbdd918.jpg",
    },
    {
      id: 116,
      name: "에이펙스 레전드",
      shortName: "에이펙스",
      genre: "RPG/슈팅",
      rating: 4.3,
      salesRank: 16,
      score: 23000,
      scoreChange: 2.1,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/fa8c45ace4f74c62922586fe9fc211a2.png",
    },
    {
      id: 117,
      name: "리니지",
      shortName: "리니지",
      genre: "RPG/슈팅",
      rating: 3.6,
      salesRank: 17,
      score: 21000,
      scoreChange: -0.8,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/6e67f2d8c46d489cacf0bd5686b0694f.jpg",
    },
    {
      id: 118,
      name: "마인크래프트",
      shortName: "마크",
      genre: "어드벤쳐",
      rating: 4.7,
      salesRank: 18,
      score: 19000,
      scoreChange: 5.2,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/7abbf5356a3d4eb78727c15c5fdacc65.jpg",
    },
    {
      id: 119,
      name: "GTA 온라인",
      shortName: "GTA",
      genre: "어드벤쳐",
      rating: 4.4,
      salesRank: 19,
      score: 17000,
      scoreChange: 0.3,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/0f6e47e7f64c48469d6971f551278387.jpg",
    },
    {
      id: 120,
      name: "포트나이트",
      shortName: "포트나이트",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 20,
      score: 15000,
      scoreChange: -2.1,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/dd27d60663f64f1b886569d5ff52667d.jfif",
    },
    {
      id: 121,
      name: "도타 2",
      shortName: "도타2",
      genre: "전략",
      rating: 4.1,
      salesRank: 21,
      score: 14000,
      scoreChange: 1.5,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/2086a96c2eec44e59c45d54b75de3912.jpg",
    },
    {
      id: 122,
      name: "엘든 링",
      shortName: "엘든링",
      genre: "RPG/슈팅",
      rating: 4.9,
      salesRank: 22,
      score: 13000,
      scoreChange: 6.8,
      rankChange: 3,
      img: "https://edge.ssalmuk.com/editorImage/728b4a1de94147d7bec4cd196abd7750.webp",
    },
    {
      id: 123,
      name: "데스티니 가디언즈",
      shortName: "데스티니",
      genre: "RPG/슈팅",
      rating: 4.0,
      salesRank: 23,
      score: 12000,
      scoreChange: -1.9,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/9fee693175524869b862134b430e4835.jpg",
    },
    {
      id: 124,
      name: "더 파이널스",
      shortName: "파이널스",
      genre: "RPG/슈팅",
      rating: 4.3,
      salesRank: 24,
      score: 11000,
      scoreChange: 15.2,
      rankChange: 5,
      img: "https://edge.ssalmuk.com/editorImage/b38ba2cf550242d7adfcd77026e4bbf4.jfif",
    },
    {
      id: 125,
      name: "레인보우 식스 시즈",
      shortName: "레식",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 25,
      score: 10000,
      scoreChange: 0.7,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/2037da0b03554abea531a679860b4982.jpg",
    },
  ];

  // ─── P2E 게임 랭킹 데이터 (25개) ───
  const p2eRankingData: GameData[] = [
    {
      id: 201,
      name: "엑시 인피니티",
      shortName: "엑시",
      genre: "수집형",
      rating: 3.9,
      salesRank: 1,
      score: 45000,
      scoreChange: -8.2,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/bad0847c72eb4b948364ed741bcf0c53.jfif",
    },
    {
      id: 202,
      name: "더 샌드박스",
      shortName: "샌드박스",
      genre: "어드벤쳐",
      rating: 4.1,
      salesRank: 2,
      score: 38000,
      scoreChange: 12.5,
      rankChange: 3,
      img: "https://edge.ssalmuk.com/editorImage/9fee693175524869b862134b430e4835.jpg",
    },
    {
      id: 203,
      name: "디센트럴랜드",
      shortName: "디센트럴",
      genre: "어드벤쳐",
      rating: 3.7,
      salesRank: 3,
      score: 32000,
      scoreChange: -4.3,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/930b1d1e0d654dd99c1f51067cf5017c.jfif",
    },
    {
      id: 204,
      name: "갓즈언체인드",
      shortName: "갓즈",
      genre: "카드/보드",
      rating: 4.3,
      salesRank: 4,
      score: 28000,
      scoreChange: 7.2,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/2037da0b03554abea531a679860b4982.jpg",
    },
    {
      id: 205,
      name: "일루비움",
      shortName: "일루비움",
      genre: "수집형",
      rating: 4.5,
      salesRank: 5,
      score: 25000,
      scoreChange: 18.9,
      rankChange: 5,
      img: "https://edge.ssalmuk.com/editorImage/6e67f2d8c46d489cacf0bd5686b0694f.jpg",
    },
    {
      id: 206,
      name: "스플린터랜드",
      shortName: "스플린터",
      genre: "카드/보드",
      rating: 4.0,
      salesRank: 6,
      score: 22000,
      scoreChange: 3.5,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/2ee9f32dc12b4ba9b5cdb55289bdd4c4.jfif",
    },
    {
      id: 207,
      name: "빅타임",
      shortName: "빅타임",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 7,
      score: 20000,
      scoreChange: 25.3,
      rankChange: 8,
      img: "https://edge.ssalmuk.com/editorImage/174e967548d240289077708d0b3d57c5.jpg",
    },
    {
      id: 208,
      name: "갈라 게임즈",
      shortName: "갈라",
      genre: "어드벤쳐",
      rating: 3.8,
      salesRank: 8,
      score: 18000,
      scoreChange: -2.1,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/c95724c5a3f2403995112aaadf1289a8.jpg",
    },
    {
      id: 209,
      name: "스타 아틀라스",
      shortName: "스타아틀라스",
      genre: "전략",
      rating: 4.4,
      salesRank: 9,
      score: 16000,
      scoreChange: 8.7,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/c3c0b437f87c429e95ccee93dbaee83f.jpg",
    },
    {
      id: 210,
      name: "엠버소드",
      shortName: "엠버소드",
      genre: "RPG/슈팅",
      rating: 4.1,
      salesRank: 10,
      score: 14500,
      scoreChange: 5.2,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/31dfb963f0064106a30044bc7fe4262b.jpg",
    },
    {
      id: 211,
      name: "미르4 글로벌",
      shortName: "미르4",
      genre: "RPG/슈팅",
      rating: 3.5,
      salesRank: 11,
      score: 13000,
      scoreChange: -6.8,
      rankChange: -3,
      img: "https://edge.ssalmuk.com/editorImage/14e2c88737a14a2d96d07a67cfc8ad02.jpg",
    },
    {
      id: 212,
      name: "나인 크로니클",
      shortName: "나인크로니클",
      genre: "RPG/슈팅",
      rating: 3.9,
      salesRank: 12,
      score: 12000,
      scoreChange: 2.3,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/94cf755506c04ef2b9aabb332a399bd9.jpg",
    },
    {
      id: 213,
      name: "크립토 유니콘",
      shortName: "유니콘",
      genre: "수집형",
      rating: 4.0,
      salesRank: 13,
      score: 11000,
      scoreChange: 15.6,
      rankChange: 4,
      img: "https://edge.ssalmuk.com/editorImage/ad1502539f13436eb76b5fd0bd32ffe8.jpg",
    },
    {
      id: 214,
      name: "에일리언 월드",
      shortName: "에일리언",
      genre: "전략",
      rating: 3.6,
      salesRank: 14,
      score: 10000,
      scoreChange: -1.5,
      rankChange: -1,
      img: "https://edge.ssalmuk.com/editorImage/afa4c567982f41b3afe18140ba32b477.jfif",
    },
    {
      id: 215,
      name: "팬텀 갤럭시",
      shortName: "팬텀",
      genre: "RPG/슈팅",
      rating: 4.3,
      salesRank: 15,
      score: 9500,
      scoreChange: 22.1,
      rankChange: 6,
      img: "https://edge.ssalmuk.com/editorImage/a565264aca2140dabe35717b71af104c.png",
    },
    {
      id: 216,
      name: "사이버콩",
      shortName: "사이버콩",
      genre: "어드벤쳐",
      rating: 3.8,
      salesRank: 16,
      score: 9000,
      scoreChange: 4.8,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/5edad4741efd40d390a6e8acfd8f72a3.jpg",
    },
    {
      id: 217,
      name: "길드 오브 가디언즈",
      shortName: "가디언즈",
      genre: "RPG/슈팅",
      rating: 4.2,
      salesRank: 17,
      score: 8500,
      scoreChange: 9.3,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/6f0ee3a64cd14ca293dd200cfdbdd918.jpg",
    },
    {
      id: 218,
      name: "블랭코스 블록 파티",
      shortName: "블랭코스",
      genre: "어드벤쳐",
      rating: 3.7,
      salesRank: 18,
      score: 8000,
      scoreChange: -3.2,
      rankChange: -2,
      img: "https://edge.ssalmuk.com/editorImage/fa8c45ace4f74c62922586fe9fc211a2.png",
    },
    {
      id: 219,
      name: "챔피언스 어센션",
      shortName: "챔피언스",
      genre: "RPG/슈팅",
      rating: 4.0,
      salesRank: 19,
      score: 7500,
      scoreChange: 6.1,
      rankChange: 1,
      img: "https://edge.ssalmuk.com/editorImage/7abbf5356a3d4eb78727c15c5fdacc65.jpg",
    },
    {
      id: 220,
      name: "레전드 오브 벤처",
      shortName: "벤처",
      genre: "전략",
      rating: 3.9,
      salesRank: 20,
      score: 7000,
      scoreChange: 0.8,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/0f6e47e7f64c48469d6971f551278387.jpg",
    },
    {
      id: 221,
      name: "해시러쉬",
      shortName: "해시러쉬",
      genre: "전략",
      rating: 3.5,
      salesRank: 21,
      score: 6500,
      scoreChange: -5.4,
      rankChange: -3,
      img: "https://edge.ssalmuk.com/editorImage/7e33ccd92eeb404fa7957770c79bde56.jpg",
    },
    {
      id: 222,
      name: "크로스더에이지",
      shortName: "크로스",
      genre: "카드/보드",
      rating: 4.1,
      salesRank: 22,
      score: 6000,
      scoreChange: 11.2,
      rankChange: 4,
      img: "https://edge.ssalmuk.com/editorImage/dd27d60663f64f1b886569d5ff52667d.jfif",
    },
    {
      id: 223,
      name: "메타버스 마이너",
      shortName: "마이너",
      genre: "시뮬레이션",
      rating: 3.4,
      salesRank: 23,
      score: 5500,
      scoreChange: 1.9,
      rankChange: 0,
      img: "https://edge.ssalmuk.com/editorImage/2086a96c2eec44e59c45d54b75de3912.jpg",
    },
    {
      id: 224,
      name: "월드 오브 에터니티",
      shortName: "에터니티",
      genre: "RPG/슈팅",
      rating: 4.0,
      salesRank: 24,
      score: 5000,
      scoreChange: 7.5,
      rankChange: 2,
      img: "https://edge.ssalmuk.com/editorImage/728b4a1de94147d7bec4cd196abd7750.webp",
    },
    {
      id: 225,
      name: "픽셀몬",
      shortName: "픽셀몬",
      genre: "수집형",
      rating: 4.2,
      salesRank: 25,
      score: 4500,
      scoreChange: 28.3,
      rankChange: 10,
      img: "https://edge.ssalmuk.com/editorImage/b38ba2cf550242d7adfcd77026e4bbf4.jfif",
    },
  ];

  // ─── 탭별 데이터 매핑 ───
  const dataMap: Record<string, GameData[]> = {
    "모바일 게임": mobileRankingData,
    "PC 게임": pcRankingData,
    "P2E 게임": p2eRankingData,
  };

  // ─── 장르 필터링 + 정렬 ───
  const filteredRankings = useMemo(() => {
    const currentData = dataMap[activeTab] || mobileRankingData;

    let result =
      selectedGenre === "전체"
        ? [...currentData]
        : currentData.filter((item) => item.genre === selectedGenre);

    switch (activeFilter) {
      case "소셜점수":
        result.sort((a, b) => b.score - a.score);
        break;
      case "구글순위":
      case "PC방순위":
      case "코인순위":
        result.sort((a, b) => {
          if (a.salesRank === 0) return 1;
          if (b.salesRank === 0) return -1;
          return a.salesRank - b.salesRank;
        });
        break;
      case "지금핫한":
        result.sort((a, b) => b.scoreChange - a.scoreChange);
        break;
      case "신규게임":
        result.sort((a, b) => b.id - a.id);
        break;
    }

    return result;
  }, [activeTab, selectedGenre, activeFilter]);

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: "#F5F6F8" }}
    >
      {/* <RightSideIcons /> */}

      {/* 장르 팝업 오버레이 (최상위 레벨) */}
      {showGenrePopup && (
        <div
          className="fixed inset-0 z-[100]"
          onClick={() => setShowGenrePopup(false)}
        />
      )}

      {/* 툴팁 팝업 오버레이 (최상위 레벨) */}
      {showTooltip && (
        <div
          className="fixed inset-0 z-[100]"
          onClick={() => setShowTooltip(false)}
        />
      )}
      {/* 버전 선택 팝업 */}
      {versionPopup && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setVersionPopup(null)}
          />
          <div className="relative z-10 bg-white rounded-2xl p-6 w-full max-w-xs shadow-2xl animate-scaleIn">
            <p className="text-sm text-gray-500 text-center mb-5">
              버전을 선택하세요
            </p>
            <div className="space-y-3">
              <button
                onClick={() => {
                  navigate(`/game/${versionPopup.id}`);
                  setVersionPopup(null);
                }}
                className="w-full py-3 bg-[#4AABF5] text-white rounded-xl font-bold hover:bg-[#3d9ae6] transition-colors"
              >
                기본 버전
              </button>
              <button
                onClick={() => {
                  navigate(`/game-v1/${versionPopup.id}`);
                  setVersionPopup(null);
                }}
                className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition-colors"
              >
                V1 버전
              </button>
              <button
                onClick={() => {
                  navigate(`/game-v2/${versionPopup.id}`);
                  setVersionPopup(null);
                }}
                className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition-colors"
              >
                V2 버전
              </button>
            </div>
            <button
              onClick={() => setVersionPopup(null)}
              className="w-full mt-4 py-2 text-gray-400 text-sm hover:text-gray-600"
            >
              취소
            </button>
          </div>
        </div>
      )}
      {/* 왼쪽 플로팅 사이드바 */}
      {/* REVERT: 원래는 그리드 안 <aside className="hidden lg:block"><div className="sticky top-6"> */}
      <aside
        className="fixed hidden xl:block w-[200px] py-6"
        style={{ left: "calc(50% - 640px - 216px)", top: "56px" }}
      >
        <LeftSidebar activeTab={activeTab} setActiveTab={handleTabChange} />
      </aside>

      <div className="max-w-[1280px] mx-auto w-full grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6 p-6">
        {/* Main Content */}
        <main className="flex flex-col gap-4 min-w-0">
          {/* Header Area - z-index 높게 설정 */}
          <div className="relative z-[200] animate-fadeUp">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-[22px] font-extrabold text-[#1A1A2E] mb-1">
                  {activeTab} 순위
                </h1>
                <p className="text-[13px] text-gray-500">
                  투명한 데이터 기반 게임 랭킹
                </p>
              </div>
            </div>

            {/* Filter - 배경색 추가하여 리스트와 구분 */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#F5F6F8] pb-2">
              <div className="flex gap-2">
                {filters.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveFilter(tab)}
                    className={`px-4 py-1.5 rounded-full text-[13px] font-semibold border transition-all ${
                      activeFilter === tab
                        ? "bg-[#72C2FF] border-[#72C2FF] text-white"
                        : "bg-white border-gray-200 text-gray-500 hover:border-[#72C2FF] hover:text-[#4AABF5]"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              {/* 장르 선택 & 툴팁 */}
              <div className="flex items-center gap-3 text-[12px] text-gray-400 ml-auto">
                {/* 기준일시 & 툴팁 */}
                <div className="flex items-center gap-1.5 relative">
                  <span>2025.01.18 10:40 기준</span>
                  <button
                    onClick={() => setShowTooltip(!showTooltip)}
                    className="w-5 h-5 border border-gray-400 rounded-full flex items-center justify-center text-[11px] font-bold text-gray-500 hover:bg-gray-100"
                  >
                    ?
                  </button>

                  {/* 툴팁 팝업 */}
                  {showTooltip && (
                    <div className="absolute top-8 right-0 w-72 bg-gray-800 text-white p-4 rounded-xl shadow-2xl z-[200] text-xs leading-relaxed animate-fadeUp">
                      <div className="flex justify-between items-center mb-2 border-b border-gray-600 pb-2">
                        <span className="font-bold text-yellow-400">
                          🏆 랭킹 집계 기준
                        </span>
                        <button
                          onClick={() => setShowTooltip(false)}
                          className="text-lg leading-none hover:text-gray-300"
                        >
                          ×
                        </button>
                      </div>
                      <p>
                        소셜 점수, 구글 매출 순위, 커뮤니티 활성도를 종합하여
                        실시간으로 집계됩니다.
                      </p>
                    </div>
                  )}
                </div>
                {/* 장르 드롭다운 */}
                <div className="relative">
                  <button
                    onClick={() => setShowGenrePopup(!showGenrePopup)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-[13px] font-semibold text-[#1A1A2E] hover:border-[#72C2FF] transition-colors"
                  >
                    <span className="text-[#72C2FF]">●</span>
                    {selectedGenre}
                    <span className="text-xs text-gray-400">▼</span>
                  </button>

                  {/* 장르 팝업 */}
                  {showGenrePopup && (
                    <div className="absolute top-10 left-0 bg-white border border-gray-200 rounded-xl shadow-2xl z-[200] min-w-[160px] max-h-64 overflow-y-auto animate-fadeUp">
                      {genres.map((genre) => (
                        <button
                          key={genre}
                          onClick={() => {
                            setSelectedGenre(genre);
                            setShowGenrePopup(false);
                          }}
                          className={`w-full px-4 py-3 text-left text-sm border-b border-gray-50 last:border-0 hover:bg-blue-50 transition-colors ${
                            selectedGenre === genre
                              ? "text-[#4AABF5] font-bold bg-[#E8F4FD]"
                              : "text-gray-700"
                          }`}
                        >
                          {genre}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Ranking List - z-index 낮게 설정 */}
          <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 relative z-10 animate-fadeUp delay-1">
            {filteredRankings.length === 0 ? (
              <div className="text-center py-20 text-gray-400 flex flex-col items-center animate-fadeUp">
                <span className="text-5xl mb-3">😢</span>
                <p className="text-[15px] font-medium">
                  선택하신 장르의 게임이 없습니다.
                </p>
                <button
                  onClick={() => setSelectedGenre("전체")}
                  className="mt-4 text-[#4AABF5] underline text-sm font-semibold hover:text-[#72C2FF]"
                >
                  전체 보기
                </button>
              </div>
            ) : (
              <div className="flex flex-col">
                {filteredRankings.map((game, i) => (
                  <RankingItem
                    key={game.id}
                    rank={i + 1}
                    game={game}
                    change={game.rankChange}
                    isLiked={likedGames.includes(game.id)}
                    onToggleLike={(e) => toggleLike(e, game.id)}
                    onClick={() => handleItemClick(game.id, game.name)}
                    animationDelay={50 + i * 30}
                  />
                ))}
              </div>
            )}
          </div>
        </main>

        {/* Right Sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-6">
            <RightSidebar />
          </div>
        </aside>
      </div>
    </div>
  );
}
