// @ts-nocheck
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { coupons } from "../components/coupon/data";
import type { Coupon } from "../components/coupon/types";
import CouponDetailPanel from "../components/coupon/CouponDetailPanel";
import PurchaseGuide from "../components/coupon/PurchaseGuide";
import CouponRegisterModal from "../components/coupon/CouponRegisterModal";
import BannerSlider from "../components/coupon/BannerSlider";
import CouponLeftSidebar from "../components/coupon/CouponLeftSidebar";
import DiscountCouponCard from "../components/coupon/DiscountCouponCard";
import FixedCouponItem from "../components/coupon/FixedCouponItem";
import PurchaseHistoryView from "../components/coupon/PurchaseHistoryView";
import CouponRightSidebar from "../components/coupon/CouponRightSidebar";

// discountItems가 있는 게임만 할인쿠폰 목록으로 사용
const discountCoupons = coupons.filter(
  (c) => c.discountItems && c.discountItems.length > 0,
);
// ===== 메인 컴포넌트 =====
export default function CouponPage() {
  const location = useLocation();
  const [mainTab, setMainTab] = useState("할인쿠폰");
  const [subNav, setSubNav] = useState("전체 쿠폰");
  const [couponType, setCouponType] = useState("전체");
  const [selectedCoupon, setSelectedCoupon] = useState<Coupon | null>(null);
  const [initialDetailTab, setInitialDetailTab] = useState<
    "할인쿠폰" | "고정쿠폰"
  >("고정쿠폰");

  // WebHome에서 특정 쿠폰으로 진입 시 자동 선택
  useEffect(() => {
    const state = location.state as { couponId?: number } | null;
    if (state?.couponId) {
      const target = coupons.find((c) => c.id === state.couponId);
      if (target) {
        setMainTab("할인쿠폰");
        setInitialDetailTab("할인쿠폰");
        setSelectedCoupon(target);
      }
    }
  }, []);
  const [likedCoupons, setLikedCoupons] = useState<number[]>([4, 6, 10]);
  const [alertCoupons, setAlertCoupons] = useState<number[]>([]);
  const [showRegister, setShowRegister] = useState<false | "등록" | "신규">(false);

  // Toast
  const [toastMsg, setToastMsg] = useState("");
  const [toastVisible, setToastVisible] = useState(false);
  const [toastShow, setToastShow] = useState(false);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setToastShow(true);
    setTimeout(() => setToastVisible(true), 10);
    setTimeout(() => setToastVisible(false), 1700);
    setTimeout(() => setToastShow(false), 2000);
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [mainTab, subNav, selectedCoupon]);

  const toggleLike = (id: number) =>
    setLikedCoupons((p) =>
      p.includes(id) ? p.filter((x) => x !== id) : [...p, id],
    );
  const toggleAlert = (id: number) =>
    setAlertCoupons((p) =>
      p.includes(id) ? p.filter((x) => x !== id) : [...p, id],
    );

  // 필터된 할인쿠폰 (UID/PIN은 discountItems 안에 해당 타입이 하나라도 있으면 노출)
  const filteredDiscount = discountCoupons.filter((c) => {
    if (couponType === "전체") return true;
    const type = couponType.replace("쿠폰", "").trim();
    return c.discountItems?.some((d) => d.type === type);
  });

  // 고정쿠폰 - 즐겨찾기/알람 필터
  const filteredFixed =
    subNav === "즐겨찾기"
      ? coupons.filter((c) => likedCoupons.includes(c.id))
      : subNav === "알람"
        ? coupons.filter((c) => alertCoupons.includes(c.id))
        : coupons;

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* 왼쪽 플로팅 사이드바 */}
      <aside
        className="fixed hidden xl:block w-[200px] py-6"
        style={{ left: "calc(50% - 640px - 216px)", top: "60px" }}
      >
        <CouponLeftSidebar
          mainTab={mainTab}
          onMainTabChange={(tab) => {
            setMainTab(tab);
            setSelectedCoupon(null);
          }}
          subNav={subNav}
          onSubNavChange={setSubNav}
        />
      </aside>

      <div className="max-w-[1280px] mx-auto px-6">
        <div className="grid grid-cols-[1fr_280px] min-h-[calc(100vh-60px)]">
          {/* 메인 */}
          <main className="bg-white border-l border-r border-gray-200 px-6 min-h-full mx-5">
            {/* 고정쿠폰 상세 패널 */}
            {selectedCoupon ? (
              <CouponDetailPanel
                coupon={selectedCoupon}
                likedCoupons={likedCoupons}
                alertCoupons={alertCoupons}
                onToggleLike={toggleLike}
                onToggleAlert={toggleAlert}
                onBack={() => setSelectedCoupon(null)}
                onToast={showToast}
                initialDetailTab={initialDetailTab}
              />
            ) : (
              <>
                {/* 배너 */}
                <div className="py-5 border-b border-gray-100">
                  <BannerSlider />
                </div>

                {/* 할인쿠폰 탭 */}
                {mainTab === "할인쿠폰" && subNav === "구매내역" && (
                  <PurchaseHistoryView />
                )}

                {mainTab === "할인쿠폰" && subNav === "구매방법" && (
                  <div className="py-6">
                    <PurchaseGuide />
                  </div>
                )}

                {mainTab === "할인쿠폰" && subNav !== "구매내역" && subNav !== "구매방법" && (
                  <div className="py-4">
                    {/* 서브 필터 */}
                    <div className="flex items-center gap-2 mb-5">
                      {["전체", "UID쿠폰", "PIN쿠폰"].map((t) => (
                        <button
                          key={t}
                          onClick={() => setCouponType(t)}
                          className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                            couponType === t
                              ? "bg-[#72C2FF] text-white"
                              : "bg-white border border-gray-200 text-gray-600 hover:border-[#72C2FF] hover:text-[#72C2FF]"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                      <div className="flex-1" />
                      <button
                        onClick={() => setShowRegister("등록")}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-semibold border border-dashed border-[#72C2FF] text-[#72C2FF] hover:bg-blue-50 transition-colors"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                        </svg>
                        쿠폰 등록
                      </button>
                    </div>

                    {/* 추천게임 섹션 */}
                    <h3 className="text-[15px] font-bold text-[#1A1A2E] mb-3">
                      추천게임
                    </h3>
                    <div className="grid grid-cols-4 gap-4">
                      {filteredDiscount.map((coupon) => (
                        <DiscountCouponCard
                          key={coupon.id}
                          coupon={coupon}
                          onClick={() => {
                            setInitialDetailTab("할인쿠폰");
                            setSelectedCoupon(coupon);
                          }}
                        />
                      ))}
                    </div>

                    {filteredDiscount.length === 0 && (
                      <div className="py-16 text-center text-gray-400 text-sm">
                        해당 타입의 쿠폰이 없습니다.
                      </div>
                    )}
                  </div>
                )}

                {/* 고정쿠폰 탭 */}
                {mainTab === "고정쿠폰" && (
                  <div>
                    {/* 서브 필터 */}
                    <div className="flex items-center gap-2 py-3 border-b border-gray-100">
                      {["전체", "즐겨찾기", "알람"].map((t) => (
                        <button
                          key={t}
                          onClick={() => setSubNav(t)}
                          className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                            subNav === t
                              ? "bg-[#72C2FF] text-white"
                              : "bg-white border border-gray-200 text-gray-600 hover:border-[#72C2FF] hover:text-[#72C2FF]"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                      <div className="flex-1" />
                      <button
                        onClick={() => setShowRegister("등록")}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-semibold border border-dashed border-[#72C2FF] text-[#72C2FF] hover:bg-blue-50 transition-colors"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                        </svg>
                        쿠폰 등록
                      </button>
                    </div>

                    {filteredFixed.length === 0 ? (
                      <div className="py-16 text-center text-gray-400 text-sm">
                        {subNav === "즐겨찾기"
                          ? "즐겨찾기한 게임이 없습니다."
                          : "알람 설정한 게임이 없습니다."}
                      </div>
                    ) : (
                      filteredFixed.map((coupon) => (
                        <FixedCouponItem
                          key={coupon.id}
                          coupon={coupon}
                          onClick={() => {
                            setInitialDetailTab("고정쿠폰");
                            setSelectedCoupon(coupon);
                          }}
                        />
                      ))
                    )}

                    {/* 하단 게임 등록 유도 버튼 */}
                    <button
                      onClick={() => setShowRegister("신규")}
                      className="w-full flex items-center gap-3 px-4 py-3.5 border border-dashed border-gray-300 rounded-xl text-left hover:border-[#72C2FF] hover:bg-blue-50 transition-all group mt-2 mb-10"
                    >
                      <div className="w-10 h-10 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center flex-shrink-0 group-hover:border-[#72C2FF]">
                        <svg className="w-5 h-5 text-gray-400 group-hover:text-[#72C2FF]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-semibold text-[#72C2FF]">게임이 없나요?</p>
                        <p className="text-xs text-gray-400 mt-0.5">새 게임쿠폰 등록 신청하기</p>
                      </div>
                      <svg className="w-4 h-4 text-gray-300 group-hover:text-[#72C2FF]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                  </div>
                )}
              </>
            )}
          </main>

          {/* 오른쪽 사이드바 */}
          <aside className="py-6 self-start sticky top-[60px]">
            <CouponRightSidebar />
          </aside>
        </div>
      </div>

      {/* Toast */}
      {toastShow && (
        <div
          className={`fixed top-20 left-1/2 -translate-x-1/2 bg-gray-800 text-white px-5 py-3 rounded-full flex items-center gap-2 z-[600] whitespace-nowrap transition-all duration-300 ${
            toastVisible
              ? "opacity-100 translate-y-0"
              : "opacity-0 -translate-y-2"
          }`}
        >
          <span className="text-green-400">✓</span>
          <span className="text-sm">{toastMsg}</span>
        </div>
      )}

      {/* 쿠폰 등록 모달 */}
      {showRegister && (
        <CouponRegisterModal
          coupon={coupons[0]}
          allCoupons={coupons}
          onClose={() => setShowRegister(false)}
          onToast={showToast}
          initialTab={showRegister}
        />
      )}
    </div>
  );
}
