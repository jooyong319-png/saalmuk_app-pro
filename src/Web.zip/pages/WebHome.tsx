import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { coupons } from "../components/coupon/data";
import { initialPosts } from "../components/gallery/postsData";
import { events as lifetechEvents } from "../components/lifetech/data";

/* ══════════════════════════════════════════════════════════════════════════
   쌀먹닷컴 웹 HOME v2
   Based on ssalmuk_v10_updated.html design
   2-column layout with left floating banner
   ══════════════════════════════════════════════════════════════════════════ */

// ── Left Floating Banner ──
function LeftFloatingBanner() {
  return (
    <div
      className="fixed z-50 flex flex-col cursor-pointer animate-fadeUp delay-1 hidden xl:flex"
      style={{
        left: "calc(50% - 640px - 160px)",
        top: "10%",
        transform: "translateY(-50%)",
        filter: "drop-shadow(4px 4px 12px rgba(0,0,0,0.25))",
      }}
    >
      <div className="rounded-xl overflow-hidden bg-black">
        <img
          src="https://appdata.hungryapp.co.kr/banner/202602/1770858901.jpg"
          alt="조선협객전M 배너"
          className="w-[140px] h-auto object-cover"
        />
      </div>
    </div>
  );
}

// // ── Right Side Icons ──
// function RightSideIcons() {
//   const icons = [
//     { emoji: "🔔", label: "알림" },
//     { emoji: "⏱️", label: "최근본" },
//     { emoji: "💬", label: "문의" },
//     { emoji: "📱", label: "QR" },
//   ];

//   return (
//     <div className="fixed right-0 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-0.5 bg-white rounded-l-xl shadow-[-2px_0_8px_rgba(0,0,0,0.06)] py-2 hidden xl:flex">
//       {icons.map((icon, i) => (
//         <button
//           key={i}
//           className="w-12 h-12 flex flex-col items-center justify-center gap-0.5 text-[9px] text-[#9CA3AF] font-semibold hover:bg-[#E8F4FD] hover:text-[#4AABF5] transition-colors"
//         >
//           <span className="text-base">{icon.emoji}</span>
//           {icon.label}
//         </button>
//       ))}
//     </div>
//   );
// }

// ── Section Header ──
function SectionHeader({
  title,
  icon,
  onMore,
}: {
  title: string;
  icon?: string;
  onMore?: () => void;
}) {
  return (
    <div className="flex items-center justify-between px-5 pt-[18px]">
      <h3 className="text-[17px] font-bold flex items-center gap-2">
        {icon && <span className="text-lg">{icon}</span>}
        {title}
      </h3>
      {onMore && (
        <span
          onClick={onMore}
          className="text-[13px] text-[#9CA3AF] cursor-pointer flex items-center gap-1 hover:text-[#4AABF5] transition-colors"
        >
          더보기 →
        </span>
      )}
    </div>
  );
}

// ── Banner Slider ──
function BannerSlider() {
  const originalBanners = [
    "https://edge.ssalmuk.com/editorImage/405612ee2de64d6dbe7ef3f04d952fd9.png",
    "https://edge.ssalmuk.com/editorImage/b5e3785c3bd54e729d09eb41e5758fc3.jpg",
    "https://edge.ssalmuk.com/editorImage/206957acaf834295997127bf3b3162ab.png",
  ];

  const banners = [...originalBanners, ...originalBanners, ...originalBanners];
  const [current, setCurrent] = useState(originalBanners.length);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [dragOffset, setDragOffset] = useState(0);

  useEffect(() => {
    if (
      !isDragging &&
      (current === originalBanners.length * 2 ||
        current === originalBanners.length - 1)
    ) {
      const timer = setTimeout(() => {
        setIsTransitioning(false);
        setCurrent(
          current === originalBanners.length * 2
            ? originalBanners.length
            : originalBanners.length * 2 - 1,
        );
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [current, isDragging, originalBanners.length]);

  const onDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    setIsTransitioning(false);
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    setStartX(clientX);
  };

  const onDragMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDragging) return;
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const diff = clientX - startX;
    setDragOffset(diff);
  };

  const onDragEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);
    setIsTransitioning(true);
    const threshold = 50;
    if (dragOffset < -threshold) setCurrent((prev) => prev + 1);
    else if (dragOffset > threshold) setCurrent((prev) => prev - 1);
    setDragOffset(0);
  };

  return (
    <div
      className="relative w-full overflow-hidden select-none touch-pan-y animate-fadeUp"
      onMouseDown={onDragStart}
      onMouseMove={onDragMove}
      onMouseUp={onDragEnd}
      onMouseLeave={onDragEnd}
      onTouchStart={onDragStart}
      onTouchMove={onDragMove}
      onTouchEnd={onDragEnd}
    >
      <div
        className={`flex items-center ${isTransitioning ? "transition-transform duration-500 ease-out" : ""}`}
        style={{
          transform: `translateX(calc(-${current * 50}% + 25% + ${dragOffset}px))`,
          width: "100%",
        }}
      >
        {banners.map((url, i) => {
          const isActive = i === current;
          return (
            <div
              key={i}
              className={`relative shrink-0 px-3 w-[50%] transition-all duration-500 ${
                isActive ? "opacity-100 z-10 scale-100" : "opacity-40 scale-95"
              }`}
            >
              <div className="w-full rounded-2xl overflow-hidden shadow-lg bg-white">
                <div className="aspect-[17/12] w-full relative">
                  <img
                    src={url}
                    alt={`banner-${i}`}
                    className="absolute inset-0 w-full h-full object-fill"
                    draggable={false}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Gallery Tabs ──
function GalleryTabs() {
  const [active, setActive] = useState("전체");
  const tabs = [
    { name: "전체", isAll: true },
    {
      name: "로스트아크",
      img: "https://edge.ssalmuk.com/editorImage/3e9c8d4f13e64add96357bd7b4ebe62a.jpg",
    },
    {
      name: "던전앤파이터",
      img: "https://edge.ssalmuk.com/editorImage/d8353df7a9834da9984f550f57af6307.jpg",
    },
    {
      name: "마비노기",
      img: "https://edge.ssalmuk.com/editorImage/2dddbb8a45b348fc9740d8b2157c6999.jpg",
    },
    {
      name: "메이플스토리",
      img: "https://edge.ssalmuk.com/editorImage/8340a446068d4799a60acbf85f415e28.jpg",
    },
    {
      name: "로드나인",
      img: "https://edge.ssalmuk.com/editorImage/145ef9589b8047169888e2f0c232b3d4.jpg",
    },
    {
      name: "리니지M",
      img: "https://edge.ssalmuk.com/editorImage/f85655d36efc44aaaf692cbef435271d.jpg",
    },
    {
      name: "오딘",
      img: "https://edge.ssalmuk.com/editorImage/56ce60fa47784514b73aa0afafbecc99.jpg",
    },
    {
      name: "패스오브엑자일2",
      img: "https://edge.ssalmuk.com/editorImage/26850577efbf4dcd9ae8df48b75d4e7a.jpg",
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden animate-fadeUp delay-1 py-5 px-6">
      <div className="grid grid-cols-4 md:grid-cols-9 gap-2 md:gap-4">
        {tabs.map((tab, i) => {
          const isActive = active === tab.name;
          return (
            <button
              key={i}
              onClick={() => setActive(tab.name)}
              className="flex flex-col items-center gap-2 group min-w-0"
            >
              <div
                className={`w-full aspect-square rounded-[20px] flex items-center justify-center overflow-hidden transition-all border shadow-sm
                  ${isActive ? "bg-[#E8F4FD] border-[#72C2FF] ring-1 ring-[#72C2FF] ring-offset-1" : "bg-[#F8F9FA] border-transparent hover:border-gray-200 hover:bg-white"}
                `}
              >
                {tab.isAll ? (
                  <span
                    className={`text-[14px] font-black ${isActive ? "text-[#72C2FF]" : "text-[#9CA3AF]"}`}
                  >
                    ALL
                  </span>
                ) : (
                  <img
                    src={tab.img}
                    alt={tab.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                )}
              </div>
              <span
                className={`text-[12px] tracking-tight whitespace-nowrap overflow-hidden text-ellipsis w-full text-center
                  ${isActive ? "text-[#4AABF5] font-bold" : "text-[#4B5563] font-medium group-hover:text-[#1A1A2E]"}
                `}
              >
                {tab.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Point Row ──
function PointRow() {
  const actions = [
    { icon: "💰", label: "출금", bg: "#FFF3E0" },
    { icon: "💳", label: "페이충전", bg: "#FFF3E0" },
    { icon: "🎟️", label: "기프티콘", bg: "#FCE4EC" },
    { icon: "📋", label: "사용내역", bg: "#E3F2FD" },
  ];

  return (
    <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden animate-fadeUp delay-2">
      <div className="flex items-center px-7 py-5">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-[38px] h-[38px] rounded-full bg-[#E8F4FD] flex items-center justify-center text-base font-extrabold text-[#4AABF5] shrink-0">
            P
          </div>
          <div>
            <div className="text-2xl font-extrabold text-[#1A1A2E] leading-[1.2]">
              532P
            </div>
            <div className="text-xs text-[#9CA3AF] mt-0.5">
              오늘 획득 가능 포인트{" "}
              <strong className="text-[#FF6B9D] font-bold">187,739P</strong>{" "}
              남음
            </div>
          </div>
        </div>
        <div className="grid grid-cols-4 ml-auto">
          {actions.map((action, i) => (
            <button
              key={i}
              className="flex flex-col items-center gap-1.5 px-6 py-2 rounded-lg hover:bg-[#F5F6F8] transition whitespace-nowrap"
            >
              <div
                className="w-[34px] h-[34px] rounded-lg flex items-center justify-center text-base"
                style={{ background: action.bg }}
              >
                {action.icon}
              </div>
              <span className="text-xs font-semibold text-[#6B7280]">
                {action.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Game Grid (Events/Coupons) ──
function GameGrid({
  title,
  icon,
  items,
  showBadge = false,
  onMore,
  onItemClick,
}: {
  title: string;
  icon: string;
  items: { id?: number; name: string; badge?: string; img?: string }[];
  showBadge?: boolean;
  onMore?: () => void;
  onItemClick?: (item: { id?: number; name: string }) => void;
}) {
  return (
    <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden animate-fadeUp delay-3">
      <SectionHeader title={title} icon={icon} onMore={onMore ?? (() => {})} />
      <div className="p-4 pt-3">
        <div className="grid grid-cols-6 gap-2">
          {items.map((item, i) => (
            <div
              key={i}
              onClick={() => onItemClick?.(item)}
              className="group relative aspect-square rounded-lg overflow-hidden cursor-pointer shadow-sm hover:shadow-md transition-all border border-[#f0f0f0]"
            >
              <img
                src={item.img}
                alt={item.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {showBadge && item.badge && (
                <div className="absolute top-1.5 left-1.5 z-20 bg-[#FF4757] text-white px-1.5 py-0.5 rounded-[4px] text-[9px] font-bold">
                  {item.badge}
                </div>
              )}
              <div
                className="absolute inset-x-0 bottom-0 z-10"
                style={{
                  height: "40%",
                  backgroundColor: "rgba(0, 0, 0, 0.6)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span
                  className="text-white font-bold tracking-tight text-center px-1"
                  style={{ fontSize: "14px" }}
                >
                  {item.name}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Baro Cards Grid ──
function BaroCardsGrid() {
  const cards = [
    {
      icon: "📱",
      title: "앱 접속하면 캐시 바로 지급",
      desc: "하루 딱 접속하고 캐시 선물 받으세요!",
      btn: "앱 접속하면 +300캐시",
      color: "blue",
      img: "https://i.pinimg.com/736x/23/3b/b6/233bb61631fa5249536e7a3ec2547763.jpg",
    },
    {
      icon: "🎮",
      title: "게임 설치하고 포인트 받기",
      desc: "신규 게임 설치하면 포인트 지급!",
      btn: "게임 접속하면 +500포인트",
      color: "orange",
      img: "https://i.pinimg.com/736x/87/df/c4/87dfc46dea930d4cbe28cfe251a02d94.jpg",
    },
    {
      icon: "📅",
      title: "출석체크 이벤트",
      desc: "매일 출석하고 보상 받으세요!",
      btn: "출석체크하면 +100포인트",
      color: "green",
      img: "https://i.pinimg.com/736x/e6/d4/b8/e6d4b83495ac811227e1794c24eb048d.jpg",
    },
  ];
  const colorMap = {
    blue: { bg: "#E3F2FD", text: "#1976D2", hover: "#BBDEFB" },
    orange: { bg: "#FFF3E0", text: "#E65100", hover: "#FFE0B2" },
    green: { bg: "#E8F5E9", text: "#388E3C", hover: "#C8E6C9" },
  };

  return (
    <div className="animate-fadeUp delay-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-bold text-[#1A1A2E] flex items-center gap-2">
          ⚡ 리워드
        </h3>
        <span className="text-[13px] text-[#9CA3AF] cursor-pointer hover:text-[#4AABF5]">
          더보기 →
        </span>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {cards.map((card, i) => {
          const colors = colorMap[card.color as keyof typeof colorMap];
          return (
            <div
              key={i}
              className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-[0_4px_12px_rgba(0,0,0,0.1)]"
            >
              <div className="w-full aspect-video relative">
                <img
                  src={card.img}
                  alt={card.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4 flex flex-col gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className="w-10 h-10 rounded-[10px] flex items-center justify-center text-lg shrink-0"
                    style={{ background: colors.bg }}
                  >
                    {card.icon}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#1A1A2E] mb-1 leading-[1.3]">
                      {card.title}
                    </h4>
                    <p className="text-xs text-[#9CA3AF] leading-[1.4]">
                      {card.desc}
                    </p>
                  </div>
                </div>
                <button
                  className="w-full py-2.5 rounded-lg text-[13px] font-bold transition-colors flex items-center justify-center gap-1.5"
                  style={{ background: colors.bg, color: colors.text }}
                >
                  {card.btn}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Popular Posts ──
function PopularPosts() {
  const navigate = useNavigate();
  const ranked = [...lifetechEvents]
    .sort((a, b) => b.views - a.views)
    .slice(0, 5)
    .map((p, i) => ({ rank: i + 1, id: p.id, title: p.title, category: p.type, comments: p.comments }));

  const getRankStyle = (rank: number) => {
    if (rank === 1) return { bg: "#FFD93D", color: "#8B6914" };
    if (rank === 2) return { bg: "#E5E7EB", color: "#4B5563" };
    if (rank === 3) return { bg: "#FDDCB5", color: "#92400E" };
    return { bg: "#F5F6F8", color: "#9CA3AF" };
  };

  return (
    <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden animate-fadeUp delay-5">
      <SectionHeader title="오늘의 인기 생활테크" icon="🔥" onMore={() => navigate("/lifetech")} />
      <div className="px-5 pb-5 pt-4 flex flex-col">
        {ranked.map((post) => {
          const style = getRankStyle(post.rank);
          return (
            <div
              key={post.rank}
              onClick={() => navigate(`/lifetech/event/${post.id}`)}
              className="flex items-center gap-3.5 py-3 border-b border-[#F3F4F6] last:border-none cursor-pointer hover:bg-[#FAFBFC] hover:mx-[-20px] hover:px-5 transition-colors"
            >
              <span
                className="w-7 h-7 rounded-lg flex items-center justify-center text-[13px] font-extrabold shrink-0"
                style={{ background: style.bg, color: style.color }}
              >
                {String(post.rank).padStart(2, "0")}
              </span>
              <span className="flex-1 text-sm font-medium text-[#1A1A2E] whitespace-nowrap overflow-hidden text-ellipsis">
                {post.title}
              </span>
              <span className="text-[11px] text-[#9CA3AF] shrink-0">{post.category}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Hot Topic Section ──
function HotTopicSection() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("베스트");
  const tabs = ["🏆 인증", "베스트", "인기글"];

  const toItem = (p: (typeof initialPosts)[0]) => {
    const img = Array.isArray(p.images) ? p.images[0] : undefined;
    const diff = Date.now() - (p.createdAt ?? Date.now());
    const mins = Math.floor(diff / 60000);
    const time = mins < 60 ? `${mins}분 전` : `${Math.floor(mins / 60)}시간 전`;
    return { id: p.id, title: p.title, comments: p.comments, category: p.boardId, time, img };
  };

  const dataMap: Record<string, ReturnType<typeof toItem>[]> = {
    "🏆 인증": [...initialPosts]
      .filter((p) => p.isVerified)
      .sort((a, b) => b.likes - a.likes)
      .slice(0, 5)
      .map(toItem),
    베스트: [...initialPosts]
      .sort((a, b) => (b.likes + b.comments) - (a.likes + a.comments))
      .slice(0, 5)
      .map(toItem),
    인기글: [...initialPosts]
      .sort((a, b) => b.views - a.views)
      .slice(0, 5)
      .map(toItem),
  };

  const currentItems = dataMap[activeTab];

  return (
    <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden animate-fadeUp delay-6">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 text-[17px] font-bold text-[#1A1A2E]">
            <span className="text-xl">🔥</span> 지금핫한
          </div>
          <div className="flex items-center gap-1.5">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3.5 py-1.5 rounded-full text-[13px] font-bold transition-all ${
                  tab === activeTab
                    ? "bg-[#72C2FF] text-white shadow-sm" // 선택된 탭 (테마색)
                    : "text-[#6B7280] hover:bg-[#E8F4FD] hover:text-[#4AABF5]" // 선택 안 된 탭
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
        <span onClick={() => navigate("/gallery")} className="text-[13px] text-[#9CA3AF] cursor-pointer hover:text-[#4AABF5] transition-colors">
          더보기 →
        </span>
      </div>

      {/* List - key 값을 activeTab으로 주어 탭을 변경할 때마다 리스트가 새로 나타나는 애니메이션 적용 */}
      <div key={activeTab} className="flex flex-col animate-fadeUp">
        {currentItems.map((item, i) => (
          <div
            key={i}
            onClick={() => navigate(`/gallery?post=${item.id}`)}
            className="flex items-center gap-4 px-5 py-3.5 border-b border-[#E5E7EB] last:border-none cursor-pointer hover:bg-[#FAFBFC] transition-colors group"
          >
            {/* Image Thumbnail */}
            <div className="w-[76px] h-[52px] rounded-lg overflow-hidden shrink-0 border border-gray-100 relative bg-[#F5F6F8] flex items-center justify-center">
              {item.img ? (
                <img
                  src={item.img}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              ) : (
                <div className="flex flex-col items-center gap-0.5">
                  <svg className="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="text-[9px] text-gray-300">이미지 없음</span>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0 flex flex-col justify-center gap-1">
              <div className="text-[14px] text-[#1A1A2E] font-medium whitespace-nowrap overflow-hidden text-ellipsis leading-tight">
                {item.title}{" "}
                <span className="text-[#4AABF5] font-bold ml-1 text-[13px]">
                  [{item.comments}]
                </span>
              </div>
              <div className="flex items-center gap-2 text-[12px] text-[#9CA3AF]">
                <span className="text-[#6B7280]">{item.category}</span>
                <span className="text-[#D1D5DB]">|</span>
                <span>{item.time}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Sidebar: Event Promo Banner ──
function EventPromoBanner() {
  return (
    <div className="rounded-xl overflow-hidden cursor-pointer transition-transform hover:-translate-y-0.5 relative animate-fadeUp delay-1 shadow-sm">
      <img
        src="https://i.pinimg.com/736x/3f/4b/99/3f4b99818ca444236c549c2ef8cd87de.jpg"
        alt="이벤트 배너"
        className="w-100 h-120"
      />
    </div>
  );
}

// ── Sidebar: Game Ranking ──
function GameRanking() {
  const [activeTab, setActiveTab] = useState("모바일");
  const tabs = ["모바일", "PC", "P2E"];
  const rankings = [
    { rank: 1, name: "버츄얼 스나", change: null },
    { rank: 2, name: "한국사능력검정시험", change: 2, up: true },
    { rank: 3, name: "숲인방", change: 2, up: true },
    { rank: 4, name: "숲 인터넷방송", change: 2, up: false },
    { rank: 5, name: "숲 롤대남", change: 2, up: false },
    { rank: 6, name: "국내 하꼬 버츄얼", change: 6, up: true },
    { rank: 7, name: "숲 스트리밍", change: 1, up: false },
    { rank: 8, name: "이세계아이돌", change: null },
    { rank: 9, name: "숲 음악방송", change: 2, up: true },
    { rank: 10, name: "공무원 공부", change: 1, up: false },
  ];
  const getRankStyle = (rank: number) => {
    if (rank === 1) return "bg-[#4A5BC7] text-white";
    if (rank === 2) return "bg-[#5B6AD4] text-white";
    if (rank === 3) return "bg-[#7080DE] text-white";
    return "bg-[#F5F6F8] text-[#9CA3AF]";
  };

  return (
    <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden animate-fadeUp delay-3">
      <div className="flex items-center gap-0 px-[18px] py-4 border-b border-[#E5E7EB]">
        <h3 className="text-base font-extrabold text-[#1A1A2E] mr-4">
          게임순위
        </h3>
        <div className="flex gap-0">
          {tabs.map((tab, i) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1 text-[13px] font-semibold relative transition-colors ${activeTab === tab ? "text-[#1A1A2E] font-bold" : "text-[#9CA3AF]"}`}
            >
              {tab}
              {i < tabs.length - 1 && (
                <span className="absolute right-0 top-[20%] h-[60%] w-px bg-[#E5E7EB]" />
              )}
            </button>
          ))}
        </div>
      </div>
      <div className="flex flex-col px-[18px] py-1 pb-3">
        {rankings.map((item) => (
          <div
            key={item.rank}
            className="flex items-center py-2.5 border-b border-[#F5F6F8] last:border-none cursor-pointer hover:bg-[#FAFBFC] hover:mx-[-18px] hover:px-[18px] transition-colors"
          >
            <span
              className={`w-[26px] h-[26px] rounded-md flex items-center justify-center text-xs font-extrabold shrink-0 mr-3 ${getRankStyle(item.rank)}`}
            >
              {item.rank}
            </span>
            <span className="flex-1 text-sm font-medium text-[#1A1A2E] whitespace-nowrap overflow-hidden text-ellipsis">
              {item.name}
            </span>
            <span
              className={`flex items-center gap-0.5 text-xs font-semibold shrink-0 min-w-8 justify-end ${item.change === null ? "text-[#9CA3AF]" : item.up ? "text-[#DC2626]" : "text-[#2563EB]"}`}
            >
              {item.change === null ? (
                "-"
              ) : (
                <>
                  <span className="text-[10px]">{item.up ? "▲" : "▼"}</span>
                  {item.change}
                </>
              )}
            </span>
          </div>
        ))}
      </div>
      <div className="px-[18px] py-2.5 pb-3.5 text-right">
        <a
          href="#"
          className="text-[13px] font-semibold text-[#4AABF5] hover:opacity-70 transition-opacity"
        >
          11위 - 20위 →
        </a>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════
// MAIN HOME COMPONENT
// ══════════════════════════════════════════════
export default function WebHome_v2() {
  const navigate = useNavigate();
  const gameEvents = [
    {
      name: "로스트아크",
      img: "https://edge.ssalmuk.com/editorImage/3e9c8d4f13e64add96357bd7b4ebe62a.jpg",
    },
    {
      name: "던전앤파이터",
      img: "https://edge.ssalmuk.com/editorImage/d8353df7a9834da9984f550f57af6307.jpg",
    },
    {
      name: "마비노기",
      img: "https://edge.ssalmuk.com/editorImage/2dddbb8a45b348fc9740d8b2157c6999.jpg",
    },
    {
      name: "패스오브엑자일2",
      img: "https://edge.ssalmuk.com/editorImage/26850577efbf4dcd9ae8df48b75d4e7a.jpg",
    },
    {
      name: "로드나인",
      img: "https://edge.ssalmuk.com/editorImage/145ef9589b8047169888e2f0c232b3d4.jpg",
    },
    {
      name: "리니지M",
      img: "https://edge.ssalmuk.com/editorImage/f85655d36efc44aaaf692cbef435271d.jpg",
    },
  ];

  const gameCoupons = coupons
    .filter((c) => c.discountItems && c.discountItems.length > 0)
    .slice(0, 6)
    .map((c) => {
      const maxDiscount = Math.max(...c.discountItems!.map((d) => d.discount));
      return { id: c.id, name: c.name, img: c.image, badge: `-${maxDiscount}%` };
    });

  return (
    <div
      className="min-h-screen"
      style={{
        fontFamily:
          "'Pretendard Variable', -apple-system, BlinkMacSystemFont, sans-serif",
        background: "#F5F6F8",
        WebkitFontSmoothing: "antialiased",
      }}
    >
      <LeftFloatingBanner />
      {/* <RightSideIcons /> */}

      <div className="max-w-[1280px] mx-auto grid grid-cols-[1fr_280px] gap-6 p-6">
        {/* ═══ Main Content ═══ */}
        <main className="flex flex-col gap-6">
          <BannerSlider />
          <GalleryTabs />
          <PointRow />
          <GameGrid title="게임 이벤트" icon="🎮" items={gameEvents} />
          <GameGrid
            title="게임 쿠폰"
            icon="🎟️"
            items={gameCoupons}
            showBadge
            onMore={() => navigate("/coupon")}
            onItemClick={(item) => navigate("/coupon", { state: { couponId: item.id } })}
          />
          <BaroCardsGrid />
          <PopularPosts />

          {/* 👇 사이드바에서 메인 영역으로 넘어온 지금핫한 섹션 */}
          <HotTopicSection />
        </main>

        {/* ═══ Sidebar ═══ */}
        <aside className="flex flex-col gap-5">
          <EventPromoBanner />
          {/* 사이드바에 있던 HotTopicSection 제거됨 */}
          <GameRanking />
        </aside>
      </div>
    </div>
  );
}
