// @ts-nocheck
import { useState, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  events as eventsData,
  getStatusBadge,
  getTypeBadge,
} from "../../components/lifetech/data";
import LikeDislikeButton from "../../components/gallery/LikeDislikeButton";
import GiftPopup from "../../components/gallery/GiftPopup";
import CommentSection from "../../components/gallery/CommentSection";
import { ToastProvider, useToast } from "../../components/gallery/Toast";
import DropdownMenu from "../../components/gallery/DropdownMenu";
import { FollowButton } from "../../components/gallery/FollowButton";
import ConfirmPopup from "../../components/gallery/ConfirmPopup";
import ReportPopup from "../../components/gallery/ReportPopup";
import type { Comment, ReplyTarget } from "../../components/gallery/types";

// ─── 더미 댓글 데이터 ───
const dummyComments: Comment[] = [
  {
    id: 1,
    author: "이벤트헌터",
    avatar: "🎯",
    avatarBg: "#FEF3C7",
    content: "좋은 이벤트 공유 감사해요!",
    time: "10분 전",
    likes: 8,
    dislikes: 2,
    isBest: true,
    replies: [
      {
        id: 101,
        author: "쌀먹왕",
        avatar: "🍚",
        avatarBg: "#DBEAFE",
        content: "저도 응모했어요 ㅎㅎ",
        time: "5분 전",
        likes: 2,
        dislikes: 0,
        replyTo: "이벤트헌터",
        replies: [
          {
            id: 102,
            author: "럭키걸",
            avatar: "🍀",
            avatarBg: "#D1FAE5",
            content: "저도 같이 응모했어요!",
            time: "3분 전",
            likes: 1,
            dislikes: 0,
            replyTo: "쌀먹왕",
            replies: [
              {
                id: 103,
                author: "쌀먹왕",
                avatar: "🍚",
                avatarBg: "#DBEAFE",
                content: "같이 당첨되면 좋겠네요 ㅎㅎ",
                time: "2분 전",
                likes: 3,
                dislikes: 0,
                replyTo: "럭키걸",
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 2,
    author: "혜택모으기",
    avatar: "💰",
    avatarBg: "#D1FAE5",
    content: "당첨되면 알려주세요!",
    time: "30분 전",
    likes: 5,
    dislikes: 1,
    isBest: true,
  },
  {
    id: 3,
    author: "럭키보이",
    avatar: "🍀",
    avatarBg: "#E0E7FF",
    content: "응모 완료! 이번엔 당첨되길...",
    time: "1시간 전",
    likes: 3,
    dislikes: 0,
  },
  {
    id: 4,
    author: "경품사냥꾼",
    avatar: "🎁",
    avatarBg: "#FCE7F3",
    content: "이 이벤트 진짜 좋네요 공유합니다",
    time: "2시간 전",
    likes: 12,
    dislikes: 1,
    isBest: true,
    replies: [
      {
        id: 401,
        author: "새내기",
        avatar: "🌱",
        avatarBg: "#D9F99D",
        content: "어떻게 참여하나요?",
        time: "1시간 전",
        likes: 1,
        dislikes: 0,
        replyTo: "경품사냥꾼",
        replies: [
          {
            id: 402,
            author: "경품사냥꾼",
            avatar: "🎁",
            avatarBg: "#FCE7F3",
            content: "인스타 팔로우하고 댓글 달면 돼요!",
            time: "50분 전",
            likes: 3,
            dislikes: 0,
            replyTo: "새내기",
            replies: [
              {
                id: 403,
                author: "새내기",
                avatar: "🌱",
                avatarBg: "#D9F99D",
                content: "감사합니다! 바로 해볼게요",
                time: "45분 전",
                likes: 2,
                dislikes: 0,
                replyTo: "경품사냥꾼",
                replies: [
                  {
                    id: 404,
                    author: "경품사냥꾼",
                    avatar: "🎁",
                    avatarBg: "#FCE7F3",
                    content: "화이팅! 당첨되면 인증샷 올려주세요 ㅎㅎ",
                    time: "40분 전",
                    likes: 5,
                    dislikes: 0,
                    replyTo: "새내기",
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
];

// ─── 사이드바 ───
function Sidebar({ event }: { event: any }) {
  const relatedEvents = eventsData.filter((e) => e.id !== event.id).slice(0, 4);
  const badge = getStatusBadge(event.status, event.dday);

  return (
    <div className="flex flex-col gap-5">
      {/* 경품 & 참여 카드 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
        <div className="bg-gradient-to-r from-[#72C2FF] to-[#5BA8E6] p-5 text-white">
          <p className="text-sm opacity-80 mb-1">경품</p>
          <p className="text-2xl font-bold">{event.prize}</p>
          <div className="flex items-center gap-3 mt-3 text-sm opacity-90">
            <span>당첨 {event.winners}명</span>
            <span>·</span>
            <span
              className={event.dday <= 3 ? "text-yellow-200 font-bold" : ""}
            >
              {event.dday === 0 ? "오늘 마감" : `D-${event.dday}`}
            </span>
          </div>
        </div>
        <div className="p-4">
          <button className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-bold hover:bg-[#5BA8E6] transition-colors">
            이벤트 참여하기
          </button>
        </div>
      </div>

      {/* 관련 이벤트 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp delay-1">
        <div className="px-4 py-3 text-sm font-bold text-gray-900 border-b border-gray-100">
          관련 이벤트
        </div>
        <div className="divide-y divide-gray-50">
          {relatedEvents.map((e) => {
            const b = getStatusBadge(e.status, e.dday);
            return (
              <Link
                key={e.id}
                to={`/lifetech/event/${e.id}`}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg flex items-center justify-center text-lg">
                  🎁
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {e.title}
                  </p>
                  <p className="text-xs text-gray-500">{e.prize}</p>
                </div>
                <span
                  className={`text-xs font-medium px-2 py-0.5 rounded-full ${b.color}`}
                >
                  {b.text}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── 메인 페이지 (Content) ───
function EventDetailContent() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const event = eventsData.find((e) => e.id === Number(id));

  // 좋아요/싫어요 상태
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [showGift, setShowGift] = useState(false);
  const [isAuthorFollowed, setIsAuthorFollowed] = useState(false);
  const [showBlockPopup, setShowBlockPopup] = useState(false);
  const [showReportPopup, setShowReportPopup] = useState(false);

  // 댓글 관련 상태 (CommentSection용)
  const [comments, setComments] = useState<Comment[]>(dummyComments);
  const [commentInput, setCommentInput] = useState("");
  const [replyingTo, setReplyingTo] = useState<ReplyTarget | null>(null);
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: string }>({});
  const [likedComments, setLikedComments] = useState<string[]>([]);
  const [dislikedComments, setDislikedComments] = useState<string[]>([]);
  const [followedUsers, setFollowedUsers] = useState<string[]>([]);
  const [highlightedComment, setHighlightedComment] = useState<string | null>(
    null,
  );
  const commentRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  if (!event) {
    return (
      <div className="max-w-[1280px] mx-auto px-6 py-20 text-center">
        <p className="text-gray-500">이벤트를 찾을 수 없습니다.</p>
        <button
          onClick={() => navigate("/lifetech")}
          className="mt-4 text-[#72C2FF] hover:underline"
        >
          목록으로 돌아가기
        </button>
      </div>
    );
  }

  const badge = getStatusBadge(event.status, event.dday);

  // 댓글 총 개수 (대댓글 포함)
  const countComments = (cmts: Comment[]): number => {
    return cmts.reduce((acc, c) => acc + 1 + (c.replies?.length || 0), 0);
  };

  // 댓글 핸들러들
  const handleCommentInputChange = (value: string) => setCommentInput(value);

  const handleSubmitComment = () => {
    if (!commentInput.trim()) return;
    const newComment: Comment = {
      id: Date.now(),
      author: "나",
      avatar: "🍚",
      avatarBg: "#E8F4FD",
      content: commentInput,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
    };
    setComments([newComment, ...comments]);
    setCommentInput("");
  };

  const handleCommentLike = (key: string) => {
    if (likedComments.includes(key)) {
      setLikedComments(likedComments.filter((k) => k !== key));
    } else {
      setLikedComments([...likedComments, key]);
      setDislikedComments(dislikedComments.filter((k) => k !== key));
    }
  };

  const handleCommentDislike = (key: string) => {
    if (dislikedComments.includes(key)) {
      setDislikedComments(dislikedComments.filter((k) => k !== key));
    } else {
      setDislikedComments([...dislikedComments, key]);
      setLikedComments(likedComments.filter((k) => k !== key));
    }
  };

  const handleCommentGift = () => {
    setShowGift(true);
  };

  const handleFollow = (name: string) => {
    if (followedUsers.includes(name)) {
      setFollowedUsers(followedUsers.filter((n) => n !== name));
    } else {
      setFollowedUsers([...followedUsers, name]);
    }
  };

  const handleStartReply = (key: string, author: string) => {
    setReplyingTo({ key, author });
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
  };

  const handleReplyInputChange = (key: string, value: string) => {
    setReplyInputs({ ...replyInputs, [key]: value });
  };

  const handleSubmitReply = (commentId: number) => {
    if (!replyingTo) return;
    const replyText = replyInputs[replyingTo.key];
    if (!replyText?.trim()) return;

    const newReply = {
      id: Date.now(),
      author: "나",
      avatar: "🍚",
      avatarBg: "#E8F4FD",
      content: replyText,
      time: "방금 전",
      likes: 0,
      dislikes: 0,
      replyTo: replyingTo.author,
    };

    setComments(
      comments.map((c) => {
        if (c.id === commentId) {
          return { ...c, replies: [...(c.replies || []), newReply] };
        }
        return c;
      }),
    );

    setReplyInputs({ ...replyInputs, [replyingTo.key]: "" });
    setReplyingTo(null);
  };

  const handleScrollToComment = (commentId: number) => {
    const key = `${event.id}-${commentId}`;
    const el = commentRefs.current[key];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      setHighlightedComment(key);
      setTimeout(() => setHighlightedComment(null), 2000);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-6 py-8">
      {/* 브레드크럼 */}
      <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6 animate-fadeUp">
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          생활테크
        </Link>
        <span>›</span>
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          이벤트
        </Link>
        <span>›</span>
        <span className="text-gray-600 truncate max-w-[200px]">
          {event.title}
        </span>
      </nav>

      {/* 2컬럼 레이아웃 */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        {/* 메인 콘텐츠 */}
        <div className="space-y-6">
          {/* 메인 카드 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
            {/* 작성자 정보 */}
            <div className="p-5 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-lg">🦎</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      저렴가를찾는용가리
                    </p>
                    <p className="text-xs text-gray-500">
                      1시간 전 · 팔로워 192
                    </p>
                  </div>
                </div>
                <FollowButton
                  name="저렴가를찾는용가리"
                  isFollowed={isAuthorFollowed}
                  onFollow={() => setIsAuthorFollowed(!isAuthorFollowed)}
                />
              </div>
            </div>

            {/* 태그 & 제목 */}
            <div className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <span
                  className={`text-xs font-medium px-2.5 py-1 rounded-full ${getTypeBadge(event.type)}`}
                >
                  {event.type}
                </span>
                <span
                  className={`text-xs font-medium text-white px-2.5 py-1 rounded-full ${badge.color}`}
                >
                  {badge.text}
                </span>
                {event.hot && (
                  <span className="text-xs font-medium text-red-500 bg-red-50 px-2.5 py-1 rounded-full">
                    🔥 HOT
                  </span>
                )}
              </div>
              <h1 className="text-xl font-bold text-gray-900 mb-4">
                {event.title}
              </h1>

              {/* 본문 */}
              <p className="text-gray-700 leading-relaxed mb-5">
                2월 카드 이벤트로 최대 80만원 병오년 용돈 받아요. 간단한 참여로
                푸짐한 경품을 받아가세요!
              </p>

              {/* 액션바 */}
              <div className="flex items-center justify-between py-4 border-y border-gray-100">
                <div className="flex items-center gap-4">
                  <LikeDislikeButton
                    likes={event.likes}
                    isLiked={isLiked}
                    isDisliked={isDisliked}
                    onLike={() => {
                      setIsLiked(!isLiked);
                      if (isDisliked) setIsDisliked(false);
                    }}
                    onDislike={() => {
                      setIsDisliked(!isDisliked);
                      if (isLiked) setIsLiked(false);
                    }}
                    size="md"
                  />
                  <span className="flex items-center gap-1.5 text-gray-500">
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      />
                    </svg>
                    <span className="text-sm">{countComments(comments)}</span>
                  </span>
                  <span className="flex items-center gap-1.5 text-gray-500">
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                      />
                    </svg>
                    <span className="text-sm">{event.views || 0}</span>
                  </span>
                  <button
                    onClick={() => setShowGift(true)}
                    className="text-gray-500 hover:text-amber-500 transition-colors"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
                      />
                    </svg>
                  </button>
                </div>
                {/* 더보기 메뉴 */}
                <DropdownMenu
                  items={[
                    {
                      icon: "share",
                      label: "공유",
                      onClick: () => {
                        navigator.clipboard.writeText(window.location.href);
                        showToast("링크를 복사했어요", { type: "link" });
                      },
                    },
                    {
                      icon: "bookmark",
                      label: "응모함 저장",
                      onClick: () => {
                        showToast("응모함에 저장했어요");
                      },
                    },
                    {
                      icon: "block",
                      label: "차단",
                      onClick: () => {
                        setShowBlockPopup(true);
                      },
                    },
                    {
                      icon: "report",
                      label: "신고",
                      onClick: () => {
                        setShowReportPopup(true);
                      },
                    },
                  ]}
                  size="lg"
                />
              </div>
            </div>
          </div>

          {/* 이벤트 정보 테이블 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp delay-1">
            <table className="w-full text-sm">
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 w-32 font-medium">
                    주최사
                  </td>
                  <td className="px-5 py-4 text-gray-900 flex items-center gap-2">
                    <span className="w-6 h-6 bg-blue-100 rounded flex items-center justify-center text-xs">
                      🏢
                    </span>
                    {event.host}
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    응모기간
                  </td>
                  <td className="px-5 py-4 text-gray-900">
                    {event.period || "2025.02.01 ~ 2025.02.28"}
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    응모형태
                  </td>
                  <td className="px-5 py-4 text-gray-900">{event.type}</td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    당첨자 발표
                  </td>
                  <td className="px-5 py-4 text-gray-900">
                    {event.announceDate || "2025.03.05"}
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    총 당첨자
                  </td>
                  <td className="px-5 py-4 text-gray-900">{event.winners}명</td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    경품
                  </td>
                  <td className="px-5 py-4 text-[#72C2FF] font-bold">
                    {event.prize}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* 모바일 참여 버튼 */}
          <div className="lg:hidden">
            <button className="w-full py-4 bg-[#72C2FF] text-white rounded-xl font-bold hover:bg-[#5BA8E6] transition-colors text-lg">
              이벤트 참여하기
            </button>
          </div>

          {/* 댓글 섹션 - CommentSection 재사용 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 animate-fadeUp delay-3">
            <h3 className="text-base font-bold text-gray-900 mb-2">
              댓글{" "}
              <span className="text-[#72C2FF]">{countComments(comments)}</span>
            </h3>

            <CommentSection
              postId={event.id}
              comments={comments}
              commentInput={commentInput}
              replyingTo={replyingTo}
              replyInputs={replyInputs}
              likedComments={likedComments}
              dislikedComments={dislikedComments}
              followedUsers={followedUsers}
              highlightedComment={highlightedComment}
              commentRefs={commentRefs}
              onCommentInputChange={handleCommentInputChange}
              onSubmitComment={handleSubmitComment}
              onCommentLike={handleCommentLike}
              onCommentDislike={handleCommentDislike}
              onCommentGift={handleCommentGift}
              onFollow={handleFollow}
              onStartReply={handleStartReply}
              onCancelReply={handleCancelReply}
              onReplyInputChange={handleReplyInputChange}
              onSubmitReply={handleSubmitReply}
              onScrollToComment={handleScrollToComment}
            />
          </div>
        </div>

        {/* 사이드바 (데스크탑) */}
        <div className="hidden lg:block">
          <div className="sticky top-[80px]">
            <Sidebar event={event} />
          </div>
        </div>
      </div>

      {/* 후원 팝업 */}
      {showGift && <GiftPopup onClose={() => setShowGift(false)} />}

      {/* 차단 팝업 */}
      {showBlockPopup && (
        <ConfirmPopup
          title="이 작성자를 차단할까요?"
          description="차단하면 이 작성자의 글과 댓글이 더 이상 보이지 않아요."
          confirmText="차단"
          cancelText="취소"
          isDestructive
          onConfirm={() => {
            setShowBlockPopup(false);
            showToast("저렴가를찾는용가리님을 차단했어요", { type: "block" });
          }}
          onCancel={() => setShowBlockPopup(false)}
        />
      )}

      {/* 신고 팝업 */}
      {showReportPopup && (
        <ReportPopup
          targetType="글"
          onReport={(reason) => {
            setShowReportPopup(false);
            showToast("신고가 접수되었습니다");
          }}
          onCancel={() => setShowReportPopup(false)}
        />
      )}
    </div>
  );
}

// ─── Wrapper (ToastProvider) ───
export default function EventDetailPage() {
  return (
    <ToastProvider>
      <EventDetailContent />
    </ToastProvider>
  );
}
