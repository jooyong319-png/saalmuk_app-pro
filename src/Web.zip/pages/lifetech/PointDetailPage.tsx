// @ts-nocheck
import { useState, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { pointSources as pointSourcesData } from "../../components/lifetech/data";
import LikeDislikeButton from "../../components/gallery/LikeDislikeButton";
import GiftPopup from "../../components/gallery/GiftPopup";
import CommentSection from "../../components/gallery/CommentSection";
import { ToastProvider, useToast } from "../../components/gallery/Toast";
import DropdownMenu from "../../components/gallery/DropdownMenu";
import { FollowButton } from "../../components/gallery/FollowButton";
import ConfirmPopup from "../../components/gallery/ConfirmPopup";
import ReportPopup from "../../components/gallery/ReportPopup";
import type { Comment, ReplyTarget } from "../../components/gallery/types";

// ─── 더미 댓글 데이터 ───
const dummyComments: Comment[] = [
  {
    id: 1,
    author: "앱테크고수",
    avatar: "🔥",
    avatarBg: "#FEF3C7",
    content: "이거 진짜 좋아요! 매일 출첵하고 있습니다",
    time: "15분 전",
    likes: 12,
    dislikes: 1,
    isBest: true,
    replies: [
      {
        id: 101,
        author: "포인트러버",
        avatar: "💰",
        avatarBg: "#D1FAE5",
        content: "저도요! 꾸준히 하면 쏠쏠해요",
        time: "10분 전",
        likes: 5,
        dislikes: 0,
        replyTo: "앱테크고수",
        replies: [
          {
            id: 102,
            author: "앱테크고수",
            avatar: "🔥",
            avatarBg: "#FEF3C7",
            content: "맞아요 한달이면 만원 이상 모여요",
            time: "8분 전",
            likes: 3,
            dislikes: 0,
            replyTo: "포인트러버",
            replies: [
              {
                id: 103,
                author: "뉴비어",
                avatar: "🌱",
                avatarBg: "#DBEAFE",
                content: "저도 시작해봐야겠네요!",
                time: "5분 전",
                likes: 2,
                dislikes: 0,
                replyTo: "앱테크고수",
                replies: [
                  {
                    id: 104,
                    author: "포인트러버",
                    avatar: "💰",
                    avatarBg: "#D1FAE5",
                    content: "환영해요! 화이팅 ㅎㅎ",
                    time: "3분 전",
                    likes: 1,
                    dislikes: 0,
                    replyTo: "뉴비어",
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 2,
    author: "초보적립러",
    avatar: "🌱",
    avatarBg: "#DBEAFE",
    content: "처음 해봤는데 생각보다 쉽네요",
    time: "1시간 전",
    likes: 8,
    dislikes: 0,
    isBest: true,
  },
  {
    id: 3,
    author: "현금화장인",
    avatar: "💸",
    avatarBg: "#E0E7FF",
    content: "출금도 빠르고 좋습니다 👍",
    time: "2시간 전",
    likes: 4,
    dislikes: 0,
  },
];

// ─── 사이드바 ───
function Sidebar({
  source,
  brand,
  status,
}: {
  source: any;
  brand: string;
  status: string;
}) {
  const similarSources = pointSourcesData
    .filter((s) => s.id !== source.id && s.category === source.category)
    .slice(0, 4);

  return (
    <div className="flex flex-col gap-5">
      {/* 리워드 카드 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
        <div className="bg-gradient-to-r from-amber-400 to-orange-400 p-5 text-white">
          <p className="text-sm opacity-80 mb-1">예상 리워드</p>
          <p className="text-2xl font-bold">{source.reward}</p>
          <div className="flex items-center gap-3 mt-3 text-sm opacity-90">
            <span className="flex items-center gap-1">
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              {source.category}
            </span>
            {brand && (
              <>
                <span>·</span>
                <span>{brand}</span>
              </>
            )}
          </div>
        </div>
        <div className="p-4 space-y-3">
          <button
            onClick={() => window.open("#", "_blank")}
            className={`w-full py-3.5 rounded-xl font-bold transition-colors ${
              status === "ended"
                ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                : "bg-amber-400 text-white hover:bg-amber-500"
            }`}
            disabled={status === "ended"}
          >
            {status === "ended" ? "마감됨" : "참여하기"}
          </button>
        </div>
      </div>

      {/* 비슷한 앱테크 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 animate-fadeUp delay-1">
        <h4 className="font-bold text-gray-900 mb-4">비슷한 앱테크</h4>
        <div className="space-y-3">
          {similarSources.map((item) => (
            <Link
              key={item.id}
              to={`/lifetech/point/${item.id}`}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center">
                💰
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate group-hover:text-amber-500 transition-colors">
                  {item.title}
                </p>
                <p className="text-xs text-amber-500 font-medium">
                  {item.reward}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── 메인 컨텐츠 ───
function PointDetailContent() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [showGift, setShowGift] = useState(false);
  const [status, setStatus] = useState<string>("active");
  const [isAuthorFollowed, setIsAuthorFollowed] = useState(false);
  const [showBlockPopup, setShowBlockPopup] = useState(false);
  const [showReportPopup, setShowReportPopup] = useState(false);

  // CommentSection용 state
  const [comments, setComments] = useState<Comment[]>(dummyComments);
  const [commentInput, setCommentInput] = useState("");
  const [replyingTo, setReplyingTo] = useState<ReplyTarget | null>(null);
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: string }>({});
  const [likedComments, setLikedComments] = useState<string[]>([]);
  const [dislikedComments, setDislikedComments] = useState<string[]>([]);
  const [followedUsers, setFollowedUsers] = useState<string[]>([]);
  const [highlightedComment, setHighlightedComment] = useState<string | null>(
    null,
  );
  const commentRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  const source = pointSourcesData.find((s) => s.id === Number(id));
  const postId = Number(id);

  if (!source) {
    return (
      <div className="max-w-[1280px] mx-auto px-6 py-20 text-center">
        <p className="text-gray-500">포인트 정보를 찾을 수 없습니다.</p>
        <button
          onClick={() => navigate("/lifetech")}
          className="mt-4 text-[#72C2FF] hover:underline"
        >
          목록으로 돌아가기
        </button>
      </div>
    );
  }

  // 브랜드 추출
  const brandMatch = source.title.match(/^\[([^\]]+)\]/);
  const brand = brandMatch ? brandMatch[1] : "";
  const titleRest = source.title.replace(/^\[[^\]]+\]\s*/, "");

  const countComments = (cmts: Comment[]): number =>
    cmts.reduce((acc, c) => acc + 1 + countComments(c.replies || []), 0);

  // CommentSection handlers
  const handleCommentInputChange = (value: string) => setCommentInput(value);

  const handleSubmitComment = () => {
    if (!commentInput.trim()) return;
    const newComment: Comment = {
      id: Date.now(),
      author: "나",
      avatar: "😊",
      avatarBg: "#E0E7FF",
      content: commentInput,
      time: "방금",
      likes: 0,
      dislikes: 0,
    };
    setComments([newComment, ...comments]);
    setCommentInput("");
  };

  const handleCommentLike = (key: string) => {
    if (likedComments.includes(key)) {
      setLikedComments(likedComments.filter((k) => k !== key));
    } else {
      setLikedComments([...likedComments, key]);
      setDislikedComments(dislikedComments.filter((k) => k !== key));
    }
  };

  const handleCommentDislike = (key: string) => {
    if (dislikedComments.includes(key)) {
      setDislikedComments(dislikedComments.filter((k) => k !== key));
    } else {
      setDislikedComments([...dislikedComments, key]);
      setLikedComments(likedComments.filter((k) => k !== key));
    }
  };

  const handleCommentGift = (key: string) => setShowGift(true);

  const handleFollow = (name: string) => {
    if (followedUsers.includes(name)) {
      setFollowedUsers(followedUsers.filter((n) => n !== name));
    } else {
      setFollowedUsers([...followedUsers, name]);
    }
  };

  const handleStartReply = (key: string, author: string) => {
    setReplyingTo({ key, author });
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
    setReplyInputs({});
  };

  const handleReplyInputChange = (key: string, value: string) => {
    setReplyInputs({ ...replyInputs, [key]: value });
  };

  const handleSubmitReply = (commentId: number) => {
    const key = `${postId}-${commentId}`;
    const replyText = replyInputs[key];
    if (!replyText?.trim()) return;

    const newReply = {
      id: Date.now(),
      author: "나",
      avatar: "😊",
      avatarBg: "#E0E7FF",
      content: replyText,
      time: "방금",
      likes: 0,
      dislikes: 0,
      replyTo: replyingTo?.author,
    };

    setComments(
      comments.map((c) =>
        c.id === commentId
          ? { ...c, replies: [...(c.replies || []), newReply] }
          : c,
      ),
    );
    setReplyInputs({});
    setReplyingTo(null);
  };

  const handleScrollToComment = (commentId: number) => {
    const key = `${postId}-${commentId}`;
    const ref = commentRefs.current[key];
    if (ref) {
      ref.scrollIntoView({ behavior: "smooth", block: "center" });
      setHighlightedComment(key);
      setTimeout(() => setHighlightedComment(null), 2000);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-6 py-8">
      {/* 브레드크럼 */}
      <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6 animate-fadeUp">
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          생활테크
        </Link>
        <span>›</span>
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          앱테크
        </Link>
        <span>›</span>
        <span className="text-gray-600 truncate max-w-[200px]">
          {titleRest}
        </span>
      </nav>

      {/* 2컬럼 레이아웃 */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        {/* 메인 콘텐츠 */}
        <div className="space-y-6">
          {/* 메인 카드 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
            {/* 작성자 정보 */}
            <div className="p-5 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-gradient-to-br from-amber-400 to-orange-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-lg">🔥</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">앱테크마스터</p>
                    <p className="text-xs text-gray-500">
                      {source.createdAt || "2시간 전"} · 팔로워 324
                    </p>
                  </div>
                </div>
                <FollowButton
                  name="앱테크마스터"
                  isFollowed={isAuthorFollowed}
                  onFollow={() => setIsAuthorFollowed(!isAuthorFollowed)}
                />
              </div>
            </div>

            {/* 태그 & 제목 */}
            <div className="p-5">
              <div className="flex items-center gap-2 mb-3">
                {brand && (
                  <span className="text-sm font-medium text-[#72C2FF] bg-[#E8F4FD] px-2.5 py-1 rounded-full">
                    {brand}
                  </span>
                )}
                <span className="text-sm font-medium text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
                  {source.category}
                </span>
                {status === "ended" && (
                  <span className="text-sm font-medium text-white bg-gray-400 px-2.5 py-1 rounded-full">
                    마감
                  </span>
                )}
              </div>
              <h1 className="text-xl font-bold text-gray-900 mb-4">
                {titleRest}
              </h1>

              {/* 본문 */}
              <p className="text-gray-700 leading-relaxed mb-5">
                {source.desc || "간단한 참여로 포인트를 적립받으세요!"}
              </p>

              {/* 액션바 */}
              <div className="flex items-center justify-between py-4 border-y border-gray-100">
                <div className="flex items-center gap-4">
                  <LikeDislikeButton
                    likes={source.likes || 0}
                    isLiked={isLiked}
                    isDisliked={isDisliked}
                    onLike={() => {
                      setIsLiked(!isLiked);
                      if (isDisliked) setIsDisliked(false);
                    }}
                    onDislike={() => {
                      setIsDisliked(!isDisliked);
                      if (isLiked) setIsLiked(false);
                    }}
                    size="md"
                  />
                  <span className="flex items-center gap-1.5 text-gray-500">
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      />
                    </svg>
                    <span className="text-sm">{countComments(comments)}</span>
                  </span>
                  <span className="flex items-center gap-1.5 text-gray-500">
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                      />
                    </svg>
                    <span className="text-sm">{source.views || 0}</span>
                  </span>
                  <button
                    onClick={() => setShowGift(true)}
                    className="text-gray-500 hover:text-amber-500 transition-colors"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
                      />
                    </svg>
                  </button>
                </div>
                {/* 더보기 메뉴 */}
                <DropdownMenu
                  items={[
                    {
                      icon: "share",
                      label: "공유",
                      onClick: () => {
                        navigator.clipboard.writeText(window.location.href);
                        showToast("링크를 복사했어요", { type: "link" });
                      },
                    },
                    {
                      icon: "hide",
                      label: status === "ended" ? "마감 취소" : "마감 처리",
                      onClick: () => {
                        if (status === "ended") {
                          setStatus("active");
                          showToast("마감이 취소되었습니다");
                        } else {
                          setStatus("ended");
                          showToast("마감 처리되었습니다");
                        }
                      },
                    },
                    {
                      icon: "block",
                      label: "차단",
                      onClick: () => {
                        setShowBlockPopup(true);
                      },
                    },
                    {
                      icon: "report",
                      label: "신고",
                      onClick: () => {
                        setShowReportPopup(true);
                      },
                    },
                  ]}
                  size="lg"
                />
              </div>
            </div>
          </div>

          {/* 모바일 참여 버튼 */}
          <div className="lg:hidden">
            <button
              onClick={() => window.open("#", "_blank")}
              className={`w-full py-4 rounded-xl font-bold transition-colors text-lg ${
                status === "ended"
                  ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                  : "bg-amber-400 text-white hover:bg-amber-500"
              }`}
              disabled={status === "ended"}
            >
              {status === "ended" ? "마감됨" : "참여하기"}
            </button>
          </div>

          {/* 댓글 섹션 - CommentSection 재사용 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 animate-fadeUp delay-1">
            <h3 className="text-base font-bold text-gray-900 mb-2">
              댓글{" "}
              <span className="text-[#72C2FF]">{countComments(comments)}</span>
            </h3>
            <CommentSection
              postId={postId}
              comments={comments}
              commentInput={commentInput}
              replyingTo={replyingTo}
              replyInputs={replyInputs}
              likedComments={likedComments}
              dislikedComments={dislikedComments}
              followedUsers={followedUsers}
              highlightedComment={highlightedComment}
              commentRefs={commentRefs}
              onCommentInputChange={handleCommentInputChange}
              onSubmitComment={handleSubmitComment}
              onCommentLike={handleCommentLike}
              onCommentDislike={handleCommentDislike}
              onCommentGift={handleCommentGift}
              onFollow={handleFollow}
              onStartReply={handleStartReply}
              onCancelReply={handleCancelReply}
              onReplyInputChange={handleReplyInputChange}
              onSubmitReply={handleSubmitReply}
              onScrollToComment={handleScrollToComment}
            />
          </div>
        </div>

        {/* 사이드바 (데스크탑) */}
        <div className="hidden lg:block">
          <div className="sticky top-[80px]">
            <Sidebar source={source} brand={brand} status={status} />
          </div>
        </div>
      </div>

      {/* 후원 팝업 */}
      {showGift && <GiftPopup onClose={() => setShowGift(false)} />}

      {/* 차단 팝업 */}
      {showBlockPopup && (
        <ConfirmPopup
          title="이 작성자를 차단할까요?"
          description="차단하면 이 작성자의 글과 댓글이 더 이상 보이지 않아요."
          confirmText="차단"
          cancelText="취소"
          isDestructive
          onConfirm={() => {
            setShowBlockPopup(false);
            showToast("앱테크마스터님을 차단했어요", { type: "block" });
          }}
          onCancel={() => setShowBlockPopup(false)}
        />
      )}

      {/* 신고 팝업 */}
      {showReportPopup && (
        <ReportPopup
          targetType="글"
          onReport={(reason) => {
            setShowReportPopup(false);
            showToast("신고가 접수되었습니다");
          }}
          onCancel={() => setShowReportPopup(false)}
        />
      )}
    </div>
  );
}

// ─── Wrapper (ToastProvider) ───
export default function PointDetailPage() {
  return (
    <ToastProvider>
      <PointDetailContent />
    </ToastProvider>
  );
}
