// @ts-nocheck
import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { marketItems as marketItemsData } from "../../components/lifetech/data";

// ─── 채팅 모달 ───
function ChatModal({
  partner,
  onClose,
}: {
  partner: string;
  onClose: () => void;
}) {
  const [messages, setMessages] = useState([
    {
      id: 1,
      from: "partner",
      text: "안녕하세요! 문의 주셨나요?",
      time: "14:30",
    },
  ]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages([
      ...messages,
      { id: Date.now(), from: "me", text: input, time: "방금" },
    ]);
    setInput("");
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-full max-w-md h-[500px] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900">{partner}님과의 대화</h3>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.from === "me" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[70%] px-4 py-2.5 rounded-2xl text-sm ${msg.from === "me" ? "bg-[#72C2FF] text-white" : "bg-white text-gray-900 border border-gray-100"}`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t border-gray-100">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              placeholder="메시지를 입력하세요..."
              className="flex-1 px-4 py-2.5 bg-gray-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#72C2FF]"
            />
            <button
              onClick={sendMessage}
              className="px-4 py-2.5 bg-[#72C2FF] text-white rounded-xl font-medium"
            >
              전송
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── 구매 모달 ───
function PurchaseModal({ product, onClose, onComplete }: any) {
  const [step, setStep] = useState(1);
  const fee = 0;
  const totalPrice = product.price + fee;
  const originalPrice = Math.round(product.price * 1.11);
  const discountRate = Math.round((1 - product.price / originalPrice) * 100);

  return (
    <div
      className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900">
            {step === 1 ? "안전결제" : step === 2 ? "거래중" : "거래완료"}
          </h3>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {step === 1 && (
          <div className="p-5">
            {/* 상품 정보 */}
            <div className="flex items-center gap-4 pb-5 border-b border-gray-100">
              <div className="w-16 h-16 bg-amber-50 rounded-xl flex items-center justify-center text-3xl">
                ☕
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">{product.brand}</p>
                <p className="font-bold text-gray-900">{product.name}</p>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-lg font-bold text-gray-900">
                    {product.price.toLocaleString()}원
                  </span>
                  <span className="text-sm text-red-500 font-medium">
                    {discountRate}% 할인
                  </span>
                </div>
              </div>
            </div>

            {/* 결제 금액 */}
            <div className="py-5 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">상품가격</span>
                <span className="text-gray-900">
                  {product.price.toLocaleString()}원
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">수수료</span>
                <span className="text-[#72C2FF]">무료 (판매자 부담)</span>
              </div>
              <div className="flex justify-between pt-3 border-t border-gray-100">
                <span className="font-bold text-gray-900">결제 금액</span>
                <span className="font-bold text-gray-900 text-lg">
                  {totalPrice.toLocaleString()}원
                </span>
              </div>
            </div>

            {/* 안전결제 안내 */}
            <div className="bg-red-50 rounded-xl p-4 mb-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-red-500">🛡️</span>
                <span className="font-bold text-gray-900">
                  안전결제로 거래됩니다
                </span>
              </div>
              <ul className="text-sm text-gray-600 space-y-1 ml-6">
                <li>결제금은 쌀먹닷컴이 안전하게 보관합니다</li>
                <li>쿠폰 확인 후 구매확정하면 판매자에게 정산됩니다</li>
                <li>문제 발생 시 3일 내 분쟁 신청 가능</li>
              </ul>
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full py-4 bg-[#72C2FF] text-white rounded-xl font-bold hover:bg-[#5BA8E6] transition-colors"
            >
              {totalPrice.toLocaleString()}원 안전결제
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="p-5">
            {/* 거래중 배너 */}
            <div className="bg-amber-400 rounded-xl text-center py-4 mb-5">
              <p className="text-xl font-bold text-white">거래중</p>
              <p className="text-amber-100 text-sm">
                ⏰ 2일 23시간 후 자동확정
              </p>
            </div>

            {/* 바코드 카드 */}
            <div className="bg-amber-50 rounded-2xl p-5 border border-amber-200 mb-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-2xl">
                  ☕
                </div>
                <div>
                  <p className="text-sm text-gray-500">{product.brand}</p>
                  <p className="font-bold text-gray-900">{product.name}</p>
                </div>
              </div>
              <p className="text-center text-emerald-600 font-medium mb-3">
                🏷️ 쿠폰 바코드
              </p>
              <div className="bg-white rounded-xl p-4 text-center">
                <div
                  className="h-12 bg-gradient-to-r from-gray-800 via-gray-300 to-gray-800 mb-2"
                  style={{
                    backgroundSize: "4px 100%",
                    backgroundImage:
                      "repeating-linear-gradient(90deg, #1f2937 0px, #1f2937 2px, transparent 2px, transparent 4px)",
                  }}
                />
                <p className="text-sm text-gray-500 font-mono">
                  1234 5678 9012 3456
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(3)}
                className="flex-1 py-3 bg-[#72C2FF] text-white rounded-xl font-bold"
              >
                구매확정
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-bold"
              >
                분쟁신청
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="p-5 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                className="w-10 h-10 text-green-500"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <h4 className="text-xl font-bold text-gray-900 mb-2">거래 완료!</h4>
            <p className="text-gray-500 mb-6">구매가 확정되었습니다.</p>
            <button
              onClick={onClose}
              className="w-full py-3 bg-[#72C2FF] text-white rounded-xl font-bold"
            >
              확인
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── 사이드바 ───
function Sidebar({ product, onPurchase, onChat }: any) {
  const relatedItems = marketItemsData
    .filter((p) => p.id !== product.id && p.brand === product.brand)
    .slice(0, 4);
  const originalPrice = Math.round(product.price * 1.11);
  const discountRate = Math.round((1 - product.price / originalPrice) * 100);

  return (
    <div className="flex flex-col gap-5">
      {/* 가격 & 구매 카드 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
        <div className="p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-amber-50 rounded-xl flex items-center justify-center text-3xl">
              ☕
            </div>
            <div>
              <p className="text-sm text-gray-500">{product.brand}</p>
              <p className="font-bold text-gray-900">{product.name}</p>
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-2xl font-bold text-gray-900">
              {product.price.toLocaleString()}원
            </span>
            <span className="text-sm text-red-500 font-medium">
              {discountRate}%
            </span>
          </div>
          <p className="text-sm text-gray-400 line-through mb-4">
            정가 {originalPrice.toLocaleString()}원
          </p>
          <button
            onClick={onPurchase}
            className="w-full py-3.5 bg-[#72C2FF] text-white rounded-xl font-bold hover:bg-[#5BA8E6] transition-colors mb-2"
          >
            안전결제로 구매
          </button>
          <button
            onClick={onChat}
            className="w-full py-2.5 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
          >
            판매자에게 문의
          </button>
        </div>
      </div>

      {/* 판매자 정보 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp delay-1">
        <div className="px-4 py-3 text-sm font-bold text-gray-900 border-b border-gray-100">
          👤 판매자 정보
        </div>
        <div className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center text-white text-sm">
              🦎
            </div>
            <div>
              <p className="font-medium text-gray-900">{product.seller}</p>
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <span className="text-amber-400">★</span> {product.rating} ·
                거래 47회
              </div>
            </div>
          </div>
          <div className="text-xs text-gray-500 space-y-1">
            <p>최근 응답 평균 10분</p>
            <p>가입일 2024.03.15</p>
          </div>
        </div>
      </div>

      {/* 같은 브랜드 상품 */}
      {relatedItems.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp delay-2">
          <div className="px-4 py-3 text-sm font-bold text-gray-900 border-b border-gray-100">
            🏷️ {product.brand} 다른 상품
          </div>
          <div className="divide-y divide-gray-50">
            {relatedItems.map((item) => (
              <Link
                key={item.id}
                to={`/lifetech/market/${item.id}`}
                className="block p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-50 rounded-lg flex items-center justify-center text-xl">
                    ☕
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900 font-medium truncate">
                      {item.name}
                    </p>
                    <p className="text-sm text-[#72C2FF] font-bold">
                      {item.price.toLocaleString()}원
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function MarketDetailPage_v3() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showChat, setShowChat] = useState(false);
  const [showPurchase, setShowPurchase] = useState(false);

  const product = marketItemsData.find((p) => p.id === Number(id));

  useEffect(() => {
    if (!product) navigate("/lifetech");
  }, [product, navigate]);

  if (!product) return null;

  const originalPrice = Math.round(product.price * 1.11);
  const discountRate = Math.round((1 - product.price / originalPrice) * 100);

  return (
    <div className="max-w-[1280px] mx-auto px-6 py-8">
      {/* 브레드크럼 */}
      <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6 animate-fadeUp">
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          생활테크
        </Link>
        <span>›</span>
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          장터
        </Link>
        <span>›</span>
        <span className="text-gray-600 truncate max-w-[200px]">
          {product.name}
        </span>
      </nav>

      {/* 2컬럼 레이아웃 */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        {/* 메인 콘텐츠 */}
        <div className="space-y-6">
          {/* 상품 카드 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
            {/* 상품 이미지 */}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-8 flex flex-col items-center">
              <div className="w-32 h-32 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-4">
                <span className="text-6xl">☕</span>
              </div>
              <div className="bg-gray-100 rounded-xl px-6 py-3 text-center">
                <p className="text-gray-500 text-sm">
                  바코드는 결제 후 공개됩니다
                </p>
              </div>
            </div>

            {/* 상품 정보 */}
            <div className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm font-medium text-[#72C2FF] bg-[#E8F4FD] px-2.5 py-1 rounded-full">
                  {product.brand}
                </span>
                {product.dday <= 7 && (
                  <span className="text-sm font-medium text-red-500 bg-red-50 px-2.5 py-1 rounded-full">
                    D-{product.dday}
                  </span>
                )}
              </div>
              <h1 className="text-xl font-bold text-gray-900 mb-3">
                {product.name}
              </h1>
              <div className="flex items-baseline gap-3 mb-1">
                <span className="text-2xl font-bold text-gray-900">
                  {product.price.toLocaleString()}원
                </span>
                <span className="text-lg text-red-500 font-medium">
                  {discountRate}% 할인
                </span>
              </div>
              <p className="text-gray-400 line-through">
                정가 {originalPrice.toLocaleString()}원
              </p>
            </div>
          </div>

          {/* 상품 정보 테이블 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp delay-1">
            <table className="w-full text-sm">
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 w-32 font-medium">
                    유효기간
                  </td>
                  <td className="px-5 py-4 text-red-500 font-medium">
                    {product.validUntil || "2025-03-15"} (D-{product.dday})
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    판매자
                  </td>
                  <td className="px-5 py-4 text-gray-900 flex items-center gap-2">
                    {product.seller}
                    <span className="text-xs text-amber-500">
                      ★ {product.rating}
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    거래방식
                  </td>
                  <td className="px-5 py-4 text-[#72C2FF] font-medium flex items-center gap-1">
                    <span className="text-red-500">🛡️</span> 안전결제 (에스크로)
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-4 bg-gray-50 text-gray-500 font-medium">
                    등록일
                  </td>
                  <td className="px-5 py-4 text-gray-900">
                    {product.createdAt || "2025.01.10"}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* 안전결제 안내 */}
          <div className="bg-red-50 rounded-xl p-5 border border-red-100 animate-fadeUp delay-2">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-red-500 text-xl">🛡️</span>
              <span className="font-bold text-gray-900">
                안전결제로 거래됩니다
              </span>
            </div>
            <ul className="text-sm text-gray-600 space-y-2 ml-7">
              <li>결제금은 쌀먹닷컴이 안전하게 보관합니다</li>
              <li>쿠폰 확인 후 구매확정하면 판매자에게 정산됩니다</li>
              <li>문제 발생 시 3일 내 분쟁 신청 가능</li>
              <li>3일 후 자동으로 구매확정 처리됩니다</li>
            </ul>
          </div>

          {/* 모바일 구매 버튼 */}
          <div className="lg:hidden">
            <button
              onClick={() => setShowPurchase(true)}
              className="w-full py-4 bg-[#72C2FF] text-white rounded-xl font-bold hover:bg-[#5BA8E6] transition-colors text-lg"
            >
              {product.price.toLocaleString()}원 안전결제
            </button>
          </div>
        </div>

        {/* 사이드바 (데스크탑) */}
        <div className="hidden lg:block">
          <div className="sticky top-[80px]">
            <Sidebar
              product={product}
              onPurchase={() => setShowPurchase(true)}
              onChat={() => setShowChat(true)}
            />
          </div>
        </div>
      </div>

      {/* 채팅 모달 */}
      {showChat && (
        <ChatModal
          partner={product.seller}
          onClose={() => setShowChat(false)}
        />
      )}

      {/* 구매 모달 */}
      {showPurchase && (
        <PurchaseModal
          product={product}
          onClose={() => setShowPurchase(false)}
        />
      )}
    </div>
  );
}
