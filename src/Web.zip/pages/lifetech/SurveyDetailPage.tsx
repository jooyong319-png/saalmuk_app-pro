// @ts-nocheck
import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { surveys as surveysData } from "../../components/lifetech/data";

// ─── 사이드바 ───
function Sidebar({ survey, progress, currentQuestion, totalQuestions }: any) {
  const relatedSurveys = surveysData
    .filter((s) => s.id !== survey.id)
    .slice(0, 4);

  return (
    <div className="flex flex-col gap-5">
      {/* 진행 상황 카드 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 animate-fadeUp">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-gray-500">진행률</span>
          <span className="text-sm font-bold text-[#72C2FF]">
            {Math.round(progress)}%
          </span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full mb-4">
          <div
            className="h-full bg-[#72C2FF] rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">질문</span>
          <span className="font-medium text-gray-900">
            {currentQuestion + 1} / {totalQuestions}
          </span>
        </div>
      </div>

      {/* 리워드 정보 */}
      <div className="bg-gradient-to-br from-amber-400 to-orange-400 rounded-xl p-5 animate-fadeUp delay-1">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl">
            🎁
          </div>
          <div className="text-white">
            <p className="text-sm opacity-80">완료 보상</p>
            <p className="text-2xl font-bold">{survey.reward}P</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm text-white/80">
          <span>⏱️ {survey.duration}</span>
          <span>·</span>
          <span>
            👥 {survey.participants}/{survey.maxParticipants}명
          </span>
        </div>
      </div>

      {/* 다른 설문 */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp delay-2">
        <div className="px-4 py-3 text-sm font-bold text-gray-900 border-b border-gray-100">
          📋 다른 설문조사
        </div>
        <div className="divide-y divide-gray-50">
          {relatedSurveys.map((s) => (
            <Link
              key={s.id}
              to={`/lifetech/survey/${s.id}`}
              className="block p-4 hover:bg-gray-50 transition-colors"
            >
              <p className="text-sm text-gray-900 font-medium truncate mb-1">
                {s.title}
              </p>
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <span className="text-[#72C2FF] font-medium">{s.reward}P</span>
                <span>·</span>
                <span>{s.duration}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function SurveyDetailPage_v3() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, any>>({});
  const [isCompleted, setIsCompleted] = useState(false);

  const survey = surveysData.find((s) => s.id === Number(id));

  useEffect(() => {
    if (!survey) {
      navigate("/lifetech");
    }
  }, [survey, navigate]);

  if (!survey) return null;

  const questions = survey.questions || [];
  const progress =
    questions.length > 0 ? ((currentQuestion + 1) / questions.length) * 100 : 0;

  const handleAnswer = (value: any) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion]: value }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const handlePrev = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-6 py-8">
      {/* 브레드크럼 */}
      <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6 animate-fadeUp">
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          생활테크
        </Link>
        <span>›</span>
        <Link to="/lifetech" className="hover:text-[#72C2FF]">
          설문조사
        </Link>
        <span>›</span>
        <span className="text-gray-600 truncate max-w-[200px]">
          {survey.title}
        </span>
      </nav>

      {/* 2컬럼 레이아웃 */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        {/* 메인 콘텐츠 */}
        <div className="space-y-6">
          {!isCompleted ? (
            <>
              {/* 설문 헤더 카드 */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fadeUp">
                {/* 작성자 정보 */}
                <div className="p-5 border-b border-gray-100">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 bg-gradient-to-br from-emerald-400 to-teal-400 rounded-full flex items-center justify-center">
                        <span className="text-white text-lg">📊</span>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">
                          {survey.host || "쌀먹 리서치"}
                        </p>
                        <p className="text-xs text-gray-500">
                          3시간 전 · 설문 32개 진행
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-[#72C2FF] font-bold">
                        {survey.reward}P
                      </span>
                      <span className="text-gray-300">|</span>
                      <span className="text-gray-500">{survey.duration}</span>
                    </div>
                  </div>
                </div>

                {/* 설문 정보 */}
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    {survey.tags?.map((tag: string, i: number) => (
                      <span
                        key={i}
                        className="text-xs text-[#72C2FF] bg-[#E8F4FD] px-2.5 py-1 rounded-full"
                      >
                        #{tag}
                      </span>
                    ))}
                    {survey.isHot && (
                      <span className="text-xs bg-red-100 text-red-600 px-2.5 py-1 rounded-full font-medium">
                        🔥 HOT
                      </span>
                    )}
                    {survey.isPremium && (
                      <span className="text-xs bg-amber-100 text-amber-600 px-2.5 py-1 rounded-full font-medium">
                        ⭐ 프리미엄
                      </span>
                    )}
                  </div>
                  <h1 className="text-xl font-bold text-gray-900 mb-3">
                    {survey.title}
                  </h1>
                  <p className="text-gray-600 leading-relaxed mb-4">
                    {survey.description ||
                      "본 설문조사에 참여해주시면 소정의 리워드를 드립니다. 응답 내용은 통계 목적으로만 활용됩니다."}
                  </p>

                  {/* 참여 현황 */}
                  <div className="flex items-center gap-4 py-4 border-y border-gray-100">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                      <span>{survey.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                        />
                      </svg>
                      <span>
                        {survey.participants}/{survey.maxParticipants}명 참여
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                        />
                      </svg>
                      <span>{questions.length}문항</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 질문 카드 */}
              {questions.length > 0 && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fadeUp delay-1">
                  {/* 모바일 진행바 */}
                  <div className="lg:hidden mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-500">진행률</span>
                      <span className="text-sm font-bold text-[#72C2FF]">
                        {Math.round(progress)}%
                      </span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div
                        className="h-full bg-[#72C2FF] rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  {/* 질문 번호 */}
                  <div className="flex items-center gap-3 mb-4">
                    <span className="w-8 h-8 bg-[#72C2FF] text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {currentQuestion + 1}
                    </span>
                    <span className="text-sm text-gray-400">
                      / {questions.length}
                    </span>
                  </div>

                  {/* 질문 내용 */}
                  <h3 className="text-lg font-bold text-gray-900 mb-6">
                    {questions[currentQuestion]?.question}
                  </h3>

                  {/* 답변 옵션 */}
                  <div className="space-y-3 mb-8">
                    {/* 단일선택 */}
                    {questions[currentQuestion]?.type === "single" &&
                      questions[currentQuestion]?.options?.map(
                        (option: string, i: number) => (
                          <button
                            key={i}
                            onClick={() => handleAnswer(option)}
                            className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                              answers[currentQuestion] === option
                                ? "border-[#72C2FF] bg-[#E8F4FD] text-[#72C2FF]"
                                : "border-gray-200 hover:border-gray-300 text-gray-700"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div
                                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                                  answers[currentQuestion] === option
                                    ? "border-[#72C2FF]"
                                    : "border-gray-300"
                                }`}
                              >
                                {answers[currentQuestion] === option && (
                                  <div className="w-3 h-3 bg-[#72C2FF] rounded-full" />
                                )}
                              </div>
                              <span className="font-medium">{option}</span>
                            </div>
                          </button>
                        ),
                      )}

                    {/* 복수선택 */}
                    {questions[currentQuestion]?.type === "multi" &&
                      questions[currentQuestion]?.options?.map(
                        (option: string, i: number) => {
                          const selected: string[] = answers[currentQuestion] ?? [];
                          const isChecked = selected.includes(option);
                          return (
                            <button
                              key={i}
                              onClick={() => {
                                const next = isChecked
                                  ? selected.filter((x) => x !== option)
                                  : [...selected, option];
                                handleAnswer(next.length > 0 ? next : undefined);
                              }}
                              className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                                isChecked
                                  ? "border-[#72C2FF] bg-[#E8F4FD] text-[#72C2FF]"
                                  : "border-gray-200 hover:border-gray-300 text-gray-700"
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div
                                  className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
                                    isChecked ? "border-[#72C2FF] bg-[#72C2FF]" : "border-gray-300"
                                  }`}
                                >
                                  {isChecked && (
                                    <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                  )}
                                </div>
                                <span className="font-medium">{option}</span>
                              </div>
                            </button>
                          );
                        },
                      )}

                    {/* 척도 */}
                    {questions[currentQuestion]?.type === "scale" && (() => {
                      const q = questions[currentQuestion];
                      const steps = Array.from({ length: q.max - q.min + 1 }, (_, i) => i + q.min);
                      return (
                        <div>
                          <div className="flex justify-between text-xs text-gray-400 mb-3 px-1">
                            <span>전혀 아니다</span>
                            <span>매우 그렇다</span>
                          </div>
                          <div className="flex gap-2">
                            {steps.map((v) => (
                              <button
                                key={v}
                                onClick={() => handleAnswer(v)}
                                className={`flex-1 py-4 rounded-xl border-2 text-base font-bold transition-all ${
                                  answers[currentQuestion] === v
                                    ? "border-[#72C2FF] bg-[#72C2FF] text-white"
                                    : "border-gray-200 hover:border-[#72C2FF] text-gray-600"
                                }`}
                              >
                                {v}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })()}

                    {/* 주관식 */}
                    {questions[currentQuestion]?.type === "text" && (
                      <textarea
                        value={answers[currentQuestion] ?? ""}
                        onChange={(e) =>
                          handleAnswer(e.target.value || undefined)
                        }
                        placeholder="자유롭게 의견을 입력해주세요..."
                        rows={5}
                        className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-[#72C2FF] outline-none text-gray-700 resize-none transition-colors placeholder-gray-300 text-[14px]"
                      />
                    )}
                  </div>

                  {/* 네비게이션 버튼 */}
                  <div className="flex gap-3">
                    {currentQuestion > 0 && (
                      <button
                        onClick={handlePrev}
                        className="flex-1 py-3.5 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                      >
                        이전
                      </button>
                    )}
                    <button
                      onClick={handleNext}
                      disabled={
                        answers[currentQuestion] === undefined ||
                        (Array.isArray(answers[currentQuestion]) && answers[currentQuestion].length === 0)
                      }
                      className={`flex-1 py-3.5 rounded-xl font-bold transition-colors ${
                        answers[currentQuestion] !== undefined &&
                        !(Array.isArray(answers[currentQuestion]) && answers[currentQuestion].length === 0)
                          ? "bg-[#72C2FF] text-white hover:bg-[#5BA8E6]"
                          : "bg-gray-200 text-gray-400 cursor-not-allowed"
                      }`}
                    >
                      {currentQuestion === questions.length - 1
                        ? "제출하기"
                        : "다음"}
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : (
            /* 완료 화면 */
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center animate-fadeUp">
              <div className="w-24 h-24 bg-gradient-to-br from-[#72C2FF]/20 to-[#4A9FD9]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-5xl">🎉</span>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                설문 완료!
              </h2>
              <p className="text-gray-500 mb-6">소중한 의견 감사합니다.</p>

              {/* 적립 포인트 */}
              <div className="inline-flex items-center gap-3 bg-gradient-to-r from-amber-400 to-orange-400 text-white px-8 py-4 rounded-2xl mb-8">
                <span className="text-3xl">🎁</span>
                <div className="text-left">
                  <p className="text-sm opacity-80">적립 완료</p>
                  <p className="text-2xl font-bold">{survey.reward}P</p>
                </div>
              </div>

              <div className="flex gap-3">
                <Link
                  to="/lifetech"
                  className="flex-1 py-3.5 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
                >
                  목록으로
                </Link>
                <button
                  onClick={() => {
                    setCurrentQuestion(0);
                    setAnswers({});
                    setIsCompleted(false);
                  }}
                  className="flex-1 py-3.5 bg-[#72C2FF] text-white rounded-xl font-bold hover:bg-[#5BA8E6] transition-colors"
                >
                  다른 설문 참여
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 사이드바 (데스크탑) */}
        <div className="hidden lg:block">
          <div className="sticky top-[80px]">
            <Sidebar
              survey={survey}
              progress={progress}
              currentQuestion={currentQuestion}
              totalQuestions={questions.length}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
